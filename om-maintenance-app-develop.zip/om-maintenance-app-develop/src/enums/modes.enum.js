export default [
  {
    key: 'mode',
    value: 'IML',
    text: 'IML',
    label: 'Mode'
  },
  {
    key: 'mode',
    value: 'RLC',
    text: 'RLC',
    label: 'Mode'
  },
  {
    key: 'mode',
    value: 'TL',
    text: 'TL',
    label: 'Mode'
  },
  {
    key: 'mode',
    value: 'DED',
    text: 'DED',
    label: 'Mode'
  },
  {
    key: 'mode',
    value: 'HRT',
    text: 'HRT',
    label: 'Mode'
  },
  {
    key: 'mode',
    value: 'DDR',
    text: 'DDR',
    label: 'Mode'
  },
  {
    key: 'mode',
    value: 'ODR',
    text: 'ODR',
    label: 'Mode'
  }
];
