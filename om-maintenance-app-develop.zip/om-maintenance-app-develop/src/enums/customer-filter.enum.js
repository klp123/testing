export default {
  status: {
    statuses: [{
      key: 'status',
      value: 'Active',
      query: ['A'],
      text: 'Active',
      label: 'Status',
      single: true,
    },
    {
      key: 'status',
      value: 'Prospect',
      query: ['P', 'R'],
      text: 'Prospect',
      label: 'Status',
      single: true,
    },
    {
      key: 'status',
      value: 'Inactive',
      query: ['D', 'I', 'X'],
      text: 'Inactive',
      label: 'Status',
      single: true,
    }],
    key: 'status',
    filterLabel: 'Status',
  },
  team: {
    teams: [],
    key: 'team',
    filterLabel: 'Team',
  },
  quickSearch: {
    disabled: false,
    selectedSearchType: '',
    types: [{
      label: 'Syscon',
      value: 'syscon',
    },
    {
      label: 'ERP CustomerID',
      value: 'erpCustomerID',
    },
    {
      label: 'Customer Name',
      value: 'name',
    },
    ],
  },
  sort: {
    field: 'name',
    direction: 1
  }
};
