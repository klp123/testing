export default [
  { country: 'CAN', label: 'Canada' },
  { country: 'MEX', label: 'Mexico' },
  { country: 'USA', label: 'USA' },
];

export const countryList = ['CAN', 'MEX', 'USA'];
