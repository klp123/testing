export default [
  {
    value: '*ALL',
    label: '*ALL'
  },
  {
    value: 'IML',
    label: 'IML',
  },
  {
    value: 'TL',
    label: 'TL'
  },
];
