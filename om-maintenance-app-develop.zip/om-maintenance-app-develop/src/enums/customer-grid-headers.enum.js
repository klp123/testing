export default [{
  text: 'NAME',
  value: 'name',
},
{
  text: 'SYSCON',
  value: '_id',
  sortable: false,
},
{
  text: 'ERP ID',
  value: 'id',
  sortable: false,
},
{
  text: 'TEAM',
  value: 'assignedTeam',
  sortable: false,
},
{
  text: 'STATUS',
  value: 'status',
  sortable: false,
}];
