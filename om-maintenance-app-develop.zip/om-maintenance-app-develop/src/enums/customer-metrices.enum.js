export default {
  stats: [{
    label: 'Active',
    text: 'Active',
    tooltip: '-',
    displayValue: '-',
    displayShortValue: '',
    key: 'active',
    value: 'Active',
    query: ['A'],
  },
  {
    label: 'Prospect',
    text: 'Prospect',
    tooltip: '-',
    displayValue: '-',
    displayShortValue: '',
    key: 'prospect',
    value: 'Prospect',
    query: ['P', 'R'],
  },
  {
    label: 'Inactive',
    text: 'Inactive',
    tooltip: '-',
    displayValue: '-',
    displayShortValue: '',
    key: 'inactive',
    value: 'Inactive',
    query: ['D', 'I', 'X'],
  }
  ],
};
