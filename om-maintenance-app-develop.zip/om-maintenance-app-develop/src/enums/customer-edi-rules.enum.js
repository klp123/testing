export default {
  timeSlots: [
    {
      label: 'Immediate',
      value: 0
    },
    {
      label: '15m',
      value: 15
    },
    {
      label: '30m',
      value: 30
    },
    {
      label: '1h',
      value: 60
    },
    {
      label: '90m',
      value: 90
    },
    {
      label: '2h',
      value: 120
    },
    {
      label: '4h',
      value: 240
    },
  ],
  tenderStatus: [
    {
      label: 'Auto Accept',
      value: 'auto-accept'
    },
    {
      label: 'Auto Reject',
      value: 'auto-reject'
    },
    {
      label: 'Remain-open',
      value: 'remain-open'
    }
  ],
  autoAccept: [
    {
      label: 'Quantity',
      value: 'quantity'
    },
    {
      label: 'Weight',
      value: 'weight'
    },
    {
      label: 'Equipment Type',
      value: 'equipmentType'
    },
    {
      label: 'Reference #\'s',
      value: 'references'
    },
    {
      label: 'Remarks',
      value: 'remarks'
    },
    {
      label: 'Requested Pickup Date',
      value: 'requestedPickupDate'
    },
    {
      label: 'Equipment Id',
      value: 'equipmentId'
    },
    {
      label: 'Origin Location',
      value: 'originLocation'
    },
    {
      label: 'Destination Location',
      value: 'destinationLocation'
    }
  ],
  autoReject: [
    {
      label: 'Quantity',
      value: 'quantity'
    },
    {
      label: 'Weight',
      value: 'weight'
    },
    {
      label: 'Equipment Type',
      value: 'equipmentType'
    }
  ]
};
