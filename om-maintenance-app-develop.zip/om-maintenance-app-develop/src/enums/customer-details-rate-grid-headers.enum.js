export default {
  RATE_GRID_HEADER: [
    { text: '($) Rate Amount', value: 'rateValue' },
    { text: 'Rate Limit', value: 'rateLimit' }
  ],
  LOCATION_HEADER: [
    { text: 'Type', value: 'StopType', width: '5%' },
    { text: 'Specific Address', value: 'Address1', width: '57%' },
    { text: 'City', value: 'City', width: '23%' },
    { text: 'State', value: 'State', width: '5%' },
    { text: 'Zipcode', value: 'PostalCode', width: '5%' },
    { text: 'Country', value: 'CountryCode', width: '5%' }
  ]
};
