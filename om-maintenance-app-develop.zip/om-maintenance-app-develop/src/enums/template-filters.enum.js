module.exports = {
  TEMPLATE_STATUS: [
    {
      name: 'TEMPLATE_STATUS',
      value: 'ACTIVE',
    },
    {
      name: 'TEMPLATE_STATUS',
      value: 'INACTIVE',
    },
  ],
  TEMPLATE_TYPES: [
    {
      name: 'TEMPLATE_TYPES',
      value: 'ELECTRONIC',
    },
    {
      name: 'TEMPLATE_TYPES',
      value: 'STANDARD'
    }
    // {
    //   name: 'TEMPLATE_TYPES',
    //   value: 'INTERNATIONAL/CROSS BORDER',
    // },
  ],
};
