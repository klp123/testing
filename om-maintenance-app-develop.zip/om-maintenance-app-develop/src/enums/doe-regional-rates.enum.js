// module.exports = {

//   ROCKY_MOUNTAIN: 'Rocky Mountain(PADD4)',
//   WEST_COAST: 'West Coast(PADD5)',
//   WEST_COAST_LESS_CALIFORNIA: 'West Coast Less California',
//   CALIFORNIA: 'California'
// };

module.exports = [
  {
    regionName: 'National',
    displayName: 'National',
  },
  {
    regionName: 'East Coast',
    displayName: 'East Coast(PADD1)',
    padding: true
  },
  {
    regionName: 'New England',
    displayName: 'New England(PADD1A)',
    padding: true
  },
  {
    regionName: 'Central Atlantic',
    displayName: 'Central Atlantic(PADD1B)',
    padding: true
  },
  {
    regionName: 'Lower Atlantic',
    displayName: 'Lower Atlantic(PADD1C)',
    padding: true
  },
  {
    regionName: 'Midwest',
    displayName: 'Midwest(PADD2)',
  },
  {
    regionName: 'Gulf Coast',
    displayName: 'Gulf Coast(PADD3)',
  },
  {
    regionName: 'Rocky Mountain',
    displayName: 'Rocky Mountain(PADD4)',
  },
  {
    regionName: 'West Coast',
    displayName: 'West Coast(PADD5)',
  },
  {
    regionName: 'West Coast less California',
    displayName: 'West Coast less California',
    padding: true
  },
  {
    regionName: 'California',
    displayName: 'California',
    padding: true
  }
];