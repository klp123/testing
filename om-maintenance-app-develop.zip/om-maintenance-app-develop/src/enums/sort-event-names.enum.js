export default {
  EVENT_BY: 'by',
  EVENT_DESC: 'desc',
};