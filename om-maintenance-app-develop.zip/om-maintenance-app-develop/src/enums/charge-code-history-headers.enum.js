export default {
  mainGrid: [
    {
      text: 'Status',
      value: 'status'
    },
    {
      text: 'Effective Date',
      value: 'effectiveDateTime.dateTime'
    },
    {
      text: 'Expired Date',
      value: 'expiredDateTime.dateTime'
    },
    {
      text: 'Modified Date',
      value: 'modifiedDateTime'
    },
    {
      text: 'Modified By',
      value: 'modifiedBy'
    },
    {
      text: 'Action',
      value: 'action'
    },
    {
      text: '',
      value: 'data-table-expand'
    }
  ],
  expandedGrid: [
    {
      text: 'Minimum Rate',
      value: 'minimumRate',
    },
    {
      text: 'Maximum Rate',
      value: 'maximumRate',
    },
    {
      text: 'Start Event',
      value: 'startEvent'
    },
    {
      text: 'End Event',
      value: 'endEvent'
    },
    {
      text: 'Holidays Free',
      value: 'holidaysFree'
    },
    {
      text: 'Free Time Type',
      value: 'freeTimeType'
    },
    {
      text: 'Free Days',
      value: 'freeDays'
    },
    {
      text: 'Free Time Cut Off',
      value: 'freeTimeCutOff'
    },
    {
      text: 'Reloads',
      value: 'reloads'
    },
    {
      text: 'Free Weekend Type',
      value: 'freeWeekendType'
    },
    {
      text: 'Special Terms',
      value: 'specialTerms'
    },
    {
      text: 'Layover Type',
      value: 'layoverType'
    },
    {
      text: 'Notes',
      value: 'notes'
    }
  ],
  rateTable: [
    {
      text: 'Rate Amount',
      value: 'rateValue'
    },
    {
      text: 'Rate Limit',
      value: 'rateLimit'
    }
  ]
};