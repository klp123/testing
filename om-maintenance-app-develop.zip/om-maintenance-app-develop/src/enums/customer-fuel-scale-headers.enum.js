export default [
  {
    text: 'PUBLISHED DATE',
    value: 'publishDateTime.dateTime',
    sortable: false
  },
  {
    text: 'MODE',
    value: 'transportMode',
    sortable: false
  },
  {
    text: 'EQUIP TYPE',
    value: 'equipment.equipmentType',
    sortable: false
  },
  {
    text: 'COUNTRY',
    value: 'country',
    sortable: false
  },
  {
    text: 'STATUS',
    value: 'status',
    sortable: false
  },
  {
    text: 'ACTIONS',
    value: 'actions',
    sortable: false
  }
];
