export default [
  { value: 'BOTH', label: 'both' },
  { value: 'ORIGIN', label: 'origin' },
  { value: 'DESTINATION', label: 'destination' },
];
