export default [{
  text: 'Status',
  value: 'status',
},
{
  text: 'Customer',
  value: 'customerId',
},
{
  text: 'Mode',
  value: 'mode'
},
{
  text: 'Charge Code/Description',
  value: 'mode'
},
{
  text: 'Equipment',
  value: 'equipment'
},
{
  text: 'C / HD',
  value: 'customerType'
},
{
  text: 'Hub Default Name',
  value: 'hubDefault'
},
{
  text: 'Rate Amount',
  value: 'rateValue'
},
{
  text: 'Rate Type',
  value: 'rateQualifier'
},
{
  text: 'Effective Date',
  value: 'effectiveDateTime'
},
{
  text: 'Expiration Date',
  value: 'expiredDateTime'
},
{
  text: 'Actions',
  value: 'actions'
},
];
