export default {
  APPOINTMENT_RULE_TYPES: [
    {
      value: 'P',
      text: 'Pickup',
      key: 'ruleType',
      label: 'Rule Type',
      single: true
    },
    {
      value: 'D',
      text: 'Delivery',
      key: 'ruleType',
      label: 'Rule Type',
      single: true
    }
  ],
  LOV_TYPES: {
    MODES: 'OM_MODES',
    SUB_MODES: 'OM_SUB_MODES',
    APPT_PICKUP_TRIGGER: 'APPT_PICKUP_TRIGGER',
    APPT_DELIVERY_TRIGGER: 'APPT_DELIVERY_TRIGGER',
    APPT_PICKUP_RULE_FROM: 'APPT_PICKUP_RULE_FROM',
    APPT_PICKUP_RULE_TO: 'APPT_PICKUP_RULE_TO',
    APPT_DELIVERY_RULE_FROM: 'APPT_DELIVERY_RULE_FROM',
    APPT_DELIVERY_RULE_TO: 'APPT_DELIVERY_RULE_TO',
    EQUIPMENT_TYPE: {
      IML_DDR_ODR: 'OC_IML_DDR_ODR_EQUIPMENT',
      RLC: 'OC_RLC_EQUIPMENT',
      DED_HRT: 'OC_DED_HRT_EQUIPMENT'
    }
  },
  RULE_TRIGGERS: {
    MANUAL_ORDER_ACCEPTED: 'MANORDCRT',
    ELECTRONIC_ORDER_ACCEPTED: 'INBOUND204',
    CLEVENT: 'CLEVENT',
    NTEVENT: 'NTEVENT',
    TAEVENT: 'TAEVENT'
  },
  RULE_OUTCOMES: {
    PC_DATETIME: 'PC_DATETIME',
    EDI_ACK_DATETIME: 'EDI_ACK_DATETIME',
    LATEST_SUGGESTED_DATETIME: 'LATEST_SUGGESTED_DATETIME',
    TA_DATETIME: 'TA_DATETIME',
    SDA_DATETIME: 'SDA_DATETIME',
    NOTIFY_DATETIME: 'NOTIFY_DATETIME',
    RAILCUTOFF_DATETIME: 'RAILCUTOFF_DATETIME',
    ACTUAL_FROM_DATETIME: 'ACTUAL_FROM_DATETIME',
    DOCK_CLOSING_DATETIME: 'DOCK_CLOSING_DATETIME',
    USERSPECIFIED_DATETIME: 'USERSPECIFIED_DATETIME',
    COMPLETE_LOADING_DATETIME: 'COMPLETE_LOADING_DATETIME'
  },
  RAIL_CUTOFF_MODES: ['ALL', 'IML', 'ODR'],
  PLUS_MINUS: [
    {
      label: '+',
      value: '+'
    },
    {
      label: '-',
      value: '-'
    }
  ],
  YES_NO: [
    {
      label: 'Yes',
      value: true
    },
    {
      label: 'No',
      value: false
    }
  ],
  WEEKDAYS: [
    {
      label: 'SUN'
    },
    {
      label: 'MON'
    },
    {
      label: 'TUES'
    },
    {
      label: 'WED'
    },
    {
      label: 'THUR'
    },
    {
      label: 'FRI'
    },
    {
      label: 'SAT'
    }
  ],
  VALIDATION_ERRORS: {
    MAX_APPT_PER_DAY: {
      SPECIFIC_LOCATION: 'Specific location Id is required for max appointments',
      INVALID_VALUE: 'Enter positive numeric value. Max 999.',
      CONFLICT: 'A rule already exists for max appointments for this location, please reference the existing rule before creating a new rule.'
    },
    APPT_HOURS: 'Enter numeric value. Max 72 hours',
    SPECIFIC_LOCATION_DOCK_CLOSING: 'Specific location Id is required for dock closing hour',
    DUPLICATE_LOCATIONS: 'Duplicate locations',
    SELECT_TIME_ERROR: 'Please specify a value for both HH and mm for time'
  },
  APPOINTMENT_RULE_STATUS: {
    ACTIVE: 'ACTIVE',
    INACTIVE: 'INACTIVE',
    DELETED: 'DELETED'
  },
  OUTCOME_TYPE: {
    FROM: 'FROM',
    TO: 'TO'
  },
  MODALS: {
    EDIT: {
      HEADER: 'Are you sure you want to leave unsaved changes?',
      BODY: 'You are about to naviagate away from editing this rule without saving changes, are you sure you want to leave?',
      CONFIRM_BUTTON_TEXT: 'Don’t Save Changes'
    },
    DELETE: {
      HEADER: 'Are you sure you want to delete this rule?',
      BODY: 'You are about to permanently delete this rule, are you sure you want to delete?',
      CONFIRM_BUTTON_TEXT: 'Delete'
    },
    DUPLICATE: {
      BODY: 'A rule already exists for this customer and details indicated. Please review the following rules: ',
      CONFIRM_BUTTON_TEXT: 'Continue Editing'
    },
    ACTIVATE_FUTURE_RULE: {
      HEADER: 'This rule has a future start date',
      BODY: 'Activating this rule will delete the rule start date, do you want to proceed? ',
      CONFIRM_BUTTON_TEXT: 'Activate rule'
    },
    CHANGE_CUSTOMER: {
      HEADER: 'Customer Change',
      BODY: 'The location data in the form will be reset if the customer is changed/removed. Do you want to proceed? ',
      CONFIRM_BUTTON_TEXT: 'Change Customer'
    },
  },
  PATTERNS: {
    ONLY_DIGITS: /^\d+$/,
    LOCATION_ID: /(L)\d+$/
  }
};
