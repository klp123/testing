import Vue from 'vue';
import VueRouter from 'vue-router';
import Location from '../pages/location/location.vue';
import Customer from '../pages/customer/customer.vue';
import Templates from '../pages/templates/templates.vue';
import Preferences from '../pages/preferences/preferences.vue';
import AppointmentRules from '../pages/appointment-rules/appointment-rules.vue';
import CustomerAccessorialFuel from '../pages/accessorial-fuel-schedules/accessorial-fuel-schedules.vue';

Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    name: 'Customer',
    component: Customer,
  },
  {
    path: '/maintenance/customer',
    name: 'Customer',
    component: Customer,
  },
  {
    path: '/maintenance/location',
    name: 'Location',
    component: Location,
  },
  {
    path: '/maintenance/templates',
    name: 'Templates',
    component: Templates,
  },
  {
    path: '/maintenance/preferences',
    name: 'Preferences',
    component: Preferences,
  },
  {
    path: '/maintenance/appointment-rules',
    name: 'Appointment Rules',
    component: AppointmentRules,
  },
  {
    path: '/maintenance/accessorial-fuel-schedules',
    name: 'CustomerAccessorialFuel',
    component: CustomerAccessorialFuel
  }
];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
});

export default router;
