/* eslint-disable no-return-assign */
<template>
  <div id="app" v-if="isEntitlementLoaded" data-app :dark="setTheme">
    <hg-notifications />
    <router-view />
  </div>
</template>
<script src="./App.js"></script>
<style lang="sass" src="./App.sass"></style>
