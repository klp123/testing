<template>
  <v-app class="app" data-app>
    <HgConfirmActionModal ref="confirm" />
    <div id="app-user-preferences">
      <div class="page-header">
        <hg-title title="My Preferences"></hg-title>
      </div>
      <div>
        <v-card class="mx-auto mt-10" max-width="800">
          <v-card-title class="card-title">My Workbench Queues </v-card-title>
          <v-divider
            :color="getColor('color_gray_border')"
            class="my-1"
          ></v-divider>
          <v-card-text>
            <v-row align="center">
              <v-col cols="12">
                <div class="pa-5 pb-4">
                  <p class="card-text p-0">
                    Use this section to both adjust active assignments and add
                    temporary assignments.
                  </p>
                  <h2 class="section-title">Assignment Name</h2>
                  <div class="d-flex align-start my-4">
                    <div :class="isTeamAssignmentOn ? 'faded' : ''">
                      <p class="mb-0 selection">My Assigned Customers</p>
                    </div>
                    <div class="team-assignment-switch">
                      <v-switch
                        hide-details
                        class="mx-2"
                        color="secondary"
                        @change="changeState()"
                        v-model="isTeamAssignmentOn"
                      ></v-switch>
                    </div>
                    <div :class="!isTeamAssignmentOn ? 'faded' : ''">
                      <p class="mb-0 selection">My Team Assigned Customers</p>
                      <div>
                        <p class="mb-0 sub-title">
                          {{ teamAssngName.length ? teamAssngName : '' }}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </v-col>
            </v-row>
            <v-divider
              :color="getColor('color_gray_border')"
              class="my-1"
            ></v-divider>
            <v-row align="center">
              <v-col cols="12">
                <div class="px-5 pb-4">
                  <div class="d-flex align-center">
                    <h2 class="mr-3 section-title">Temporary Assignment</h2>
                    <div>
                      <v-radio-group
                        v-model="temporaryAssignmentSelection"
                        @change="clearDropdownSelection()"
                        class="radio-group temporary-assignment-radio-group"
                        row
                        ref="temporaryAssignmentTypeRadioGroup"
                      >
                        <v-tooltip top>
                          <template v-slot:activator="{ on, attrs }">
                            <v-radio
                              v-bind="attrs"
                              v-on="on"
                              value="USER"
                              @click="confirmAssignmentTypeSwitch('USER')"
                              :readonly="changesMadeTempAssignments"
                              color="secondary"
                              label="By Individuals"
                            ></v-radio>
                          </template>
                          <span>{{
                            changesMadeTempAssignments
                              ? 'You have unsaved changes'
                              : 'Switch type'
                          }}</span>
                        </v-tooltip>
                        <v-tooltip top>
                          <template v-slot:activator="{ on, attrs }">
                            <v-radio
                              v-bind="attrs"
                              v-on="on"
                              value="CUSTOMER"
                              @click="confirmAssignmentTypeSwitch('CUSTOMER')"
                              color="secondary"
                              :readonly="changesMadeTempAssignments"
                              label="By Customers"
                            ></v-radio>
                          </template>
                          <span>{{
                            changesMadeTempAssignments
                              ? 'You have unsaved changes'
                              : 'Switch type'
                          }}</span>
                        </v-tooltip>
                        <v-tooltip top>
                          <template v-slot:activator="{ on, attrs }">
                            <v-radio
                              v-bind="attrs"
                              v-on="on"
                              value="TEAM"
                              @click="confirmAssignmentTypeSwitch('TEAM')"
                              color="secondary"
                              :readonly="changesMadeTempAssignments"
                              label="By Teams"
                            ></v-radio>
                          </template>
                          <span>{{
                            changesMadeTempAssignments
                              ? 'You have unsaved changes'
                              : 'Switch type'
                          }}</span>
                        </v-tooltip>
                      </v-radio-group>
                    </div>
                  </div>

                  <div class="d-flex justify-space-between align-start">
                    <div
                      v-if="temporaryAssignments.length"
                      class="temporary-assignment-list"
                    >
                      <div class="d-flex align-center list-headers">
                        <div class="assignment-name">
                          Temporary Assignment Name
                        </div>
                        <div class="assignment-active mx-2">Active</div>
                        <div>
                          Remove
                          <span
                            v-if="temporaryAssignments.length"
                            @click="confirmAssignmentRemoval()"
                            class="text-btn clickable ml-2"
                            >Remove All
                          </span>
                        </div>
                      </div>
                      <div
                        v-for="assignment in temporaryAssignments"
                        :key="assignment.value"
                        class="d-flex align-center my-1 assignments"
                      >
                        <div class="assignment-name">
                          {{ assignment.displayValue }}
                        </div>
                        <div class="assignment-active mx-2 d-flex align-center">
                          <v-switch
                            color="secondary"
                            class="ma-0"
                            hide-details
                            v-model="assignment.active"
                            @change="changeStateTempAssignments()"
                          ></v-switch>
                          <span
                            class="active-status"
                            :class="{ highlighted: assignment.active }"
                          >
                            {{ assignment.active ? 'On' : 'Off' }}
                          </span>
                        </div>
                        <div>
                          <v-img
                            @click="confirmAssignmentRemoval(assignment)"
                            class="clickable"
                            max-height="15"
                            max-width="15"
                            :src="getIcon(CdnImagesEnum.delete_icon)"
                          ></v-img>
                        </div>
                      </div>
                    </div>

                    <div class="d-flex flex-column">
                      <p class="list-headers ma-0">
                        {{
                          generateAutocompleteLabel(
                            oldTemporaryAssignmentSelection
                          )
                        }}
                      </p>
                      <div class="d-flex align-center">
                        <hg-autocomplete
                          class="assignment-autocomplete"
                          v-if="oldTemporaryAssignmentSelection === 'CUSTOMER'"
                          clearable
                          :hideDetails="true"
                          @onSearchTextChanged="
                            customersAutocompleteSearchTextChanged($event)
                          "
                          :placeholder="
                            generateAutocompletePlaceholder(
                              oldTemporaryAssignmentSelection
                            )
                          "
                          :items="customersDropdownValues"
                          :item-text="formatDDText"
                          :item-value="formatDDValue"
                          @input="updateSelectedValue($event)"
                          @click:clear="clearDropdownSelection()"
                          ref="customersAutocomplete"
                        ></hg-autocomplete>
                        <hg-autocomplete
                          class="assignment-autocomplete"
                          v-if="oldTemporaryAssignmentSelection === 'TEAM'"
                          clearable
                          :hideDetails="true"
                          :placeholder="
                            generateAutocompletePlaceholder(
                              oldTemporaryAssignmentSelection
                            )
                          "
                          :items="teamsDropdownValues"
                          :item-text="formatDDText"
                          :item-value="formatDDValue"
                          @input="updateSelectedValue($event)"
                          @click:clear="clearDropdownSelection()"
                          ref="teamsAutocomplete"
                        ></hg-autocomplete>
                        <hg-autocomplete
                          class="assignment-autocomplete"
                          v-if="oldTemporaryAssignmentSelection === 'USER'"
                          clearable
                          :hideDetails="true"
                          @onSearchTextChanged="
                            individualAutocompleteSearchTextChanged($event)
                          "
                          :placeholder="
                            generateAutocompletePlaceholder(
                              oldTemporaryAssignmentSelection
                            )
                          "
                          :items="individualsDropdownValues"
                          :item-text="formatDDText"
                          :item-value="formatDDValue"
                          @input="updateSelectedValue($event)"
                          @click:clear="clearDropdownSelection()"
                          ref="individualsAutocomplete"
                        ></hg-autocomplete>
                        <span
                          class="text-btn clickable mx-3"
                          @click="addSelectedValueToAssignments()"
                          >Add</span
                        >
                      </div>
                    </div>
                  </div>
                </div>
              </v-col>
            </v-row>
          </v-card-text>
          <v-divider
            :color="getColor('color_gray_border')"
            class="my-1"
          ></v-divider>
          <v-card-actions class="pa-5">
            <HgLibBtn
              title="Cancel"
              type="secondary"
              :disabled="!changesMade"
              @click.native="cancelPreferenceEdit"
            ></HgLibBtn>
            <v-spacer></v-spacer>
            <HgLibBtn
              class="ml-auto"
              :title="'Save Changes'"
              type="primary"
              :disabled="!changesMade"
              @click.native="submitForm()"
            ></HgLibBtn>
          </v-card-actions>
        </v-card>
      </div>
    </div>
  </v-app>
</template>

<script src="./preferences.js"></script>
<style src="./preferences.sass" lang="sass" scoped></style>
