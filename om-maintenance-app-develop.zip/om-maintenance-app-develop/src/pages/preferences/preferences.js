import _ from 'lodash';
import Vue from 'vue';
import {
  ImageLoaderService, GoogleAnalyticsService,
} from '@hubgroup/hg-om-shared-services';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import { AppSetupEnum, CdnImagesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import hgTitle from '../../components/hg-title/hg-title.vue';
import HgConfirmActionModal from '../../components/shared/hg-confirm-modal/hg-confirm-modal.vue';
import HgAutocomplete from '../../components/shared/drop-downs/hg-autocomplete/hg-autocomplete.vue';
import customerService from '../../services/customer/customer.service';
import hgNotifications from '../../components/hg-notifications/hg-notifications.vue';

import prefService from '../../services/preferences/preferences.service';
import commonService from '../../services/common.service';

function getIcon(iconName) {
  return ImageLoaderService.getCdnImageUrl(iconName);
}

function getColor(name) {
  return _colors[name];
}

function setGoogleAnalytics(details) {
  GoogleAnalyticsService.event(Vue, 'Metric', 'Maintenance', details);
}

function getChangesState() {
  this.changesMade = (this.changesMadeToggle
    || this.changesMadeTempAssignments
    || this.changesMadeTempAssignmentsType);
}

async function setTemporaryAssignment(data) {
  const tempAssgn = {
    teamAssgnValues: [],
    customerAssgnValues: [],
    individualAssgnValues: [],
  };
  const tempTeamAssgn = _.get(data, 'teamAssignment.tempAssignments.teamName', []);
  const tempCustomerAssgn = _.get(data, 'teamAssignment.tempAssignments.customerId', []);
  const tempIndividualAssgn = _.get(data, 'teamAssignment.tempAssignments.username', []);
  if (!_.isEmpty(tempTeamAssgn)) {
    tempAssgn.teamAssgnValues = tempTeamAssgn.map((item) => (
      {
        displayValue: item.displayValue, value: item.value, active: item.active,
      }
    ));
  }
  if (!_.isEmpty(tempCustomerAssgn)) {
    tempAssgn.customerAssgnValues = tempCustomerAssgn.map((item) => (
      {
        displayValue: item.displayValue, value: item.value, active: item.active,
      }
    ));
  }
  if (!_.isEmpty(tempIndividualAssgn)) {
    tempAssgn.individualAssgnValues = tempIndividualAssgn.map((item) => (
      {
        displayValue: item.displayValue, value: item.value, active: item.active,
      }
    ));
  }
  return tempAssgn;
}

function setAssignmentNames(data) {
  const customerNameAssgn = {};
  const teamNameAssgn = {};
  const myAssgn = _.get(data, 'teamAssignment.myAssignments', []);
  myAssgn.forEach((item) => {
    const teamName = _.get(item, 'teamName', null);
    const customerName = _.get(item, 'customerName', null);
    if (teamName) {
      teamNameAssgn[teamName] = true;
    }
    if (customerName) {
      customerNameAssgn[customerName] = true;
    }
  });
  return {
    teamNames: Object.keys(teamNameAssgn),
    customerNames: Object.keys(customerNameAssgn),
  };
}

async function getUser() {
  try {
    const userObj = localStorage.getItem('user');
    const userId = userObj && _.get(JSON.parse(userObj), 'username', 'N/A').toUpperCase();
    if (userId && userId === 'N/A') {
      // eslint-disable-next-line no-throw-literal
      throw { message: 'Please login!' };
    }
    const userData = await prefService.getInternalUser(userId);
    if (!_.isEmpty(userData)) {
      this.userInfo = userData;
      this.allTemporaryAssignments = await setTemporaryAssignment(this.userInfo);
      const tempAssgn = _.get(userData, 'teamAssignment.tempAssignments.activeType', null);
      if (tempAssgn.toUpperCase() === 'TEAM') {
        this.temporaryAssignmentSelection = 'TEAM';
        this.oldTemporaryAssignmentSelection = 'TEAM';
        this.temporaryAssignments = this.allTemporaryAssignments.teamAssgnValues;
      } else if (tempAssgn.toUpperCase() === 'CUSTOMER') {
        this.temporaryAssignmentSelection = 'CUSTOMER';
        this.oldTemporaryAssignmentSelection = 'CUSTOMER';
        this.temporaryAssignments = this.allTemporaryAssignments.customerAssgnValues;
      } else {
        this.temporaryAssignmentSelection = 'USER';
        this.oldTemporaryAssignmentSelection = 'USER';
        this.temporaryAssignments = this.allTemporaryAssignments.individualAssgnValues;
      }

      const getAssgnName = _.get(userData, 'userPreferences.myAssignmentNameToggle', false);
      if (getAssgnName === 'TEAM') { this.isTeamAssignmentOn = true; } else { this.isTeamAssignmentOn = false; }
    }
  } catch (error) {
    const errorMessage = error.message ? error.message : 'Failed to get user data';
    HgNotificationService.errorMessage(errorMessage);
  }
}

function handleNewChanges(formData, apiData) {
  const queryMapObj = {
    TEAM: 'teamName',
    USER: 'username',
    CUSTOMER: 'customerId',
  };
  const updatedData = _.cloneDeep(apiData);
  const temporaryAssignmentsType = _.get(formData, 'temporaryAssignmentsType', null);
  if (this.changesMadeToggle) {
    updatedData.userPreferences = {
      myAssignmentNameToggle: formData.isTeamAssignmentOn ? 'TEAM' : 'USER',
    };
    setGoogleAnalytics('Assignment name changed');
  }
  if (this.changesMadeTempAssignmentsType) {
    _.set(updatedData, 'teamAssignment.tempAssignments.activeType', temporaryAssignmentsType);
  }
  if (this.changesMadeTempAssignments) {
    const pathToUpdate = queryMapObj[temporaryAssignmentsType];
    const newTempAssignments = _.cloneDeep(formData.temporaryAssignments);
    _.set(updatedData.teamAssignment.tempAssignments, pathToUpdate, newTempAssignments);
    setGoogleAnalytics('Temporary assignment changed in My Preferences');
  }
  _.unset(updatedData, '_id');
  return updatedData;
}

async function submitForm() {
  this.changesMade = false;
  try {
    const userObj = localStorage.getItem('user');
    const userId = userObj && _.get(JSON.parse(userObj), 'username', 'N/A').toUpperCase();
    if (userId && userId === 'N/A') {
      // eslint-disable-next-line no-throw-literal
      throw { message: 'Please login' };
    }
    const submission = {
      temporaryAssignmentsType: this.temporaryAssignmentSelection,
      temporaryAssignments: this.temporaryAssignments,
      isTeamAssignmentOn: this.isTeamAssignmentOn,
    };
    const updatedData = await this.handleNewChanges(
      submission, this.userInfo, this.allTemporaryAssignments,
    );
    const savedData = await prefService.updateInternalUser(updatedData, userId);
    if (_.isEmpty(savedData)) {
      // eslint-disable-next-line no-throw-literal
      throw { message: 'Failed to save data' };
    }
    localStorage.setItem('assignmentInfo', JSON.stringify(updatedData));
    await getUser.bind(this)();
    this.changesMadeToggle = false;
    this.changesMadeTempAssignmentsType = false;
    this.changesMadeTempAssignments = false;
    this.getChangesState();
    HgNotificationService.successMessage('Successfully saved changes');
  } catch (error) {
    const errorMsg = error.message ? error.message : 'Failed to submit form';
    HgNotificationService.errorMessage(errorMsg);
  }
}

async function initIndividualsDropdownValues() {
  const individualSearchData = await prefService.listUsers({}, true) || [];
  if (!_.isEmpty(individualSearchData)) {
    this.individualsDropdownValues = individualSearchData;
  }
}

async function initCustomersDropdownValues() {
  const customerSearchData = await customerService.searchCustomers() || [];
  if (!_.isEmpty(customerSearchData)) {
    this.customersDropdownValues = customerSearchData;
  }
}

/**
 * Calls api to search customer
 * Searches if searchText is 3 or more character long or searchText is empty
 * For empty searchText, api will give first 50 items sorted by customer name
 * Api searches customer in customer collection in OperationDB
 * @param {*} searchText
 * @param {*} initialSearch
 */
async function customersAutocompleteSearchTextChanged($event) {
  const searchText = $event;
  if (searchText && searchText.length >= AppSetupEnum.MINIMUM_SEARCH_CHARACTER) {
    try {
      const customerSearchData = await customerService.searchCustomers(searchText) || [];
      if (!_.isEmpty(customerSearchData)) {
        this.customersDropdownValues = customerSearchData;
      }
    } catch (error) {
      console.error(error, 'error');
    }
  } else {
    this.customersDropdownValues = [];
  }
}
async function individualAutocompleteSearchTextChanged($event) {
  const searchText = $event;
  if (searchText && searchText.length >= AppSetupEnum.MINIMUM_SEARCH_CHARACTER) {
    const reqPayload = {
      query: {
        quickSearch: searchText,
      },
      limit: 15,
      page: 1,
    };
    const invidualSearchData = await prefService.listUsers(reqPayload, true) || [];
    if (!_.isEmpty(invidualSearchData)) {
      this.individualsDropdownValues = invidualSearchData;
    }
  }
}

async function loadTeamNames() {
  const values = await commonService.getCommonLov('AM_TEAMS');
  this.teamsDropdownValues = await commonService.getFilterObjects('AM_TEAMS', 'team', 'Team', values);
  // Add other as team
  this.teamsDropdownValues.push({
    key: 'team',
    value: 'OTHER',
    text: 'OTHER',
    label: 'Team',
  });
  const names = setAssignmentNames(this.userInfo);
  this.customerAssgnName = names.customerNames;
  this.teamAssngName = this.userInfo.team;
}

function generateAutocompletePlaceholder(searchType) {
  return `Type to search ${searchType} names…`;
}

function generateAutocompleteLabel(searchType) {
  let label = '';
  switch (searchType) {
    case 'USER':
      label = 'INDIVIDUALS';
      break;
    case 'TEAM':
      label = 'TEAMS';
      break;
    case 'CUSTOMER':
      label = 'CUSTOMERS';
      break;
    default:
      break;
  }
  return label;
}

function updateSelectedValue(event) {
  let selectedAssignment;
  switch (this.temporaryAssignmentSelection) {
    case 'CUSTOMER': {
      selectedAssignment = this.customersDropdownValues.filter((item) => item.value === event);
      break;
    }
    case 'TEAM': {
      selectedAssignment = this.teamsDropdownValues.filter((item) => item.value === event);
      break;
    }
    case 'USER': {
      selectedAssignment = this.individualsDropdownValues.filter((item) => item.value === event);
      break;
    }
    default:
      break;
  }
  if (!_.isEmpty(selectedAssignment)) [this.selectedAssignment] = selectedAssignment;
}

function addSelectedValueToAssignments() {
  // make sure to not add duplicates before adding
  const duplicates = this.temporaryAssignments
    .filter((item) => item.value === this.selectedAssignment.value);
  if (_.isEmpty(duplicates) && !_.isEmpty(this.selectedAssignment)) {
    this.temporaryAssignments.push(
      {
        displayValue: this.selectedAssignment.text,
        active: true,
        value: this.selectedAssignment.value,
      },
    );
    this.changesMadeTempAssignments = true;
  }
  this.getChangesState();
  this.clearDropdownSelection();
}

function clearDropdownSelection() {
  // clear selected from dropdown
  if (_.get(this, '$refs.customersAutocomplete', null)) {
    this.$refs.customersAutocomplete.value = '';
  }
  if (_.get(this, '$refs.teamsAutocomplete', null)) {
    this.$refs.teamsAutocomplete.value = '';
  }
  if (_.get(this, '$refs.individualsAutocomplete', null)) {
    this.$refs.individualsAutocomplete.value = '';
  }
  // clear current selection
  this.selectedAssignment = {};
}

function removeTemporaryAssignments(assignment = null) {
  if (assignment) {
    this.temporaryAssignments = this.temporaryAssignments
      .filter((item) => item.value !== assignment.value);
  } else {
    const localMapObj = {
      teams: 'teamAssgnValues',
      individuals: 'individualAssgnValues',
      customers: 'customerAssgnValues',
    };
    this.temporaryAssignments = [];
    this.allTemporaryAssignments[localMapObj[this.temporaryAssignmentSelection]] = [];
  }
}

async function confirmAssignmentRemoval(assignment = null) {
  if (assignment) {
    if (
      await this.$refs.confirm.open(
        'Remove Temporary Assignment',
        `Are you sure you want to remove <b>${assignment.displayValue}</b> form temporary assignments?`,
        'Remove',
      )
    ) {
      this.changesMadeTempAssignments = true;
      this.getChangesState();
      this.removeTemporaryAssignments(assignment);
    }
  } else if (
    await this.$refs.confirm.open(
      'Remove All Temporary Assignments',
      'You are about to move all temporary assignments, are you sure you want to do this?',
      'Remove All',
    )
  ) {
    this.changesMadeTempAssignments = true;
    this.getChangesState();
    this.removeTemporaryAssignments();
  }
}

async function confirmAssignmentTypeSwitch(assignmentType) {
  let loadDataOnSwith = true;
  if (assignmentType !== this.oldTemporaryAssignmentSelection && !this.changesMadeTempAssignments && !this.changesMadeTempAssignmentsType) {
    // eslint-disable-next-line no-lonely-if
    if (await this.$refs.confirm.open(
      'Switch temporary assignments type',
      `You are now moving from ${this.generateAutocompleteLabel(this.oldTemporaryAssignmentSelection)} to
      ${this.generateAutocompleteLabel(assignmentType)} type temporary assignments.
      To confirm, select 'Switch Assignments' below.`,
      'Switch assignments',
    )
    ) {
      // remove all assignments and switch assignment type
      this.temporaryAssignmentSelection = assignmentType;
      this.oldTemporaryAssignmentSelection = assignmentType;
      this.changesMadeTempAssignmentsType = true;
      this.getChangesState();
      this.submitForm();
    } else {
      this.temporaryAssignmentSelection = this.oldTemporaryAssignmentSelection;
      loadDataOnSwith = false;
    }
    if (loadDataOnSwith) {
      if (assignmentType === 'TEAM') {
        this.temporaryAssignments = this.allTemporaryAssignments.teamAssgnValues;
      } else if (assignmentType === 'CUSTOMER') {
        try {
          this.customersDropdownValues = await customerService.searchCustomers() || [];
        } catch (error) {
          HgNotificationService.errorMessage('Failed to load customers');
        }
        this.temporaryAssignments = this.allTemporaryAssignments.customerAssgnValues;
      } else if (assignmentType === 'USER') {
        const invidualSearchData = await prefService.listUsers({}, true);
        if (!_.isEmpty(invidualSearchData)) {
          this.individualsDropdownValues = invidualSearchData;
        }
        this.temporaryAssignments = this.allTemporaryAssignments.individualAssgnValues;
      }
    }
  }
}

async function cancelPreferenceEdit() {
  await getUser.bind(this)();
  this.changesMade = false;
  this.changesMadeToggle = false;
  this.changesMadeTempAssignments = false;
  HgNotificationService.successMessage('Canceled changes');
}

function changeState() {
  this.changesMadeToggle = !this.changesMadeToggle;
  this.getChangesState();
}

function changeStateTempAssignments() {
  this.changesMadeTempAssignments = true;
  this.getChangesState();
}

export default {
  name: 'Preferences',
  components: {
    hgTitle,
    HgAutocomplete,
    HgConfirmActionModal,
    hgNotifications,
  },
  data: () => ({
    userInfo: {},
    customersDropdownValues: [],
    teamsDropdownValues: [],
    individualsDropdownValues: [],
    formatDDText: (value) => {
      if (!value || !value.text) return '';
      if (value.key && value.key === 'Individual') {
        return value.text.toLowerCase().replace(/(?:^|\s|-)\S/g, (x) => x.toUpperCase());
      }
      return value.text.toUpperCase();
    },
    formatDDValue: (value) => {
      if (!value || !value.value) return '';
      return value.value;
    },
    CdnImagesEnum,
    isTeamAssignmentOn: false,
    originalTeamAssignment: false,
    temporaryAssignmentSelection: '',
    oldTemporaryAssignmentSelection: '',
    selectedAssignment: {},
    customerAssgnName: [],
    teamAssngName: [],
    allTemporaryAssignments: {},
    temporaryAssignments: [],
    changesMade: false,
    changesMadeToggle: false,
    changesMadeTempAssignments: false,
    changesMadeTempAssignmentsType: false,
  }),
  methods: {
    getIcon,
    getColor,
    submitForm,
    customersAutocompleteSearchTextChanged,
    individualAutocompleteSearchTextChanged,
    initIndividualsDropdownValues,
    initCustomersDropdownValues,
    generateAutocompletePlaceholder,
    generateAutocompleteLabel,
    updateSelectedValue,
    addSelectedValueToAssignments,
    removeTemporaryAssignments,
    clearDropdownSelection,
    confirmAssignmentRemoval,
    confirmAssignmentTypeSwitch,
    cancelPreferenceEdit,
    getUser,
    changeState,
    changeStateTempAssignments,
    getChangesState,
    handleNewChanges,
  },
  async beforeMount() {
    await getUser.bind(this)();
    await loadTeamNames.bind(this)();
  },
  mounted() {
    this.$nextTick(function init() {
      this.initIndividualsDropdownValues();
      this.initCustomersDropdownValues();
    });
  },
};
