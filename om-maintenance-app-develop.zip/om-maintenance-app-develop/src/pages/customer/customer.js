import _ from 'lodash';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import { AppSetupEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import CustomerFilters from '../../components/customer/filters/customer-filters.vue';
import CustomerGrid from '../../components/customer/grid/customer-grid.vue';
import CustomerDetail from '../../components/customer/details/customer-details.vue';
import hgPagination from '../../components/shared/hg-pagination/hg-pagination.vue';
import hgTiles from '../../components/shared/hg-tiles/hg-tiles.vue';
import hgTitle from '../../components/hg-title/hg-title.vue';
import customerService from '../../services/customer/customer.service';
import customerMetricesEnum from '../../enums/customer-metrices.enum';
import customerFilterEnum from '../../enums/customer-filter.enum';

function paginationChanged(options) {
  this.$store.dispatch('customersStore/updatePagination', options);
}

function customerSelected(customer) {
  this.selectedCustomer = customer.id;
}

function getSeletedStatusFilter() {
  return this.$store.getters['customersStore/getFilters'].status[0] || {};
}

function handleMetricFilterClick(updatedStatus) {
  const statusFilterObj = _.get(customerFilterEnum, 'status.statuses' || []).find((cust) => cust
    .value === updatedStatus.value);
  this.$store.dispatch('customersStore/updateFilter', statusFilterObj || {});
  this.$refs.filterComponent.setLocalStorageFilter();
}

async function loadOrderMetrics() {
  try {
    const result = (await customerService.getMetrics()).data || {};

    // Assign value to each metric
    Object.keys(result).forEach((key) => {
      this.customerStats.forEach((stat) => {
        if (stat.key === key) {
          // if value is greater than limit show LIMIT+ in UI
          // eg 1000 ==> 999+
          if (result[key] > AppSetupEnum.MAX_CUST_COUNT_LIMIT) {
            _.set(stat, 'displayValue', `${AppSetupEnum.MAX_CUST_COUNT_LIMIT}+`);
          } else {
            _.set(stat, 'displayValue', result[key]);
          }
        }

        _.set(stat, 'tooltip', `${stat.displayValue} ${stat.text} Customers`);
      });
    });
  } catch (err) {
    console.error(err);
    if (err.message !== 'CANCEL_REQUEST') HgNotificationService.errorMessage('Failed to load customer metrics');
  }
}

export default {
  name: 'Customer',

  components: {
    CustomerDetail,
    CustomerFilters,
    CustomerGrid,
    hgPagination,
    hgTitle,
    hgTiles,
  },
  data: () => ({
    counts: {},
    filters: {},
    selectedCustomer: '',
    mentrics: {},
    customerStats: customerMetricesEnum.stats,
  }),
  methods: {
    paginationChanged,
    customerSelected,
    loadOrderMetrics,
    handleMetricFilterClick,
  },
  computed: {
    getSeletedStatusFilter,
  },
  async mounted() {
    this.counts = this.$store.getters['customersStore/getCounts'];
    this.filters = this.$store.getters['customersStore/getFilters'];
    this.loadOrderMetrics();
  },
  watch: {
    filters: {
      handler() {
        this.$refs.paginationComponent.resetPage();
      },
      deep: true,
    },
  },
};
