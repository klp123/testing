<template>
  <v-app class="app" data-app>
    <div id="app-customer-maintenance">
      <div class="page-header">
        <hg-title title="Maintenance - Customer">
          <template v-slot:metrics>
            <div class="d-flex align-center">
              <div id="grid-metrics" class="mr-3">
                <hg-tiles
                  :items="customerStats"
                  :selectedItem="getSeletedStatusFilter"
                  :isGroupByMode="false"
                  @refreshStats="refreshStats()"
                  @onTileClick="handleMetricFilterClick($event)"
                ></hg-tiles>
              </div>
            </div>
          </template>
        </hg-title>
      </div>

      <div class="page-filter">
        <customer-filters id="filters-customer-maintenance" ref="filterComponent"/>
      </div>

      <div class="page-content">
        <div class="content-grid">
          <customer-grid
            @customerSelected="customerSelected($event)"
            id="grid-customer-maintenance"
          />
        </div>

        <div class="content-details">
          <customer-detail
            :customerId="selectedCustomer"
            id="details-customer-maintenance"
          />
        </div>
      </div>

      <div class="pagination">
        <div>
          <hg-pagination
            @paginationChanged="paginationChanged($event)"
            :totalCounts="counts.total"
            :showingCounts="counts.showing"
            id="pagination-customer-maintenance"
            ref="paginationComponent"
          />
        </div>
        <div></div>
      </div>
    </div>
  </v-app>
</template>

<script src="./customer.js"></script>
<style src="./customer.sass" lang="sass" scoped></style>
