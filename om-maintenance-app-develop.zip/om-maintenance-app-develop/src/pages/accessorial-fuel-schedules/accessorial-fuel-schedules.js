import Vue from 'vue';
import { GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import hgTitle from '../../components/hg-title/hg-title.vue';
import hgPagination from '../../components/shared/hg-pagination/hg-pagination.vue';
import customerAccessorialsFuelFilters from '../../components/accessorial-fuel-schedules/customer-accessorials-fuel/filters/customer-acessorials-fuel-filters.vue';
import accesorialFuelScheduleService from '../../services/accessorial-fuel-schedules/customer-acessorials.service';
import filterService from '../../services/filters/filters.service';
import customerAccessorialsFuel from '../../components/accessorial-fuel-schedules/customer-accessorials-fuel/grid/customer-accessorials-fuel.vue';
import HgTableMetadata from '../../components/shared/hg-table-metadata/hg-table-metadata.vue';

async function getCustomerAccessorialsFuelListByPage(options) {
  this.options = options;
  await this.getCustomerAccesorialsFuelData(this.filters, options);
}

async function getCustomerAccesorialsFuelListByFilter(filters) {
  this.filters = filters;
  this.options.page = 1;
  await this.getCustomerAccesorialsFuelData(filters, this.options);
}

async function refreshGrid() {
  this.$refs.accessorialCustomerPaginationComponent && this.$refs.accessorialCustomerPaginationComponent.resetPage();
  const currentAFSFilters = this.$store.getters['customerAccessorialFuelStore/getFilters'];
  this.$store.dispatch('customerAccessorialFuelStore/updateRefreshGrid', true);
  await this.getCustomerAccesorialsFuelData(currentAFSFilters, this.options);
  GoogleAnalyticsService.event(Vue, 'Refresh grid', 'Accessorial-Fuel-Schedules', 'Refresh AFS grid');
}

async function getCustomerAccesorialsFuelData(filters, options) {
  try {
    this.loadingCustomerAccesorial = true;
    const resp = await accesorialFuelScheduleService.customerAccesorialFuel(filters, options);
    this.lastRefreshedDate = new Date();
    this.customerAccessorialFuelData = resp.data.data;
    this.counts.total = resp.data.meta.total;
    this.counts.showing = resp.data.meta.limit * (resp.data.meta.page - 1)
      + this.customerAccessorialFuelData.length;
    this.loadingCustomerAccesorial = false;
  } catch (err) {
    if (err.message && err.message !== RequestErrorTypesEnum.CANCEL_REQUEST) {
      HgNotificationService.errorMessage('Error while fetching accessorials fuel schedules');
    }
  }
  this.loadingCustomerAccesorial = false;
}

function getColor(name) {
  return _colors[name];
}

function refreshGridCloseDetails() {
  return this.$store.getters['customerAccessorialFuelStore/getRefreshGrid'];
}

export default {
  name: 'CustomerAccessorialFuel',

  components: {
    hgTitle,
    hgPagination,
    customerAccessorialsFuel,
    customerAccessorialsFuelFilters,
    HgTableMetadata
  },
  mounted() {
    this.counts = this.$store.getters['customerAccessorialFuelStore/getCounts'];
    this.$refs.accessorialCustomerPaginationComponent.resetPage();
  },
  data: () => ({
    counts: {
      total: 0,
      showing: 0
    },
    options: { page: 1, limit: 20 },
    filters: filterService.getFilterParams(),
    customerAccessorialFuelData: [],
    loadingCustomerAccesorial: false,
    lastRefreshedDate: new Date()
  }),
  async created() {
    this.getCustomerAccesorialsFuelListByFilter(this.filters);
  },
  methods: {
    getCustomerAccesorialsFuelListByFilter,
    getCustomerAccesorialsFuelData,
    getCustomerAccessorialsFuelListByPage,
    refreshGrid,
    getColor
  },
  watch: {
    refreshGridCloseDetails(value) {
      if (value) {
        this.refreshGrid();
      }
    }

  },
  computed: {
    refreshGridCloseDetails
  },
};
