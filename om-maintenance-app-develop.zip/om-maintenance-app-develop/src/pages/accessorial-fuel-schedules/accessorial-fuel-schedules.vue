<template>
  <v-app class="app" data-app>
    <div id="app-accessorial-fuel-schedule-maintenance">
      <div class="page-header">
        <hg-title title="ACCESSORIAL AND FUEL SCHEDULES"> </hg-title>
      </div>
    </div>
    <div>
      <!-- <Filters-Component-Placeholder> -->
      <customer-accessorials-fuel-filters
        @filters="getCustomerAccesorialsFuelListByFilter($event)"
      />
      <div class="ml-4 mr-4">
        <hg-table-metadata :refreshTime="lastRefreshedDate" :totalResults="counts.total" page="Accessorial Grid" @onRefreshClick="refreshGrid()" />
        <customerAccessorialsFuel
          id="customer-accessorial-fuel"
          :loadingCustomerAccesorial="loadingCustomerAccesorial"
          :customerAccessorialFuelData="customerAccessorialFuelData || []"
        />
      </div>
      <div class="pagination">
        <div>
          <hg-pagination
            @paginationChanged="getCustomerAccessorialsFuelListByPage($event)"
            :totalCounts="counts.total"
            :showingCounts="counts.showing"
            sourceText="Charge Code"
            ref="accessorialCustomerPaginationComponent"
            id="pagination-customer-accessorials"
          />
        </div>
        <div></div>
      </div>
    </div>
  </v-app>
</template>

<script src="./accessorial-fuel-schedules.js"></script>
<style src="./accessorial-fuel-schedules.sass" lang="sass" scoped></style>
