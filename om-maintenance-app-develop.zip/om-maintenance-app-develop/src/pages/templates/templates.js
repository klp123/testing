import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import hgTitle from '../../components/hg-title/hg-title.vue';
import hgPagination from '../../components/shared/hg-pagination/hg-pagination.vue';
import TemplateDetails from '../../components/template/template-details/template-details.vue';
import templatesService from '../../services/templates/templates.service';
import TemplateFilters from '../../components/template/filters/template-filters.vue';
import filterService from '../../services/filters/filters.service';

async function getTemplatesListByPage(options) {
  const currentTPFilters = this.$store.getters['templatesStore/getFilters'];
  await this.getTemplatesData(currentTPFilters, options);
}

async function getTemplatesListByFilter(filters) {
  await this.getTemplatesData(filters, this.options);
}

async function getTemplatesData(filters, options) {
  try {
    this.loadingTemplates = true;
    const resp = await templatesService.filterTemplates(filters, options);
    this.templateData = resp.data.data;
    this.counts.total = resp.data.meta.total;
    this.counts.showing = resp.data.meta.limit * (resp.data.meta.page - 1)
                                            + this.templateData.length;
    this.loadingTemplates = false;
  } catch (err) {
    if (err.message && err.message !== RequestErrorTypesEnum.CANCEL_REQUEST) {
      HgNotificationService.errorMessage('Error while fetching templates');
      this.loading = false;
    }
  }
}

export default {
  name: 'Templates',

  components: {
    hgTitle,
    hgPagination,
    TemplateDetails,
    TemplateFilters,
  },
  data: () => ({
    counts: {
      total: 0,
      showing: 0,
    },
    options: { page: 1, limit: 20 },
    filters: filterService.getFilterParams(),
    templateData: [],
    loadingTemplates: false,
  }),
  async created() {
    this.getTemplatesListByFilter(this.filters);
  },
  methods: {
    getTemplatesListByPage,
    getTemplatesListByFilter,
    getTemplatesData,
  },
  mounted() {
    this.$refs.templatePaginationComponent.resetPage();
  },
};
