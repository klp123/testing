<template>
  <v-app class="app" data-app>
    <div id="app-templates-maintenance">
      <div class="page-header">
        <hg-title title="Maintenance - Templates"> </hg-title>
      </div>
    </div>
   <div>
     <template-filters
     @filters="getTemplatesListByFilter($event)"
      />
      <template-details :templates="templateData" :loadingTemplate="loadingTemplates" />
    </div>
    <div v-if="!templateData.length" class="no-templates">No Templates to Display</div>
      <div class="pagination">
        <div>
          <hg-pagination
            @paginationChanged="getTemplatesListByPage($event)"
            :totalCounts="counts.total"
            :showingCounts="counts.showing"
            sourceText="Templates"
            ref="templatePaginationComponent"
            id="pagination-templates-maintenance"
          />
        </div>
      </div>
  </v-app>
</template>

<script src="./templates.js"></script>
<style src="./templates.sass" lang="sass" scoped></style>
