<template>
  <div id="page-maintenance">
    <hg-title :title="`Maintenance - Locations`"></hg-title>
    <div class="filter">
      <location-settings-filter
        :params="params"
      />
    </div>

    <div class="maintenance-body">
      <location-settings-component/>
    </div>
  </div>
</template>

<script src="./location.js"></script>
<style src="./location.sass" lang="sass" scoped></style>
