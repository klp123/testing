import LocationSettingsComponent from '../../components/location/location-settings-component/location-settings-component.vue';
import LocationSettingsFilter from '../../components/location/location-settings-filter-component/location-settings-filter.vue';
import hgTitle from '../../components/hg-title/hg-title.vue';

function redirectTo(url) {
  if (url) {
    this.$emit('redirectTo', url);
  }
}

// @vuese
// @group MENU
// Menu for side Order Management
export default {
  name: 'Location',
  components: {
    LocationSettingsComponent,
    LocationSettingsFilter,
    hgTitle,
  },
  data: () => ({
    params: {},
  }),
  methods: {
    // @vuese
    // Used fire event on menu item click
    // @arg (url) clicked url
    redirectTo,
  },
  created() {
    this.params = this.$route.params;
  },
};
