<template>
  <v-app class="app" data-app>
    <div id="page-maintenance-appointment-rules">
      <HgConfirmActionModal ref="confirm" />
      <hg-title :title="`Maintenance - Appointment Rules`"></hg-title>
      <div>
        <appointment-rules-filter-component ref="appointmentRulesFilterRef" />
      </div>
      <div class="create-rules-container">
        <create-rules-component :lovData="lovData" :entitlements="entitlements" />
      </div>
      <div>
        <rules-grid-component :lovData="lovData" :entitlements="entitlements" />
      </div>
    </div>
  </v-app>
</template>

<script src="./appointment-rules.js"></script>
<style src="./appointment-rules.sass" lang="sass" scoped></style>
