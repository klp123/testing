import _ from 'lodash';
import entitlementsEnum from '@hubgroup/hg-om-shared-services/src/enums/entitlements.enum';
import CreateRulesComponent from '../../components/appointment-rules/create-rules-component/create-rules.vue';
import RulesGridComponent from '../../components/appointment-rules/rules-grid-component/rules-grid.vue';
import AppointmentRulesFilterComponent from '../../components/appointment-rules/appointment-rules-filter-component/appointment-rules-filter-component.vue';
import hgTitle from '../../components/hg-title/hg-title.vue';
import appointmentRulesService from '../../services/appointment-rules/appointment-rules.service';
import HgConfirmActionModal from '../../components/shared/hg-confirm-modal/hg-confirm-modal.vue';
import appointmentRulesEnum from '../../enums/appointment-rules.enum';

async function initialiseData() {
  this.$store.dispatch('appointmentRulesStore/updateLoadingLovData', true);
  this.lovData = await appointmentRulesService.getLovs();
  this.$store.dispatch('appointmentRulesStore/updateLoadingLovData', false);
  this.entitlements = this.getUserEntitlements();
}

function getUserEntitlements() {
  const userObj = localStorage.getItem('user');
  const userEntitlements = _.get(JSON.parse(userObj), 'userEntitlements', []);
  return {
    canCreate: userEntitlements.some((obj) => obj.code === entitlementsEnum.AUTO_APPT_CRT),
    canView: userEntitlements.some((obj) => obj.code === entitlementsEnum.AUTO_APPT_VIEW),
    canEdit: userEntitlements.some((obj) => obj.code === entitlementsEnum.AUTO_APPT_EDT)
  };
}

export default {
  name: 'AppointmentRules',
  components: {
    AppointmentRulesFilterComponent,
    CreateRulesComponent,
    RulesGridComponent,
    hgTitle,
    HgConfirmActionModal
  },
  computed: {
    isFormOpen() {
      return this.$store.getters['appointmentRulesStore/getFormOpenState'];
    },
    isViewForm() {
      return this.$store.getters['appointmentRulesStore/getViewFormState'];
    },
  },
  async beforeRouteLeave(to, from, next) {
    if (this.isFormOpen && !this.isViewForm) {
      const { HEADER, BODY, CONFIRM_BUTTON_TEXT } = appointmentRulesEnum.MODALS.EDIT;
      const response = await this.$refs.confirm.open(HEADER, BODY, CONFIRM_BUTTON_TEXT);
      if (response) {
        this.$store.dispatch('appointmentRulesStore/updateViewFormData', {});
        this.$store.dispatch('appointmentRulesStore/updateCopyRuleData', {});
        this.$store.dispatch('appointmentRulesStore/updateEditFormData', {});
        this.$store.dispatch('appointmentRulesStore/updateCopyStatus', false);
        this.$store.dispatch('appointmentRulesStore/updateEditStatus', false);
        this.$store.dispatch('appointmentRulesStore/updateViewStatus', false);
        this.$store.dispatch('appointmentRulesStore/updateFormOpenStatus', false);
        next();
      } else {
        next(false);
      }
    } else {
      next();
    }
  },
  async created() {
    await this.initialiseData();
  },
  data: (() => ({
    lovData: {},
    entitlements: {}
  })),
  methods: {
    initialiseData,
    getUserEntitlements
  }
};
