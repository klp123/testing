import { setPublicPath } from 'systemjs-webpack-interop';

setPublicPath('@order-management/om-maintenance', 2);
