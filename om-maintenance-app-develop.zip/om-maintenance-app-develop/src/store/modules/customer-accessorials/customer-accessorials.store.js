/* eslint-disable no-shadow */
/** ################ State ################## */
const state = () => ({
  multiSelect: {
    selectedCustomers: [],
    action: 'NONE',
  },
  filters: {
    mode: [],
    customer: [],
    equipment: [],
    chargeCodes: [],
    customerHubDefault: [],
    recordType: [],
    rateQualifier: [],
    expiredDateTime: [],
    effectiveDateTime: [],
    status: [{
      key: 'status',
      value: 'ACTIVE',
      text: 'ACTIVE',
      label: 'Status',
      single: false
    }]
  },
  counts: {
    total: 0,
    showing: 0,
  },
  pagination: {
    page: 1,
    limit: 20,
  },
  loadingPage: false,
  refreshGrid: false
});

/** ################ Getters ################## */
const getters = {
  getFilters: (state) => state.filters,
  getPagination: (state) => state.pagination,
  getCounts: (state) => state.counts,
  getMultiSelectAction: (state) => state.multiSelect.action,
  getRefreshGrid: (state) => state.refreshGrid
};

/** ################ Actions ################## */
const actions = {
  updateFilter({
    commit,
  }, filter) {
    commit('setFilters', filter);
  },
  removeFilter({
    commit,
  }, filter) {
    commit('removeFilter', filter);
  },
  removeFilterByKey({
    commit,
  }, key) {
    commit('removeFilterByKey', key);
  },
  updateLoadingPage({
    commit,
  }, loadingPage) {
    commit('setLoadingPage', loadingPage);
  },
  updatePagination: (context, pagination) => {
    context.commit('setPagination', pagination);
  },
  updateMultiSelectAction({ commit }, action) {
    commit('setMultiSelectAction', action);
  },
  updateRefreshGrid({ commit }, closeDetails) {
    commit('setRefreshGrid', closeDetails);
  }
};

/** ################ Mutations ################## */
const mutations = {
  setFilters(state, filter) {
    // Check if value or object is already in filter
    const filterAlreadyExists = state.filters[filter.key].some((fltr) => fltr.key === filter.key
      && fltr.value === filter.value);

    // Add to filter only if filter doesn't exist to avoid duplication
    if (!filterAlreadyExists) {
      if (filter.single) {
        state.filters[filter.key] = [];
      }
      state.filters[filter.key].push(filter);
    }
  },
  removeFilter(state, filter) {
    // if filter is null empty all filters
    if (!filter) {
      Object.keys(state.filters).forEach((key) => {
        state.filters[key] = [];
      });
    } else if (filter.single) {
      state.filters[filter.key] = [];
    } else {
      // otherwise remove specific filter element
      const currentVal = state.filters[filter.key];
      state.filters[filter.key] = currentVal.filter((item) => item.value !== filter.value);
    }
  },
  removeFilterByKey(state, key) {
    state.filters[key] = [];
  },
  setLoadingPage(state, loadingPage) {
    state.loadingPage = loadingPage;
  },
  setPagination: (state, pagination) => {
    state.pagination.page = pagination.page;
    state.pagination.limit = pagination.limit;
  },
  setMultiSelectAction(state, action) {
    state.multiSelect.action = action;
  },
  setRefreshGrid(state, closeDetails) {
    state.refreshGrid = closeDetails;
  }
};

/** ################ accesorial fuel schedule Store Module ################## */
export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
