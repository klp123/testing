/* eslint-disable no-shadow */
/** ################ State ################## */
const state = () => ({
  LOV: {},
});

/** ################ Getters ################## */
const getters = {
  getLOV: (state) => state.LOV,
};

/** ################ Mutations ################## */
const mutations = {
  updateLOV(state, LOV) {
    state.LOV[`${LOV.type}`] = LOV.value;
  },
  deleteLOV(state, LOV) {
    state.LOV[`${LOV.type}`] = null;
  },
};

/** ################ Actions ################## */
const actions = {
  updateLOV({
    commit,
  }, LOV) {
    commit('updateLOV', LOV);
  },
  deleteLOV({
    commit,
  }, LOV) {
    commit('deleteLOV', LOV);
  },
};

/** ################ LOV Module ################## */
export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
