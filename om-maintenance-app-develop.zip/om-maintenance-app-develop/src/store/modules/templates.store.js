/* eslint-disable no-shadow */
/** ################ State ################## */
const state = () => ({
  filters: {
    templateType: [],
    status: [],
    mode: [],
    customer: [],
    origin: [],
    destination: [],
    quickSearch: [],
  },
  loadingPage: false,
  counts: {
    total: 0,
    showing: 0,
  },
  pagination: {
    page: 1,
    limit: 20,
  },
});

/** ################ Getters ################## */
const getters = {
  getFilters: (state) => state.filters,
  getPagination: (state) => state.pagination,
  getLoadingPage: (state) => state.loadingPage,
  getCounts: (state) => state.counts,
};

/** ################ Actions ################## */
const actions = {
  updateFilter({
    commit,
  }, filter) {
    commit('setFilters', filter);
  },
  updatePagination({
    commit,
  }, pagination) {
    commit('setPagination', pagination);
  },
  updateCounts({
    commit,
  }, counts) {
    commit('setCounts', counts);
  },
  removeFilter({
    commit,
  }, filter) {
    commit('removeFilter', filter);
  },
  removeFilterByKey({
    commit,
  }, key) {
    commit('removeFilterByKey', key);
  },
  updateLoadingPage({
    commit,
  }, loadingPage) {
    commit('setLoadingPage', loadingPage);
  },
};

/** ################ Mutations ################## */
const mutations = {
  setFilters(state, filter) {
    // Check if value or object is already in filter
    const filterAlreadyExists = state.filters[filter.key].some((fltr) => fltr.key === filter.key
      && fltr.value === filter.value);

    // Add to filter only if filter doesn't exist to avoid duplication
    if (!filterAlreadyExists) {
      if (filter.single) {
        state.filters[filter.key] = [];
      }
      state.filters[filter.key].push(filter);
    }
  },
  setPagination(state, pagination) {
    state.pagination.page = pagination.page;
    state.pagination.limit = pagination.limit;
  },
  setCounts(state, counts) {
    state.counts.total = counts.total;
    state.counts.showing = counts.showing;
  },
  removeFilter(state, filter) {
    // if filter is null empty all filters
    if (!filter) {
      Object.keys(state.filters).forEach((key) => {
        state.filters[key] = [];
      });
    } else if (filter.single) {
      state.filters[filter.key] = [];
    } else {
      // otherwise remove specific filter element
      const currentVal = state.filters[filter.key];
      state.filters[filter.key] = currentVal.filter((item) => item.value !== filter.value);
    }
  },
  removeFilterByKey(state, key) {
    state.filters[key] = [];
  },
  setLoadingPage(state, loadingPage) {
    state.loadingPage = loadingPage;
  },

};

/** ################ Template Store Module ################## */
export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
