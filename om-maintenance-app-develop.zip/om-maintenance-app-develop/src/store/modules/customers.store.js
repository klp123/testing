/* eslint-disable no-shadow */
/** ################ State ################## */
const state = () => ({
  appointments: [],
  filters: {
    status: [],
    team: [],
    quickSearch: [],
  },
  loadingPage: false,
  counts: {
    total: 0,
    showing: 0,
  },
  pagination: {
    page: 1,
    limit: 20,
  },
  sort: {
    field: 'name',
    direction: 1
  }
});

/** ################ Getters ################## */
const getters = {
  getFilters: (state) => state.filters,
  getPagination: (state) => state.pagination,
  getLoadingPage: (state) => state.loadingPage,
  getCounts: (state) => state.counts,
  getSort: (state) => state.sort,
};

/** ################ Actions ################## */
const actions = {
  updateFilter({
    commit,
  }, filter) {
    commit('setFilters', filter);
  },
  updatePagination({
    commit,
  }, pagination) {
    commit('setPagination', pagination);
  },
  updateCounts({
    commit,
  }, counts) {
    commit('setCounts', counts);
  },
  updateSort({
    commit,
  }, sort) {
    commit('setSort', sort);
  },
  removeFilter({
    commit,
  }, filter) {
    commit('removeFilter', filter);
  },
  removeFilterByKey({
    commit,
  }, key) {
    commit('removeFilterByKey', key);
  },
  updateLoadingPage({
    commit,
  }, loadingPage) {
    commit('setLoadingPage', loadingPage);
  },
};

/** ################ Mutations ################## */
const mutations = {
  setFilters(state, filter) {
    // Check if value or object is already in filter
    let alreadyExists = false;
    // If filter is object. eg { id: '2345', name: 'TARGET'}
    if (filter.value instanceof (Object)) {
      alreadyExists = state.filters[filter.key].findIndex((obj) => obj.value === filter.value) > -1;
    } else {
      // if filter is string eg: "ACC"
      alreadyExists = state.filters[filter.key].indexOf(filter.value) > -1;
    }

    // Add to filter only if filter doesn't exist to avoid duplication
    if (!alreadyExists) {
      if (filter.single) {
        state.filters[filter.key] = [];
      }

      state.filters[filter.key].push(filter);
    }
  },
  setPagination(state, pagination) {
    state.pagination.page = pagination.page;
    state.pagination.limit = pagination.limit;
  },
  setCounts(state, counts) {
    state.counts.total = counts.total;
    state.counts.showing = counts.showing;
  },
  setSort(state, sort) {
    state.sort.field = sort.field;
    state.sort.direction = sort.direction;
  },
  removeFilter(state, filter) {
    // if filter is null empty all filters
    if (!filter) {
      Object.keys(state.filters).forEach((key) => {
        state.filters[key] = [];
      });
    } else if (filter.single) {
      state.filters[filter.key] = [];
    } else {
      // otherwise remove specific filter element
      const currentVal = state.filters[filter.key];
      state.filters[filter.key] = currentVal.filter((item) => item.value !== filter.value);
    }
  },
  removeFilterByKey(state, key) {
    state.filters[key] = [];
  },
  setLoadingPage(state, loadingPage) {
    state.loadingPage = loadingPage;
  },

};

/** ################ Order Store Module ################## */
export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
