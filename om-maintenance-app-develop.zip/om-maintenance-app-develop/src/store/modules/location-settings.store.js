/* eslint-disable no-shadow */
/** ################ State ################## */
const state = () => ({
  filters: {
    status: [],
    customer: [],
    mode: [],
    location: [],
    quickSearch: [],
  },
  resetPage: null,
});

/** ################ Getters ################## */
const getters = {
  getFilters: (state) => state.filters,
  getResetPage: (state) => state.resetPage,
};

/** ################ Actions ################## */
const actions = {
  updateFilter({ commit }, filter) {
    commit('setFilters', filter);
  },
  removeFilter({ commit }, filter) {
    commit('removeFilter', filter);
  },
  removeFilterByKey({ commit }, key) {
    commit('removeFilterByKey', key);
  },
  updateResetPage({ commit }, value) {
    commit('updateResetPage', value);
  },
};

/** ################ Mutations ################## */
const mutations = {
  setFilters(state, filter) {
    // Check if value or object is already in filter
    const alreadyExists = state.filters[filter.key].some((fltr) => fltr.key === filter.key
      && fltr.value === filter.value);

    if (!alreadyExists) {
      if (filter.single) {
        state.filters[filter.key] = [];
      }

      state.filters[filter.key].push(filter);
    }
  },
  removeFilter(state, filter) {
    // if filter is null empty all filters
    if (!filter) {
      Object.keys(state.filters).forEach((key) => {
        state.filters[key] = [];
      });
    } else if (filter.single) {
      state.filters[filter.key] = [];
    } else {
      // otherwise remove specific filter element
      const currentVal = state.filters[filter.key];
      state.filters[filter.key] = currentVal.filter((item) => item.value !== filter.value);
    }
  },
  removeFilterByKey(state, key) {
    state.filters[key] = [];
  },
  updateResetPage(state, value) {
    state.resetPage = value;
  },
};

/** ################ Location Settings Store Module ################## */
export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
