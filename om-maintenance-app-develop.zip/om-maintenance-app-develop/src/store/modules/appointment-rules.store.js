/* eslint-disable no-shadow */
/** ################ State ################## */
const state = () => ({
  counts: {
    total: 0,
    showing: 0
  },
  pagination: {
    page: 1,
    limit: 20
  },
  filters: {
    customer: [],
    ruleType: [],
    ruleId: []
  },
  resetForm: false,
  isFormOpen: false,
  refreshGrid: false,
  isEditForm: false,
  isViewForm: false,
  editFormData: {},
  viewFormData: {},
  isCopyingRule: false,
  copyRuleData: {},
  loadingLovData: false,
});

/** ################ Getters ################## */
const getters = {
  getPagination: (state) => state.pagination,
  getCounts: (state) => state.counts,
  getFilters: (state) => state.filters,
  getRefreshGrid: (state) => state.refreshGrid,
  getFormOpenState: (state) => state.isFormOpen,
  getFormResetState: (state) => state.resetForm,
  getEditFormState: (state) => state.isEditForm,
  getEditFormData: (state) => state.editFormData,
  getViewFormState: (state) => state.isViewForm,
  getViewFormData: (state) => state.viewFormData,
  getIsCopyingRule: (state) => state.isCopyingRule,
  getCopyRuleData: (state) => state.copyRuleData,
  getLoadingLovData: (state) => state.loadingLovData,
};

/** ################ Actions ################## */
const actions = {
  updatePagination({ commit }, pagination) {
    commit('setPagination', pagination);
  },
  updateCounts({ commit }, counts) {
    commit('setCounts', counts);
  },
  updateFilter({ commit }, filter) {
    commit('setFilters', filter);
  },
  removeFilter({ commit }, filter) {
    commit('removeFilter', filter);
  },
  updateRefreshGrid({ commit }, filter) {
    commit('setRefreshGrid', filter);
  },
  updateFormOpenStatus({ commit }, isFormOpen) {
    commit('updateFormOpenStatus', isFormOpen);
  },
  updateFormResetStatus({ commit }, resetForm) {
    commit('updateFormResetStatus', resetForm);
  },
  updateEditStatus({ commit }, isEditForm) {
    commit('updateEditStatus', isEditForm);
  },
  updateEditFormData({ commit }, data) {
    commit('updateEditFormData', data);
  },
  updateViewStatus({ commit }, isViewForm) {
    commit('updateViewStatus', isViewForm);
  },
  updateViewFormData({ commit }, data) {
    commit('updateViewFormData', data);
  },
  updateCopyStatus({ commit }, isCopyingRule) {
    commit('updateCopyStatus', isCopyingRule);
  },
  updateCopyRuleData({ commit }, data) {
    commit('updateCopyRuleData', data);
  },
  updateLoadingLovData({ commit }, isLoading) {
    commit('updateLoadingLovData', isLoading);
  },
};

/** ################ Mutations ################## */
const mutations = {
  setPagination(state, pagination) {
    state.pagination.page = pagination.page;
    state.pagination.limit = pagination.limit;
  },
  setCounts(state, counts) {
    state.counts.total = counts.total;
    state.counts.showing = counts.showing;
  },
  setFilters(state, filter) {
    // Check if value or object is already in filter
    const alreadyExists = state.filters[filter.key].some(
      (fltr) => fltr.key === filter.key && fltr.value === filter.value
    );

    if (!alreadyExists) {
      if (filter.single) {
        state.filters[filter.key] = [];
      }
      state.filters[filter.key].push(filter);
    }
  },
  removeFilter(state, filter) {
    // if filter is null empty all filters
    if (!filter) {
      Object.keys(state.filters).forEach((key) => {
        state.filters[key] = [];
      });
    } else if (filter.single) {
      state.filters[filter.key] = [];
    } else {
      // otherwise remove specific filter element
      const currentVal = state.filters[filter.key];
      state.filters[filter.key] = currentVal.filter((item) => item.value !== filter.value);
    }
  },
  setRefreshGrid(state, value) {
    state.refreshGrid = value;
  },
  updateEditStatus(state, isEditForm) {
    state.isEditForm = isEditForm;
  },
  updateEditFormData(state, data) {
    state.editFormData = data;
  },
  updateViewStatus(state, isViewForm) {
    state.isViewForm = isViewForm;
  },
  updateViewFormData(state, data) {
    state.viewFormData = data;
  },
  updateCopyStatus(state, isCopyingRule) {
    state.isCopyingRule = isCopyingRule;
  },
  updateCopyRuleData(state, data) {
    state.copyRuleData = data;
  },
  updateFormOpenStatus(state, data) {
    state.isFormOpen = data;
  },
  updateFormResetStatus(state, data) {
    state.resetForm = data;
  },
  updateLoadingLovData(state, isLoading) {
    state.loadingLovData = isLoading;
  },
};

/** ################ Appointment Rules Store Module ################## */
export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
};
