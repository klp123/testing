import Vue from 'vue';
import Vuex from 'vuex';
import moment from 'moment';
import customersStore from './modules/customers.store';
import lovStore from './modules/LOV.store';
import templatesStore from './modules/templates.store';
import customerAccessorialFuelStore from './modules/customer-accessorials/customer-accessorials.store';
import customerAccessorialsUploadDialogFiltersStore from './modules/customer-accessorials/upload-dialog.store';
import locationSettingsStore from './modules/location-settings.store';
import appointmentRulesStore from './modules/appointment-rules.store';

Vue.use(Vuex);
Vue.filter('shortDate', (value) => (value ? moment(value).format('MM/DD/YY') : moment(new Date()).format('MM/DD/YY')));

export default new Vuex.Store({
  modules: {
    customersStore,
    lovStore,
    templatesStore,
    locationSettingsStore,
    appointmentRulesStore,
    customerAccessorialFuelStore,
    customerAccessorialsUploadDialogFiltersStore,
  },
});
