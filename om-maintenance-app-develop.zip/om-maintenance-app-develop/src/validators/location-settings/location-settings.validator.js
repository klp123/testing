export default {
  /**
   * Validate can go early/late hours
   * Not required if you can go early/late to location
   * Otherwise required and hours should be less than 99
   * @param {*} canGoEarlyLate
   * @returns true/false
   */
  validateCanGoEarlyLateHours(canGoEarlyLate) {
    return (v) => {
      if (!canGoEarlyLate) return true;
      return !!v || !v;
    };
  },
  /**
   * Hours should not be required if location closed
   * @param {*} isClosed
   * @returns valid/invalid
   */
  validateHours(isClosed) {
    if (isClosed) return true;
    return (v) => !!v || 'Required';
  },
  /**
   * Validate date range
   * @param {*} value  format: hh:mm-hh:mm
   * hh should be 00-23
   * mm should be 00-59
   * @returns true/false Valid/Invalid
   */
  validateHoursRange(value = '') {
    if (!value || !value.trim()) return true;
    const valArray = value.split('-');

    if (valArray.length !== 2) return 'Invalid Date Range';

    if (!(this.validateTime(valArray[0]) && this.validateTime(valArray[1]))) {
      return 'Invalid Date Range';
    }

    if (
      !valArray[0].split(':')[0]
      || !valArray[0].split(':')[1]
      || !valArray[1].split(':')[0]
      || !valArray[1].split(':')[1]
    ) {
      return 'Invalid Date Range';
    }

    // Check start time with endtime
    const startTime = 60 * Number(valArray[0].split(':')[0]) + Number(valArray[0].split(':')[1]);
    const endTime = 60 * Number(valArray[1].split(':')[0]) + Number(valArray[1].split(':')[1]);

    return endTime >= startTime || 'Invalid Date Range';
  },

  /**
   * Validate if interval1 and interval2 are overlapping given both are valid timeRange
   * @param {*} interval1
   * @param {*} interval2
   * @returns true/Invalid message
   */
  validateIntervalOverlap(interval1, interval2) {
    if (
      !interval1
      || !interval2
      || !this.validateHoursRange(interval1)
      || !this.validateHoursRange(interval2)
    ) {
      return true;
    }

    const interval1End = interval1.split('-')[1];
    const interval1EndNumber = 60 * Number(interval1End.split(':')[0]) + Number(interval1End.split(':')[1]);

    const interval2Start = interval2.split('-')[0];
    const interval2StartNumber = 60 * Number(interval2Start.split(':')[0]) + Number(interval2Start.split(':')[1]);

    // if interval1 end is greater than interval2 Start
    return interval1EndNumber < interval2StartNumber || 'Overlapped Intervals';
  },

  /**
   * Validates time
   * @param {*} time format: hh:mm
   * hh should be 00-23
   * mm should be 00-59
   * @returns true/false Valid/Invalid
   */
  validateTime(time = '') {
    if (!time || !time.trim()) return false;

    const timeArr = time.split(':');
    // if hh:mm  is not given
    // or hh:mm are not numbers
    if (timeArr.length !== 2 || Number.isNaN(timeArr[0]) || Number.isNaN(timeArr[1])) return false;

    // hh should not be greater than 23 and less than 0
    // mm should not be greater than 59 and less than 0
    if (
      Number(timeArr[0]) > 23
      || Number(timeArr[0]) < 0
      || Number(timeArr[1]) > 59
      || Number(timeArr[1]) < 0
    ) {
      return false;
    }
    return true;
  },
};
