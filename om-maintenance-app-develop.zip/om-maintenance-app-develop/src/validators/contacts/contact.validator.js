import { RegexEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';

export default {
  validateEmail() {
    return (v) => !v || RegexEnum.EMAIL.test(v) || 'Invalid Email address';
  },
  validateName() {
    return (v) => !v || RegexEnum.NAME.test(v) || 'Enter a Valid Name';
  },
  validatePhone() {
    return (v) => {
      const cleanedPhone = (v || '').replaceAll('-', '-');
      return !cleanedPhone || RegexEnum.PHONE.test(cleanedPhone) || 'Invalid Phone Number';
    };
  },
  validateWebUrl() {
    return (v) => !v || RegexEnum.WEB_URL.test(v) || 'Invalid URL';
  },
};
