import Vue from 'vue';
import VueGtag from 'vue-gtag';

/**
 * Google analytics setup
 * set googleAnalyticsId from local storage // Ex: G-YX6ZDW23212
 * set user preferences/dimensions(user scope)
 * added routers for auto page tracking
 */
Vue.use(VueGtag, {
  config: {
    id: localStorage.getItem('gaKey'),
  },
});

export default new Vue({});
