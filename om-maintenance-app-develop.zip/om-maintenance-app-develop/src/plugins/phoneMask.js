import Vue from 'vue';
import { VueMaskDirective } from 'v-mask';

Vue.directive('mask', VueMaskDirective);
export default new Vue({});
