import Vue from 'vue';
import _ from 'lodash';
import vuetify from '@hubgroup/hg-vue-library/src/plugins/vuetify';
import singleSpaVue from 'single-spa-vue';
import vueDebounce from 'vue-debounce';
import HgVueLibrary from '@hubgroup/hg-vue-library';
import HgVueOcUtilLib from '@hubgroup/hg-vue-oc-util-lib';
import HgVueOmUtilLib from '@hubgroup/hg-vue-om-util-lib';
import hgAuthorizationDirective from '@hubgroup/hg-om-shared-services/src/directives/hg-authorization.directive';
import vClickOutside from 'v-click-outside';
import VuePhoneMask from './plugins/phoneMask';
import '@hubgroup/hg-vue-library/src/assets/styles/core/global.sass';
import './set-public-path';

import router from './router/index';
import App from './App.vue';
import store from './store';
import VueClipboard from './plugins/vueClipboard';
import VueGtag from './plugins/VueGtag';
import Notifications from './plugins/notifications';

Vue.config.productionTip = false;
Vue.use(HgVueLibrary);
Vue.use(HgVueOcUtilLib);
Vue.use(HgVueOmUtilLib);
Vue.use(vueDebounce);
Vue.use(vClickOutside);
Vue.directive('oc-entitlements', hgAuthorizationDirective);
Vue.set(Vue.prototype, '_', _);

const vueLifecycles = singleSpaVue({
  Vue,
  appOptions: {
    render(h) {
      return h(App, {
        props: {
          // single-spa props are available on the "this" object.
          // Forward them to your component as needed.
          // https://single-spa.js.org/docs/building-applications#lifecyle-props
          // if you uncomment these, remember to add matching prop
          // definitions for them in your App.vue file.
          /*
          name: this.name,
          mountParcel: this.mountParcel,
          singleSpa: this.singleSpa,
          */
        },
      });
    },
    store,
    vuetify,
    router,
    HgVueLibrary,
    HgVueOcUtilLib,
    HgVueOmUtilLib,
    Notifications,
    vueDebounce,
    VueClipboard,
    VueGtag,
    VuePhoneMask,
    vClickOutside,
  },
});

export const { bootstrap } = vueLifecycles;
export const { mount } = vueLifecycles;
export const { unmount } = vueLifecycles;
