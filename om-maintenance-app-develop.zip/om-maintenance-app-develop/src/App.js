import { StartUpService } from '@hubgroup/hg-om-shared-services';
import Location from './pages/location/location.vue';
import Customer from './pages/customer/customer.vue';
import Templates from './pages/templates/templates.vue';
import Preferences from './pages/preferences/preferences.vue';
import hgNotifications from './components/hg-notifications/hg-notifications.vue';

function setTheme() {
  if (this.goDark === true) {
    // eslint-disable-next-line no-return-assign
    return (this.$vuetify.theme.dark = true);
  }
  // eslint-disable-next-line no-return-assign
  return (this.$vuetify.theme.dark = false);
}
function isEntitlementLoaded() {
  return this.entitlementLoaded;
}
export default {
  name: 'App',
  components: {
    Location,
    Customer,
    Templates,
    Preferences,
    hgNotifications
  },
  data: () => ({
    goDark: false,
    entitlementLoaded: false,
  }),
  async beforeMount() {
    if (window.location.hostname.includes('localhost')) {
      await new StartUpService().setup();
    }
    this.entitlementLoaded = true; // Render UI only after startup servivce is completed.
  },
  created() {
    window.addEventListener('themeChange', (event) => {
      this.goDark = event.detail.isDarkMode;
    });
  },
  computed: {
    setTheme,
    isEntitlementLoaded,
  },
};
