import _ from 'lodash';

const filterParams = {
  showTemplateModal: false,
  loadingLocList: false,
  loadingCustList: false,
  templateType: {
    templateTypes: [],
    key: 'templateType',
    menuLabel: 'Template Type',
  },
  status: {
    statuses: [],
    key: 'status',
    menuLabel: 'Status',
  },
  mode: {
    modes: [],
    key: 'mode',
    menuLabel: 'Mode',
  },
  customer: {
    items: [],
    placeholder: 'Start typing to search customers...',
    filterKey: 'customer',
    menuLabel: 'Customer',
  },
  origin: {
    items: [],
    placeholder: 'Search by City, State, or Region',
    filterKey: 'origin',
    menuLabel: 'Origin',
  },
  destination: {
    items: [],
    placeholder: 'Search by City, State, or Region',
    filterKey: 'destination',
    menuLabel: 'Destination',
  },
  quickSearch: {
    disabled: false,
    selectedSearchType: '',
    searchTypeList: [
      {
        label: 'Template Name',
        value: 'templateName',
      },
      {
        label: 'Template ID',
        value: 'templateId',
      },
    ],
  },
};

const appointmentRuleFilterParams = {
  customer: {
    items: [],
    placeholder: 'Search By Customers...',
    filterKey: 'customer',
    filterLabel: 'Customer',
  },
  ruleType: {
    items: [],
    filterKey: 'ruleType',
    filterLabel: 'Rule Type'
  },
};

const locSetttingsFilterParams = {
  location: {
    items: [],
    placeholder: 'Search By City/State...',
    filterKey: 'location',
    filterLabel: 'City / State',
    single: true,
  },
  customer: {
    items: [],
    placeholder: 'Search By Customers...',
    filterKey: 'customer',
    filterLabel: 'Customer',
  },
  status: {
    filterLabel: 'Status',
    subComponents: [
      {
        items: [
          {
            value: true,
            text: 'Yes',
            label: 'Active',
            key: 'status',
            single: true,
          },
          {
            value: false,
            text: 'No',
            label: 'Active',
            key: 'status',
            single: true,
          },
        ],
        title: 'Active',
      },
    ],
  },
  quickSearch: {
    disabled: false,
    selectedSearchType: '',
    defaultSearchType: 'name',
    searchTypeList: [
      {
        label: 'Location Name',
        value: 'name',
      },
      {
        label: 'Location ID',
        value: 'locationId',
      },
    ],
  },
};

const accesorialScheduleUploadDialogFilterParams = {
  showAsfModal: false,
  loadingCustList: false,
  customer: {
    items: [],
    placeholder: 'Start typing to search customers...',
    filterKey: 'customer',
    menuLabel: 'Customer',
  },
  mode: {
    modes: [],
    key: 'mode',
    menuLabel: 'Transport Mode',
  },
  equipmentType: {
    equipmentTypes: [],
    key: 'equipmentType',
    menuLabel: 'Equipment Type',
  },
  publishDateTime: {
    key: 'publishDateTime',
    menuLabel: 'Published Date',
  },
};

const accesorialScheduleFilterParams = {
  showAsfModal: false,
  loadingCustList: false,
  loadingChargeCodesList: false,
  customer: {
    items: [],
    placeholder: 'Start typing to search customers...',
    filterKey: 'customer',
    menuLabel: 'Customer',
  },
  mode: {
    modes: [],
    key: 'mode',
    menuLabel: 'Transport Mode',
  },
  equipment: {
    equipment: [],
    key: 'equipment',
    menuLabel: 'Equipment',
  },
  chargeCodes: {
    items: [],
    placeholder: 'Start typing to search charge codes ...',
    filterKey: 'chargeCode',
    menuLabel: 'Charge Codes',
  },
  recordType: {
    recordTypes: [],
    key: 'recordType',
    menuLabel: 'Record Type',
  },
  customerHubDefault: {
    customerHubDefault: [],
    key: 'customerHubDefault',
    menuLabel: 'Customer/Hub Default',
  },
  rateQualifier: {
    rateQualifiers: [],
    key: 'rateQualifier',
    menuLabel: 'Rate Qualifier',
  },
  expiredDateTime: {
    key: 'expiredDateTime',
    menuLabel: 'Expiration Date',
  },
  status: {
    key: 'status',
    menuLabel: 'Status Type',
    statuses: [],
  }
};
/**
 * Filters
 * @param {*} page
 * Returns filters based on the page being called from
 *
 */
function getFilterParams() {
  return _.cloneDeep(filterParams);
}

function getAccesorialFilterParams() {
  return _.cloneDeep(accesorialScheduleFilterParams);
}

function getAccesorialUploadDialogFilterParams() {
  return _.cloneDeep(accesorialScheduleUploadDialogFilterParams);
}

export default {
  filterParams,
  locSetttingsFilterParams,
  appointmentRuleFilterParams,
  getFilterParams,
  getAccesorialFilterParams,
  accesorialScheduleFilterParams,
  getAccesorialUploadDialogFilterParams,
  accesorialScheduleUploadDialogFilterParams,
};
