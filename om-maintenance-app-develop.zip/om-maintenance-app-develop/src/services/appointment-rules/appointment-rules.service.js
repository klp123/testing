import _ from 'lodash';
import axios from 'axios';
import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import { ApiHelperService, AxiosHelperService } from '@hubgroup/hg-om-shared-services';
import commonService from '../common.service';
import appointmentRulesEnum from '../../enums/appointment-rules.enum';

const lovDataTemplate = {
  modesEnum: [],
  subModesEnum: [],
  appointmentRulesEnum: {
    P: {
      TO: [],
      FROM: []
    },
    D: {
      TO: [],
      FROM: []
    }
  },
  triggersEnum: {
    P: [],
    D: []
  },
  equipmentsEnum: {
    ALL: [],
    IML: [],
    DDR: [],
    ODR: [],
    DED: [],
    HRT: [],
    RLC: [],
    TL: []
  }
};
const defaultEntitlements = {
  canView: true,
  canEdit: false,
  canCreate: false
};

const lovs = _.cloneDeep(lovDataTemplate);

const ajaxRequest = {};
const APPOINTMENT_RULE_ENDPOINT = `${ApiHelperService.getApiUrl()}om-appointment-rule-processor`;

function buildQuery(filters, opts) {
  const query = {
    customerId: _.get(filters, 'customer', []).map((t) => t.value),
    ruleId: _.get(filters, 'ruleId', []).map((t) => t.value),
    ...opts
  };
  const ruleType = _.get(filters, 'ruleType[0].value', '');
  if (ruleType) query.ruleType = ruleType;
  return query;
}

const filterAppointmentRules = (filters, options) => {
  const axiosHelper = AxiosHelperService.attach();
  const apiUrl = `${APPOINTMENT_RULE_ENDPOINT}/rules/filter`;

  // cancel previous ajax if exists
  if (ajaxRequest.FILTER_RULES) {
    ajaxRequest.FILTER_RULES.cancel(RequestErrorTypesEnum.CANCEL_REQUEST);
  }

  // creates a new token for upcomming ajax (overwrite the previous one)
  ajaxRequest.FILTER_RULES = axios.CancelToken.source();

  return axiosHelper.post(apiUrl, buildQuery(filters, options), {
    cancelToken: ajaxRequest.FILTER_RULES.token
  });
};

function postAppointmentRule(appointmentRuleData) {
  const apiUrl = `${APPOINTMENT_RULE_ENDPOINT}/rule/create`;
  const axiosHelper = AxiosHelperService.attach();
  return axiosHelper.post(apiUrl, appointmentRuleData);
}

async function getEquipmentsEnum(equipmentsEnum) {
  try {
    const modeEquipmentCodes = [
      appointmentRulesEnum.LOV_TYPES.EQUIPMENT_TYPE.IML_DDR_ODR,
      appointmentRulesEnum.LOV_TYPES.EQUIPMENT_TYPE.DED_HRT,
      appointmentRulesEnum.LOV_TYPES.EQUIPMENT_TYPE.RLC
    ];
    const modeEquipmentPromises = modeEquipmentCodes.map((equipmentType) => commonService.getCommonLov(equipmentType));
    const submodeEquipmentPromises = lovs.subModesEnum.map((subMode) => commonService.getCommonLov(`OC_${subMode.value}_EQUIPMENT`));
    const [IML_DDR_ODR, DED_HRT, RLC, ...TL] = await Promise.all([...modeEquipmentPromises, ...submodeEquipmentPromises]);
    equipmentsEnum.ALL = [{ displayValue: 'ALL', name: 'ALL', value: { type: 'ALL', length: '', code: 'ALL' } }];
    equipmentsEnum.IML = IML_DDR_ODR;
    equipmentsEnum.DDR = IML_DDR_ODR;
    equipmentsEnum.ODR = IML_DDR_ODR;
    equipmentsEnum.DED = DED_HRT;
    equipmentsEnum.HRT = DED_HRT;
    equipmentsEnum.RLC = RLC;
    equipmentsEnum.TL = _.flatten(TL);
  } catch (error) {
    console.error('Error when getting equipment types:', error);
  }
}

function getEquipmentTypes(modes) {
  if (modes.includes('ALL')) {
    modes = ['ALL', 'IML', 'DDR', 'ODR', 'HRT', 'RLC', 'TL'];
  }
  let equipmentData = [{ displayValue: 'ALL', name: 'ALL', value: { type: 'ALL', length: '', code: 'ALL' } }];
  modes.forEach((mode) => {
    equipmentData = _.unionBy((lovs.equipmentsEnum[mode] || []), equipmentData, 'value.code');
  });
  return _.sortBy(equipmentData, [
    function (eq) {
      return eq.displayValue;
    }
  ]);
}

async function getLovs() {
  try {
    const [
      modesEnum,
      subModesEnum,
      apptDeliveryRuleFrom,
      apptDeliveryRuleTo,
      apptPickupRuleFrom,
      apptPickupRuleTo,
      apptDeliveryTrigger,
      apptPickupTrigger
    ] = await Promise.all([
      commonService.getCommonLov(appointmentRulesEnum.LOV_TYPES.MODES),
      commonService.getCommonLov(appointmentRulesEnum.LOV_TYPES.SUB_MODES),
      commonService.getCommonLov(appointmentRulesEnum.LOV_TYPES.APPT_DELIVERY_RULE_FROM),
      commonService.getCommonLov(appointmentRulesEnum.LOV_TYPES.APPT_DELIVERY_RULE_TO),
      commonService.getCommonLov(appointmentRulesEnum.LOV_TYPES.APPT_PICKUP_RULE_FROM),
      commonService.getCommonLov(appointmentRulesEnum.LOV_TYPES.APPT_PICKUP_RULE_TO),
      commonService.getCommonLov(appointmentRulesEnum.LOV_TYPES.APPT_DELIVERY_TRIGGER),
      commonService.getCommonLov(appointmentRulesEnum.LOV_TYPES.APPT_PICKUP_TRIGGER)
    ]);
    lovs.modesEnum = _.uniq(_.unionBy([{ displayValue: 'ALL', value: 'ALL' }], modesEnum));
    lovs.subModesEnum = subModesEnum;
    lovs.appointmentRulesEnum = {
      P: {
        TO: apptPickupRuleTo,
        FROM: apptPickupRuleFrom
      },
      D: {
        TO: apptDeliveryRuleTo,
        FROM: apptDeliveryRuleFrom
      }
    };
    lovs.triggersEnum = {
      P: apptPickupTrigger,
      D: apptDeliveryTrigger
    };
    await getEquipmentsEnum(lovs.equipmentsEnum);
  } catch (err) {
    console.error('Failed to get LOVs');
  }
  return lovs;
}

function updateRuleStatus(payload) {
  try {
    const apiUrl = `${APPOINTMENT_RULE_ENDPOINT}/update-rule-status`;
    const axiosHelper = AxiosHelperService.attach();
    return axiosHelper.post(apiUrl, payload);
  } catch (error) {
    console.error(`Error while updating rule ${error}`);
    throw error;
  }
}

function updateAppointmentRule(appointmentRuleData) {
  const apiUrl = `${APPOINTMENT_RULE_ENDPOINT}/rule/edit`;
  const axiosHelper = AxiosHelperService.attach();
  return axiosHelper.post(apiUrl, appointmentRuleData);
}

export default {
  lovDataTemplate,
  defaultEntitlements,
  filterAppointmentRules,
  postAppointmentRule,
  getLovs,
  updateRuleStatus,
  updateAppointmentRule,
  getEquipmentTypes
};
