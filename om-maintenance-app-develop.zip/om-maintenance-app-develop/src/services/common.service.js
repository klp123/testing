import Vue from 'vue';
import { CommonLovService } from '@hubgroup/hg-om-shared-services';
import _ from 'lodash';
import store from '../store/index';

class LovService extends CommonLovService {
  constructor() {
    super(store);
  }

  getCommonLov(lovName) {
    return super.getCommonLov(lovName, Vue);
  }

  /**
   *
   * @param {*} filterName The filter name which we are getting lov's
   * @param {*} filterOptions
   * @returns the list of values for filter.
   * For equipment we get the unique list of equipments since we are getting all OM equipments
   *   irrespective of mode from the backend. Value is form of object, convert it to string and
   *   get unique values for the filter
   */
  getFilterList(filterName, filterOptions) {
    let filterList = super.getFilterObjects(filterName, filterName, _.startCase(filterName), filterOptions);
    if (filterName === 'equipment') {
      const formatedFilterList = [];
      filterList.forEach((filterValue) => formatedFilterList.push({
        key: filterValue.key,
        value: filterValue.text || '',
        text: filterValue.text,
        label: filterValue.label,
        single: filterValue.single || false
      }));
      filterList = [...new Map(formatedFilterList.map((equipment) => [equipment.value, equipment])).values()];
    } else if (filterName === 'customerHubDefault') {
      filterList.forEach((filterValue) => {
        filterValue.single = true;
      });
    }
    return filterList;
  }
}
export default new LovService();
