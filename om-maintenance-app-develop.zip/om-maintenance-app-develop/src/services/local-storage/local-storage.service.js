/**
 * Sets value for given key on Local Storage
 * @param {*} key
 * @param {*} value
 */
function setLocalStorage(key, value) {
  if (!key || !value) return;

  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.log(`Error occured while setting ${key} local store`, err);
  }
}

/**
 * Gets Local Storage value for given Key
 * @param {*} key
 * @returns JSON object for given key
 */
function getLocalStorageValue(key) {
  if (!key) return {};
  try {
    return JSON.parse(localStorage.getItem(key));
  } catch (err) {
    console.log(err);
    console.log(`Error occured while getting ${key} local store`, err);
  }
  return {};
}

/**
 * Apply Filter from Local Storage
 * @param {*} filterKey
 * @param callback function to trigger filter selected
 * @param callback function to trigger clear all filters
 */
function applyFilterFromLocalStorage(filterKey, fnFilterSelected) {
  const filters = getLocalStorageValue(filterKey);
  if (filters) {
    Object.values(filters).forEach((filter) => {
      if (filter && filter.length) {
        filter.forEach((element) => {
          if (element.value !== null || element.value !== undefined) {
            fnFilterSelected(element);
          }
        });
      }
    });
  }
}

export default {
  setLocalStorage,
  getLocalStorageValue,
  applyFilterFromLocalStorage,
};
