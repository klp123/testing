import {
  AxiosHelperService,
  ApiHelperService,
} from '@hubgroup/hg-om-shared-services';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';

const axiosHelper = AxiosHelperService.attach();
function mapToFilterObj(customer) {
  return {
    value: customer.id,
    text: customer.name ? `${customer.name}, ${customer.id}` : customer.id,
    label: 'Customer',
    key: 'customer',
  };
}
/**
 * Calls api to get customers
 * with limit of 50
 * @param {*} searchText
 *
 */
async function searchCustomers(searchText) {
  let apiUrl = `${ApiHelperService.getApiUrl()}customers/search?limit=50`;
  if (searchText) {
    // append searchText to url if exists
    apiUrl = `${apiUrl}&searchText=${encodeURIComponent(searchText)}`;
  }

  try {
    const result = await axiosHelper.get(apiUrl);
    return result.data.map((cust) => mapToFilterObj(cust)) || [];
  } catch (err) {
    console.log('Error', err);
    HgNotificationService.errorMessage('Failed to search locations.');
  }
  return [];
}

export default {
  searchCustomers,
};
