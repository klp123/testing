import moment from 'moment-timezone';

function cstStartOf(value, onlyDate = true, format = 'YYYY-MM-DD') {
  try {
    if (onlyDate) {
      const currentTime = moment().format('HH:mm:ss');
      format = `${format}THH:mm:ss`;
      value = `${value}T${currentTime}`;
    }
    return moment(value, format).tz('America/Chicago').startOf('day').toISOString();
  } catch (error) {
    return null;
  }
}

function cstEndOf(value, onlyDate = true, format = 'YYYY-MM-DD') {
  try {
    if (onlyDate) {
      const currentTime = moment().format('HH:mm:ss');
      format = `${format}THH:mm:ss`;
      value = `${value}T${currentTime}`;
    }
    return moment(value, format).tz('America/Chicago').endOf('day').toISOString();
  } catch (error) {
    return null;
  }
}

function cstDateTime(value, format, returnFormat, ignoreUtcOffset) {
  try {
    let date = moment.tz(value, format, 'America/Chicago');
    if (ignoreUtcOffset) {
      date = moment(date).utcOffset(0, true);
    }
    return returnFormat ? date.format(returnFormat) : date.toISOString();
  } catch (error) {
    return null;
  }
}

export default {
  cstStartOf,
  cstEndOf,
  cstDateTime,
};
