// ########### EXTERNAL LIBS ############
import axios from 'axios';
import _ from 'lodash';
// ########### SHARED LIBS ############
import { ApiHelperService, AxiosHelperService } from '@hubgroup/hg-om-shared-services';
import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';

// ########### ENUMS ############
const axiosHelper = AxiosHelperService.attach();

const currentRequest = {};

/**
 * Get filter object from store filter object
 * @param {*} filters
 */
function getFilterObject(filters) {
  const filterObj = {
    transportMode: filters.transportMode.map((mode) => mode.value),
    customerId: filters.customer.map((cust) => cust.value && cust.value.value),
    equipmentType: filters.equipmentType.map((equipmentType) => equipmentType.value),
    country: filters.country.map((country) => country.value),
    publishDateTime: filters.publishDateTime.map((publishDateTime) => publishDateTime.value)
  };
  const filterPayload = {
    customer: {
      id: _.get(filterObj, 'customerId[0]', '')
    },
    transportMode: _.get(filterObj, 'transportMode[0]', ''),
    equipment: filterObj.equipmentType.map((equipmentType) => ({
      equipmentCode: _.get(equipmentType, 'value.code', ''),
      equipmentType: _.get(equipmentType, 'value.type', ''),
      length: {
        amount: _.get(equipmentType, 'value.length', ''),
      },
    })),
    country: _.get(filterObj, 'country[0]', ''),
    publishDateTime: {
      dateTime: _.get(filterObj, 'publishDateTime[0]', '')
    }
  };
  return filterPayload;
}

function publishedFiles(filters) {
  const apiUrl = `${ApiHelperService.getApiUrl('om-fuel')}fuel-scales`;
  const filterParams = {
    ...getFilterObject(filters),
  };

  // if there is any current request waiting, cancel it
  if (currentRequest.FILTER_UPLOAD_DIALOG_PUBLISHED_FILES) {
    currentRequest.FILTER_UPLOAD_DIALOG_PUBLISHED_FILES.cancel(
      RequestErrorTypesEnum.CANCEL_REQUEST
    );
  }

  // creates a new token for upcomming request (overwrite the previous one)
  currentRequest.FILTER_UPLOAD_DIALOG_PUBLISHED_FILES = axios.CancelToken.source();

  return axiosHelper.post(apiUrl, filterParams, {
    cancelToken: currentRequest.FILTER_UPLOAD_DIALOG_PUBLISHED_FILES.token
  });
}

export default {
  publishedFiles
};
