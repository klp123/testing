// ########### EXTERNAL LIBS ############
import axios from 'axios';
import _ from 'lodash';

// ########### SERVICES ############
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';

// ########### SHARED LIBS ############
import { ApiHelperService, AxiosHelperService } from '@hubgroup/hg-om-shared-services';
import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
// ########### ENUMS ############
const axiosHelper = AxiosHelperService.attach();

const currentRequest = {};

/**
 * Get options object for request
 * @param {*} options
 */
function getMetadataOptions(options) {
  return {
    page: options.page || 1,
    limit: options.limit,
    sortField: 'createdDateTime',
    sortDirection: -1,
  };
}

/**
 * Get filter object from store filter object
 * @param {*} filters
 */
function getFilterObject(filters) {
  const filterObj = {
    transportMode: filters.mode && filters.mode.length
      ? filters.mode.map((mode) => mode.value) : [],
    customerId: filters.customer && filters.customer.length
      ? filters.customer.map((cust) => cust.value) : [],
    equipment: filters.equipment && filters.equipment.length
      ? filters.equipment.map((equipment) => equipment.value).flat() : [],
    chargeCode: filters.chargeCodes && filters.chargeCodes.length
      ? filters.chargeCodes.map((chargeCode) => chargeCode.value) : [],
    type: filters.recordType && filters.recordType.length
      // eslint-disable-next-line radix
      ? filters.recordType.map((recordType) => recordType.value) : [],
    isUsingHubDefault: filters.customerHubDefault && filters.customerHubDefault.length
      // eslint-disable-next-line radix
      ? filters.customerHubDefault.map((customerHubDefault) => _.get(customerHubDefault.value, 'status')) : [],
    rateQualifier: filters.rateQualifier && filters.rateQualifier.length
      // eslint-disable-next-line radix
      ? filters.rateQualifier.map((rateQualifier) => rateQualifier.value) : [],
    expiredDateTime: filters.expiredDateTime && filters.expiredDateTime.length
      // eslint-disable-next-line radix
      ? filters.expiredDateTime.map((expiredDateTime) => expiredDateTime.value) : [],
    effectiveDateTime: filters.effectiveDateTime && filters.effectiveDateTime.length
      // eslint-disable-next-line radix
      ? filters.effectiveDateTime.map((effectiveDateTime) => effectiveDateTime.value) : [],
    status: filters.status && filters.status.length
      ? filters.status.map((status) => status.value) : [],
    vendorId: filters.vendorId && filters.vendorId.length
      ? filters.vendorId.map((vendorId) => vendorId.value) : [],
    railScac: filters.railScac && filters.railScac.length
      ? filters.railScac.map((railScac) => railScac.value) : [],
    rampScac: filters.rampScac && filters.rampScac.length
      ? filters.rampScac.map((rampScac) => rampScac.value) : [],
    bundleCode: filters.bundleCode && filters.bundleCode.length
      ? filters.bundleCode.map((bundleCode) => bundleCode.value) : [],
    serviceType: filters.serviceType && filters.serviceType.length
      ? filters.serviceType.map((serviceType) => serviceType.value) : [],
    originId: filters.originId && filters.originId.length
      ? filters.originId.map((originId) => originId.value) : [],
    originCity: filters.originCity && filters.originCity.length
      ? filters.originCity.map((originCity) => originCity.value) : [],
    originState: filters.originState && filters.originState.length
      ? filters.originState.map((originState) => originState.value) : [],
    originPostalCode: filters.originPostalCode && filters.originPostalCode.length
      ? filters.originPostalCode.map((originPostalCode) => originPostalCode.value) : [],
    destinationId: filters.destinationId && filters.destinationId.length
      ? filters.destinationId.map((destinationId) => destinationId.value) : [],
    destinationCity: filters.destinationCity && filters.destinationCity.length
      ? filters.destinationCity.map((destinationCity) => destinationCity.value) : [],
    destinationState: filters.destinationState && filters.destinationState.length
      ? filters.destinationState.map((destinationState) => destinationState.value) : [],
    destinationPostalCode: filters.destinationPostalCode && filters.destinationPostalCode.length
      ? filters.destinationPostalCode.map((destinationPostalCode) => destinationPostalCode.value) : [],
  };
  return filterObj;
}

function customerAccesorialFuel(filters, options) {
  const apiUrl = `${ApiHelperService.getApiUrl('om-accessorials')}accessorials-and-fuel/filter`;
  const filterParams = {
    ...getFilterObject(filters),
    ...getMetadataOptions(options),
  };

  // if there is any current request waiting, cancel it
  if (currentRequest.FILTER_ACCESORIAL_FUEL_SCHEDULE) {
    currentRequest.FILTER_ACCESORIAL_FUEL_SCHEDULE.cancel(RequestErrorTypesEnum.CANCEL_REQUEST);
  }

  // creates a new token for upcomming request (overwrite the previous one)
  currentRequest.FILTER_ACCESORIAL_FUEL_SCHEDULE = axios.CancelToken.source();

  return axiosHelper.post(apiUrl, filterParams, {
    cancelToken: currentRequest.FILTER_ACCESORIAL_FUEL_SCHEDULE.token,
  });
}

function mapToFilterObj(chargeCode) {
  return {
    value: chargeCode.value,
    text: chargeCode.value ? ` ${chargeCode.displayValue} - ${chargeCode.value}` : '',
    name: chargeCode.displayValue,
    label: 'Charge Code',
    key: 'chargeCodes'
  };
}

async function getAccessorialChargeCodes(searchText = '', limit = 20) {
  const apiUrl = `${ApiHelperService.getApiUrl('om-accessorials')}accessorial-charge-codes/search?limit=${limit}&searchText=${encodeURIComponent(searchText)}`;
  try {
    if (currentRequest.SEARCH_CHARGE_CODES) {
      currentRequest.SEARCH_CHARGE_CODES.cancel(RequestErrorTypesEnum.CANCEL_REQUEST);
    }

    // creates a new token for upcoming search (overwrite the previous one)
    currentRequest.SEARCH_CHARGE_CODES = axios.CancelToken.source();

    const result = await axiosHelper.get(apiUrl, { cancelToken: currentRequest.SEARCH_CHARGE_CODES.token });
    const data = result.data ? result.data.filter((item) => !_.isEmpty(item)) : [];
    const mappedData = data ? data.map((chargeCode) => mapToFilterObj(chargeCode)) || [] : [];
    return mappedData;
  } catch (err) {
    if (err.message !== 'CANCEL_REQUEST') HgNotificationService.errorMessage('Failed to search customers.');
    return [];
  }
}

async function searchLocations(searchText, limit = 20) {
  const apiUrl = `${ApiHelperService.getOCApiUrl()}/search/master-location?limit=${limit}&searchText=${encodeURIComponent(searchText)}`;
  try {
    if (currentRequest.SEARCH_LOCATIONS) {
      currentRequest.SEARCH_LOCATIONS.cancel(RequestErrorTypesEnum.CANCEL_REQUEST);
    }

    // creates a new token for upcoming search (overwrite the previous one)
    currentRequest.SEARCH_LOCATIONS = axios.CancelToken.source();

    const result = await axiosHelper.get(apiUrl, { cancelToken: currentRequest.SEARCH_LOCATIONS.token });
    const data = result.data.paginatedResults || [];
    return data;
  } catch (err) {
    if (err.message !== 'CANCEL_REQUEST') HgNotificationService.errorMessage('Failed to search locations.');
    return [];
  }
}

async function searchCarriers(searchText, limit = 20) {
  const apiUrl = `${ApiHelperService.getApiUrl('om-accessorials')}carrier/search?limit=${limit}&searchText=${searchText}`;
  try {
    if (currentRequest.SEARCH_CARRIERS) {
      currentRequest.SEARCH_CARRIERS.cancel(RequestErrorTypesEnum.CANCEL_REQUEST);
    }

    // creates a new token for upcoming search (overwrite the previous one)
    currentRequest.SEARCH_CARRIERS = axios.CancelToken.source();

    const result = await axiosHelper.get(apiUrl, { cancelToken: currentRequest.SEARCH_CARRIERS.token });
    const data = result.data.filter((item) => !item.meta) || [];
    return data;
  } catch (err) {
    if (err.message !== 'CANCEL_REQUEST') HgNotificationService.errorMessage('Failed to search locations.');
    return [];
  }
}

async function searchCities(searchText, limit = 20) {
  const apiUrl = `https://microservicesdev.hubgroup.com/location/cities?limit=${limit}&text=${searchText}`;
  try {
    if (currentRequest.SEARCH_CITIES) {
      currentRequest.SEARCH_CITIES.cancel(RequestErrorTypesEnum.CANCEL_REQUEST);
    }

    // creates a new token for upcoming search (overwrite the previous one)
    currentRequest.SEARCH_CITIES = axios.CancelToken.source();

    const result = await axiosHelper.get(apiUrl, { cancelToken: currentRequest.SEARCH_CITIES.token });
    const data = result.data || [];
    return data;
  } catch (err) {
    if (err.message !== 'CANCEL_REQUEST') HgNotificationService.errorMessage('Failed to search locations.');
    return [];
  }
}

export default {
  customerAccesorialFuel,
  getAccessorialChargeCodes,
  searchLocations,
  searchCarriers,
  searchCities
};
