// ########### SHARED LIBS ############
import { ApiHelperService, AxiosHelperService } from '@hubgroup/hg-om-shared-services';

// ########### ENUMS ############
const axiosHelper = AxiosHelperService.attach();

function doeRegionalRatesData(publishDate) {
  const apiUrl = `${ApiHelperService.getApiUrl('om-fuel')}doe-fuel-rates`;
  return axiosHelper.post(apiUrl, { 'publishDateTime.dateTime': publishDate });
}

export default {
  doeRegionalRatesData,
};
