// ########### SHARED LIBS ############
import _ from 'lodash';
import { ApiHelperService, AxiosHelperService } from '@hubgroup/hg-om-shared-services';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import axios from 'axios';
// ########### ENUMS ############
const axiosHelper = AxiosHelperService.attach();

const ajaxRequest = {};

function mapToFilterObj(hubDefaults) {
  const hubDefault = hubDefaults[0];
  return {
    text: hubDefault.hubDefault.name,
    name: hubDefault.hubDefault.name,
    label: 'Hub Default',
    key: 'hubDefault',
    items: hubDefaults
  };
}

async function saveChargeCodeUsingHubDefaults(formattedPayload) {
  try {
    const apiUrl = `${ApiHelperService.getApiUrl('om-accessorials')}/accessorials-and-fuel/upsert/use-hub-defaults`;
    const response = await axiosHelper.post(apiUrl, formattedPayload);
    if (response.data && response.data.length === response.data.filter((item) => item.result.status).length) {
      HgNotificationService.successMessage('Charge code(s) created/updated successfully.');
    } else {
      HgNotificationService.errorMessage(response.message || 'Failed to create/update Charge code(s).');
    }
    return true;
  } catch (error) {
    HgNotificationService.errorMessage(_.get(error, 'response.data.message') || 'Error while saving Charge Code details.');
  }
  return false;
}

async function searchHubDefaultData(formattedPayload) {
  const apiUrl = `${ApiHelperService.getApiUrl('om-accessorials')}hub-defaults/search-by-text?searchText=${formattedPayload}`;
  try {
    if (ajaxRequest.SEARCH_HUB_DEFAULTS) {
      ajaxRequest.SEARCH_HUB_DEFAULTS.cancel(RequestErrorTypesEnum.CANCEL_REQUEST);
    }

    // creates a new token for upcomming ajax (overwrite the previous one)
    ajaxRequest.SEARCH_HUB_DEFAULTS = axios.CancelToken.source();

    const result = await axiosHelper.get(apiUrl, {
      cancelToken: ajaxRequest.SEARCH_HUB_DEFAULTS.token,
    });

    const data = result.data ? result.data.filter((item) => !_.isEmpty(item)) : [];
    const groupedDataByHubDefaultName = Object.values(data.reduce((acc, item) => {
      acc[item.hubDefault.name] = [...(acc[item.hubDefault.name] || []), item];
      return acc;
    }, {}));
    const mappedData = groupedDataByHubDefaultName ? groupedDataByHubDefaultName.map((cust) => mapToFilterObj(cust)) || [] : [];
    return mappedData;
  } catch (err) {
    if (err.message !== 'CANCEL_REQUEST') HgNotificationService.errorMessage('Failed to search hub defaults.');
    return null;
  }
}

async function unassignChargeCodeUsingHubDefaults(chargeCodeId) {
  try {
    const apiUrl = `${ApiHelperService.getApiUrl('om-accessorials')}hub-defaults/unassign/${chargeCodeId}`;
    const response = await axiosHelper.post(apiUrl);
    return response;
  } catch (error) {
    return { errorMessage: `Error: ${error} occurred while unassigning from Hub Default Base Record.` };
  }
}

export default {
  searchHubDefaultData,
  saveChargeCodeUsingHubDefaults,
  unassignChargeCodeUsingHubDefaults
};