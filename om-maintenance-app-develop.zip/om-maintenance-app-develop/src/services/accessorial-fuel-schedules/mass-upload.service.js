import { saveAs } from 'file-saver';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
// ########### SHARED LIBS ############
import { ApiHelperService, AxiosHelperService } from '@hubgroup/hg-om-shared-services';

// ########### ENUMS ############
const axiosHelper = AxiosHelperService.attach();

const downloadTemplate = async () => {
  const apiUrl = `${ApiHelperService.getApiUrl('om-fuel')}fuel-scales/export/template`;
  const response = await axiosHelper.get(apiUrl, {
    responseType: 'blob'
  });
  const blob = new Blob([response.data], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });
  saveAs(blob, 'om-customer-fuel-schedules.xlsx');
};

const addFuelScales = async (data, isConfirmed) => {
  try {
    const apiUrl = `${ApiHelperService.getApiUrl('om-fuel')}fuel-scales/upload?confirmed=${isConfirmed}`;
    const response = await axiosHelper.post(apiUrl, data);
    if (response.status === 200 && response.data) {
      return response.data;
    }
    HgNotificationService.errorMessage('Error while uploading data.');
  } catch (error) {
    HgNotificationService.errorMessage('Error while uploading fuel scales data.');
  }
};

export default {
  downloadTemplate,
  addFuelScales,
};