// ########### SHARED LIBS ############
import { ApiHelperService, AxiosHelperService } from '@hubgroup/hg-om-shared-services';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
// ########### ENUMS ############
const axiosHelper = AxiosHelperService.attach();

function saveChargeCodeData(formattedPayload) {
  try {
    const apiUrl = `${ApiHelperService.getApiUrl('om-accessorials')}accessorials-and-fuel/upsert`;
    return axiosHelper.post(apiUrl, formattedPayload);
  } catch (error) {
    HgNotificationService.errorMessage('Error while saving Charge Code details.');
  }
}
function deleteChargeCodeData(chargeCodeId) {
  try {
    const apiUrl = `${ApiHelperService.getApiUrl('om-accessorials')}accessorials-and-fuel/delete-charge-code`;
    return axiosHelper.post(apiUrl, { chargeCodeId });
  } catch (error) {
    console.error('Error', error);
    HgNotificationService.errorMessage('Error while deleting Charge Code details.');
  }
}

async function getChargeCodeHistory(chargeCodeId) {
  let chargeCodeHistory;
  const apiUrl = `${ApiHelperService.getApiUrl('om-accessorials')}/accessorials-and-fuel/history/${chargeCodeId}`;
  const res = await axiosHelper.get(apiUrl);
  if (res.status === 200 && res.data && res.data.length) {
    chargeCodeHistory = res.data;
  }
  return chargeCodeHistory;
}

export default {
  saveChargeCodeData,
  deleteChargeCodeData,
  getChargeCodeHistory
};
