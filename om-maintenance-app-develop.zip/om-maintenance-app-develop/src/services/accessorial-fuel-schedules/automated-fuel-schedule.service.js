// ########### SHARED LIBS ############
import { ApiHelperService, AxiosHelperService } from '@hubgroup/hg-om-shared-services';

// ########### ENUMS ############
const axiosHelper = AxiosHelperService.attach();

function createFuelSchedule(fuelSchedule) {
  const apiUrl = `${ApiHelperService.getApiUrl('om-fuel')}fuel-schedules/create`;
  return axiosHelper.post(apiUrl, fuelSchedule);
}

async function getFuelSchedule(chargeCodeIdentifier) {
  let fuelSchedule;
  const apiUrl = `${ApiHelperService.getApiUrl('om-fuel')}fuel-schedules/${chargeCodeIdentifier}`;
  const res = await axiosHelper.get(apiUrl);
  if (res.status === 200 && res.data && res.data.length) {
    fuelSchedule = res.data;
  }
  return fuelSchedule;
}

async function calculateFuelSchedule(fuelSchedule) {
  let calcData;
  const apiUrl = `${ApiHelperService.getApiUrl('om-fuel')}fuel-schedules/calculate`;
  const res = await axiosHelper.post(apiUrl, fuelSchedule);
  if (res.status === 200 && res.data) {
    calcData = res.data;
  }
  return calcData;
}

export default {
  createFuelSchedule,
  getFuelSchedule,
  calculateFuelSchedule
};
