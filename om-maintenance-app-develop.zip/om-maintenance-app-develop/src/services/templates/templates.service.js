// ########### EXTERNAL LIBS ############
import axios from 'axios';

// ########### SHARED LIBS ############
import { ApiHelperService, AxiosHelperService } from '@hubgroup/hg-om-shared-services';
import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';

// ########### ENUMS ############
import * as _ from 'lodash';

const axiosHelper = AxiosHelperService.attach();

const currentRequest = {};

/**
 * Get options object for request
 * @param {*} options
 */
function getMetadataOptions(options) {
  return {
    page: options.page || 1,
    limit: options.limit,
    sortField: 'modifiedDateTime',
    sortDirection: -1,
  };
}

/**
 * Parse location string based on field
 * @param {*} locationString
 * @returns { city: '', state: ''}
 */
function parseLocation(loc) {
  if (!loc) return [];
  switch (loc.field) {
    case 'region':
      return {
        region: loc.value,
      };

    case 'state':
      return {
        state: loc.value,
      };

    case 'city-state':
      return {
        city: loc.value.split(',')[0].trim().toUpperCase(), state: loc.value.split(',')[1].trim().toUpperCase(),
      };

    default:
      if (loc.value.split(',').length === 2) {
        return {
          city: loc.value.split(',')[0].trim().toUpperCase(),
          state: loc.value.split(',')[1].trim().toUpperCase(),
        };
      }
      return [];
  }
}

function parseQuickSearch(filters) {
  const mappedQuickSearch = filters.quickSearch
    && filters.quickSearch.length
    ? filters.quickSearch.map((qs) => ({ type: qs.type, value: qs.value }))[0] : null;
  return mappedQuickSearch;
}

/**
 * Get filter object from store filter object
 * @param {*} filters
 */
function getFilterObject(filters) {
  const filterObj = {
    templateType: filters.templateType && filters.templateType.length
      ? filters.templateType.map((templateType) => templateType.value) : [],
    status: filters.status && filters.status.length
      ? filters.status.map((status) => status.value) : [],
    mode: filters.mode && filters.mode.length
      ? filters.mode.map((mode) => mode.value) : [],
    customerId: filters.customer && filters.customer.length
      ? filters.customer.map((cust) => cust.value) : [],
    origin: filters.origin && filters.origin.length
      ? filters.origin.map((loc) => parseLocation(loc)) : [],
    destination: filters.destination && filters.destination.length
      ? filters.destination.map((loc) => parseLocation(loc)) : [],
    quicksearch: parseQuickSearch(filters),
  };
  return filterObj;
}

function filterTemplates(filters, options) {
  const apiUrl = `${ApiHelperService.getApiUrl('om-oc-template')}templates/filter`;
  const filterParams = {
    ...getFilterObject(filters),
    ...getMetadataOptions(options),
  };

  // if there is any current request waiting, cancel it
  if (currentRequest.FILTER_TEMPLATES) {
    currentRequest.FILTER_TEMPLATES.cancel(RequestErrorTypesEnum.CANCEL_REQUEST);
  }

  // creates a new token for upcomming request (overwrite the previous one)
  currentRequest.FILTER_TEMPLATES = axios.CancelToken.source();

  return axiosHelper.post(apiUrl, filterParams, {
    cancelToken: currentRequest.FILTER_TEMPLATES.token,
  });
}

/**
 * Update the template status
 */
async function updateTemplateStatus(templateDetails, status) {
  const reqPayload = {
    template: {
      id: _.get(templateDetails, 'templateId', ''),
      name: _.get(templateDetails, 'name', ''),
      type: _.get(templateDetails, 'type', ''),
    },
    customer: {
      id: _.get(templateDetails, 'customer.id', ''),
    },
    mode: _.get(templateDetails, 'mode', ''),
    statusToUpdate: status,
    stops: _.get(templateDetails, 'stops', []).map((stop) => ({ location: stop.location })),
  };
  const apiUrl = `${ApiHelperService.getApiUrl('om-oc-template')}template/update-status`;
  const resp = await axiosHelper.post(apiUrl, reqPayload);
  return resp.data;
}

/**
 * Get template details by tepmplateId
 * @param templateId
 */
async function getTemplateDetailsById(templateId) {
  const apiUrl = `${ApiHelperService.getApiUrl('om-oc-template')}template/${templateId}`;
  console.log(apiUrl);
  const resp = await axiosHelper.get(apiUrl);
  return resp.data.length > 0 ? resp.data[0] : [];
}

export default {
  filterTemplates,
  updateTemplateStatus,
  getTemplateDetailsById,
};
