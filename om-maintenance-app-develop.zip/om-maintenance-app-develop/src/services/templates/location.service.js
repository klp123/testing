/* eslint-disable no-case-declarations */
import * as _ from 'lodash';
import { AxiosHelperService, ApiHelperService } from '@hubgroup/hg-om-shared-services';

const axiosHelper = AxiosHelperService.attach();

/**
 *
 * @param {*} regions
 * @param {*} stop Origin, destination etc
 * @returns mapped formatted regions for filter list
 * single --> indicates only one field is selectable from the list for the filters
 */
function mapRegions(regions, stop) {
  return regions.map((region) => ({
    value: `${region.region}`,
    text: `${_.startCase(_.toLower(region.region))}`,
    label: stop,
    key: stop.toLowerCase(),
    field: 'region',
    single: true,
  })) || [];
}

/**
 *
 * @param {*} States
 * @param {*} stop Origin, destination etc
 * @returns mapped formatted states for filter list
 * single --> indicates only one field is selectable from the list for the filters
 */

function mapStates(states, stop) {
  return states.map((state) => ({
    value: `${state.state}`,
    text: `${state.state}`,
    label: stop,
    key: stop.toLowerCase(),
    field: 'state',
    single: true,
  })) || [];
}

/**
 *
 * @param {*} States
 * @param {*} stop Origin, destination etc
 * @returns mapped formatted City, States formatted values for filter list
 * single --> indicates only one field is selectable from the list for the filters
 */
function mapCityStates(cityStates, stop) {
  return cityStates.map((cityState) => ({
    value: `${cityState.city}, ${cityState.state}`,
    text: `${cityState.city}, ${cityState.state}`,
    label: stop,
    key: stop.toLowerCase(),
    field: 'city-state',
    single: true,
  })) || [];
}

/**
 * Backend to get location list
 * @param {*} searchText
 */
async function searchLocation(searchText, stop) {
  let apiUrl = `${ApiHelperService.getApiUrl()}search/location`;
  if (searchText) {
    // append searchText to url if exists
    apiUrl = `${apiUrl}?searchText=${encodeURIComponent(searchText)}`;
  }
  try {
    const result = await axiosHelper.get(apiUrl);
    const regions = mapRegions(result.data.regions, stop);
    const states = mapStates(result.data.states, stop);
    const cityStates = mapCityStates(result.data.cities, stop);

    return _.concat(regions, states, cityStates);
  } catch (err) {
    console.error('Error while searching location', err);
    return [];
  }
}

export default {
  searchLocation,
};
