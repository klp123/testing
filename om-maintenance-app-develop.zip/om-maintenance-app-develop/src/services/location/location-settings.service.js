import _ from 'lodash';
import { AxiosHelperService, ApiHelperService } from '@hubgroup/hg-om-shared-services';
import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import moment from 'moment';
import axios from 'axios';
import locationSettingsValidator from '../../validators/location-settings/location-settings.validator';
import contactValidator from '../../validators/contacts/contact.validator';
import dockHoursService from './dock-hours.service';
import customerService from '../customer/customer.service';

const axiosHelper = AxiosHelperService.attach();
const ajaxRequest = {};

/**
 * Get Location settings API
 * @param {*} locationMasterId
 * @param {*} customerId
 * @returns location settings
 */
async function getLocationSettings(locationMasterId, customerId) {
  const apiUrl = `${ApiHelperService.getApiUrl()}location-settings/${locationMasterId}/${customerId}`;
  try {
    return (await axiosHelper.get(apiUrl)).data;
  } catch (err) {
    return [];
  }
}

/**
 * Parse Phone number
 * @param {*} phoneStr 111-111-111-9999 (111-111-1111 => phone number, 9999 => extension)
 * @param {*} countryCode { USA, MEX, CAN }
 * @param {*} type { MOBILE, HOME }
 * @returns Phone object
 */
function parsePhoneNumber(phoneStr = '', countryCode, type) {
  const cleanPhone = (phoneStr || '').replaceAll('-', '');
  return {
    type: type || 'MOBILE',
    countryCode,
    extension: cleanPhone.substring(10) || '',
    number: cleanPhone.substring(0, 10),
  };
}

/**
 * Parse Location setting object from UI modal to API modal
 * @param {*} locationSettings
 * @returns locationSetting formatted for API
 */
function parseLocationSettings(locationSettings) {
  const locSettingsObj = {};

  locSettingsObj.generalInstructions = _.cloneDeep(locationSettings.generalInstructions);

  if (locationSettings.appointmentContacts) {
    const appointmentContacts = _.cloneDeep(locationSettings.appointmentContacts);
    appointmentContacts.forEach((contact) => {
      if (contact.phone) {
        contact.phone = parsePhoneNumber(
          contact.phone.value,
          contact.phone.countryCode,
          contact.phone.type,
        );
      }
    });
    locSettingsObj.appointmentContacts = appointmentContacts;
  } else {
    locSettingsObj.appointmentContacts = [];
  }

  locSettingsObj.loadDropRules = _.cloneDeep(locationSettings.loadDropRules);
  if (!locSettingsObj.loadDropRules) locSettingsObj.loadDropRules = [];

  const pickup = _.cloneDeep(locationSettings.pickup);
  delete pickup.rules;
  pickup.hours = dockHoursService.parseDockHours(pickup.hours);
  pickup.canGoEarlyMinutes = Number(pickup.canGoEarlyMinutes) * 60;
  pickup.canGoLateMinutes = Number(pickup.canGoLateMinutes) * 60;
  locSettingsObj.pickup = pickup;

  const delivery = _.cloneDeep(locationSettings.delivery);
  delete delivery.rules;
  delivery.hours = dockHoursService.parseDockHours(delivery.hours);
  delivery.canGoEarlyMinutes = Number(delivery.canGoEarlyMinutes) * 60;
  delivery.canGoLateMinutes = Number(delivery.canGoLateMinutes) * 60;
  locSettingsObj.delivery = delivery;

  return locSettingsObj;
}

function getContactFormObject(contact = {}) {
  return {
    name: contact.name || '',
    email: contact.email || '',
    websitePortal: contact.websitePortal || '',
    phone: {
      countryCode: _.get(contact, 'phone.countryCode', 'USA'),
      type: _.get(contact, 'phone.type', 'MOBILE'),
      value: _.get(contact, 'phone.number', '') + _.get(contact, 'phone.extension', ''),
      valueRules: [contactValidator.validatePhone()],
    },
    rules: {
      email: contactValidator.validateEmail,
      name: contactValidator.validateName,
      webUrl: contactValidator.validateWebUrl,
    },
  };
}

function getLoadDropRuleFormObject(loadDropRule = {}) {
  return {
    mode: loadDropRule.name || '',
    stopType: loadDropRule.stopType || '',
    loadingType: loadDropRule.loadingType || '',
  };
}

/**
 * Parse Location settings from API modal to UI modal
 * @param {*} locSettings
 * @returns
 */
async function getLocationSettingsFormObject(locSettings) {
  const locationContacts = [];
  const locationCustomerId = _.get(locSettings, 'customerId', '');
  let locationCustomerName;
  if (_.has(locSettings, 'appointmentContacts') && locSettings.appointmentContacts.length) {
    locSettings.appointmentContacts.forEach(
      (contact) => locationContacts.push(getContactFormObject(contact)),
    );
  } else {
    locationContacts.push(getContactFormObject());
  }
  if (Boolean(locationCustomerId) && locationCustomerName === undefined) {
    const customerData = await customerService.getCustomerData(locationCustomerId);
    locSettings.customerName = _.get(customerData, 'data.name', '');
  }

  return {
    appointmentContacts: locationContacts,
    generalInstructions: {
      internalNotes: _.get(locSettings, 'generalInstructions.internalNotes', ''),
      appointmentNotes: _.get(locSettings, 'generalInstructions.appointmentNotes', '-'),
    },
    customerName: _.get(locSettings, 'customerName', ''),
    locationDetails: {
      locationId: _.get(locSettings, 'locationId'),
      address: _.get(locSettings, 'address', ''),
      city: _.get(locSettings, 'city', ''),
      state: _.get(locSettings, 'state', ''),
      postalCode: _.get(locSettings, 'postalCode', ''),
      country: _.get(locSettings, 'country', ''),
      name: _.get(locSettings, 'name', ''),
      cleanseStatus: _.get(locSettings, 'cleanseStatus', ''),
      status: _.get(locSettings, 'status', ''),
    },
    pickup: {
      hours: dockHoursService.mapDockHoursToFormObject(_.get(locSettings, 'pickup.hours', {})),
      canGoEarly: _.get(locSettings, 'pickup.canGoEarly', false),
      canGoEarlyMinutes: _.get(locSettings, 'pickup.canGoEarlyMinutes', 0) / 60,
      canGoLate: _.get(locSettings, 'pickup.canGoLate', false),
      canGoLateMinutes: _.get(locSettings, 'pickup.canGoLateMinutes', false) / 60,
      appointmentType: _.get(locSettings, 'pickup.appointmentType', ''),
      liveOrDrop: _.get(locSettings, 'pickup.liveOrDrop', ''),
      rules: {
        canGoEarlyLate: locationSettingsValidator.validateCanGoEarlyLateHours,
      },
    },
    delivery: {
      hours: dockHoursService.mapDockHoursToFormObject(_.get(locSettings, 'delivery.hours', {})),
      canGoEarly: _.get(locSettings, 'delivery.canGoEarly', false),
      canGoEarlyMinutes: _.get(locSettings, 'delivery.canGoEarlyMinutes', 0) / 60,
      canGoLate: _.get(locSettings, 'delivery.canGoLate', false),
      canGoLateMinutes: _.get(locSettings, 'delivery.canGoLateMinutes', 0) / 60,
      appointmentType: _.get(locSettings, 'delivery.appointmentType', ''),
      liveOrDrop: _.get(locSettings, 'delivery.liveOrDrop', ''),
      rules: {
        canGoEarlyLate: locationSettingsValidator.validateCanGoEarlyLateHours,
      },
    },
    modifiedDate: _.get(locSettings, 'modifiedDateTime', null) ? moment(_.get(locSettings, 'modifiedDateTime')).format('MM/DD/YYYY HH:mm') : '',
    modifiedBy: _.get(locSettings, 'modifiedBy', ''),
    loadDropRules: _.get(locSettings, 'loadDropRules', ''),
  };
}

/**
 * PATCH location settings to API
 * @param {*} settings
 * @param {*} locationMasterId
 * @param {*} customerId
 * @returns updated payload
 */
async function updateLocationSettings(settings, locationMasterId, customerId) {
  const settingsObj = parseLocationSettings(settings);
  const apiUrl = `${ApiHelperService.getApiUrl()}location-settings/${locationMasterId}/${customerId}`;

  return (await axiosHelper.patch(apiUrl, settingsObj)).data;
}

/**
 * GET formatted location settings
 * @param {*} locationMasterId
 * @param {*} customerId
 * @returns formatted location settings
 */
async function getFormattedLocationSettings(locationMasterId, customerId) {
  const locationSettings = await getLocationSettings(locationMasterId, customerId);
  return _.cloneDeep(getLocationSettingsFormObject(locationSettings));
}

/**
 * Parses cityState string to object
 * eg: "Chicago, IL" => { city: 'Chicago', state: 'IL' }
 * @param {*} cityStateStr
 * @returns cityState Object
 */
function parseLocation(loc) {
  if (!loc) return {};

  switch (loc.field) {
    case 'region':
      return { region: loc.value };

    case 'state':
      return { state: loc.value };

    case 'city-state':
      return { city: loc.value.split(',')[0].trim().toUpperCase(), state: loc.value.split(',')[1].trim().toUpperCase() };

    default:
      return {};
  }
}

function formatFilterObject(filters, options) {
  const filter = {};

  if (filters.status.length) {
    filter.status = _.get(filters, 'status[0].value') ? 'ACTIVE' : 'INACTIVE';
  }

  // Add city/state to filter object if its selected
  if (filters.location.length) {
    filter.location = parseLocation(_.get(filters, 'location[0]', ''));
  }

  // Add customerId array to filter object if customers are selected
  if (filters.customer.length) {
    filter.customerId = filters.customer.map((c) => c.value);
  }

  // Adds quick search to filter object
  if (filters.quickSearch.length) {
    if (filters.quickSearch[0].type && filters.quickSearch[0].value) {
      filter.quickSearch = {
        type: filters.quickSearch[0].type,
        value: filters.quickSearch[0].value,
      };
    }
  }

  return {
    filter,
    meta: {
      page: options.page || 1,
      limit: options.limit || 20,
    },
  };
}

async function filterLocationSettings(filters, options) {
  try {
    // this willl be replaced next sprint
    if (ajaxRequest.FILTER_LOCATIONS) {
      ajaxRequest.FILTER_LOCATIONS.cancel(RequestErrorTypesEnum.CANCEL_REQUEST);
    }

    // creates a new token for upcomming ajax (overwrite the previous one)
    ajaxRequest.FILTER_LOCATIONS = axios.CancelToken.source();

    const apiUrl = `${ApiHelperService.getApiUrl()}location-settings/filter`;
    const payload = formatFilterObject(filters, options);
    const result = await axiosHelper.post(apiUrl, payload, {
      cancelToken: ajaxRequest.FILTER_LOCATIONS.token,
    });

    return result.data;
  } catch (err) {
    return [];
  }
}

export default {
  getFormattedLocationSettings,
  getLocationSettingsFormObject,
  updateLocationSettings,
  filterLocationSettings,
  getLocationSettings,
  getContactFormObject,
  getLoadDropRuleFormObject
};
