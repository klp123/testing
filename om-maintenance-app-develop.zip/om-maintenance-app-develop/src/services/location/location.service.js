import { AxiosHelperService, ApiHelperService } from '@hubgroup/hg-om-shared-services';
import * as _ from 'lodash';

const axiosHelper = AxiosHelperService.attach();

function mapRegions(states, stop) {
  return (
    states.map((loc) => ({
      value: `${loc.region}`,
      text: `${_.startCase(_.toLower(loc.region))}`,
      label: stop,
      key: stop.toLowerCase(),
      field: 'region',
      single: true,
    })) || []
  );
}

function mapCityStatesNoStop(cityStates) {
  return (
    cityStates.map((loc) => ({
      value: loc,
      text: `${loc.city}, ${loc.state}`,
    })) || []
  );
}

function mapCityStates(cityStates, stop) {
  return (
    cityStates.map((loc) => ({
      value: `${loc.city}, ${loc.state}`,
      text: `${loc.city}, ${loc.state}`,
      label: stop,
      key: stop.toLowerCase(),
      field: 'city-state',
      single: true,
    })) || []
  );
}

function mapStates(states, stop) {
  return (
    states.map((loc) => ({
      value: `${loc.state}`,
      text: `${loc.state}`,
      label: stop,
      key: stop.toLowerCase(),
      field: 'state',
      single: true,
    })) || []
  );
}

/**
 * Calls api to get location
 * @param {*} searchText
 *
 */
async function searchLocation(searchText, stop) {
  let apiUrl = `${ApiHelperService.getApiUrl()}search/location`;
  if (searchText) {
    // append searchText to url if exists
    apiUrl = `${apiUrl}?searchText=${encodeURIComponent(searchText)}`;
  }

  try {
    const result = await axiosHelper.get(apiUrl);
    const regions = mapRegions(result.data.regions, stop);
    const states = mapStates(result.data.states, stop);
    const cityStates = mapCityStates(result.data.cities, stop);

    return _.concat(regions, states, cityStates);
  } catch (err) {
    console.log('Error while searching location');
    return [];
  }
}

async function searchCustomerLocations(searchText, customerId) {
  let apiUrl = `${ApiHelperService.getApiUrl()}customer-locations`;
  if (searchText) {
    apiUrl = `${apiUrl}?searchText=${encodeURIComponent(searchText)}&customerId=${encodeURIComponent(customerId)}`;
  }
  try {
    const result = await axiosHelper.get(apiUrl);
    return result.data.paginatedResults.map((location) => ({
      text: location.LocationID,
      value: location.LocationID
    })) || [];
  } catch (err) {
    console.log('Error while searching customer location', err);
    return [];
  }
}

async function searchCityStates(searchText) {
  let apiUrl = `${ApiHelperService.getApiUrl()}search/location`;
  if (searchText) {
    // append searchText to url if exists
    apiUrl = `${apiUrl}?searchText=${encodeURIComponent(searchText)}`;
  }

  try {
    const result = await axiosHelper.get(apiUrl);
    return mapCityStatesNoStop(result.data.cities);
  } catch (err) {
    console.log('Error while searching location');
    return [];
  }
}

async function getLocationContacts(locations) {
  const apiUrl = `${ApiHelperService.getApiUrl()}location-settings/contacts`;
  try {
    return (await axiosHelper.post(apiUrl, locations)).data;
  } catch (err) {
    return [];
  }
}

function getLocationDetails(orderId) {
  const apiUrl = `${ApiHelperService.getApiUrl()}om-order/location-details/${orderId}`;
  return axiosHelper.get(apiUrl);
}

export default {
  searchLocation,
  searchCityStates,
  getLocationContacts,
  getLocationDetails,
  searchCustomerLocations,
};
