import _ from 'lodash';
import { WeekdaysEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import locationSettingsValidator from '../../validators/location-settings/location-settings.validator';

/**
 * Format interval to hh:mm
 * eg: 109 ==> 01:09, 1 ==> 00:01
 * @param {*} time
 * @returns formated time to hh:mm
 */
function formatInterval(time) {
  while ((time || '').length < 4) {
    time = `0${time}`;
  }

  return `${time.slice(0, 2)}:${time.slice(2)}`;
}

/**
 * Stringify given interval to range string
 * eg: { begin: 1, end: 2359 } => '00:01-23:59'
 * @param {*} interval { begin: 1, end: 2359 }
 * @returns Formatted interval to range string
 */
function stringifyInterval(interval = {}) {
  const beginStr = formatInterval(String(interval.begin || 0));
  const endStr = formatInterval(String(interval.end || 0));
  return `${beginStr}-${endStr}`;
}

function parseTime(timeStr) {
  if (!timeStr) return null;

  const timeArr = timeStr.split(':');
  timeArr[0] = timeArr[0].length < 2 ? `0${timeArr[0]}` : timeArr[0];
  timeArr[1] = timeArr[1].length < 2 ? `0${timeArr[1]}` : timeArr[1];
  return Number(`${timeArr[0]}${timeArr[1]}`);
}

/**
 * Parse interval string to interval object
 * eg: { begin: 1, end: 2359 } => '00:01-23:59'
 * @param {*} intervalStr '00:01-23:59'
 * @returns { begin: 1, end: 2359 }
 */
function parseInterval(intervalStr) {
  if (!intervalStr || !intervalStr.length) {
    return {
      begin: 0,
      end: 0,
    };
  }

  const intervalArr = intervalStr.split('-');
  return {
    begin: Number(parseTime(intervalArr[0])),
    end: Number(parseTime(intervalArr[1])),
  };
}

/**
 * Parse Array of Dock hours from '00:01-23:59' => { begin: 1, end: 2359 }
 * @param {*} hours array of weekdays with interval formatted '00:01-23:59'
 * @returns weekdays object with interval formatted { begin: 1, end: 2359 }
 */
function parseDockHours(hours = []) {
  const hoursObj = {};

  hours.forEach((hour) => {
    hoursObj[hour.key] = {};
    hoursObj[hour.key].interval1 = parseInterval(hour.interval1);
    if (hour.interval2) {
      hoursObj[hour.key].interval2 = parseInterval(hour.interval2);
    }

    hoursObj[hour.key].closed = _.get(hour, 'closed', false);
    hoursObj[hour.key].is24Hour = _.get(hour, 'is24Hour', false);
  });

  return hoursObj;
}

/**
 * Map dock hours with stringifying the interval
 * and converting weekdays Object to weekdays array
 * @param {*} hours
 * @returns
 */
function mapDockHoursToFormObject(hours) {
  const formHours = Object.keys(hours).map((keyDay) => {
    const mappedDay = {
      key: keyDay,
      label: WeekdaysEnum.weekdays.find((d) => d.key === keyDay).title,
      day: WeekdaysEnum.weekdays.find((d) => d.key === keyDay).day,
      interval1: stringifyInterval(hours[keyDay].interval1),
      closed: hours[keyDay].closed || false,
      is24Hour: hours[keyDay].is24Hour || false,
      rules: {
        required: locationSettingsValidator.validateHours.bind(locationSettingsValidator),
        checkInterval: locationSettingsValidator.validateHoursRange.bind(locationSettingsValidator),
        checkOverlapInterval:
        locationSettingsValidator.validateIntervalOverlap.bind(locationSettingsValidator),
      },
    };

    if (hours[keyDay].interval2 && (hours[keyDay].interval2.begin || hours[keyDay].interval2.end)) {
      mappedDay.interval2 = stringifyInterval(hours[keyDay].interval2);
    }

    return mappedDay;
  });

  return _.sortBy(formHours, 'day');
}

export default {
  stringifyInterval,
  parseInterval,
  parseDockHours,
  mapDockHoursToFormObject,
};
