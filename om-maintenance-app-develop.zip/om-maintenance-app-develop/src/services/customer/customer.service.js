import _ from 'lodash';
import Vue from 'vue';
import {
  GoogleAnalyticsService,
  ApiHelperService,
  AxiosHelperService,
} from '@hubgroup/hg-om-shared-services';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import axios from 'axios';
import customerFilterEnum from '../../enums/customer-filter.enum';

const ajaxRequest = {};

const filterParams = _.cloneDeep(customerFilterEnum);

function getCustomerData(customerId) {
  const axiosHelper = AxiosHelperService.attach();
  const apiUrl = `${ApiHelperService.getApiUrl()}customer/${customerId}`;
  // cancel  previous ajax if exists
  if (ajaxRequest.GET_CUSTOMER_DATA) {
    ajaxRequest.GET_CUSTOMER_DATA.cancel(RequestErrorTypesEnum.CANCEL_REQUEST);
  }

  // creates a new token for upcomming ajax (overwrite the previous one)
  ajaxRequest.GET_CUSTOMER_DATA = axios.CancelToken.source();

  return axiosHelper.get(apiUrl, { params: { searchText: customerId, limit: 1 } }, {
    cancelToken: ajaxRequest.GET_CUSTOMER_DATA.token,
  });
}

function buildQuery(filters, opts, sort) {
  const query = {
    filters: {
      status: _.get(filters, 'status[0].query', ''),
      assignedTeam: _.get(filters, 'team', []).map((t) => t.value),
      quickSearch: {
        type: _.get(filters, 'quickSearch[0].type', ''),
        value: _.get(filters, 'quickSearch[0].value', ''),
      },
    },
    options: opts,
    sort
  };
  return query;
}

const filterErpCustomers = (filters, options, sort) => {
  const axiosHelper = AxiosHelperService.attach();
  const apiUrl = `${ApiHelperService.getApiUrl()}customers/filterErpCustomers`;

  // cancel  previous ajax if exists
  if (ajaxRequest.FILTER_CUSTOMERS) {
    ajaxRequest.FILTER_CUSTOMERS.cancel(RequestErrorTypesEnum.CANCEL_REQUEST);
  }

  // creates a new token for upcomming ajax (overwrite the previous one)
  ajaxRequest.FILTER_CUSTOMERS = axios.CancelToken.source();

  return axiosHelper.post(apiUrl, buildQuery(filters, options, sort), {
    cancelToken: ajaxRequest.FILTER_CUSTOMERS.token,
  });
};

const getMetrics = () => {
  const axiosHelper = AxiosHelperService.attach();
  const apiUrl = `${ApiHelperService.getApiUrl()}customers/metrics`;
  if (ajaxRequest.GET_METRICS) {
    ajaxRequest.GET_METRICS.cancel(RequestErrorTypesEnum.CANCEL_REQUEST);
  }

  // creates a new token for upcomming ajax (overwrite the previous one)
  ajaxRequest.GET_METRICS = axios.CancelToken.source();

  return axiosHelper.get(apiUrl, {
    cancelToken: ajaxRequest.GET_METRICS.token,
  });
};

function sendFilterGoogleAnalytics(selectedItem, category) {
  switch (selectedItem.key) {
    case 'status':
    case 'team':
      GoogleAnalyticsService.event(Vue, 'Filter', category, `${selectedItem.key}`);
      GoogleAnalyticsService.event(Vue, 'Filter', category,
        `User filtered to ${selectedItem.value} ${selectedItem.label}`, {});
      break;
    case 'quickSearch':
      GoogleAnalyticsService.event(Vue, 'Search', category, `User searched by ${selectedItem.label}`);
      GoogleAnalyticsService.event(Vue, 'Search', category, `${selectedItem.label}`);
      break;

    default:
      break;
  }
}

function mapToFilterObj(customer) {
  return {
    value: customer.id,
    text: customer.name ? `${customer.name}, ${customer.id}` : customer.id,
    name: customer.name,
    label: 'Customer',
    key: 'customer',
  };
}

async function searchCustomers(searchText, limit = 20) {
  let apiUrl = `${ApiHelperService.getApiUrl()}customers/search?limit=${limit}`;
  if (searchText) {
    // append searchText to url if exists
    apiUrl = `${apiUrl}&searchText=${encodeURIComponent(searchText)}`;
  }

  try {
    const axiosHelper = AxiosHelperService.attach();
    if (ajaxRequest.SEARCH_CUSTOMERS) {
      ajaxRequest.SEARCH_CUSTOMERS.cancel(RequestErrorTypesEnum.CANCEL_REQUEST);
    }

    // creates a new token for upcomming ajax (overwrite the previous one)
    ajaxRequest.SEARCH_CUSTOMERS = axios.CancelToken.source();

    const result = await axiosHelper.get(apiUrl, {
      cancelToken: ajaxRequest.SEARCH_CUSTOMERS.token,
    });

    const data = result.data ? result.data.filter((item) => !_.isEmpty(item)) : [];
    const mappedData = data ? data.map((cust) => mapToFilterObj(cust)) || [] : [];
    return mappedData;
  } catch (err) {
    if (err.message !== 'CANCEL_REQUEST') HgNotificationService.errorMessage('Failed to search customers.');
    return null;
  }
}

const getCustomerList = async (customerList) => {
  try {
    const axiosHelper = AxiosHelperService.attach();
    const apiUrl = `${ApiHelperService.getApiUrl()}customer-list`;
    return axiosHelper.post(apiUrl, customerList);
  } catch (error) {
    console.error('Error', error);
    HgNotificationService.errorMessage('Failed to fetch customer list.');
    return null;
  }
};

export default {
  filterParams,
  filterErpCustomers,
  getCustomerData,
  sendFilterGoogleAnalytics,
  getMetrics,
  mapToFilterObj,
  searchCustomers,
  getCustomerList,
};
