import * as XLSX from 'xlsx';

// Function to download data as a CSV file
function downloadFileAsCSV(dataField, fileName) {
  // Convert datafield array into CSV content
  const csvContent = dataField.map((row) => row.join(',')).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', `${fileName}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Function to download data as an Excel file
function downloadFileAsExcel(dataField, fileName) {
  const workBook = XLSX.utils.book_new();
  const workSheet = XLSX.utils.aoa_to_sheet(dataField);
  XLSX.utils.book_append_sheet(workBook, workSheet, 'Sheet 1');
  XLSX.writeFile(workBook, fileName);
}

export default {
  downloadFileAsCSV,
  downloadFileAsExcel
};
