/* eslint-disable no-throw-literal */
/* eslint-disable indent */
import _ from 'lodash';
import {
  ApiHelperService,
  AxiosHelperService,
} from '@hubgroup/hg-om-shared-services';
import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import axios from 'axios';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';

const ajaxRequest = {};
const mapToFilterObj = (individual) => ({
    value: individual.email,
    text: (individual.fullname && individual.fullname.toLowerCase().replace(/(?:^|\s|-)\S/g, (x) => x.toUpperCase())) || '',
    label: 'Individual',
    key: 'Individual',
    username: individual.username,
});
const axiosHelper = AxiosHelperService.attach();
const getInternalUser = async (userId) => {
    try {
        const apiUrl = `${ApiHelperService.getApiUrl()}user/${userId}`;

        if (ajaxRequest.GET_USER) {
          ajaxRequest.GET_USER.cancel(RequestErrorTypesEnum.CANCEL_REQUEST);
        }

        // creates a new token for upcomming ajax (overwrite the previous one)
        ajaxRequest.GET_USER = axios.CancelToken.source();

        const resp = await axiosHelper.get(apiUrl, {
          cancelToken: ajaxRequest.GET_USER.token,
        });

        const apiStatus = _.get(resp, 'status', null);
        if (apiStatus && apiStatus !== 200) {
            throw resp;
        }
        const apiData = _.get(resp, 'data', null);
        if (!apiData) {
            throw { message: 'Failed to get user' };
        }
        return apiData;
    } catch (error) {
        const errorMsg = error.message ? error.message : 'Failed to get user';
        if (error.message !== 'CANCEL_REQUEST') {
          HgNotificationService.errorMessage(errorMsg);
        }
        return {};
    }
};

const updateInternalUser = async (reqPayload, userId) => {
    try {
        const apiUrl = `${ApiHelperService.getApiUrl()}user/${userId}`;

        if (ajaxRequest.UPDATE_USER) {
          ajaxRequest.UPDATE_USER.cancel(RequestErrorTypesEnum.CANCEL_REQUEST);
        }

        // creates a new token for upcomming ajax (overwrite the previous one)
        ajaxRequest.UPDATE_USER = axios.CancelToken.source();

        const resp = await axiosHelper.patch(apiUrl, reqPayload, {
          cancelToken: ajaxRequest.UPDATE_USER.token,
        });

        const apiStatus = _.get(resp, 'status', null);
        if (apiStatus && apiStatus !== 200) {
            throw resp;
        }
        const apiData = _.get(resp, 'data', null);
        if (!apiData) {
            throw { message: 'Failed to update Assignments' };
        }
        return apiData;
    } catch (error) {
        const errorMsg = error.message ? error.message : 'Failed to update Assignments';
        if (error.message !== 'CANCEL_REQUEST') {
          HgNotificationService.errorMessage(errorMsg);
        }
        return {};
    }
};

const listUsers = async (reqPayload, listUserName) => {
    try {
        const apiUrl = `${ApiHelperService.getApiUrl()}filter/user`;

        if (ajaxRequest.LIST_USERS) {
          ajaxRequest.LIST_USERS.cancel(RequestErrorTypesEnum.CANCEL_REQUEST);
        }

        // creates a new token for upcomming ajax (overwrite the previous one)
        ajaxRequest.LIST_USERS = axios.CancelToken.source();

        const resp = await axiosHelper.post(apiUrl, reqPayload, {
          cancelToken: ajaxRequest.LIST_USERS.token,
        });

        const apiStatus = _.get(resp, 'status', null);
        if (apiStatus && apiStatus !== 200) {
            throw resp;
        }
        const apiData = _.get(resp, 'data', null);

        const returnObj = apiData ? apiData.map((cust) => mapToFilterObj(cust)) || [] : [];
        if (listUserName) return returnObj.map((item) => ({ ...item, value: item.username }));
        return returnObj;
    } catch (error) {
        const errorMsg = error.message ? error.message : 'Failed to get all Individuals';
        if (error.message !== 'CANCEL_REQUEST') {
          HgNotificationService.errorMessage(errorMsg);
        }
        return {};
    }
};

export default {
    getInternalUser,
    updateInternalUser,
    listUsers,
};
