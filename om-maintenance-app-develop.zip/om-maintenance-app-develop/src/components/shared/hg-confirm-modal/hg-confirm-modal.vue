<template>
  <div class="text-center">
    <v-dialog
      persistent
      v-model="dialog"
      :max-width="options.width"
      :style="{ zIndex: options.zIndex }"
      @keydown.esc="cancel"
    >
      <v-card>
        <v-form>
          <div class="d-flex justify-space-between">
            <div class="modal-header">{{ title }}</div>
            <div>
              <v-btn @click.native="cancel" icon>
                <v-icon>mdi-close</v-icon>
              </v-btn>
            </div>
          </div>
          <hr class="horizontal-divider" />
          <v-card-text>
            <p v-html="message"></p>
          </v-card-text>
          <v-card-actions class="actions">
            <HgLibBtn
              title="Cancel"
              type="secondary"
              :disabled="false"
              @click.native="cancel"
            ></HgLibBtn>
            <v-spacer></v-spacer>
            <HgLibBtn :title="confirmButtonText ? confirmButtonText : 'Confirm'"
            type="error" @click.native="agree"></HgLibBtn>
          </v-card-actions>
        </v-form>
      </v-card>
    </v-dialog>
  </div>
</template>
<script src="./hg-confirm-modal.js"></script>
<style src="./hg-confirm-modal.sass" lang="sass" scoped></style>
