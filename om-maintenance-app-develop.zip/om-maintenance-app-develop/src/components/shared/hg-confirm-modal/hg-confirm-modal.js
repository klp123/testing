export default {
  name: 'HgConfirmActionModal',
  data: () => ({
    dialog: false,
    resolve: null,
    reject: null,
    message: null,
    confirmButtonText: null,
    title: null,
    options: {
      width: 500,
      zIndex: 200,
    },
  }),
  methods: {
    open(title, message, confirmButtonText, options) {
      this.confirmButtonText = confirmButtonText;
      this.dialog = true;
      this.title = title;
      this.message = message;
      this.options = Object.assign(this.options, options);
      return new Promise((resolve, reject) => {
        this.resolve = resolve;
        this.reject = reject;
      });
    },
    agree() {
      this.resolve(true);
      this.dialog = false;
    },
    cancel() {
      this.resolve(false);
      this.dialog = false;
    },
  },
};
