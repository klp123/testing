<template>
  <div class="row">
    <div class="meta-item">
      <HgLabelCounts
        v-if="showAlertRiskLevelCounts"
        :labelCounts="alertRiskLevelCounts"
      ></HgLabelCounts>
      <p>Total Results:</p>
      <v-skeleton-loader v-if="loading" class="py-1" type="text" width="75" />
      <p class="display-data" v-if="!loading">
        {{ computeCount(totalResults)
        }}<label v-if="totalResults >= maxItemLimit">+</label>
        {{ totalResultsLabel }}
      </p>
      <p v-if="selectedItems > 0 && !loading" class="display-data">
        ({{ computeCount(selectedItems) }} {{ selectedItemsLabel }})
      </p>
    </div>
    <div class="meta-item">
      <p>Last Updated:</p>
      <v-skeleton-loader v-if="loading" class="py-1" type="text" width="75" />
      <p class="display-data" v-if="!loading">
        {{ computeTime(refreshTime) }}
      </p>
      <v-btn
        icon
        dense
        height="20"
        width="20"
        class="icon clickable"
        :color="getColor('color_text_gray')"
        @click="refreshData"
      >
        <v-icon size="20px">mdi-refresh</v-icon>
      </v-btn>
    </div>
  </div>
</template>

<script src="./hg-table-metadata.js"></script>
<style src="./hg-table-metadata.sass" lang="sass" scoped></style>
