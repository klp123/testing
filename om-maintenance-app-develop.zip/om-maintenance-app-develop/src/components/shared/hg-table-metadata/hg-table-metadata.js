import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import { HgMomentService, AppSetupEnum } from '@hubgroup/hg-om-shared-services';
import HgLabelCounts from '../hg-label-counts/hg-label-counts.vue';

function computeCount(amount) {
  return Number(amount).toLocaleString();
}

function maxItemLimit() {
  return AppSetupEnum.MAX_CUST_LIMIT;
}

function computeTime(refresh) {
  return HgMomentService.formatTime(refresh, 'LT');
}

function refreshData() {
  this.$emit('onRefreshClick');
}

function getColor(name) {
  return _colors[name];
}

// @vuese
// @group TABLE
// table metadata component
export default {
  name: 'HgTableMetadata',
  components: {
    HgLabelCounts,

  },
  props: {
    showAlertRiskLevelCounts: {
      type: Boolean,
      required: false,
      default: false,
    },
    alertRiskLevelCounts: {
      type: Array,
      required: false,
      default: () => [],
    },
    totalResults: {
      type: Number,
      required: true,
      default: () => 0,
    },
    totalResultsLabel: {
      type: String,
      required: false,
      default: () => '',
    },
    selectedItems: {
      type: Number,
      required: false,
      default: () => 0,
    },
    selectedItemsLabel: {
      type: String,
      required: false,
      default: () => 'selected',
    },
    refreshTime: {
      type: Date,
      required: true,
      default: () => new Date(),
    },
    page: {
      type: String,
      required: true,
      default: () => '',
    },
    loading: {
      type: Boolean,
      required: false,
      default: () => false,
    },
  },
  methods: {
    computeCount,
    computeTime,
    refreshData,
    getColor,
  },
  computed: {
    maxItemLimit,
  },
};
