<template>
  <v-autocomplete
    :background-color="backgroundColor"
    :items="items"
    v-model="value"
    :item-text="itemText"
    :item-value="itemValue"
    :label="label"
    outlined
    :search-input.sync="search"
    :disabled="disabled"
    :clearable="clearable"
    :hide-details="hideDetails"
    append-icon="mdi-chevron-down"
    :placeholder="placeholder"
    :rules="rules"
    :error="manualError"
  >
  </v-autocomplete>
</template>

<script src="./hg-autocomplete.js"></script>
<style src="./hg-autocomplete.sass" lang="sass" scoped></style>
