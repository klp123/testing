import {
  VAutocomplete,
} from 'vuetify/lib';
import mixinRulesService from '@hubgroup/hg-vue-om-util-lib/src/utils/mixins/mixin-rules.service';

// @vuese
// @group BUTTONS
// Default buttons with styling

/**
 * Prepopulate the value if present else reset the value to the initial state
 */
function prepopulateValue() {
  this.value = (this.prepopulateItem) ? this.prepopulateItem : null;
}

export default {
  name: 'HgAutocomplete',
  components: {
    VAutocomplete,
  },
  data: () => ({
    value: null,
    search: '',
    initialList: true,
  }),
  mixins: [mixinRulesService],
  props: {
    prepopulateItem: {
      type: [String, Object],
      required: false,
      default: ''
    },
    // Dropdown items
    items: {
      type: Array,
      required: true,
    },
    manualError: {
      type: Boolean,
      required: false,
      default: false
    },
    /**
     * When passing in a list of objects,
     * We can pass a function to specify
     * how to display the items in the dropdown
     */
    itemText: {
      type: Function,
      required: false,
    },
    /**
     * When passing in a list of objects,
     * We can pass a function to specify
     * how to assign a value to an item
     * when selected
     */
    itemValue: {
      type: Function,
      required: false,
    },
    // Default placeholder text shown when nothing is selected
    placeholder: {
      type: String,
      required: false,
    },
    // Is the dropdown disabled
    disabled: {
      type: Boolean,
      required: false,
      default: () => false,
    },
    // Default text shown when nothing is selected
    label: {
      type: String,
      required: false,
    },
    // Can the dropdown be cleared after something is selected?
    clearable: {
      type: Boolean,
      required: false,
      default: () => false,
    },
    // hide below field details?
    hideDetails: {
      type: Boolean,
      required: false,
      default: () => false,
    },
    // background color
    backgroundColor: {
      type: String,
      required: false,
      default: () => undefined,
    },
    /**
     * boolean to determine whether we should get
     * an initial list of commodity codes on component
     * load
     */
    generateList: {
      type: Boolean,
      required: false,
      default: () => true,
    },
    emitType: {
      type: String,
      required: false,
      default: () => '',
    },
    defaultValue: {
      type: [String, Object],
      required: false,
      default: () => '',
    },
  },
  beforeMount() {
    this.initialList = this.generateList;
    if (this.defaultValue) {
      this.value = this.defaultValue;
    }
  },
  created() {
    this.prepopulateValue();
  },
  methods: {
    debounceSearch(searchText) {
      // cancel pending call
      clearTimeout(this.timerId);

      // delay new call 300ms
      this.timerId = setTimeout(() => {
        this.$emit('onSearchTextChanged', searchText);
      }, 300);
    },
    prepopulateValue
  },
  watch: {
    value(data) {
      this.$emit('input', data);
      if (this.emitType) {
        const emitItem = this.items.find((item) => item.code === data);
        if (emitItem) this.$emit(`${this.emitType}`, emitItem[`${this.emitType}`]);
      }
    },
    search(searchText) {
      if (this.initialList) {
        this.debounceSearch(searchText);
      }
      this.initialList = true;
    },
    prepopulateItem() {
      this.prepopulateValue();
    }
  },
};
