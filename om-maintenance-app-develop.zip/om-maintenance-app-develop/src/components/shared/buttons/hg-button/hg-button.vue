<template>
  <v-btn :disabled="disabled" :class="'hg__' + type">{{title}}</v-btn>
</template>

<script src="./hg-button.js"></script>
<style src="./hg-button.sass" lang="sass" scoped></style>
