// @vuese
// @group BUTTONS
// Default buttons with styling
export default {
  name: 'HgButton',
  data: () => ({}),
  props: {
    // Text on button
    title: {
      type: String,
      required: true,
    },
    // Which style of button to use? Primary (blue) Secondary (gray)
    type: {
      type: String,
      required: false,
      default: () => 'primary',
    },
    // Is the button disabled
    disabled: {
      type: Boolean,
      required: false,
      default: () => false,
    },
  },
};
