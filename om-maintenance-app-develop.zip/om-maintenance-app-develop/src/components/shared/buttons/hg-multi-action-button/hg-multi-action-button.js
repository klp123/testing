import _colors from '~@hubgroup/hg-vue-library/src/assets/styles/core/_colors';

function actionClicked(disabled, action) {
  if (!disabled) {
    this.$emit('actionClicked', action);
  }
}

function getColor(name) {
  return _colors[name];
}

// @vuese
// @group BUTTONS
// Default buttons with Multiple dropdown options
export default {
  name: 'HgMultiActionButton',
  props: {
    // List of actions for dropdown
    actions: {
      type: Array,
      required: false,
      default: () => [],
    },
    // Button label
    btnLabel: {
      type: String,
      required: false,
      default: () => '',
    },
    // Disable the button
    disabled: {
      type: Boolean,
      required: false,
      default: () => true,
    },
  },
  methods: {
    // @vuese
    // Used fire event on button click
    // @arg (action) clicked action
    actionClicked,
    getColor,
  },
};
