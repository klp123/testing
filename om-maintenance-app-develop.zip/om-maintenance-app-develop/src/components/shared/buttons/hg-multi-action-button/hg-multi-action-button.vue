<template>
  <div class="action-buttons">
    <v-menu offset-y>
      <template v-slot:activator="{ on, attrs }">
        <v-btn
          :color="getColor('color_primary_blue')"
          dark
          v-bind="attrs"
          v-on="on"
          class="btn-action"
          :disabled="disabled"
          v-bind:class="{ 'btn-action-disabled': disabled }"
        >
          <label class="btn-label">{{ btnLabel }}</label>

          <v-icon large :color="getColor('color_text_gray')" class="icon-arrow-down" v-bind:class="{ 'icon-arrow-down-disabled': disabled }">
            mdi-chevron-down
          </v-icon>
        </v-btn>
      </template>
      <v-list>
        <v-list-item
          v-for="(item, index) in actions"
          :key="index"
        >
          <v-list-item-title @click="actionClicked(item.disabled, item.action)">
            <label class="action-title"  v-bind:class="{ 'action-title-disabled': item.disabled }">{{ item.title }}</label>
            <label v-if="item.disabled" class="disable-reason">{{item.disabledReason}}</label>
          </v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>
  </div>
</template>

<script src="./hg-multi-action-button.js"></script>
<style src="./hg-multi-action-button.sass" lang="sass" scoped></style>
