// @vuese
// @group TABLE
// Filtered appointments alert risk level counts
export default {
  name: 'HgLabelCounts',
  data: () => ({}),
  filters: {
    Titlecase(value) {
      if (!value) return '';
      return value.toLowerCase().replace(/(?:^|\s|-)\S/g, (x) => x.toUpperCase());
    },
  },
  props: {
    labelCounts: {
      type: Array,
      required: false,
      default: () => [],
    },
  },
};
