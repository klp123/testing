<template>
  <div class="d-flex" v-if="labelCounts && labelCounts.length">
    <div class="d-flex pr-3" v-for="alert in labelCounts" :key="alert.label">
      <i
        class="alert-label"
        v-bind:style="{ backgroundColor: alert.color }"
      ></i>
      <p class="pr-1">{{ alert.label | Titlecase }} Risk:</p>
      <p class="font-weight-bold">
        {{ alert.value }}
      </p>
    </div>
  </div>
</template>
<script src="./hg-label-counts.js"></script>
<style src="./hg-label-counts.sass" lang="sass" scoped></style>
