import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';

function onItemSelected(title) {
  const modalValue = this.selectedFieldModal[title] || '';
  const value = this.selectedFields[title] || '';
  if (modalValue !== value && this.shown) {
    this.shown = false;
    // get the selected element from items compared by value
    const selectedValue = ((this.subComponents || []).find((sc) => sc.title === title) || {}).items.find((item) => item.value === modalValue);
    this.$emit('onItemSelected', selectedValue);
  }
}

function onClickOutsideDialog($event) {
  const clickedClasses = $event.srcElement.className;
  if (clickedClasses.indexOf('menu-dialog') === -1 && clickedClasses.indexOf('subcomponent') === -1 && this.shown && !$event.srcElement.hasAttribute('autocomplete')) {
    this.shown = false;
  }
}

function onOptionFieldChecked(optField) {
  if (this.selectedOptionalFields && this.selectedOptionalFields[optField.key]) {
    // if field is checked fire uncheck event
    this.$emit('onUnItemSelected', optField);
  } else {
    this.$emit('onOptionalFieldSelected', optField);
  }
}

function isOptionalFieldChecked(key) {
  return this.selectedOptionalFields && this.selectedOptionalFields[key];
}

function isCheckedItem(item, title) {
  if (!title) return false;
  return item === (this.selectedFields[title] || {}).value;
}

function autoFocus() {
  setTimeout(() => {
    this.$refs.autocomplete[0].focus();
  }, 100);
}

function getColor(name) {
  return _colors[name];
}

// @vuese
// @group FILTERS
// This filter has dropdown field.
// User can apply filter by selecting any option.
export default {
  name: 'HgDropdownField',
  data: () => ({
    filter: {},
    shown: false,
    selectedFieldModal: {},
    hasSuggestedReasonCode: false,
  }),
  props: {
    // Filter Label name
    filterLabel: {
      type: String,
      required: true,
      default: () => null,
    },
    // Key from option field to disable the autocomplete
    disableKey: {
      type: String,
      required: true,
      default: () => null,
    },
    // selected Fields
    selectedFields: {
      type: Object,
      required: true,
      default: () => null,
    },
    // Optional fields for filter
    optionalFields: {
      type: Array,
      required: true,
      default: () => false,
    },
    // Selected optional field info
    selectedOptionalFields: {
      type: Object,
      required: true,
      default: () => { },
    },
    // Autocomplete fields
    subComponents: {
      type: Array,
      required: false,
      default: () => [],
    },
    // Disabled filter
    disabled: {
      type: Boolean,
      required: false,
      default: () => false,
    },
  },
  watch: {
    selectedFields() {
      // Update Modal if filtered items are altered
      Object.keys(this.selectedFields || {}).forEach((key) => {
        if (this.selectedFieldModal[key] !== this.selectedFields[key]) {
          this.selectedFieldModal[key] = this.selectedFields[key];
        }
      });
    },
  },
  methods: {
    // @vuese
    // Used to update filter on item selected from list
    // @arg ($event)
    onItemSelected,
    // @vuese
    // Used to change the up/down icon when clicked outside filter component.
    // @arg ($event)
    onClickOutsideDialog,
    // @vuese
    // Check if given filter item is checked
    // @arg filter item
    isCheckedItem,
    // @vuese
    // Focuses on first autocomplete component as soon as filter is opened
    // @arg -
    autoFocus,
    // @vuese
    // Fires When option field is checked
    // @arg filter obj
    onOptionFieldChecked,
    // @vuese
    // Checks if optional field is checked
    // @arg filter obj
    isOptionalFieldChecked,
    // @vuese
    // Gets color for given name
    // @arg name
    getColor,
  },
};
