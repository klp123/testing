<template>
  <div class="filter-content">

       <div v-if="disabled" class="filter-disabled">
      <label
            color="primary"
            dark
            class="label-filter"
          >
            <label>{{ filterLabel }}</label>
            <v-icon large :color="getColor('color_text_gray')">
              mdi-chevron-down
            </v-icon>
          </label>
    </div>

    <div
      v-if="!disabled"
      v-click-outside="onClickOutsideDialog"
    >
        <v-menu offset-y :close-on-content-click="false" :value="shown">
      <template v-slot:activator="{ on, attrs }">
        <label
          dark
          v-bind="attrs"
          v-on="on"
          v-on:click="shown = !shown; autoFocus()"
          app
          class="label-filter"
          v-bind:class="{ 'label-filter-active': shown }"
        >
          <label>{{ filterLabel }}</label>
          <v-icon large :color="getColor('color_text_gray')" v-if="!shown">
            mdi-chevron-down
          </v-icon>
          <v-icon large :color="getColor('color_text_gray')" v-if="shown">
            mdi-chevron-up
          </v-icon>
        </label>
      </template>

      <v-card class="hg-card menu-dialog">
        <div class="show-all" v-for="(optField, index) in optionalFields" :key="index" v-on:click="onOptionFieldChecked(optField)">
          <v-checkbox
              class="show-all-checkbox"
              :color="getColor('color_primary_blue')"
              :input-value="isOptionalFieldChecked(optField.key)"
            ></v-checkbox>

            <label class="show-all-message">{{ optField.fieldText }}</label>
        </div>

        <div class="subcomponent" v-for="item in subComponents || []" v-bind:key="item.title">
          <label class="filter-title">{{ item.title }}</label>
          <v-autocomplete ref="autocomplete" :disabled="isOptionalFieldChecked(disableKey)" :items="item.items" color="field-autocomplete" v-model="selectedFieldModal[item.title]" :value="selectedFields[item.title]" v-on:change="onItemSelected(item.title)">
            <template v-slot:item="data">
                <input type="radio" :checked="isCheckedItem(data.item.value, item.title)" class="radio-button">
                <label class="radio-label">{{ data.item.text }}</label>
            </template>
          </v-autocomplete>
        </div>
      </v-card>
    </v-menu>
    </div>

  </div>
</template>

<script src="./hg-dropdown-field.js"></script>
<style src="./hg-dropdown-field.sass" lang="sass" scoped></style>
