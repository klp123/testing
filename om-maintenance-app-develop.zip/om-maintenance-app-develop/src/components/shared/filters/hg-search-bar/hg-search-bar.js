import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import customerService from '../../../../services/orders/customer.service';

function onItemSelected(item) {
  if ((this.selectedItems || []).findIndex((itm) => itm.value === item.value) < 0) {
    this.$emit('searchItemSelected', item);
  } else {
    this.$emit('searchItemUnSelected', item);
  }

  if (item.single) {
    this.shown = false;
    this.searchText = '';
    this.$emit('filterClosed');
  }
}

function onClickOutsideDialog($event) {
  const clickedClasses = $event.srcElement.className;
  if (clickedClasses.indexOf('menu-dialog') === -1 && $event.srcElement.type !== 'checkbox' && this.shown) {
    this.shown = false;
    this.searchText = '';
    this.$emit('filterClosed');
  }
}

function onKeyupCustomerSearch() {
  this.$emit('searchTextChanged', this.searchText);
}

function isSelected(item) {
  return this.selectedItems.find((itm) => itm.value === item.value);
}

function autoFocus() {
  setTimeout(() => {
    this.$refs.searchBar.focus();
  }, 100);
}

function getColor(name) {
  return _colors[name];
}

// @vuese
// @group FILTERS
// This filter has search field. It searches on given parameter and renders the list.
// User can apply filter by selecting any option.
export default {
  name: 'HgSearchBar',
  data: () => ({
    filter: {},
    shown: false,
    searchText: '',
    searched: false,
  }),
  props: {
    // Items of checkbox vaues
    items: {
      type: Array,
      required: false,
      default: () => [],
    },
    placeholder: {
      type: String,
      required: true,
      default: () => null,
    },
    selectedItems: {
      type: Array,
      required: false,
      default: () => [],
    },
    // Filter field
    filterKey: {
      type: String,
      required: true,
      default: () => null,
    },
    // Filter Label
    filterLabel: {
      type: String,
      required: true,
      default: () => null,
    },
    loading: {
      type: Boolean,
      required: false,
      default: () => false,
    },
    // Disabled filter
    disabled: {
      type: Boolean,
      required: false,
      default: () => false,
    },
  },
  methods: {
    // @vuese
    // Used to update filter on item selected from search list
    // @arg ($event)
    onItemSelected,
    // @vuese
    // Used to change the up/down icon when clicked outside filter component.
    // @arg ($event)
    onClickOutsideDialog,
    // @vuese
    // Fires searchTextChanged event on keyup event for customer input box
    // Uses default of 300ms debounce
    // @arg -
    onKeyupCustomerSearch,
    // @vuese
    // Check if given item is selected or not
    // @arg (item)
    isSelected,
    autoFocus,
    getColor,
  },
  mounted() {
    this.customers = customerService.searchCustomers();
  },
};
