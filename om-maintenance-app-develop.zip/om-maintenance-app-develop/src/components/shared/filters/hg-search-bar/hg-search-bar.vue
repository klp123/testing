<template>
  <div class="filter-content">
    <div v-if="disabled" class="filter-disabled">
      <label
        color="primary"
        dark
        class="label-filter">
        <label>{{ filterLabel }}</label>
        <v-icon large :color="getColor('color_text_gray')"
          >mdi-chevron-down</v-icon
        >
      </label>
    </div>

    <div v-if="!disabled">
      <div v-click-outside="onClickOutsideDialog">
        <v-menu offset-y :close-on-content-click="false" :value="shown">
          <template v-slot:activator="{ on, attrs }">
            <label
              color="primary"
              dark
              v-bind="attrs"
              v-on="on"
              v-on:click="
                shown = !shown;
                autoFocus();
              "
              app
              class="label-filter"
              v-bind:class="{ 'label-filter-active': shown }"
            >
              <label>{{ filterLabel }}</label>
              <v-icon large :color="getColor('color_text_gray')" v-if="!shown"
                >mdi-chevron-down</v-icon
              >
              <v-icon large :color="getColor('color_text_gray')" v-if="shown"
                >mdi-chevron-up</v-icon
              >
            </label>
          </template>
          <v-card class="search-card menu-dialog">
            <input
              class="txt-search menu-dialog"
              :placeholder="placeholder"
              v-model="searchText"
              v-debounce="onKeyupCustomerSearch"
              ref="searchBar"
            />
            <div class="progress-bar" v-if="loading">
              <v-progress-circular
                :width="3"
                :color="getColor('color_primary_blue')"
                indeterminate
              ></v-progress-circular>
            </div>
            <label
              v-if="searchText && !loading && !items.length"
              class="no-results"
              >No results</label
            >
            <div class="search-results" v-if="!loading && items.length">
              <v-list>
                <v-list-item v-for="(itm, index) in items" :key="index">
                  <v-checkbox
                    class="menu-dialog"
                    :color="getColor('color_primary_blue')"
                    v-if="!itm.single"
                    v-on:click="onItemSelected(itm)"
                    :input-value="isSelected(itm)"
                  ></v-checkbox>
                  <div
                    v-on:click="onItemSelected(itm)"
                    :id="itm.value"
                    v-bind:class="{ 'paddding-left': itm.single }"
                    class="menu-dialog"
                  >
                    {{ itm.text }}
                  </div>
                </v-list-item>
              </v-list>
            </div>
          </v-card>
        </v-menu>
      </div>
    </div>
  </div>
</template>

<script src="./hg-search-bar.js"></script>
<style src="./hg-search-bar.sass" lang="sass" scoped></style>
