import * as moment from 'moment';
import * as _ from 'lodash';
import { DatePresetsEnum } from '@hubgroup/hg-om-shared-services';
import _colors from '~@hubgroup/hg-vue-library/src/assets/styles/core/_colors';

function setTextToDate(input) {
  if (input) {
    this.setByQuickAction = '';
    this.picker = [];
    const dates = input.split('~');
    dates.forEach((date) => {
      const tempDate = moment.utc(date).startOf('day');
      if (tempDate.year() === 2001) {
        tempDate.set('year', moment().year());
      }
      if (moment(tempDate).isValid()) {
        this.picker.push(tempDate.format('yyyy-MM-DD'));
        this.setByQuickAction = '';
      } else if (Object.values(DatePresetsEnum).find((preset) => preset.title === input)) {
        this.focusedSelection.value = input;
      } else {
        this.focusedSelection.value = tempDate;
        this.setByQuickAction = '';
      }
    });
  } else {
    this.picker = [];
    this.setNewFocus(this.focusedSelection, true);
  }
}

function setDateByPreset(title, start, end = null) {
  this.setByQuickAction = title;
  this.setDate(start, end);
}

function setDate(start, end = null) {
  this.picker = [start.format('yyyy-MM-DD')];
  if (end) {
    this.picker.push(end.format('yyyy-MM-DD'));
  }
}

function setfocusedValue(dates) {
  if (!moment(dates[0]).isValid()) return;
  const displayValue = [];
  const formattedDate = dates.map((date) => {
    const tempDate = moment.utc(date).startOf('day');
    if (tempDate.year() === 2001) {
      tempDate.set('year', moment().year());
    }
    displayValue.push(moment(date).format('MM/DD/YY'));
    return tempDate.toISOString();
  }).join('~');

  if (this.setByQuickAction) {
    this.focusedSelection.value = this.setByQuickAction;
  } else {
    this.focusedSelection.value = displayValue.join(' ~ ');
  }

  const fieldType = this.subComponents.find((component) => component.value.length);
  if (!this.setByQuickAction) {
    const data = {
      key: this.filterKey,
      text: displayValue.join(' ~ '),
      value: { time: formattedDate, type: fieldType.key },
      label: fieldType.key,
      single: true,
    };
    this.$emit('onItemSelected', data);
  } else {
    const data = {
      key: this.filterKey,
      text: this.setByQuickAction,
      value: { time: this.setByQuickAction, type: fieldType.key },
      label: fieldType.key,
      single: true,
    };
    this.$emit('onItemSelected', data);
    this.setByQuickAction = '';
  }
}

function setNewFocus(focusedElement, clear = false) {
  const date = {
    key: this.filterKey,
    single: true,
  };
  if (focusedElement === this.focusedSelection && !clear) {
    return;
  }
  const fieldType = _.cloneDeep(this.subComponents).find((component) => component.value);
  if (fieldType) {
    date.label = fieldType.key;
  }
  this.subComponents.forEach((component) => component.value = '');
  this.picker = [];
  this.focusedSelection = focusedElement;

  const storeString = this.parentPage === 'appointments' ? 'appointmentsStore' : 'orderStore';

  if (this.$store.getters[`${storeString}/getFilters`][this.filterKey] && this.$store.getters[`${storeString}/getFilters`][this.filterKey].length) {
    this.$emit('focusChanged', date);
  }
}

function checkField(input) {
  if (!input && this.subComponents.find((field) => field.value)) {
    return true;
  }
}

function resetPicker() {
  this.setByQuickAction = '';
  const value = _.compact(this.subComponents.map((item) => item.value));
  if (_.isEmpty(value)) {
    this.picker = [];
  }
}

function autoFocus() {
  setTimeout(() => {
    this.$refs.dateInput[0].focus();
  }, 100);
}

function getColor(name) {
  return _colors[name];
}

// @vuese
// @group FILTERS
// Filter with select box elements
export default {
  name: 'HgDateBox',
  data: () => ({
    filter: {},
    shown: false,
    showCalendar: false,
    picker: [],
    focusedSelection: null,
    setByQuickAction: '',
  }),
  props: {
    // Filter label
    filterLabel: {
      type: String,
      required: true,
      default: () => null,
    },
    filterKey: {
      type: String,
      required: true,
      default: () => null,
    },
    // sub menus
    subComponents: {
      type: Array,
      required: false,
      default: () => [],
    },
    selectedItems: {
      type: Array,
      required: false,
      default: () => [],
    },
    dateButtons: {
      type: Array,
      required: false,
      default: () => [],
    },
    parentPage: {
      type: String,
      required: true,
      default: () => null,
    },
    // Disabled filter
    disabled: {
      type: Boolean,
      required: false,
      default: () => false,
    },
  },
  methods: {
    setDate,
    setNewFocus,
    setTextToDate,
    setfocusedValue,
    checkField,
    resetPicker,
    autoFocus,
    setDateByPreset,
    getColor,
  },
  watch: {
    picker(dates) {
      let displayDates = _.cloneDeep(dates);
      displayDates = displayDates.sort();
      if (displayDates.length > 0) {
        this.setfocusedValue(displayDates);
      }
    },
    selectedItems(data) {
      if (data.length < 1) {
        this.subComponents.forEach((component) => component.value = '');
      } else if (data.length === 1) {
        const selectedFilter = data[0];
        const matchingSubcomponent = this.subComponents.filter((item) => item.key === selectedFilter.label)[0];
        matchingSubcomponent.value = selectedFilter.text;
        this.focusedSelection = matchingSubcomponent;
      }
    },
  },
  mounted() {
  },
};
