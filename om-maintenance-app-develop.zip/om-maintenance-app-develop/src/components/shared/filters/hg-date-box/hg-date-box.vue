<template>
  <div class="filter-content">
    <div v-if="disabled" class="filter-disabled">
      <label
        dark
        class="label-filter"
      >
        <label>{{ filterLabel }}</label>
        <v-icon large :color="getColor('color_text_gray')" v-if="!shown">
          mdi-chevron-down
        </v-icon>
      </label>
    </div>

    <div v-if="!disabled">
      <v-menu
        content-class="elevation-0"
        offset-y
        :close-on-content-click="false"
        :value="shown"
        v-model="shown"
      >
        <template v-slot:activator="{ on, attrs }">
          <label
            dark
            v-bind="attrs"
            v-on="on"
            @click="
              (shown = !shown) && (showCalendar = false);
              autoFocus();
            "
            app
            class="label-filter"
            v-bind:class="{ 'label-filter-active': shown }"
          >
            <label>{{ filterLabel }}</label>
            <v-icon large :color="getColor('color_text_gray')" v-if="!shown">
              mdi-chevron-down
            </v-icon>
            <v-icon large :color="getColor('color_text_gray')" v-if="shown">
              mdi-chevron-up
            </v-icon>
          </label>
        </template>
        <v-container fluid>
          <v-row no-gutters>
            <v-col class="container-width">
              <v-card
                class="search-card menu-dialog inline"
                id="hg-date-box-dialog"
              >
                <div
                  class="component"
                  v-for="(item, index) in subComponents || []"
                  v-bind:key="item.title"
                  id="hg-date-box-row"
                >
                  <label
                    v-if="item.title && item.show"
                    :id="'hg-date-box-title-' + index"
                    class="txt-title"
                    >{{ item.title }}</label
                  >
                  <v-text-field
                  v-if="item.show"
                    flat
                    solo
                    dense
                    clearable
                    @blur="setTextToDate(item.value)"
                    @keydown.enter="setTextToDate(item.value)"
                    @focus="setNewFocus(item)"
                    @click:clear="setNewFocus(item, true)"
                    v-model="item.value"
                    hide-details="true"
                    :disabled="checkField(item.value)"
                    :id="'hg-date-box-input-' + index"
                    class="txt-search menu-dialog"
                    ref="dateInput"
                  >
                    <template class="clickable" v-slot:append>
                      <v-btn
                        small
                        icon
                        max-height="24px"
                        max-width="24px"
                        @click="
                          resetPicker();
                          showCalendar = true;
                        "
                      >
                        <v-icon
                          id="hg-date-box-input-icon"
                          dense
                          size="20px"
                          :color="getColor('color_text_gray')"
                          >mdi-calendar</v-icon
                        >
                      </v-btn>
                    </template>
                  </v-text-field>
                </div>
              </v-card>
            </v-col>
            <v-col>
              <v-card
                max-width="400px"
                v-if="showCalendar"
                id="hg-date-box-date-card"
              >
                <div
                  class="date-buttons"
                  v-for="dates in dateButtons || []"
                  v-bind:key="dates.key"
                >
                  <v-btn
                    id="hg-date-box-date-buttons"
                    class="no-text-transform no-letter-spacing"
                    @click="
                      setDateByPreset(
                        dates.title,
                        dates.dateStart,
                        dates.dateEnd
                      )
                    "
                    >{{ dates.title }}</v-btn
                  >
                </div>
                <v-date-picker
                  class="search-card menu-dialog inline"
                  no-title
                  range
                  v-model="picker"
                  id="hg-date-box-date-picker"
                ></v-date-picker>
              </v-card>
            </v-col>
          </v-row>
        </v-container>
      </v-menu>
    </div>
  </div>
</template>

<script src="./hg-date-box.js"></script>
<style src="./hg-date-box.sass" lang="sass" scoped></style>
