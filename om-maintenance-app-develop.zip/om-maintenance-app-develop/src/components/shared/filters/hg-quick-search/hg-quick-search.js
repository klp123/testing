import _ from 'lodash';

const data = {
  quickSearchType: 'orderId',
  quickSearchValue: ''
};

function onSearchTextChange(cmd) {
  if (cmd === 'CLEAR_ALL') {
    this.quickSearchValue = '';
  }
  if ((this.quickSearchValue && this.quickSearchValue.trim().length > 2)
    || this.quickSearchValue.trim().length === 0) {
    const { label } = this.searchTypeList.find(
      (searchType) => searchType.value === this.quickSearchType,
    );
    this.$emit('quickSearchChange', {
      key: 'quickSearch',
      value: this.quickSearchValue,
      single: true,
      type: this.quickSearchType,
      label,
      text: `${this.quickSearchValue.trim()}`,
    });
  }
}

function searchTypeChange() {
  if (this.quickSearchValue && this.quickSearchValue.trim().length > 2) {
    const { label } = this.searchTypeList.find(
      (searchType) => searchType.value === this.quickSearchType,
    );
    this.$emit('quickSearchChange', {
      key: 'quickSearch',
      value: this.quickSearchValue.trim(),
      single: true,
      type: this.quickSearchType,
      label,
      text: `${this.quickSearchValue.trim()}`,
    });
  }
  this.$emit('quickSearchTypeChange', this.quickSearchType);
}

function getPlaceholder() {
  const selected = this.searchTypeList.find(
    (searchType) => searchType.value === this.quickSearchType,
  );
  if (_.isEmpty(selected)) {
    return '';
  }
  return selected.label;
}

function setExistingSearch() {
  if (_.get(this, 'selectedItems[0].type', null) && _.get(this, 'selectedItems[0].value', null)) {
    this.quickSearchType = this.selectedItems[0].type;
  } else {
    this.quickSearchType = _.get(this, 'selectedItems[0].type', null) || this.quickSearchType || this.defaultSearchType;
  }
  this.quickSearchValue = (this.selectedItems && this.selectedItems.length) ? this.selectedItems[0].value : '';
}

// @vuese
// @group FILTERS
// Quick search with type and value
// User can apply filter by selecting any type and any value.
export default {
  name: 'HgQuickSearch',
  data: () => (data),
  components: {},
  props: {
    // Search type list
    searchTypeList: {
      type: Array,
      required: false,
      default: () => [{
        label: 'Order ID',
        value: 'orderId',
      },
      {
        label: 'Equipment ID',
        value: 'equipmentId',
      },
      {
        label: 'All References',
        value: 'allReferences',
      },
      ],
    },
    // Default search type
    defaultSearchType: {
      type: String,
      required: false,
      default: () => 'orderId',
    },
    // Aleady selected value if any
    selectedItems: {
      type: Array,
      required: false,
      default: () => [],
    },
    // Disabled filter
    disabled: {
      type: Boolean,
      required: false,
      default: () => false,
    },
    // Queck search type state
    quickSearchTypeState: {
      type: String,
      required: false,
      default: () => '',
    },
  },
  created() {
    this.quickSearchType = this.defaultSearchType;
    setExistingSearch.bind(this)();
  },
  watch: {
    selectedItems: {
      handler() {
        setExistingSearch.bind(this)();
      },
      deep: true,
    },
  },
  methods: {
    // @vuese
    // Get Placeholder with currently selected search type
    getPlaceholder,
    // @vuese
    // Emit event on search text change
    onSearchTextChange,
    // @vuese
    // Emit event on search type change
    searchTypeChange,
    // @vuese
    // Sets existing search if any
    setExistingSearch
  },
};
