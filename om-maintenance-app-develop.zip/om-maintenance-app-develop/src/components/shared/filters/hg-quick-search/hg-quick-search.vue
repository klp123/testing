<template>
  <div class="search-container" id="search-filter" :class="{ 'disabled-filter': disabled }">
    <v-select
      :items="searchTypeList"
      item-text="label"
      v-model="quickSearchType"
      @change="searchTypeChange"
      class="search-dropdown"
      color="highlight"
      dense
      outlined
      filled
      :disabled="disabled"
    ></v-select>
    <v-text-field
      class="search-box"
      v-model="quickSearchValue"
      v-debounce:500="onSearchTextChange"
      :placeholder="`Search ${getPlaceholder()}`"
      prepend-inner-icon="mdi-magnify"
      clearable
      @click:clear="onSearchTextChange('CLEAR_ALL')"
      outlined
      color="highlight"
      :disabled="disabled"
    ></v-text-field>
  </div>
</template>

<script src="./hg-quick-search.js"></script>
<style src="./hg-quick-search.sass" lang="sass" scoped></style>
