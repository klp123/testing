import _colors from '~@hubgroup/hg-vue-library/src/assets/styles/core/_colors';

function onItemSelected(item, subItem) {
  this.shown = false;

  // Check if item is already selected
  // Unselect if it is selected
  if (this.selectedFields.type === item.value.type && (!subItem || this.selectedFields.level === subItem.value)) {
    this.$emit('onUnItemSelected', item);
  } else {
    const valueObj = {
      type: item.value.type,
      level: subItem ? subItem.value : 0,
    };

    // Emit selected event if its not been selected
    this.$emit('onItemSelected', {
      key: item.key,
      value: valueObj,
      label: item.label,
      text: subItem ? `${item.shortLabel} (${subItem.text})` : item.shortLabel,
      single: true,
    });
  }
}

function onClickOutsideDialog($event) {
  const clickedClasses = $event.srcElement.className;
  if (clickedClasses.indexOf('menu-dialog') === -1 && clickedClasses.indexOf('field-component') === -1 && this.shown && !$event.srcElement.hasAttribute('autocomplete')) {
    this.shown = false;
  }
}

function isCheckedItem(type, level) {
  if (!type || !this.selectedFields.type) return false;

  return this.selectedFields.type === type && (this.selectedFields.level === level || !level);
}

function autoFocus() {
  setTimeout(() => {
    this.$refs.radio[0].focus();
  }, 100);
}

function getColor(name) {
  return _colors[name];
}

// @vuese
// @group FILTERS
// This filter has dropdown field.
// User can apply filter by selecting any option.
export default {
  name: 'HgNestedRadioField',
  data: () => ({
    filter: {},
    shown: false,
  }),
  props: {
    filterLabel: {
      type: String,
      required: true,
      default: () => null,
    },
    selectedFields: {
      type: Object,
      required: true,
      default: () => null,
    },
    subComponents: {
      type: Array,
      required: false,
      default: () => [],
    },
    // Disabled filter
    disabled: {
      type: Boolean,
      required: false,
      default: () => false,
    },
  },
  methods: {
    // @vuese
    // Used to update filter on item selected from list
    // @arg ($event)
    onItemSelected,
    // @vuese
    // Used to change the up/down icon when clicked outside filter component.
    // @arg ($event)
    onClickOutsideDialog,
    // @vuese
    // Fires searchTextChanged event on keyup event for customer input box
    // Uses default of 300ms debounce
    // @arg -
    isCheckedItem,
    // @vuese
    // Auto focus
    // @arg none
    autoFocus,
    // @vuese
    // Gets the color code for given color name
    // @arg ($colorName)
    getColor,
  },
};
