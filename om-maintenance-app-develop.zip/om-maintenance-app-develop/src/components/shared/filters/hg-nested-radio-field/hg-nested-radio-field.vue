<template>
  <div class="filter-content">
    <div v-if="disabled" class="filter-disabled">
      <label dark class="label-filter">
        <label>{{ filterLabel }}</label>
        <v-icon large :color="getColor('color_text_gray')" v-if="!shown">
          mdi-chevron-down
        </v-icon>
      </label>
    </div>

    <div
      v-click-outside="onClickOutsideDialog"
      v-if="!disabled"
    >
      <v-menu offset-y :close-on-content-click="false" :value="shown">
        <template v-slot:activator="{ on, attrs }">
          <label
            dark
            v-bind="attrs"
            v-on="on"
            v-on:click="
              shown = !shown;
              autoFocus();
            "
            app
            class="label-filter"
            v-bind:class="{ 'label-filter-active': shown }"
          >
            <label>{{ filterLabel }}</label>
            <v-icon large :color="getColor('color_text_gray')" v-if="!shown">
              mdi-chevron-down
            </v-icon>
            <v-icon large :color="getColor('color_text_gray')" v-if="shown">
              mdi-chevron-up
            </v-icon>
          </label>
        </template>

        <v-card class="hg-radio-field-card menu-dialog" width="245px">
          <div
            class="field-component"
            v-for="item in subComponents || []"
            v-bind:key="item.text"
            v-bind:class="{ margin: item.items && item.items.length }"
          >
            <div class="filter-title" v-on:click="onItemSelected(item)">
              <div class="input-wrapper">
                <input
                  ref="radio"
                  type="radio"
                  class="radio-button"
                  :checked="isCheckedItem(item.value.type, 0)"
                />
              </div>
              <div class="text-wrapper">
                <div
                  v-if="
                    !item.items ||
                    !item.items.length ||
                    (item.items && item.items.length === 1)
                  "
                  class="level-color-box color_primary_red"
                ></div>
                <label>{{ item.text }}</label>
              </div>
            </div>
            <div class="filter-options">
              <div
                v-for="subItem in item.items || []"
                v-bind:key="subItem.text"
                class="filter-options-item"
                v-on:click="onItemSelected(item, subItem)"
              >
                <div class="select-field">
                  <input
                    ref="radio"
                    type="radio"
                    class="radio-button"
                    :checked="isCheckedItem(item.value.type, subItem.value)"
                  />
                </div>
                <div class="select-text">
                  <div class="level-color-box" :class="subItem.color"></div>
                  <label>{{ subItem.text }}</label>
                </div>
              </div>
            </div>
          </div>
        </v-card>
      </v-menu>
    </div>
  </div>
</template>

<script src="./hg-nested-radio-field.js"></script>
<style src="./hg-nested-radio-field.sass" lang="sass" scoped></style>
