<template>
  <div class="filter-content">
    <div v-if="disabled" class="filter-disabled">
      <label dark class="label-filter">
        <label>{{ filterLabel }}</label>
        <v-icon large :color="getColor('color_text_gray')" v-if="!shown">
          mdi-chevron-down
        </v-icon>
      </label>
    </div>

    <div
      v-click-outside="onClickOutsideDialog"
      v-if="!disabled"
    >
      <v-menu offset-y :close-on-content-click="false" :value="shown">
        <template v-slot:activator="{ on, attrs }">
          <label
            dark
            v-bind="attrs"
            v-on="on"
            v-on:click="
              shown = !shown;
              autoFocus();
            "
            app
            class="label-filter"
            v-bind:class="{ 'label-filter-active': shown }"
          >
            <label>{{ filterLabel }}</label>
            <v-icon large :color="getColor('color_text_gray')" v-if="!shown">
              mdi-chevron-down
            </v-icon>
            <v-icon large :color="getColor('color_text_gray')" v-if="shown">
              mdi-chevron-up
            </v-icon>
          </label>
        </template>

        <v-card class="hg-radio-field-card menu-dialog">
          <div
            class="field-component"
            v-for="item in options || []"
            v-bind:key="item.text"
          >
            <div class="filter-title" v-on:click="onItemSelected(item)">
              <div class="input-wrapper">
                <input
                  ref="radio"
                  type="radio"
                  class="radio-button"
                  :checked="isCheckedItem(item.value)"
                  :id="`id-radio-value-${item.value}`"
                />
              </div>
              <div class="text-wrapper" :id="`id-radio-text-${item.text}`">
                <label>{{ item.text }}</label>
              </div>
            </div>
          </div>
        </v-card>
      </v-menu>
    </div>
  </div>
</template>

<script src="./hg-radio-filter.js"></script>
<style src="./hg-radio-filter.sass" lang="sass" scoped></style>
