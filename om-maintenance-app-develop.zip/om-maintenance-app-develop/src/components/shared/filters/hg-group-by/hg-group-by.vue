<template>
  <div class="group-by">
    <div>
      <label
        class="show-as-orders"
        :class="!showGroupBy ? 'active' : 'inactive'"
        >Show as Orders</label
      >
    </div>

    <div>
      <v-switch color="light" v-model="showGroupByModel" @click="toogleGroupBy()"></v-switch>
    </div>

    <div class="group-by-options">
      <label
        class="show-as-groups-by-ne"
        :class="showGroupBy ? 'active' : 'inactive'"
        >Show as Groups by</label
      >
      <br />
      <v-menu offset-y>
        <template v-slot:activator="{ on, attrs }">
          <label
            class="show-as-groups-by-ne"
            :class="showGroupBy ? 'active' : 'inactive'"
            v-bind="attrs"
            v-on="on">
            {{ selectedValue.text || defaultSelectedValue.text }}
            <v-icon color="white"> mdi-chevron-down </v-icon>
          </label>
        </template>
        <v-list v-if="showGroupBy">
          <v-list-item v-for="(item, index) in items" :key="index" @click="updateSelected(item)">
            <input type="radio" class="radio-button" :checked="isChecked(item.value.type)" />
            <v-list-item-title class="radio-text">{{ item.text }}</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>
    </div>
  </div>
</template>

<script src="./hg-group-by.js"></script>
<style src="./hg-group-by.sass" lang="sass" scoped></style>
