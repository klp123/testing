function toogleGroupBy() {
  this.$emit('toogleGroupBy', !this.showGroupBy);
}

function updateSelected(value) {
  this.$emit('change', value);
}

function isChecked(type) {
  return this.selectedValue.key === type;
}

// @vuese
// @group GROUP BY
// GroupBy Options
export default {
  name: 'HgGroupBy',
  data: () => ({
    showGroupByModel: false,
  }),
  props: {
    // List of dropdown for groups
    items: {
      type: Array,
      required: false,
      default: () => [],
    },
    // selected active group
    selectedValue: {
      type: Object,
      required: false,
      default: {},
    },
    // default selected active group
    defaultSelectedValue: {
      type: Object,
      required: false,
      default: {},
    },
    // show group by dropdown
    showGroupBy: {
      type: Boolean,
      required: false,
      default: false,
    },
  },
  watch: {
    showGroupBy: {
      handler(newVal) {
        this.showGroupByModel = newVal;
      },
      deep: true,
    },
  },
  methods: {
    // @vuese
    // Toogle GroupBy
    // @arg (show) show/not-show
    toogleGroupBy,
    // @vuese
    // Update Selected group
    // @arg (group)
    updateSelected,
    // @vuese
    // Is group selected
    // @arg (type) group type
    isChecked,
  },
};
