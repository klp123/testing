import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';

function onItemSelected(item, key) {
  this.shown = false;
  const result = {};
  result[key] = item;

  if ((this.selectedFields[key] || {}).value === item.value) {
    this.$emit('onUnItemSelected', item);
  } else {
    this.$emit('onItemSelected', item);
  }
}

function onClickOutsideDialog($event) {
  const clickedClasses = $event.srcElement.className;
  if (clickedClasses.indexOf('menu-dialog') === -1 && clickedClasses.indexOf('field-component') === -1 && this.shown && !$event.srcElement.hasAttribute('autocomplete')) {
    this.shown = false;
  }
}

function isCheckedItem(item, key) {
  if (!key) return false;
  return item === (this.selectedFields[key] || {}).value;
}

function autoFocus() {
  setTimeout(() => {
    this.$refs.radio[0].focus();
  }, 100);
}

function getColor(name) {
  return _colors[name];
}

// @vuese
// @group FILTERS
// This filter has dropdown field.
// User can apply filter by selecting any option.
export default {
  name: 'HgRadioField',
  data: () => ({
    filter: {},
    shown: false,
  }),
  props: {
    filterLabel: {
      type: String,
      required: true,
      default: () => null,
    },
    selectedFields: {
      type: Object,
      required: true,
      default: () => null,
    },
    subComponents: {
      type: Array,
      required: false,
      default: () => [],
    },
    // Disabled filter
    disabled: {
      type: Boolean,
      required: false,
      default: () => false,
    },
  },
  methods: {
    // @vuese
    // Used to update filter on item selected from list
    // @arg ($event)
    onItemSelected,
    // @vuese
    // Used to change the up/down icon when clicked outside filter component.
    // @arg ($event)
    onClickOutsideDialog,
    // @vuese
    // Fires searchTextChanged event on keyup event for customer input box
    // Uses default of 300ms debounce
    // @arg -
    isCheckedItem,
    autoFocus,
    getColor,
  },
};
