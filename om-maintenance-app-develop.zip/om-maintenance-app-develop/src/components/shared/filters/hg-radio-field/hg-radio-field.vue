<template>
  <div class="filter-content" v-click-outside="onClickOutsideDialog">

      <div v-if="disabled" class="filter-disabled">
      <label
            color="primary"
            dark
            class="label-filter"
          >
            <label>{{ filterLabel }}</label>
            <v-icon large :color="getColor('color_text_gray')">
              mdi-chevron-down
            </v-icon>
          </label>
    </div>
        <div
      v-if="!disabled"
      v-click-outside="onClickOutsideDialog"
    >
        <v-menu offset-y :close-on-content-click="false" :value="shown">
      <template v-slot:activator="{ on, attrs }">
        <label
          dark
          v-bind="attrs"
          v-on="on"
          v-on:click="shown = !shown; autoFocus()"
          app
          class="label-filter"
          v-bind:class="{ 'label-filter-active': shown }"
        >
          <label>{{ filterLabel }}</label>
          <v-icon large :color="getColor('color_text_gray')" v-if="!shown">
            mdi-chevron-down
          </v-icon>
          <v-icon large :color="getColor('color_text_gray')" v-if="shown">
            mdi-chevron-up
          </v-icon>
        </label>
      </template>

      <v-card class="hg-radio-field-card menu-dialog">
        <div
          class="field-component"
          v-for="(item, index) in subComponents || []"
          v-bind:key="item.title"
          v-bind:class="{ 'border-bottom': index !== subComponents.length - 1 }"
        >
          <div class="filter-title">
            <label>{{ item.title }}</label>
          </div>
          <div class="filter-options">
            <div v-for="subItem in item.items || []" v-bind:key="subItem.value"
            class="filter-options-item"
            v-on:click="onItemSelected(subItem, subItem.key)">
              <div class="select-field">
                <input
                  ref="radio"
                  type="radio"
                  class="radio-button"
                  :checked="isCheckedItem(subItem.value, subItem.key)"
                />
              </div>
              <div class="select-text">
                <label>{{
                  subItem.text
                }}</label>
              </div>
            </div>
          </div>
        </div>
      </v-card>
    </v-menu>

    </div>

  </div>
</template>

<script src="./hg-radio-field.js"></script>
<style src="./hg-radio-field.sass" lang="sass" scoped></style>
