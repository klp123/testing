<template>
  <div class="save-filter-content" v-click-outside="onClickOutsideDialog" title="save filter">
    <v-menu offset-y :close-on-content-click="false" :value="shown">
      <template v-slot:activator="{ on, attrs }">
        <v-img
          class="saved-filter-img"
          max-height="32"
          max-width="32"
          v-bind="attrs"
          v-on="on"
          :src="getIcon('saved_filter')"
        ></v-img>
      </template>
      <v-card class="save-filter-card menu-dialog">
        <div class="save-filter-heading">Saved Filters</div>
        <div class="save-filter-list-container" id="save-filter-list-container">
          <div
            v-for="(savedFilter, index) in savedFiltersList"
            :key="index"
            class="save-filter-list-grid-container"
          >
            <div>
              <input
                type="radio"
                name="radio"
                class="radio-button"
                :value="savedFilter"
                :checked="isChecked(savedFilter)"
                :id="savedFilter"
                @click="onselectedItem(savedFilter)"
              />
            </div>
            <div>
              <label
                :for="savedFilter"
                @click.prevent="onselectedItem(savedFilter)"
                class="select-text"
              >{{ savedFilter.name }}</label>
            </div>
            <div>
              <v-img
                class="saved-filter-img"
                max-height="15"
                max-width="15"
                @click="deleteFilter(savedFilter)"
                :src="getIcon('delete_icon')"
              ></v-img>
            </div>
          </div>
        </div>
        <v-form ref="saveFiltersForm" onsubmit="return false;">
          <div class="save-filter-container">
            <v-text-field
              class="add-saved-filter"
              color="highlight"
              v-model="saveFilterName"
              @keydown.enter="addSaveFilter()"
              placeholder="Save Filter"
              :loading="loading"
              outlined
              :error-messages="`${this.errorMessage}`"
              :rules="[validateMinCharacterLength,
            validateMaxCharacterLength,
            noSpecialCharacters,
            validateDulicateFilterName]"
            ></v-text-field>
            <div
              class="save-btn"
              @click="addSaveFilter()"
            >Save</div>
          </div>
        </v-form>
      </v-card>
    </v-menu>
  </div>
</template>

<script src="./hg-save-filter.js"></script>
<style src="./hg-save-filter.sass" lang="sass" scoped></style>
