import images from '@hubgroup/hg-vue-library/src/assets/images/_image.loader';
import _ from 'lodash';

const componentData = {
  shown: false,
  saveFilterName: '',
  errorMessage: '',
};

function onClickOutsideDialog($event) {
  const clickedClasses = $event.srcElement.className;
  if (this.$refs.saveFiltersForm) {
    this.$refs.saveFiltersForm.resetValidation();
  }
  this.errorMessage = '';
  if (clickedClasses.indexOf('menu-dialog') === -1 && $event.srcElement.type !== 'checkbox') {
    this.shown = false;
  }
}

function addSaveFilter() {
  if (this.saveFilterName.trim() && this.$refs.saveFiltersForm.validate()) {
    this.$emit('saveFilter', this.saveFilterName.trim());
    if (!this.hasDuplicateSavedFilter) {
      this.saveFilterName = '';
      this.errorMessage = '';
      this.$refs.saveFiltersForm.resetValidation();
    } else {
      this.errorMessage = `Filter already exists! (${this.duplicateSavedFilterName ? this.duplicateSavedFilterName : ''})`;
    }
  }
}

function deleteFilter(filter) {
  this.$emit('deleteSavedFilter', filter.name);
}

function onselectedItem(val) {
  this.$emit('selectedSavedFilterChanged', val);
}

function validateMaxCharacterLength(filterName) {
  return (filterName && filterName.length <= 60) || 'Name must be less than 60 characters';
}

function validateMinCharacterLength(filterName) {
  return (filterName && filterName.length >= 2) || 'Name must be atleast 2 characters';
}

function noSpecialCharacters(filterName) {
  const pattern = /^[-@.#&+:,()~/\w\s]*$/;
  return (pattern.test(filterName.trim())) || 'Filter Name can only have -@.#&+:,()~ Special characters';
}

function validateDulicateFilterName(filterName) {
  let name;
  const hasDuplicate = this.savedFiltersList.some((filter) => {
    name = (filter.name.toUpperCase().trim() === filterName.toUpperCase().trim()) ? filterName : 'Filter Name';
    return (filter.name.toUpperCase().trim() === filterName.toUpperCase().trim());
  });
  return !hasDuplicate || `${name} already exists!`;
}

function getIcon(iconName) {
  return images[iconName];
}

function isChecked(filter) {
  return _.isEqual(this.selectedSavedFilter, filter);
}

// @vuese
// @group FILTERS
// Saved filters component
export default {
  name: 'hg-save-filter',
  data: () => (componentData),
  props: {
    // Items of checkbox vaues
    savedFiltersList: {
      type: Array,
      required: false,
      default: () => [],
    },
    loading: {
      type: Boolean,
      required: false,
      default: () => false,
    },
    hasDuplicateSavedFilter: {
      type: Boolean,
      required: false,
      default: () => false,
    },
    duplicateSavedFilterName: {
      required: false,
      default: () => null,
    },
    selectedSavedFilter: {
      required: false,
      default: () => null,
    },
  },
  methods: {
    onClickOutsideDialog,
    addSaveFilter,
    deleteFilter,
    onselectedItem,
    validateMaxCharacterLength,
    validateMinCharacterLength,
    noSpecialCharacters,
    validateDulicateFilterName,
    getIcon,
    isChecked,
  },
  mounted() {
  },
};
