import * as _ from 'lodash';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';

function getFiltersArray() {
  let filterArr = [];

  // Get all filters into a single array with label and value
  Object.keys(this.selectedFilters).forEach((key) => {
    if (this.selectedFilters[key] && this.selectedFilters[key].length) {
      const temp = _.cloneDeep(this.selectedFilters[key].filter(
        (filter) => (filter.label && filter.text),
      ));
      filterArr = filterArr.concat(temp);
    }
  });

  return filterArr;
}

function clearFilter(filter) {
  this.$emit('clearFilters', filter);
}

function clearAllFilters() {
  this.$emit('clearAllFilters');
}

function getColor(name) {
  return _colors[name];
}

function isGroupBySelected() {
  return _.get(this.groupBy, 'active', false);
}

function groupByLabel() {
  return _.get(this.groupBy, 'field.groupLabel', '');
}

function clearGroupBy() {
  this.$emit('clearGroupBy');
}

function truncate(str, maxLength = 15) {
  return (str.length > maxLength) ? `${str.substr(0, maxLength - 1)}...` : str;
}

// @vuese
// @group FILTERS
// Renders applied multiple filters. Takes filters from order store.
// Updates view instantly on addition/removal of any filter.
// Users can clear filter individually or do clear all.
export default {
  name: 'HgFilterDisplay',
  data: () => ({
    filter: {},
  }),
  props: {
    // Items of checkbox vaues
    selectedFilters: {
      type: Object,
      required: false,
      default: () => [],
    },
    // Group By status, field and applied filters
    groupBy: {
      type: Object,
      required: false,
      default: () => ({
        active: false,
        field: {},
        filters: [],
      }),
    },
  },
  methods: {
    truncate,
    // @vuese
    // Used to clear filter
    // @arg ({ filterKey, value})  Removing filter
    clearFilter,
    // @vuese
    // Used to clear all filter
    clearAllFilters,
    // @vuese
    // Gets color for given color name
    // @arg color name
    getColor,
    // @vuese
    // Used to clear groupBy
    clearGroupBy,
  },
  computed: {
    getFiltersArray,
    isGroupBySelected,
    groupByLabel,
  },
};
