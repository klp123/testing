<template>
  <div>
    <div v-if="isGroupBySelected" class="inline-block">
      <label
        class="filter-text"
        >Grouped by:</label>
         <v-chip
        class="ma-2"
        :color="getColor('color_primary_blue')"
        label
        :text-color="getColor('color_white')"
      >
        <label class="chip-label">{{ groupByLabel }}</label>
        <v-icon
          large
          :color="getColor('color_white')"
          v-on:click="clearGroupBy()"
        >
          mdi-close
        </v-icon>
      </v-chip>
    </div>
    <div class="inline-block">
      <label
        v-if="getFiltersArray && getFiltersArray.length"
        class="filter-text"
        >Filtering by:</label
      >
      <v-chip
        class="ma-2"
        :color="getColor('color_primary_blue')"
        label
        :text-color="getColor('color_white')"
        v-for="item in getFiltersArray"
        :key="item.value + item.key"
        @click:close="clearFilter(item)"
      >
        <label class="chip-label">
          {{ item.label }}: {{ item.key === 'quickSearch' ? truncate(item.text) : item.text }}
        </label>
        <v-icon
          large
          :color="getColor('color_white')"
          v-on:click="clearFilter(item)"
        >
          mdi-close
        </v-icon>
      </v-chip>
      <label
        v-if="getFiltersArray && getFiltersArray.length"
        v-on:click="clearAllFilters()"
        class="clear"
        >Clear All</label
      >
    </div>
  </div>
</template>

<script src="./hg-filter-display.js"></script>
<style src="./hg-filter-display.sass" lang="sass" scoped></style>
