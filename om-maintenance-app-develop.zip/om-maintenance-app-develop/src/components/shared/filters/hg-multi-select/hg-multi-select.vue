<template>
  <v-menu
    offset-y
    @input="onClickOutsideDialog"
    :close-on-click="true"
    :close-on-content-click="false"
    :disabled="disabled"
  >
    <template v-slot:activator="{ on, attrs }">
      <div class="container" >
        <div
          tabindex="0"
          color="primary"
          dark
          v-bind="attrs"
          v-on="on"
          :disabled="disabled"
          v-on:click="if (disabled) shown = !shown;"
          app
          class="multi-select-box"
        >
          <v-chip
            v-bind="attrs"
            class="chip-style"
            v-for="(item, index) in displayData"
            :key="index"
            close
            @click:close="onItemSelected(item, index)"
          >
            <span>{{ item.displayValue }}</span>
          </v-chip>
            <v-icon
              right
              medium
              class="float-right"
              v-if="!shown"
            >
              mdi-chevron-down
            </v-icon>
            <v-icon
              right
              medium
              class="float-right"
              v-if="shown"
            >
              mdi-chevron-up
            </v-icon>
          </div>
      </div>
    </template>
    <v-card class="search-card menu-dialog">
      <v-list>
        <v-list-item
          v-on:click="onItemSelected(item, index)"
          v-for="(item, index) in items"
          :key="index"
        >
          <v-checkbox
            class="menu-dialog"
            :color="getColor('color_primary_blue')"
            :input-value="isSelected(item)"
            :disabled="isAllSelected && index!==0"
            ref="list"
          ></v-checkbox>
          <div
            :id="item.value"
            class="item-label menu-dialog"
            v-bind:class="{
              disabledMulitSelectCheckbox:
                isAllSelected && index!==0
            }"
          >
            {{ item.displayValue }}
          </div>

        </v-list-item>
      </v-list>
    </v-card>
  </v-menu>
</template>

<script src='./hg-multi-select.js' />
<style src='./hg-multi-select.sass' lang='sass' scoped />
