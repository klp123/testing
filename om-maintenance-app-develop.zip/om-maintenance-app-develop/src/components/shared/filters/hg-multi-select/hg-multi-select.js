import _ from 'lodash';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';

function onClickOutsideDialog(isMenuOpen) {
  if (!isMenuOpen) {
    this.shown = false;
  }
}

function onItemSelected(item, index) {
  if (this.isAllSelected && index !== 0) return;
  if ((this.selectedItems || []).findIndex((el) => el.value === item.value) < 0) {
    this.$emit('onItemChecked', item);
  } else {
    this.$emit('onItemUnchecked', item);
  }
  this.updateDisplayData();
}

function isSelected(item) {
  return this.selectedItems.findIndex((el) => el.displayValue === item.displayValue) > -1;
}

function updateDisplayData() {
  if (!_.isEmpty(this.selectedItems)) {
    const displayStr = [];
    this.selectedItems.forEach((item) => {
      const val = item || [];
      displayStr.push(val);
    });
    this.displayData = displayStr;
  } else {
    this.displayData = [];
  }
}

function getColor(name) {
  return _colors[name];
}

export default {
  name: 'HgMultiSelect',
  components: {
  },
  data: () => ({
    shown: false,
    displayData: [],
  }),
  watch: {
    selectedItems: {
      handler() {
        this.updateDisplayData();
      }
    },
  },
  created() {
    this.updateDisplayData();
  },
  computed: {
    isAllSelected() {
      return this.selectedItems.findIndex((el) => el.displayValue === 'ALL') > -1;
    }
  },
  props: {
    disabled: {
      type: Boolean,
      default: false,
    },
    items: {
      type: Array,
      required: false,
      default: () => [],
    },
    // Already checked items
    selectedItems: {
      type: Array,
      required: false,
      default: () => [],
    },
  },
  methods: {
    onClickOutsideDialog,
    updateDisplayData,
    getColor,
    onItemSelected,
    isSelected
  },
};
