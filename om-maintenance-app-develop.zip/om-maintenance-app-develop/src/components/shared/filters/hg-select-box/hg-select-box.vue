<template>
  <div class="filter-content">
    <div v-if="disabled" class="filter-disabled">
      <label color="primary" dark class="label-filter">
        <label>{{ filterLabel }}</label>
        <v-icon large :color="getColor('color_text_gray')">
          mdi-chevron-down
        </v-icon>
      </label>
    </div>

    <div v-if="!disabled" v-click-outside="onClickOutsideDialog">
      <v-menu offset-y :close-on-content-click="false" :value="shown">
        <template v-slot:activator="{ on, attrs }">
          <label
            color="primary"
            dark
            v-bind="attrs"
            v-on="on"
            v-on:click="
              shown = !shown;
              autoFocus();
            "
            app
            class="label-filter"
            v-bind:class="{ 'label-filter-active': shown }"
          >
            <label>{{ filterLabel }}</label>
            <v-icon large :color="getColor('color_text_gray')" v-if="!shown">
              mdi-chevron-down
            </v-icon>
            <v-icon large :color="getColor('color_text_gray')" v-if="shown">
              mdi-chevron-up
            </v-icon>
          </label>
        </template>

        <v-card class="search-card menu-dialog">
          <v-list>
            <v-list-item
              v-on:click="onItemSelected(item)"
              v-for="(item, index) in items"
              :key="index"
            >
              <v-checkbox
                class="menu-dialog"
                :color="getColor('color_primary_blue')"
                :input-value="isSelected(item)"
                ref="list"
              ></v-checkbox>
              <div :id="item.value" class="item-label menu-dialog">
                {{ item.text }}
              </div>
            </v-list-item>
          </v-list>
        </v-card>
      </v-menu>
    </div>
  </div>
</template>

<script src="./hg-select-box.js"></script>
<style src="./hg-select-box.sass" lang="sass" scoped></style>
