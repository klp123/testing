import _colors from '~@hubgroup/hg-vue-library/src/assets/styles/core/_colors';

function onItemSelected(item) {
  if ((this.selectedItems || []).findIndex((itm) => itm.value === item.value) < 0) {
    this.$emit('onItemChecked', item);
  } else {
    this.$emit('onItemUnchecked', item);
  }
}

function isSelected(item) {
  return this.selectedItems.findIndex((itm) => itm.value === item.value) > -1;
}

function onClickOutsideDialog($event) {
  const clickedClasses = $event.srcElement.className;
  if (clickedClasses.indexOf('menu-dialog') === -1 && $event.srcElement.type !== 'checkbox') {
    this.shown = false;
  }
}

function autoFocus() {
  setTimeout(() => {
    this.$refs.list[0].$el.children[0].children[0].children[0].children[1].focus();
  }, 100);
}

function getColor(name) {
  return _colors[name];
}

// @vuese
// @group FILTERS
// Filter with select box elements
export default {
  name: 'HgSelectBox',
  data: () => ({
    filter: {},
    shown: false,
  }),
  props: {
    // Items of checkbox vaues
    items: {
      type: Array,
      required: false,
      default: () => [],
    },
    // Already checked items
    selectedItems: {
      type: Array,
      required: false,
      default: () => [],
    },
    // Filter field
    filterKey: {
      type: String,
      required: true,
      default: () => null,
    },
    // Filter label
    filterLabel: {
      type: String,
      required: true,
      default: () => null,
    },
    // Disabled filter
    disabled: {
      type: Boolean,
      required: false,
      default: () => false,
    },
  },
  methods: {
    // @vuese
    // Used to update filter on item selected from search list
    // @arg (event, status)
    onItemSelected,
    // @vuese
    // Used to check if element is alredy selected
    // @arg (status)
    isSelected,
    onClickOutsideDialog,
    autoFocus,
    getColor,
  },
};
