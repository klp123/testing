<template>
  <div class="footer">
    <div class="pagination-info text">
      Showing
      {{ Number(showingCounts).toLocaleString() }}
      of
      {{
        totalCounts > 9999
          ? `${Number(totalCounts).toLocaleString()}+`
          : Number(totalCounts).toLocaleString()
      }}
      {{ totalCounts === 1 ? "Item" : "Items" }}.
    </div>
    <div class="divider"></div>
    <div class="pagination-dropdown">
      <div class="text">{{sourceText}} per page</div>
      <div>
        <v-select
          :items="rowsPerPageItems"
          v-model="options.limit"
          label="Solo field"
          class="select-items-per-page"
          dense
          solo
          @change="itemsPerPageChanged()"
          whitespace="false"
        ></v-select>
      </div>
    </div>
    <div class="pagination-page-numbers">
      <v-pagination
        :length="totalPages"
        v-model="options.page"
        class="custom-pagination"
        :color="getColor('color_primary_blue')"
        total-visible="7"
      ></v-pagination>
    </div>
  </div>
</template>

<script src="./hg-pagination.js"></script>
<style src="./hg-pagination.sass" lang="sass" scoped></style>
