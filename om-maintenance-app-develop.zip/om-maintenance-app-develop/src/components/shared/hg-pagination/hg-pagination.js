import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';

const optionsData = {
  rowsPerPageItems: [10, 20, 30, 40, 50, 100],
  options: {
    page: 1,
    limit: 20,
  },
};

function getColor(name) {
  return _colors[name];
}

function totalPages() {
  return Math.ceil(this.totalCounts / this.options.limit);
}

function itemsPerPageChanged() {
  this.resetPage();
}

function resetPage() {
  this.options.page = 1;
  this.options = { ...this.options };
}

// @vuese
// @group PAGINATION
// Pagination for table
export default {
  name: 'HgTablePagination',
  data: () => (optionsData),
  props: {
    totalCounts: {
      type: Number,
      required: false,
      default: () => 0,
    },
    showingCounts: {
      type: Number,
      required: false,
      default: () => 0,
    },
    sourceText: {
      type: String,
      required: false,
      default: 'Groups',
    },
  },
  watch: {
    options: {
      handler(newVal) {
        this.$emit('paginationChanged', newVal);
      },
      deep: true,
    },
  },
  computed: {
    totalPages,
  },
  methods: {
    // @vuese
    // Gets color for given color name
    // @arg (name) color name
    getColor,
    itemsPerPageChanged,
    resetPage,
  },
  components: {

  },
};
