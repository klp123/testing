import moment from 'moment-timezone';
import VueTimepicker from 'vue2-timepicker';
import { ImageLoaderService } from '@hubgroup/hg-om-shared-services';
import cdnImagesEnum from '@hubgroup/hg-vue-oc-util-lib/src/enums/cdn-images.enum';

function onOutsideMenuClick() {
  if (this.$refs.menu) {
    if (!this.$refs.menu.isActive) {
      this.$refs.menu.save(this.formatted);
    }
  }
}

function getIcon(iconName) {
  return ImageLoaderService.getCdnImageUrl(iconName);
}

const getTodayDate = () => moment(new Date()).tz('America/Chicago').format().split('T')[0];

const getISODate = (value) => {
  if (!value) return '';
  return new Date(value).toISOString();
};

function isDisabled() {
  return this.config.disabled;
}

function clearDatetime() {
  this.formatted = '';
  this.date = '';
  this.time = '';
  this.$emit('dateTimeChanged', null);
}

function onDateChange(dateEvent) {
  this.date = dateEvent;
  this.setDisplayDate();
}

function onTimeChange(timeEvent) {
  if (timeEvent.data.HH) {
    const hour = parseInt(timeEvent.data.HH, 10);
    this.hours = hour;
    this.setDateTime();
  }
}

function setDisplayDate() {
  if (!this.showTimeOption) {
    this.formatted = moment(this.date).format('MM/DD/YY');
    this.$emit('dateTimeChanged', this.date);
  } else {
    this.formatted = moment(this.date).format('MM/DD/YY');
    const dateTime = new Date(moment(this.date));
    this.$emit('dateTimeChanged', dateTime);
  }
}

function setDateTime() {
  const dateTime = moment(this.date).hours(this.hours).format();
  this.$emit('timeChanged', dateTime);
}

/**
 *
 * @param {*} value
 * Check if the date is valid , example 12/34/23 is an invalid date and show the error message
 */
function onInputChange(value) {
  if (value) {
    if (moment(value || null, 'MM/DD/YY', true).isValid()) {
      this.errorMessage = '';
      this.date = moment(value).format('YYYY-MM-DD');
      this.setDisplayDate();
    } else if (this.checkIfValidDate) {
      this.formatted = moment(value).format('MM/DD/YY');
    }
  }
}

function setAllDateValues(date) {
  [this.date] = date.toISOString().split('T');
}

export default {
  name: 'DatetimePickerComponent',
  components: {
    VueTimepicker
  },
  data: () => ({
    cdnImagesEnum,
    menu: false,
    date: '',
    time: '',
    formatted: '',
    errorMessage: '',
    hours: 0,
    minutes: 0
  }),
  props: {
    datePickerAttach: {
      type: Boolean,
      default: true,
    },
    showRequiredIcon: {
      type: Boolean,
      default: false,
    },
    timeFormat: {
      type: String,
      default: 'HH:mm'
    },
    showTimeOption: {
      type: Boolean,
      default: false
    },
    dateTime: {
      type: String,
      required: false,
      default: null
    },
    clearInput: {
      type: Boolean,
      required: false,
      default: false
    },
    config: {
      type: Object,
      required: false,
      default: () => ({
        mode: 'datetime',
        maxDate: null,
        minDate: getTodayDate(),
        disabled: false,
        label: ''
      })
    },
    required: {
      type: Boolean,
      required: false,
      default: false
    },
    warningMessage: {
      type: Object,
      required: false,
      default: () => ({
        visible: false,
        message: ''
      })
    },
    checkIfValidDate: {
      type: Boolean,
      required: false,
      default: false
    },
    minRule: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  methods: {
    onOutsideMenuClick,
    isDisabled,
    clearDatetime,
    onDateChange,
    setDisplayDate,
    onInputChange,
    setAllDateValues,
    setDateTime,
    onTimeChange,
    getIcon,
  },
  computed: {
    isDateTimeValid() {
      let valid = true;
      this.errorMessage = '';
      const isEmptyField = this.formatted === null || this.formatted === '';
      const isValidDatetimeEntry = moment(this.formatted || null, 'MM/DD/YY', true).isValid();
      const isBeforeMinDate = moment(this.date).isBefore(moment(this.config.minDate));
      if (!isEmptyField) {
        if (!isValidDatetimeEntry) {
          valid = false;
          this.errorMessage = 'Please enter a valid datetime (MM/DD/YY) or shortcut';
        } else if (isBeforeMinDate && this.config.minDate) {
          valid = false;
          this.errorMessage = 'Please select a date within allowed values';
        }
      }
      if (!(this.$refs.dateTimeInputField && this.$refs.dateTimeInputField.hasInput)) valid = true;
      this.$emit('isValidDateTime', valid);
      return valid || this.errorMessage;
    },
    dateTimeFieldRules() {
      return this.required ? [(value) => !!value || 'From Date/Time is Required'] : [];
    },
    dateTimeFieldMinRule() {
      return this.minRule ? [(value) => (!!value && moment(value).format('MM/DD/YY') >= moment(this.dateTime).format('MM/DD/YY')) || 'From Date/Time is Required'] : [];
    }
  },
  beforeMount() {
    if (this.dateTime) {
      const date = moment(this.dateTime);
      this.date = date;
      this.setDisplayDate(date);
      this.setAllDateValues(date);
    }
  },
  watch: {
    dateTime() {
      if (this.dateTime && this.dateTime !== this.formatted) {
        const date = moment(this.dateTime);
        this.setAllDateValues(date);
        this.setDisplayDate(date);
      }
    },
    clearInput(clear) {
      if (clear) {
        this.clearDatetime();
      }
      this.$emit('clearInput', false);
    }
  }
};
