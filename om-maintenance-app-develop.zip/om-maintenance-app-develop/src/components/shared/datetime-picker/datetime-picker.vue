<template>
  <div class="hg-datetime-picker">
    <label class="header-label">{{ config.label }}</label>
    <img class="label-required" v-if="showRequiredIcon" :src="getIcon(cdnImagesEnum.required_icon)" />
    <div class="d-flex align-center" :class="{ 'disabled-filter': isDisabled() }">
      <v-menu :attach="datePickerAttach" ref="menu" v-model="menu" :close-on-content-click="false" :v-click-outside="onOutsideMenuClick()"
        :return-value.sync="formatted" transition="scale-transition" offset-y min-width="auto" class="white">
        <template v-slot:activator="{ on, attrs }">
          <v-text-field ref="dateTimeInputField" flat solo dense clearable class="txt-field menu-dialog"
            :value="formatted" placeholder="mm/dd/yy" @click:clear="clearDatetime()" :disabled="isDisabled()"
            @change="onInputChange($event)" hide-details :rules="[isDateTimeValid, ...dateTimeFieldRules, ...dateTimeFieldMinRule]"
            :error="isDateTimeValid !== true">
            <template v-slot:append>
              <v-btn small icon class="calendar-icon" max-height="24px" max-width="24px" v-bind="attrs" v-on="on">
                <v-icon id="hg-date-box-input-icon" dense size="20px" color="grey darken-2">mdi-calendar</v-icon>
              </v-btn>
            </template>
          </v-text-field>
        </template>
        <div class="d-flex white justify-center f-column">
          <v-date-picker v-model="date" no-title scrollable reactive :min="config.minDate" :max="config.maxDate"
            @change="onDateChange($event)" persistent>
          </v-date-picker>
          <div v-if="showTimeOption" class="white">
            <vue-timepicker hide-clear-button auto-scroll close-on-complete manual-input id="time-picker" v-model="time"
              drop-direction="up" :format="timeFormat" input-width="125px"
              @change="onTimeChange($event)" />
          </div>
        </div>
      </v-menu>
    </div>
    <div class="error--text error-messages" v-if="isDateTimeValid !== true">
      {{ isDateTimeValid }}
    </div>

    <div class="warning-message" v-if="isDateTimeValid === true && warningMessage.visible && formatted">
      {{ warningMessage.message }}
    </div>
  </div>
</template>

<script src="./datetime-picker.js"></script>
<style src="./datetime-picker.sass" lang="sass" scoped></style>