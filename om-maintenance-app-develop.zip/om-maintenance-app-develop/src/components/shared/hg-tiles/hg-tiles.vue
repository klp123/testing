<template>
  <div class="tiles d-flex">
    <div
      v-for="(item, index) in items"
      :key="index"
      :id="item.key"
      class="tile"
      @click="tileClicked(item)"
      v-bind:class="{
        'highlighted-customer': isSelected(item),
        'disable-hover': isGroupByMode && !item.enableGroupBy,
      }"
    >
      <v-tooltip bottom>
        <template v-slot:activator="{ on, attrs }">
          <div
            class="metric"
            v-html="item.label"
            v-bind="attrs"
            v-on="on"
            v-bind:class="{
              'highlighted-customer': isSelected(item),
            }"
          ></div>
        </template>
        <span class="tooltip">{{ item.tooltip }}</span>
      </v-tooltip>
      <div class="value">
        <span v-if="item.displayValue != -1">{{ item.displayValue }} </span>
        <span v-if="item.displayShortValue != -1" class="short-value">
          {{ item.displayShortValue }}</span
        >
        <v-icon
          size="20px"
          class="refresh"
          v-if="item.displayValue == -1"
          @click="refreshStats()"
          >mdi-refresh</v-icon
        >
      </div>
    </div>
  </div>
</template>

<script src="./hg-tiles.js"></script>
<style src="./hg-tiles.sass" lang="sass" scoped></style>
