import {
  VTooltip,
} from 'vuetify/lib';
import _ from 'lodash';

function tileClicked(item) {
  if (!item.disabled) {
    this.$emit('onTileClick', item);
  }
}

function refreshStats() {
  this.$emit('refreshStats');
}

function isSelected(item) {
  return (item.value
      && this.selectedItem.type
      && _.isEqual(this.selectedItem.type, item.value.type)
      && !this.selectedItem.level)
    || (_.isEqual(this.selectedItem.value, item.value)
      && item.value
      && this.selectedItem.value);
}

// @vuese
// @group TILES
// Tiles for rendering count metrics
export default {
  name: 'HgTiles',
  components: {
    VTooltip,
  },
  props: {
    // List of tile with label and displayValue
    items: {
      type: Array,
      required: false,
      default: () => [],
    },
    // selected active filter
    selectedItem: {
      type: Object,
      required: false,
      default: {},
    },
    // Is GroupBy Mode
    isGroupByMode: {
      type: Boolean,
      required: false,
      default: false,
    },
  },

  methods: {
    // @vuese
    // Captures tile click event and emits tile value
    // @arg (tile) clicked tile
    tileClicked,
    // @vuese
    // Used fire event when refresh is click
    refreshStats,
    // @vuese
    // Used fire event when refresh is click
    isSelected,
  },
};
