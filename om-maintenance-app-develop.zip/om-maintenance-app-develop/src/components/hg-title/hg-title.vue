<template>
  <div class="hg-title">
    <div class="title">{{ title }}</div>

    <div></div>
    <div class="d-flex align-right">
      <slot name="metrics"></slot>
    </div>
  </div>
</template>

<script src="./hg-title.js"></script>
<style src="./hg-title.sass" lang="sass" scoped></style>
