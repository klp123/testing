// @vuese
// Renders Page Title
export default {
  name: 'hg-title',
  props: ['title'],
  components: {

  },
  data: () => ({
    goDark: false,
  }),
  watch: {
    title: {
      immediate: true,
      handler() {
        document.title = this.title;
      },
    },
  },
  render() {
  },
};
