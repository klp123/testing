import {
  ImageLoaderService,
  HgMomentService,
  GoogleAnalyticsService,
} from '@hubgroup/hg-om-shared-services';
import TemplateCreateModal from '@hubgroup/hg-vue-oc-util-lib/src/components/template/template-create-modal/template-create-modal.vue';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import { EntitlementsEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import CdnImagesEnum from '@hubgroup/hg-vue-oc-util-lib/src/enums/cdn-images.enum';
import * as _ from 'lodash';
import Vue from 'vue';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import templatesService from '../../../services/templates/templates.service';
import DuplicateTemplateAlert from '../duplicate-template-alert/duplicate-template-alert.vue';
import TemplateTypesEnum from '../../../enums/template-types.enum';
import TemplateActionsEnum from '../../../enums/template-actions.enum';

/**
 *
 * @returns extract all ref types and return a combined string with comma seperated.
 */
function getRefTypes(index) {
  const refTypes = this.templates[index].references ? this.templates[index].references.map((ref) => ref.type) : [];
  return refTypes.join(', ');
}

/**
 *
 * @returns returns last used date in 'MM/DD/YY' format.
 */
function getLastUsedDate(index) {
  return this.templates[index].lastUsed ? HgMomentService.formatTime(this.templates[index].lastUsed, 'MM/DD/YY') : '';
}

/**
 *
 * @returns returns last used date in 'MM/DD/YY hh:mm' format.
 */
function getLastUpdatedDate(index) {
  return this.templates[index].modifiedDateTime ? HgMomentService.formatTime(this.templates[index].modifiedDateTime, 'MM/DD/YY hh:mm') : '';
}

/**
 *
 * @returns The Truncated first remark to show on UI.
 */
function getTruncatedFirstRemarks(index) {
  const firstRemark = _.get(this.templates[index], 'remarks[0].value', '');
  return (firstRemark.length > 15) ? `${firstRemark.substring(0, 15)}...` : firstRemark;
}

/**
 *
 * @param {*} source From or To
 * @returns the stop location details to show on UI
 */
function getStopLocation(source, index) {
  const { location } = this.getSourceStopDetails(source, index);
  if (location && (location.name || location.address1)) {
    return `${location.name} - ${location.address1} ${location.city},
    ${location.stateProvinceCode} ${location.postalCode} (${location.countryCode}) - ${(source === 'ORIGIN') ? 'Live' : 'Drop'}`;
  }
  return '';
}

/**
 *
 * @param {*} source From or To
 * @returns the stop location contacts to show on UI
 */
function getStopContact(source, index) {
  const { contacts } = this.getSourceStopDetails(source, index);
  if (contacts) {
    return `${contacts[0].fullName} ${contacts[0].contactMethods[0].value ? `- ${contacts[0].contactMethods[0].value}` : ''} ${contacts[0].contactMethods[1].value}`;
  }
  return '';
}

/**
 *
 * @param {*} source
 * @returns Extract the right stop based on From or To
 */
function getSourceStopDetails(source, index) {
  const indexToFind = _.findIndex(this.templates[index].stops, (stop) => stop.stopType === source);
  return (indexToFind > -1) ? this.templates[index].stops[indexToFind] : '';
}

function setTemplateFlagIcons(index) {
  const flagList = [];
  if (_.get(this.templates[index], 'hazmatFlag', 'N') === 'Y') {
    flagList.push({
      icon: this.getIcon(CdnImagesEnum.hazmat_icon),
      text: 'Hazmat',
    });
  }
  if (_.get(this.templates[index], 'highSecurityFlag', 'N') === 'Y') {
    flagList.push({
      icon: this.getIcon(CdnImagesEnum.high_security_icon),
      text: 'High-Security',
    });
  }
  if (_.get(this.templates[index], 'fdaFlag', 'N') === 'Y') {
    flagList.push({
      icon: this.getIcon(CdnImagesEnum.fda_icon),
      text: 'FDA',
    });
  }
  if (_.get(this.templates[index], 'tempControlFlag', 'N') === 'Y') {
    flagList.push({
      icon: this.getIcon(CdnImagesEnum.temp_control_icon),
      text: 'Temp Control',
    });
  }
  if (_.get(this.templates[index], 'inbondFlag', 'N') === 'Y') {
    flagList.push({
      icon: this.getIcon(CdnImagesEnum.in_bond_icon),
      text: 'In Bond',
    });
  }
  return flagList;
}

function getColor(name) {
  return _colors[name];
}

/**
 * To be worked on later sprints
 */
function copyTemplate() {
  console.log('Duplicate template');
}

/**
 *
 * @param {*} index Index of the template to update
 * Updates the status of the template. Update the status on the UI after successful backend update
 */
async function updateTemplateStatus(index, templateType) {
  try {
    this.updatingStatus = true;
    const statusToUpdate = (this.templates[index].status === 'ACTIVE') ? 'INACTIVE' : 'ACTIVE';
    GoogleAnalyticsService.event(Vue, 'Template Status update', 'Template', statusToUpdate, {
      template_id: _.get(this.templates[index], 'templateId', 'n/a'),
      order_customer: _.get(this.templates[index], 'customer.name', 'n/a'),
      order_mode: _.get(this.templates[index], 'mode', 'n/a'),
      feature_rating_scale: '10X',
    });
    const updatedTemplate = await templatesService.updateTemplateStatus(this.templates[index], statusToUpdate);
    if (!_.get(updatedTemplate, 'duplicate', false)) {
      this.templates[index].status = updatedTemplate.status || updatedTemplate.template.status;
      this.setGoogleAnalytics(`${this.templates[index].customer.id} - Template ${this.templates[index].templateId} to ${statusToUpdate}`);
      HgNotificationService.successMessage('Template status succeessfully updated', 3000);
    } else {
      this.showDuplicateTemplateAlert = true;
      this.duplicateTemplateType = templateType;
      this.duplicateTemplate = updatedTemplate.template;
    }
    this.updatingStatus = false;
  } catch (error) {
    this.updatingStatus = false;
    console.error('Error when updating template status:', error);
    HgNotificationService.errorMessage('Template status updated failed');
  }
}

function closeDuplicateTemplateDialog() {
  this.showDuplicateTemplateAlert = false;
}

/**
 * @function - used for setting google analytics
 * @param {*} details - event message that needs to be send for ga
 */
function setGoogleAnalytics(details) {
  GoogleAnalyticsService.event(Vue, 'Metric', 'Maintenance', details);
}

function getIcon(iconName) {
  return ImageLoaderService.getCdnImageUrl(iconName);
}

/**
 * @function - used for opening the template modal with prefilled data
 * @param {*} templateId - templateId which needs to be edited/copied
 */
async function openTemplateModal(templateId, action) {
  try {
    this.loadingData = true;
    const templatePayload = await templatesService.getTemplateDetailsById(templateId);
    this.template = {
      action,
      templateData: templatePayload,
    };
    this.showTemplateModal = true;
    if (action === TemplateActionsEnum.EDIT_TEMPLATE) {
      GoogleAnalyticsService.event(Vue, 'Edit Template', 'Maintenance', `Edit Template ${templateId}`);
    } else if (action === TemplateActionsEnum.COPY_TEMPLATE) {
      GoogleAnalyticsService.event(Vue, 'Copy Template', 'Maintenance', `Copy Template ${templateId}`);
    }
    this.loadingData = false;
  } catch (error) {
    console.error('Error when loading template modal', error);
    this.loadingData = false;
  }
}

function getNumberOfRules(entity) {
  if (!entity || !entity.rules) return 0;
  return entity.rules.length;
}

function closeTemplateModal() {
  this.showTemplateModal = false;
}

export default {
  name: 'template-details',

  components: {
    DuplicateTemplateAlert,
    TemplateCreateModal
  },
  data: () => ({
    showTemplateModal: false,
    CdnImagesEnum,
    TemplateTypesEnum,
    TemplateActionsEnum,
    updatingStatus: false,
    loadingData: false,
    showDuplicateTemplateAlert: false,
    duplicateTemplateType: '',
    duplicateTemplate: {},
    entitlement: EntitlementsEnum,
    token: localStorage.getItem('jwt'),
  }),
  props: {
    templates: {
      type: Array,
      required: true,
      default: {},
    },
    loadingTemplate: {
      type: Boolean,
      required: true,
      default: false,
    },
  },
  methods: {
    getIcon,
    getColor,
    getRefTypes,
    getLastUsedDate,
    getStopLocation,
    getSourceStopDetails,
    getStopContact,
    copyTemplate,
    setTemplateFlagIcons,
    updateTemplateStatus,
    getTruncatedFirstRemarks,
    setGoogleAnalytics,
    closeDuplicateTemplateDialog,
    openTemplateModal,
    closeTemplateModal,
    getNumberOfRules,
    getLastUpdatedDate
  },
};
