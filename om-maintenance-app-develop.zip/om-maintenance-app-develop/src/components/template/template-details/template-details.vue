<template>
  <div>
    <div>
      <template-create-modal v-if="showTemplateModal" :template="template" @closeTemplateDialog="closeTemplateModal()" />
    </div>
    <v-overlay v-if="updatingStatus || loadingData">
      <v-progress-circular indeterminate :size="70" :color="getColor('color_white')">
      </v-progress-circular>
    </v-overlay>
    <div class="template-details pt-4" v-for="(templateDetails, index) in templates" :key="index">
      <v-card elevation="12" outlined rounded>
        <v-skeleton-loader v-if="loadingTemplate" type="card" />
        <div v-if="!loadingTemplate">
          <v-card-title>
            <div class="form-header template-header">
              <span :class="templateDetails.status === 'ACTIVE'
                  ? 'templateStatus'
                  : 'templateStatusInActive'
                ">
                {{ templateDetails.status }}
              </span>
              {{ templateDetails.type }} - {{ templateDetails.name }} ({{
                templateDetails.templateId
              }})
            </div>
            <div class="action-buttons">
              <v-tooltip bottom>
                <template v-slot:activator="{ on, attrs }">
                  <v-btn v-oc-entitlements="[[entitlement.OC_EDIT], token]" class="btn-actions" text dense v-bind="attrs"
                    v-on="on" @click.stop="
                      openTemplateModal(
                        templateDetails.templateId,
                        TemplateActionsEnum.EDIT_TEMPLATE
                      )
                      ">
                    <img class="edit-action mt-n2 mr-n3" :src="getIcon(CdnImagesEnum.edit_icon)" />
                  </v-btn>
                </template>
                <span class="tooltip">Edit Template</span>
              </v-tooltip>
              <v-menu :close-on-content-click="true" offset-y>
                <template v-slot:activator="{ on: onMenu }">
                  <v-tooltip bottom>
                    <template v-slot:activator="{ on: onTooltip, attrs }">
                      <v-btn text dense v-bind="attrs" v-on="{ ...onMenu, ...onTooltip }">
                        <v-icon class="action-icon mt-n2" dark>
                          mdi-dots-horizontal
                        </v-icon>
                      </v-btn>
                    </template>
                    <span class="tooltip">Actions</span>
                  </v-tooltip>
                </template>
                <v-list dense>
                  <v-list-item v-oc-entitlements="[
                    [entitlement.OC_CREATE, entitlement.OC_EDIT],
                    token,
                  ]" text>
                    <v-list-item-title @click.stop="
                      openTemplateModal(
                        templateDetails.templateId,
                        TemplateActionsEnum.COPY_TEMPLATE
                      )
                      ">
                      Copy Template
                    </v-list-item-title>
                  </v-list-item>
                  <v-list-item v-oc-entitlements="[[entitlement.OC_EDIT], token]" text>
                    <v-list-item-title @click="updateTemplateStatus(index, templateDetails.type)">
                      {{
                        templateDetails.status === "ACTIVE"
                        ? "Inactivate"
                        : "Activate"
                      }}
                    </v-list-item-title>
                  </v-list-item>
                </v-list>
              </v-menu>
            </div>
          </v-card-title>
          <v-card-text>
            <div class="d-flex template-details-text" v-if="templateDetails.type === TemplateTypesEnum.ELECTRONIC">
              <div class="template-details-overall">
                <div>
                  <div class="align-block-first">
                    <label>Customer:</label>
                  </div>
                  <div>{{ templateDetails.customer.name }}</div>
                </div>
                <div>
                  <div class="align-block-first">
                    <label>Mode:</label>
                  </div>
                  <div>{{ getNumberOfRules(templateDetails.mode) }} Rules</div>
                </div>
                <div>
                  <div class="align-block-first">
                    <label>Equip Type:</label>
                  </div>
                  <div>{{ getNumberOfRules(templateDetails.equipmentType) }} Rules</div>
                </div>
              </div>
              <div class="template-details-overall subInfo">
                <div>
                  <div class="align-block-first">
                    <label>Service Type:</label>
                  </div>
                  <div>{{ getNumberOfRules(templateDetails.serviceType) }} Rules</div>
                </div>
                <div>
                  <div class="align-block-first">
                    <label>Commodity:</label>
                  </div>
                  <div>{{ getNumberOfRules(templateDetails.commodity) }} Rules</div>
                </div>
              </div>
              <div class="template-details-overall subInfo">
                <div>
                  <div class="align-block-flags">
                    <label>InBond Flag:</label>
                  </div>
                  <div>{{ getNumberOfRules(templateDetails.inBondFlag) }} Rules</div>
                </div>
                <div>
                  <div class="align-block-flags">
                    <label>High Security Flag:</label>
                  </div>
                  <div>{{ getNumberOfRules(templateDetails.highSecurityFlag) }} Rules</div>
                </div>
              </div>
              <div class="template-details-overall subInfo">
                <div>
                  <div class="align-block-first">
                    <label>Hazmat:</label>
                  </div>
                  <div>{{ getNumberOfRules(templateDetails.hazmatFlag) }} Rules</div>
                </div>
                <div>
                  <div class="align-block-first">
                    <label>Remarks:</label>
                  </div>
                  <div>{{ getNumberOfRules(templateDetails.remarks) }} Rules</div>
                </div>
              </div>
              <div class="template-details-overall userInfo">
                <div>
                  <div class="align-block-user">
                    <label>Last Updated By:</label>
                  </div>
                  <div>{{ templateDetails.modifiedBy }}</div>
                </div>
                <div>
                  <div class="align-block-user">
                    <label>Last Update:</label>
                  </div>
                  <div>{{ getLastUpdatedDate(index) }}</div>
                </div>
              </div>
            </div>
            <div class="d-flex template-details-text" v-if="templateDetails.type === TemplateTypesEnum.STANDARD">
              <div class="template-details-overall">
                <div>
                  <div class="align-block-first">
                    <label>Customer:</label>
                  </div>
                  <div>{{ templateDetails.customer.name }}</div>
                </div>
                <div>
                  <div class="align-block-first">
                    <label>Mode:</label>
                  </div>
                  <div>{{ templateDetails.mode }}</div>
                </div>
                <div>
                  <div class="align-block-first">
                    <label>Service Type:</label>
                  </div>
                  <div>{{ templateDetails.serviceType }}</div>
                </div>
                <div>
                  <div class="align-block-first">
                    <label>Equip Type:</label>
                  </div>
                  <div>
                    {{ templateDetails.equipment && templateDetails.equipment.equipmentType }}
                    {{
                      templateDetails.equipment &&
                      templateDetails.equipment.length &&
                      templateDetails.equipment.length.amount > 0
                      ? `${templateDetails.equipment.length.amount}'`
                      : ""
                    }}
                  </div>
                </div>
              </div>
              <div class="template-details-overall subInfo">
                <div>
                  <div class="align-block-first">
                    <label>Commodity:</label>
                  </div>
                  <div>{{ templateDetails.commodityDescription }}</div>
                </div>
                <div>
                  <div class="align-block-first">
                    <label>Flags:</label>
                  </div>
                  <div class="d-inline-flex">
                    <div class="mt-1" v-for="(flag, indexFlag) in setTemplateFlagIcons(index)" :key="indexFlag">
                      <v-tooltip bottom>
                        <template v-slot:activator="{ on, attrs }">
                          <v-img class="mr-1" :src="flag.icon" max-height="16" max-width="16" v-bind="attrs"
                            v-on="on"></v-img>
                        </template>
                        <span>{{ flag.text }}</span>
                      </v-tooltip>
                    </div>
                  </div>
                </div>
                <div>
                  <div class="align-block-first">
                    <label>Ref Type:</label>
                  </div>
                  <div>{{ getRefTypes(index) }}</div>
                </div>
              </div>
              <div class="template-details-overall locationInfo">
                <div>
                  <div class="align-location-details">
                    <label>From:</label>
                  </div>
                  <div>{{ getStopLocation("ORIGIN", index) }}</div>
                </div>
                <div>
                  <div class="align-location-details">
                    <label>Contact:</label>
                  </div>
                  <div>{{ getStopContact("ORIGIN", index) }}</div>
                </div>
              </div>
              <div class="template-details-overall locationInfo">
                <div>
                  <div class="align-location-details">
                    <label>To:</label>
                  </div>
                  <div>{{ getStopLocation("DESTINATION", index) }}</div>
                </div>
                <div>
                  <div class="align-location-details">
                    <label>Contact:</label>
                  </div>
                  <div>{{ getStopContact("DESTINATION", index) }}</div>
                </div>
              </div>
              <div class="template-details-overall subInfo">
                <div class="align-block-third">
                  <label>Bill To:</label>
                </div>
                <div class="align-block-third">
                  <label>Payment Method:</label>
                </div>
                <div class="align-block-third">
                  <label>Additional Charges:</label>
                </div>
              </div>
              <div class="template-details-overall subInfo">
                <div>
                  <div class="align-block-second">
                    <label>Last Used:</label>
                  </div>
                  <div>{{ getLastUsedDate(index) }}</div>
                </div>
                <div>
                  <div class="align-block-second">
                    <label>Times Used:</label>
                  </div>
                  <div>{{ templateDetails.usedCount }}</div>
                </div>
                <div class="flex-column">
                  <label>Remarks:</label>
                  <div>
                    <v-tooltip bottom>
                      <template v-slot:activator="{ on, attrs }">
                        <span v-bind="attrs" v-on="on">{{
                          getTruncatedFirstRemarks(index)
                        }}</span>
                      </template>
                      <div v-if="templateDetails.remarks && templateDetails.remarks[0]
                          ">
                        <span>{{ templateDetails.remarks[0].value }}</span>
                      </div>
                      <div v-else></div>
                    </v-tooltip>
                  </div>
                </div>
              </div>
            </div>
          </v-card-text>
        </div>
      </v-card>
    </div>
    <duplicate-template-alert
      v-if="showDuplicateTemplateAlert"
      :TemplateInfo="duplicateTemplate"
      :templateType="duplicateTemplateType"
      @closeDuplicateTemplateDialog="closeDuplicateTemplateDialog"
    >
    </duplicate-template-alert>
  </div>
</template>

<script src="./template-details.js"></script>
<style src="./template-details.sass" lang="sass" scoped></style>
