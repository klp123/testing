<template>
  <div class="filter-container" id="template-filter">
    <div class="d-flex justify-space-between">
      <div class="filter-components" id="filter-components">
        <!-- Template Type -->
        <hg-lib-menu-select-box
          id="template-filter-type"
          :menuLabel="templateType.menuLabel"
          :items="templateType.templateTypes"
          :selectedItems="selectedFilters('templateType')"
          @onItemChecked="onFilterSelected($event)"
          @onItemUnchecked="onFilterUnSelected($event)"
        />

        <!-- Status -->
        <hg-lib-menu-select-box
          id="template-filter-status"
          :menuLabel="status.menuLabel"
          :items="status.statuses || []"
          :selectedItems="selectedFilters('status')"
          @onItemChecked="onFilterSelected($event)"
          @onItemUnchecked="onFilterUnSelected($event)"
        />

        <!-- Mode -->
        <hg-lib-menu-select-box
          id="template-filter-modes"
          :menuLabel="mode.menuLabel"
          :items="mode.modes || []"
          :selectedItems="selectedFilters('mode')"
          @onItemChecked="onFilterSelected($event)"
          @onItemUnchecked="onFilterUnSelected($event)"
        />

        <!-- Customer -->
        <hg-lib-menu-search-bar
          id="template-filter-customer"
          :placeholder="customer.placeholder"
          :menuLabel="customer.menuLabel"
          :filterKey="customer.filterKey"
          :items="customer.items || []"
          :selectedItems="selectedFilters('customer')"
          :loading="loadingCustList"
          @searchTextChanged="customerSearchTextChanged($event, 'Customer')"
          @searchItemSelected="onFilterSelected($event)"
          @searchItemUnSelected="onFilterUnSelected($event)"
          @filterClosed="custFilterClosed"
        />

        <!-- Origin -->
        <hg-lib-menu-search-bar
          id="template-filter-origin"
          :placeholder="origin.placeholder"
          :menuLabel="origin.menuLabel"
          :filterKey="origin.filterKey"
          :items="origin.items || []"
          :selectedItems="selectedFilters('origin')"
          :loading="loadingLocList"
          @searchTextChanged="locationSearchTextChanged($event, 'Origin')"
          @searchItemSelected="onFilterSelected($event)"
          @searchItemUnSelected="onFilterUnSelected($event)"
          @filterClosed="locFilterClosed"
        />
        <!-- Destination -->
        <hg-lib-menu-search-bar
          id="template-filter-destination"
          :placeholder="destination.placeholder"
          :menuLabel="destination.menuLabel"
          :filterKey="destination.filterKey"
          :items="destination.items || []"
          :selectedItems="selectedFilters('destination')"
          :loading="loadingLocList"
          @searchTextChanged="locationSearchTextChanged($event, 'Destination')"
          @searchItemSelected="onFilterSelected($event)"
          @searchItemUnSelected="onFilterUnSelected($event)"
          @filterClosed="locFilterClosed"
        />
      </div>

      <div class="action-menu d-flex">
        <div class="create-template-button">
          <template-create-modal
            v-if="showTemplateModal"
            @closeTemplateDialog="closeTemplateModal()"
          />
          <hg-lib-btn
            v-oc-entitlements="[
              [entitlement.OC_CREATE, entitlement.OC_EDIT],
              token,
            ]"
            class="pl-3"
            title="Create Template"
            type="primary"
            @click.native="openTemplateModal()"
          />
        </div>
        <div class="d-flex flex-column">
          <hg-lib-search-bar-category
            :quickSearchTypeState="quickSearch.selectedSearchType"
            :selectedItems="selectedFilters('quickSearch')"
            :searchTypeList="quickSearch.searchTypeList"
            :defaultSearchType="'templateName'"
            @quickSearchChange="onFilterSelected($event)"
            @quickSearchTypeChange="onQuicksearchTypeChange($event)"
            id="template-quick-search"
          ></hg-lib-search-bar-category>
        </div>
      </div>
    </div>

    <div class="current-filters">
      <hg-lib-filter-bread-crumb-display
        id="template-filter-breadcrumbs"
        :groupBy="{}"
        :selectedFilters="selectedFilters()"
        @clearFilters="clearFilter($event)"
        @clearAllFilters="clearAllFilters()"
      />
    </div>
  </div>
</template>

<script src="./template-filters.js"></script>
<style src="./template-filters.sass" scoped lang="sass"></style>
