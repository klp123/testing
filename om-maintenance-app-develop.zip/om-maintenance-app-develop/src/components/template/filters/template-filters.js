import _ from 'lodash';
import { EntitlementsEnum, AppSetupEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import TemplateCreateModal from '@hubgroup/hg-vue-oc-util-lib/src/components/template/template-create-modal/template-create-modal.vue';
import FilterNamesEnum from '@hubgroup/hg-vue-oc-util-lib/src/enums/filter-names.enum';
import { GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import Vue from 'vue';
import filterService from '../../../services/filters/filters.service';
import locationService from '../../../services/templates/location.service';
import customerService from '../../../services/customer/customer.service';
import commonService from '../../../services/common.service';
import templateFiltersEnum from '../../../enums/template-filters.enum';

const filterParams = filterService.getFilterParams();
filterParams.entitlement = EntitlementsEnum;

/**
 * Populate list of values for the filters
 */
async function loadFiltersList() {
  try {
    filterParams.templateType.templateTypes = commonService.getFilterList('templateType', templateFiltersEnum.TEMPLATE_TYPES);
    filterParams.mode.modes = commonService.getFilterList('mode', await commonService.getCommonLov(FilterNamesEnum.MODES));
    filterParams.status.statuses = commonService.getFilterList('status', templateFiltersEnum.TEMPLATE_STATUS);
  } catch (e) {
    console.error('Error when setting beforemount data', e);
  }
}

async function locationSearchTextChanged(searchText, stop) {
  searchText = (searchText || '').trim();
  if (searchText) {
    this.loadingLocList = true;
    try {
      this[stop.toLowerCase()].items = await locationService.searchLocation(searchText, stop);
      this.loadingLocList = false;
    } catch (e) {
      this.loadingLocList = false;
    }
  }
}

async function customerSearchTextChanged(searchText) {
  if (!searchText || searchText.length >= AppSetupEnum.MINIMUM_SEARCH_CHARACTER) {
    this.loadingCustList = true;
    try {
      this.customer.items = await customerService.searchCustomers(searchText);
      this.loadingCustList = false;
    } catch (e) {
      this.loadingCustList = false;
    }
  }
}

/**
 * reset results to default in the filter when filter is closed
 */
function locFilterClosed() {
  this.origin.items = [];
  this.destination.items = [];
}

/**
 * reset results to default in the customer filter when filter is closed
 * TODO: hg-vue-lib needs to updated for this component to make it work.
 */
function custFilterClosed() {
  this.customerSearchTextChanged('');
}

/**
 * Update the selected filter to the store
 */
function onFilterSelected(filterSelected) {
  // clear quickSearch type if value is empty
  if (filterSelected.key === 'quickSearch' && filterSelected.value === '') {
    filterSelected.type = '';
  }
  this.$store.dispatch('templatesStore/updateFilter', filterSelected);
  this.setLocalStorageFilter();
  this.uncheckSavedFilter();
}

/**
 *
 * @param {*} filterType type of filter
 * @returns filter values from the store
 */
function selectedFilters(filterType) {
  return filterType ? this.$store.getters['templatesStore/getFilters'][filterType] : this.$store
    .getters['templatesStore/getFilters'];
}

/**
 * Clear the specific filter closed from the filtering component and relaod templates
 */
function clearFilter(filter) {
  this.uncheckSavedFilter();
  this.onFilterUnSelected(filter);
}

/**
 * Clear all filters from the filtering by component and reload templates
 */
function clearAllFilters() {
  this.uncheckSavedFilter();
  this.onFilterUnSelected();
}

/**
 *
 * @param {*} filterUnSelected The filter unselected from lov / removed
 * from filtering by the filter is removed from the store
 */
function onFilterUnSelected(filterUnSelected) {
  if (filterUnSelected) {
    this.$store.dispatch('templatesStore/removeFilter', filterUnSelected);
  } else {
    this.$store.dispatch('templatesStore/removeFilter');
  }
  this.setLocalStorageFilter();
  this.uncheckSavedFilter();
}

/**
 * Update selected quick search type
 */
function onQuicksearchTypeChange(searchType) {
  this.quickSearch.selectedSearchType = searchType;
  const currentFilters = this.$store.getters['templatesStore/getFilters'];
  const filter = currentFilters.quickSearch[0];
  if (filter) {
    this.onFilterSelected(filter);
  }
}

function uncheckSavedFilter() {
  this.selectedSavedFilter = null;
}

function setLocalStorageFilter() {
  const currentTPFilters = this.$store.getters['templatesStore/getFilters'];
  this.$emit('filters', currentTPFilters);
  localStorage.setItem('templateFilters', JSON.stringify(currentTPFilters));
}

async function selectLocalStorageFilter() {
  const localStorageFilters = localStorage.getItem('templateFilters');
  const currentTemplateFilters = localStorageFilters ? JSON.parse(localStorageFilters) : null;

  // set quickSearch type from local storage
  if (_.get(currentTemplateFilters, 'quickSearch[0].type', null)) {
    this.onQuicksearchTypeChange(currentTemplateFilters.quickSearch[0].type);
  }

  if (currentTemplateFilters) {
    Object.values(currentTemplateFilters).forEach((ftr) => {
      if (ftr && ftr.length) {
        ftr.forEach((element) => {
          if (element.value) {
            this.onFilterSelected(element);
          }
        });
      }
    });
  }
}

function openTemplateModal() {
  this.showTemplateModal = true;
  GoogleAnalyticsService.event(Vue, 'Open Template', 'Maintenance', 'Create Template clicked');
}

function closeTemplateModal() {
  this.showTemplateModal = false;
}

export default {
  name: 'template-filters',
  data() {
    filterParams.token = localStorage.getItem('jwt');
    return filterParams;
  },
  components: {
    TemplateCreateModal
  },
  props: [],
  computed: {},
  methods: {
    loadFiltersList,
    onFilterSelected,
    clearFilter,
    clearAllFilters,
    selectedFilters,
    onFilterUnSelected,
    locationSearchTextChanged,
    locFilterClosed,
    customerSearchTextChanged,
    custFilterClosed,
    onQuicksearchTypeChange,
    uncheckSavedFilter,
    setLocalStorageFilter,
    selectLocalStorageFilter,
    openTemplateModal,
    closeTemplateModal,
  },
  created() {
    this.loadFiltersList();
    this.selectLocalStorageFilter();
  },
};
