<template>
  <v-row justify="center">
    <v-dialog v-model="showDialog" persistent max-width="500px" max-height="195px">
      <v-card>
        <!--  header -->
        <v-card-title class="justify-space-between alert-title">
          Duplicate Template
          <v-spacer></v-spacer>
          <v-btn @click="closeDialog()" icon>
            <v-icon id="modal-close">mdi-close</v-icon>
          </v-btn>
        </v-card-title>

        <hr class="horizontal-divider-title" />

        <!--  body -->
        <v-card-text class="alert-body" v-if="templateType === templateTypesEnum.STANDARD">
          <label>
            You are trying to activate a Template that already exists called
          </label>

          <br />
          <label class="template-label">
            {{ TemplateInfo.name }}<label>.</label>
          </label>

          <br />
          <label>
            You can not activate a template that is the same as an existing one.
          </label>
        </v-card-text>

        <v-card-text class="alert-body" v-if="templateType === templateTypesEnum.ELECTRONIC">
          <label>
            An active EDI Template for this customer already exists called
          </label>

          <br />
          <label class="template-label">
            {{ TemplateInfo.name }}
          </label>
        </v-card-text>

        <!--  action -->
        <v-card-actions class="alert-action">
          <hg-lib-btn
            :title="'Cancel'"
            :type="'secondary'"
            :disabled="false"
            @click.native="closeDialog()"
            id="cancel-dialog"
          />
          <v-spacer></v-spacer>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-row>
</template>
<script src="./duplicate-template-alert.js"></script>
<style src="./duplicate-template-alert.sass" scoped lang="sass"></style>
