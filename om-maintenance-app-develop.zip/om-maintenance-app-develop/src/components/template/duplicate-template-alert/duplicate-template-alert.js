import templateTypesEnum from '../../../enums/template-types.enum';

/**
 * Close the dialog
 */
function closeDialog() {
  this.showDialog = false;
  this.$emit('closeDuplicateTemplateDialog');
}

export default {
  name: 'duplicate-template-alert',
  components: {},
  props: {
    TemplateInfo: {
      type: Object,
      required: true,
      default: () => ({}),
    },
    templateType: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      showDialog: false,
      templateTypesEnum
    };
  },
  created() {
    this.showDialog = true;
  },
  methods: {
    closeDialog,
  },
};
