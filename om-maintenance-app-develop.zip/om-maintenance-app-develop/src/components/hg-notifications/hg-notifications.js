import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import { ImageLoaderService } from '@hubgroup/hg-om-shared-services';
import { CdnImagesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';

function getIcon(iconName) {
  return ImageLoaderService.getCdnImageUrl(iconName);
}

function getColor(name) {
  return _colors[name];
}

export default {
  data: () => ({
    CdnImagesEnum,
  }),
  name: 'HgNotifications',
  methods: {
    getIcon,
    getColor,
  },
};
