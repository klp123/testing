<template>
  <notifications group="app" position="top right" width="390px">
    <template slot="body" slot-scope="{ item, close }">
      <div
        class="hg-notification-container"
        v-bind:class="{
          'hg-success': item.type === 'success',
          'hg-error': item.type === 'error',
          'hg-warn': item.type === 'warn',
        }"
      >
        <div class="hg-content">
          <div class="hg-title">
            <div>
              <img
                class="title-logo"
                v-if="item.type === 'success'"
                :src="getIcon(CdnImagesEnum.icon_checkbox_checked)"
              />
              <img
                class="title-logo"
                v-if="item.type === 'warn'"
                :src="getIcon(CdnImagesEnum.icon_bell)"
              />
              <img
                class="title-logo"
                v-if="item.type === 'error'"
                :src="getIcon(CdnImagesEnum.icon_bell)"
              />
            </div>
            <div class="title-text">{{ item.title }}</div>
          </div>
          <div class="hg-message">{{ item.text }}</div>
        </div>
        <div class="close">
          <v-icon medium :color="getColor('color_white')" @click="close"
            >mdi-close</v-icon
          >
        </div>
      </div>
    </template>
  </notifications>
</template>

<script src="./hg-notifications.js"></script>
<style src="./hg-notifications.sass" lang="sass" scoped></style>
