/* eslint-disable no-param-reassign */
import _ from 'lodash';
import Vue from 'vue';
import { GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import accessorialsEntitlements from '@hubgroup/hg-om-shared-services/src/enums/entitlements.enum';
import HgSearchBar from '../../shared/filters/hg-search-bar/hg-search-bar.vue';
import HgQuickSearch from '../../shared/filters/hg-quick-search/hg-quick-search.vue';
import customerService from '../../../services/customer/customer.service';
import commonService from '../../../services/common.service';
import FuelScaleDialog from '../../accessorial-fuel-schedules/upload-dialog/upload-dialog.vue';

async function initFilterOptions() {
  // initialize LOV for filter
  const values = await commonService.getCommonLov('AM_TEAMS');
  this.filterParams.team.teams = await commonService.getFilterObjects('AM_TEAMS', 'team', 'Team', values);

  // Add other as team
  this.filterParams.team.teams.push({
    key: 'team',
    value: 'OTHER',
    text: 'OTHER',
    label: 'Team',
  });
}

function selectedFilter(filterType) {
  return filterType ? this.$store.getters['customersStore/getFilters'][filterType] : this.$store
    .getters['customersStore/getFilters'];
}

function setLocalStorageFilter() {
  const currentFilter = this.$store.getters['customersStore/getFilters'];
  localStorage.setItem('currentCustomerMaintenanceFilter', JSON.stringify(currentFilter));
}

async function selectLocalStorageFilter() {
  const memVal = localStorage.getItem('currentCustomerMaintenanceFilter') ? JSON.parse(localStorage.getItem('currentCustomerMaintenanceFilter')) : null;
  const curCustomerFilter = memVal;
  // set quickSearch type from local storage
  if (_.get(curCustomerFilter, 'quickSearch[0].type', null)) {
    this.onQuicksearchTypeChange(curCustomerFilter.quickSearch[0].type);
  }

  if (curCustomerFilter) {
    this.clearAllFilter(true);
    Object.values(curCustomerFilter).forEach((ftr) => {
      if (ftr && ftr.length) {
        ftr.forEach((element) => {
          if (element.value) {
            this.onFilterSelected(element);
          }
        });
      }
    });
  }
}

function onFilterSelected(selectedItem = {}) {
  // clear quickSearch type if value is empty
  if (selectedItem.key === 'quickSearch' && selectedItem.value === '') {
    selectedItem.type = '';
  }
  // Update filter in store
  this.$store.dispatch('customersStore/updateFilter', selectedItem);
  // reset the customer list
  customerService.sendFilterGoogleAnalytics(selectedItem, 'Customer Maintenance');
  this.setLocalStorageFilter();
  this.$emit('trackAndTraceFilterChanged');
}
function onFilterUnSelected(filter) {
  if (filter) {
    // remove filter by catogory
    this.$store.dispatch('customersStore/removeFilter', filter);
    GoogleAnalyticsService.event(Vue, 'Filter', 'Customer Maintenance',
      `User removed ${filter.label ? filter.label : filter.key} filter`);
  } else {
    // remove all filters
    this.$store.dispatch('customersStore/removeFilter');
    GoogleAnalyticsService.event(Vue, 'Filter', 'Customer Maintenance', 'User removed all filters');
  }
  this.setLocalStorageFilter();
}

function clearFilter(filter) {
  this.onFilterUnSelected(filter);
}

function clearAllFilter(saveFilter = false) {
  if (saveFilter) {
    this.$store.dispatch('customersStore/removeFilterByKey', 'quickSearch');
  }
  this.onFilterUnSelected();
}

function onQuicksearchTypeChange(searchType) {
  this.filterParams.quickSearch.selectedSearchType = searchType;
  if (searchType === 'allReferences') {
    const currentFilters = this.$store.getters['customersStore/getFilters'];
    if (_.get(currentFilters, 'quickSearch[0].value', false)) {
      const filter = currentFilters.quickSearch[0];
      this.clearFilter();
      this.onFilterSelected(filter);
    } else {
      this.clearFilter();
    }
  }
}

function closeFuelUploadDialog() {
  this.fuelUploadDialog = false;
}

export default {
  name: 'CustomerDetails',
  data: () => ({
    filterParams: customerService.filterParams,
    fuelUploadDialog: false,
    accessorialsEntitlements,
    token: localStorage.getItem('jwt')
  }),
  components: {
    HgSearchBar,
    HgQuickSearch,
    FuelScaleDialog
  },
  created() {
    this.initFilterOptions();
    this.selectLocalStorageFilter();
  },
  methods: {
    initFilterOptions,
    onFilterSelected,
    onFilterUnSelected,
    selectedFilter,
    clearFilter,
    clearAllFilter,
    onQuicksearchTypeChange,
    setLocalStorageFilter,
    selectLocalStorageFilter,
    closeFuelUploadDialog
  },
};
