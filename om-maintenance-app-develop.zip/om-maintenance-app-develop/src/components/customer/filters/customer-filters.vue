<template>
  <div>
    <div class="filter-container" id="customer-filter">
      <div class="d-flex justify-space-between">
        <div class="filter-components" id="filter-components">
          <hg-lib-menu-select-box
            :items="filterParams.team.teams"
            :filterKey="filterParams.team.key"
            :menuLabel="filterParams.team.filterLabel"
            :selectedItems="selectedFilter('team')"
            id="cm-filter-team"
            @onItemChecked="onFilterSelected($event)"
            @onItemUnchecked="onFilterUnSelected($event)"
          />

          <hg-lib-menu-radio-list
            :options="filterParams.status.statuses"
            :menuLabel="filterParams.status.filterLabel"
            id="cm-filter-status"
            :selectedValue="selectedFilter('status')[0] || {}"
            @onItemSelected="onFilterSelected($event)"
            @onUnItemSelected="onFilterUnSelected($event)"
          />
        </div>
        <div class="action-menu d-flex">
          <div class="mr-2" >
            <v-btn
              v-oc-entitlements="[
              [accessorialsEntitlements.ACCS_CREATE, accessorialsEntitlements.ACCS_EDIT],
              token
            ]"
            color="secondary"
            class="font-weight-bold text-capitalize"
            @click.native="fuelUploadDialog = true"
            >
              Upload Fuel Scale
            </v-btn>
            <FuelScaleDialog v-if="fuelUploadDialog" @closeDialog="closeFuelUploadDialog" />
          </div>
          <div class="d-flex flex-column">
            <hg-quick-search
              :quickSearchTypeState="filterParams.quickSearch.selectedSearchType"
              :selectedItems="selectedFilter('quickSearch')"
              :searchTypeList="filterParams.quickSearch.types"
              defaultSearchType="syscon"
              @quickSearchChange="onFilterSelected($event)"
              @quickSearchTypeChange="onQuicksearchTypeChange($event)"
              id="cm-quick-search"
            ></hg-quick-search>
          </div>
        </div>
      </div>

      <div class="current-filters">
        <hg-lib-filter-bread-crumb-display
          :selectedFilters="selectedFilter()"
          :groupBy="{}"
          @clearFilters="clearFilter($event)"
          @clearAllFilters="clearAllFilter()"
          id="cm-current-filters-list"
        />
      </div>
    </div>
  </div>
</template>

<script src="./customer-filters.js"></script>
<style src="./customer-filters.sass" lang="sass" scoped></style>
