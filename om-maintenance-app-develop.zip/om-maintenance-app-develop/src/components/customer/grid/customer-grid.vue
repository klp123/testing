<template>
  <div class="wrapper" id="tt-orders-grid">
    <div class="orders-table-container table-content">
      <hg-table-metadata
        :showAlertRiskLevelCounts="false"
        :totalResults="counts.total"
        :refreshTime="lastRefreshedDate"
        page="Customer - Maintainance"
        @onRefreshClick="loadCustomers()"
        :loading="loading"
        id="cm-meta-data"
      />
      <v-sheet>
        <v-data-table
          :headers="headers"
          :items="customers"
          :key="tableKey"
          :options.sync="options"
          :footer-props="{ 'items-per-page-options': rowsPerPageItems }"
          @update:sort-by="updateSort('by', $event)"
          @update:sort-desc="updateSort('desc', $event)"
          item-key="_id"
          :hide-default-footer="true"
          class="hg-table"
          :loading="loading"
          id="cm-grid"
        >
          <template v-slot:item="{ item }">
            <tr
              @click="activeRow(item)"
              :key="item._id"
              :class="{
                'active-row': item.id === activeCustomerId,
              }"
            >
              <!-- NAME COLUMN -->
              <td>
                <v-skeleton-loader
                  v-if="loading"
                  class="py-1"
                  type="text"
                  width="75"
                />
                <label
                  v-if="!loading"
                  class="customer-name bold-font"
                  :id="`cust-name-${item.name}`"
                  >{{ item.name }}</label
                >
              </td>
              <!-- SYSCON COLUMN -->
              <td>
                <v-skeleton-loader
                  v-if="loading"
                  class="py-1"
                  type="text"
                  width="75"
                />
                <label
                  v-if="!loading"
                  class="customer-syscon medium-font"
                  :id="`cust-syscon-${item._}`"
                  >{{ item._id }}</label
                >
              </td>
              <!-- ERP COLUMN -->
              <td>
                <v-skeleton-loader
                  v-if="loading"
                  class="py-1"
                  type="text"
                  width="75"
                />
                <label
                  v-if="!loading"
                  class="customer-erp-id regular-font"
                  :id="`cust-id-${item.id}`"
                  >{{ item.id }}</label
                >
              </td>
              <!-- TEAM COLUMN -->
              <td>
                <v-skeleton-loader
                  v-if="loading"
                  class="py-1"
                  type="text"
                  width="75"
                />
                <label
                  v-if="!loading"
                  class="customer-team regular-font"
                  :id="`cust-team-${item.assignedTeam}`"
                  >{{ item.assignedTeam }}</label
                >
              </td>
              <!-- STATUS COLUMN -->
              <td>
                <v-skeleton-loader
                  v-if="loading"
                  class="py-1"
                  type="text"
                  width="75"
                />
                <label
                  v-if="!loading"
                  class="customer-status bold-font"
                  :id="`cust-status-${item.status}`"
                  >{{ mapStatus(item.status) }}</label
                >
              </td>
            </tr>
          </template>
        </v-data-table>
      </v-sheet>
    </div>
  </div>
</template>

<script src="./customer-grid.js"></script>
<style src="./customer-grid.sass" lang="sass" scoped></style>
