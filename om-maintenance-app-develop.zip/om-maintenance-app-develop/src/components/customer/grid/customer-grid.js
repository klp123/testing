import _ from 'lodash';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import customerGridHeadersEnum from '../../../enums/customer-grid-headers.enum';
import customerFilterEnum from '../../../enums/customer-filter.enum';
import HgTableMetadata from '../../shared/hg-table-metadata/hg-table-metadata.vue';
import customerService from '../../../services/customer/customer.service';
import sortEventNamesEnum from '../../../enums/sort-event-names.enum';

function mapStatus(status) {
  switch (status) {
    case 'A':
      return 'Active';

    case 'P':
      return 'Prospect';

    case 'R':
      return 'Prospect';

    case 'D':
      return 'Inactive';

    case 'I':
      return 'Inactive';

    case 'X':
      return 'Inactive';

    default:
      return '';
  }
}

async function loadCustomers() {
  try {
    this.loading = true;
    const response = (await customerService.filterErpCustomers(this.filters, this.pagination, this.sort)).data;
    this.customers = response.data;
    this.lastRefreshedDate = new Date();
    this.tableKey = Math.random();
    const activeCustomer = _.get(this.customers, '0', {});
    this.activeRow(activeCustomer);

    const counts = {
      total: response.meta.total,
      showing: response.meta.limit * (response.meta.page - 1) + this.customers.length,
    };
    this.$store.dispatch('customersStore/updateCounts', counts);
    this.loading = false;
  } catch (err) {
    if (err.message && err.message !== RequestErrorTypesEnum.CANCEL_REQUEST) {
      HgNotificationService.errorMessage('Error while filtering customers.');
      this.loading = false;
    }
  }
}

function updateSort(action, event) {
  if (event && action === sortEventNamesEnum.EVENT_DESC) {
    this.$store.dispatch('customersStore/updateSort', { field: this.sort.field, direction: -1 });
    return;
  }
  if (event && action === sortEventNamesEnum.EVENT_BY) {
    this.$store.dispatch('customersStore/updateSort', { field: event, direction: customerFilterEnum.sort.direction });
    return;
  }
  this.$store.dispatch('customersStore/updateSort', { field: customerFilterEnum.sort.field, direction: customerFilterEnum.sort.direction });
  this.options.sortDesc = [false];
  this.options.sortBy = [customerFilterEnum.sort.field];
}

function activeRow(item) {
  this.activeCustomerId = item.id;
  this.$emit('customerSelected', item);
}

export default {
  name: 'CustomerGrid',
  components: {
    HgTableMetadata,
  },
  data: () => ({
    filters: {},
    pagination: {},
    options: {
      page: 1,
      itemsPerPage: 200,
      sortBy: ['name'],
      sortDesc: [false],
    },
    sort: {},
    counts: {},
    tableKey: Math.random(),
    activeCustomerId: '',
    lastRefreshedDate: new Date(),
    loading: false,
    rowsPerPageItems: [20, 30, 40, 50, 100],
    headers: customerGridHeadersEnum,
    customers: [],
  }),
  mounted() {
    this.filters = this.$store.getters['customersStore/getFilters'];
    this.pagination = this.$store.getters['customersStore/getPagination'];
    this.counts = this.$store.getters['customersStore/getCounts'];
    this.sort = this.$store.getters['customersStore/getSort'];
    this.loadCustomers();
  },
  watch: {
    filters: {
      handler() {
        this.$store.dispatch('customersStore/updatePagination', {
          page: 1,
          limit: this.pagination.limit,
        });
        this.loadCustomers();
      },
      deep: true,
    },
    pagination: {
      handler() {
        this.loadCustomers();
      },
      deep: true,
    },
    sort: {
      handler() {
        this.loadCustomers();
      },
      deep: true,
    },
  },
  methods: {
    loadCustomers,
    activeRow,
    mapStatus,
    updateSort
  },
  filters: {
    titleCase(value) {
      return _.startCase(_.toLower(value));
    },
  },
};
