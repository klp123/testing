import _ from 'lodash';
import Vue from 'vue';
import { GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import entitlementsEnum from '@hubgroup/hg-om-shared-services/src/enums/entitlements.enum';
import utilitiesService from '@hubgroup/hg-om-shared-services/src/services/utilities/utilities.service';
import customerService from './services/customer.service';
import CustomerDetailTab from './components/customer-detail-tab/customer-details-tab.vue';
import CustomerFuelScaleTab from './components/customer-fuel-scale-tab/customer-fuel-scale-tab.vue';

/**
 * retrieve data from service based off customer ERPId
 * @param {string} customerId
 * @return {object} customer object from mongoDB
 */
async function getCustomerData(customerId) {
  try {
    this.loading = true;
    if (!customerId) {
      this.loading = false;
      this.customerData = {};
      return;
    }
    GoogleAnalyticsService.event(Vue, 'Fetch customer', 'Customer-Detail', 'Retrive customer data', { accessorials_fuel_customer: customerId });
    const resp = await customerService.getCustomerData(customerId);
    this.customerData = _.get(resp, 'data', {});
    this.loading = false;
    return resp.data;
  } catch (error) {
    this.loading = false;
    HgNotificationService.errorMessage('Failed to get customer details');
    return {};
  }
}

function getSubTabs() {
  const subTabs = [{ name: 'Details', component: 'CustomerDetailTab' }];

  const hasAccessorialEntitlements = utilitiesService.verifyEntitlements([entitlementsEnum.ACCS_VIEW], localStorage.getItem('jwt'));
  if (hasAccessorialEntitlements) {
    subTabs.push({
      name: 'Customer Fuel Scales',
      component: 'CustomerFuelScaleTab'
    });
  }
  return subTabs;
}

export default {
  components: {
    CustomerDetailTab,
    CustomerFuelScaleTab
  },
  data: () => ({
    activeTab: 0,
    customerData: {},
    entitlementsEnum,
    tabs: getSubTabs()
  }),
  props: {
    customerId: {
      type: String,
      default: ''
    }
  },
  filters: {
    titleCase(value) {
      if (!value || !value.trim()) return '-';

      return _.startCase(_.toLower(value));
    }
  },
  watch: {
    customerId: {
      handler(newCustomerId) {
        this.getCustomerData(newCustomerId);
      }
    }
  },
  methods: {
    getCustomerData
  },
  mounted() {
    this.$nextTick(async () => {
      await this.getCustomerData(this.customerId);
    });
  }
};
