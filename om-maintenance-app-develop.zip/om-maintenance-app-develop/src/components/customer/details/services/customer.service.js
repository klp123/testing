/* eslint-disable func-names */
/* eslint-disable no-return-await */
/* eslint-disable prefer-arrow-callback */
import { ApiHelperService, AxiosHelperService } from '@hubgroup/hg-om-shared-services';

const axios = AxiosHelperService.attach();

function getCustomerData(orderId) {
  const apiUrl = `${ApiHelperService.getApiUrl()}customer/${orderId}`;
  return axios.get(apiUrl, { params: { searchText: orderId, limit: 1 } });
}

function getCustomerEdiSettings(customerId) {
  const apiUrl = `${ApiHelperService.getApiUrl()}customers/get-edi-settings?customerId=${customerId}`;
  return axios.get(apiUrl);
}

function updateCustomerEdiSettings(customerEdiSettings, customerId) {
  const apiUrl = `${ApiHelperService.getApiUrl()}customers/update-edi-settings?customerId=${customerId}`;
  return axios.post(apiUrl, customerEdiSettings);
}

async function getCustomerTeamAssignmetData(customerId) {
  const apiUrl = `${ApiHelperService.getApiUrl()}assignment/customer/${customerId}`;
  return await axios.get(apiUrl);
}
function postCustomerAssignments(customerData) {
  const apiUrl = `${ApiHelperService.getApiUrl()}assignment/customer/${customerData.id}`;
  return axios.post(apiUrl, customerData);
}

export default {
  getCustomerData,
  getCustomerTeamAssignmetData,
  postCustomerAssignments,
  getCustomerEdiSettings,
  updateCustomerEdiSettings
};
