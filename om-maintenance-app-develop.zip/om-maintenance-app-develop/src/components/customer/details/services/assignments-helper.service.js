/* eslint-disable no-param-reassign */
function updateExpansionText(inputList, tableOptions, type) {
  if (inputList.length && inputList.length > 3) {
    if (tableOptions.itemsPerPage === inputList.length) {
      return `Hide ${inputList.length - 3 || ''} other ${type}`;
    }
    return `View ${inputList.length - 3 || ''} other ${type}`;
  }
  return '';
}

/**
 * sets the table expansion to either 3 rows or 99 rows
 * also changes the display button to reflect whether
 * expanded or contracted.
 * @returns { Object }
 * { itemsPerPage: Number, expansionText: String }
 */
function viewMore(inputList, tableOptions, type) {
  if (tableOptions.itemsPerPage > 3) {
    tableOptions.itemsPerPage = 3;
  } else {
    tableOptions.itemsPerPage = inputList.length;
  }

  const expansionText = this.updateExpansionText(inputList, tableOptions, type);
  return {
    itemsPerPage: tableOptions.itemsPerPage,
    expansionText,
  };
}

/**
 * Sets the init values of the expansion text and only 3 rows visible.
 * @returns { Object }
 * { itemsPerPage: Number, expansionText: String }
 */
function initExpansionText(inputList, tableOptions, type) {
  const expansionText = this.updateExpansionText(inputList, tableOptions, type);
  return {
    itemsPerPage: 3,
    expansionText,
  };
}

export default {
  initExpansionText,
  viewMore,
  updateExpansionText,
};
