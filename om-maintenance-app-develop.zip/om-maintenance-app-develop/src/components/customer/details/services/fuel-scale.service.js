import { ApiHelperService, AxiosHelperService } from '@hubgroup/hg-om-shared-services';

const axios = AxiosHelperService.attach();

function customerFuelScale(customerData, limit = 50, status = '') {
  const apiUrl = `${ApiHelperService.getApiUrl('om-fuel')}fuel-scales?limit=${limit}&status=${status}`;
  return axios.post(apiUrl, customerData);
}

function allFuelScale() {
  const apiUrl = `${ApiHelperService.getApiUrl('om-fuel')}fuel-scales?limit=50`;
  return axios.post(apiUrl);
}

export default {
  customerFuelScale,
  allFuelScale
};
