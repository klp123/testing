<template>
  <v-container>
    <v-row>
      <v-col cols="6" class="pt-3 pl-3" v-if="mode == 'EDIT'">
        <h2 class="form-sub-header-alt">Add Team Inboxes</h2>
        <v-form v-model="addInboxForm">
          <v-row dense>
            <v-col cols="6">
              <v-text-field
                ref="inboxForm"
                class="pt-3 team-inbox-input"
                placeholder="Type an inbox to add..."
                type="email"
                outlined
                :rules="[rules.required, rules.email]"
                dense
                v-model="inboxText"
              ></v-text-field>
            </v-col>
            <v-col cols="2">
              <v-btn
                plain
                :color="getColor('secondary')"
                :ripple="false"
                class="clickable add-btn mt-6"
                :disabled="!addInboxForm"
                @click="addInbox()"
              >
                Add
              </v-btn>
            </v-col>
          </v-row>
        </v-form>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="12">
        <div v-if="loading" class="px-1">
          <v-skeleton-loader
            :types="skeletonLoader"
            type="team-assignment-table"
            class="team-assignment-skeleton mb-1"
          />
          <v-skeleton-loader type="text" width="150" class="mb-1" />
        </div>
        <div v-else>
          <v-form v-model="validTeams">
            <v-data-table
              :headers="header"
              :items="teamAssignments"
              :options="tableOptions"
              hide-default-footer
              class="elevation-0 hg-table"
              v-bind:class="{ 'edit-table': mode == 'EDIT' }"
            >
            <template v-slot:item.email="props">
              <v-col>
                <v-row>
                  <label class="table-sub-header">{{ props.item.email }}</label>
                </v-row>
                <v-row v-if="mode === 'EDIT'">
                  <label class="error-state">{{ props.item.emailError }}</label>
                </v-row>
              </v-col>
            </template>
              <template v-if="mode === 'EDIT'" v-slot:item.region="props">
                <div>
                  <region-dropdown
                    :inputRegion="props.item.region"
                    :ref="`${props.index}-team-region-dropdown`"
                    :key="`${props.index}-team-${forceUpdate}`"
                    :disabled="props.item.mode || ''"
                    @valueSelected="updateRegion($event, props.index)"
                  />
                </div>
              </template>
              <template v-else v-slot:item.region="props">
                <div>
                  {{ displayStandardRegion(props.item.region) }}
                </div>
              </template>
              <template v-if="mode === 'EDIT'" v-slot:item.region.type="props">
                <div v-if=!!(props.item.region.name)>
                  <region-type
                    :selectedRegionType="props.item.region.type"
                    :key="`${props.index}-individual-region-type-${forceUpdate}`"
                    @regionTypeSelected="updateRegionType($event, props.index)"
                  />
                </div>
              </template>
              <template v-else v-slot:item.region.type="props">
                <div class="regionType">
                  {{ props.item.region.type }}
                </div>
              </template>
              <template v-if="mode === 'EDIT'" v-slot:item.mode="props">
                <v-select
                  dense
                  v-model="props.item.mode"
                  :items="modes"
                  :disabled="!!(props.item.region.name)"
                  outlined
                  hide-details="true"
                  @change="calculateErrors()"
                  class="mode-select"
                  append-icon="mdi-chevron-down"
                  clearable
                ></v-select>
              </template>
              <template v-if="mode === 'EDIT'" v-slot:item.delete="props">
                <v-btn icon @click="removeInbox(props.index)">
                  <img :src="getCdnImageUrl(CdnImagesEnum.delete_icon)" />
                </v-btn>
              </template>
            </v-data-table>
          </v-form>
          <span class="clickable expansion mt-2" v-on:click="viewMore">
            {{ expandText }}
          </span>
        </div>
      </v-col>
    </v-row>
  </v-container>
</template>

<script src='./team-assignments.js' />
<style src='./team-assignments.sass' lang='sass' scoped />
