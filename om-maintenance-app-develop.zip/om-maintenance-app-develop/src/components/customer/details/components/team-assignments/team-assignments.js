/* eslint-disable arrow-body-style */
/* eslint-disable no-undef */
/* eslint-disable max-len */
/* eslint-disable no-plusplus */
/* eslint-disable no-param-reassign */
import _ from 'lodash';
import Vue from 'vue';
import { ImageLoaderService, GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import { CdnImagesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import hgAutocomplete from '../../../../shared/drop-downs/hg-autocomplete/hg-autocomplete.vue';
import regionDropdown from '../region-dropdown/region-dropdown.vue';
import regionType from '../region-type/region-type.vue';
import regionTypes from '../../../../../enums/region-types.enum';
import assignmentsHelperService from '../../services/assignments-helper.service';
import commonService from '../../../../../services/common.service';
import { countryList } from '../../../../../enums/countries.enum';
import ModesEnum from '../../../../../enums/modes.enum';

function viewMore() {
  const options = assignmentsHelperService.viewMore(this.teamAssignments, this.tableOptions, 'Inboxes');
  this.expandText = options.expansionText;
  this.tableOptions.itemsPerPage = options.itemsPerPage;
}

/**
 * gets image from hubgroup CDN
 * @param {String} imageName
 * @return {String} image URL
 */
function getCdnImageUrl(imageName) {
  return ImageLoaderService.getCdnImageUrl(imageName);
}

/**
 * @function - used for setting google analytics
 * @param {*} details - event message that needs to be send for ga
 */
function setGoogleAnalytics(details) {
  GoogleAnalyticsService.event(Vue, 'Metric', 'Maintenance', details);
}
function addInbox() {
  this.teamAssignments.push({
    email: `${this.inboxText}`,
    region: {},
    mode: ''
  });
  this.inboxText = '';
  this.$refs.inboxForm.resetValidation();
  if (this.tableOptions.itemsPerPage !== 99) {
    const options = assignmentsHelperService.viewMore(this.teamAssignments, this.tableOptions, 'Inboxes');
    this.expandText = options.expansionText;
    this.tableOptions.itemsPerPage = options.itemsPerPage;
  } else {
    this.expandText = assignmentsHelperService.updateExpansionText(this.teamAssignments, this.tableOptions, 'Inboxes');
  }
  this.calculateErrors();
  this.forceUpdate++;
}

function removeInbox(removedInbox) {
  this.teamAssignments.splice(removedInbox, 1);
  this.expandText = assignmentsHelperService.updateExpansionText(this.teamAssignments, this.tableOptions, 'Inboxes');
  this.calculateErrors();
  setGoogleAnalytics('Inbox email has removed');
  this.forceUpdate++;
}

function updateRegion(selectedRegion, regionIndex) {
  const standardRegion = _.find(this.standardRegions, selectedRegion);
  const _regionType = _.get(this.teamAssignments, `${regionIndex}.region.type`, regionTypes[1].value);
  let region = {};
  if (_.isArray(selectedRegion)) {
    const countries = [];
    const states = [];
    selectedRegion.map((item) => {
      if (countryList.includes(item)) {
        countries.push(item);
      } else {
        states.push(item);
      }
      return null;
    });
    region = { name: 'custom', states, countries };
  } else if (standardRegion) {
    region = { name: standardRegion.region, states: standardRegion.states };
  } else {
    region = {};
  }
  this.teamAssignments[regionIndex].region = _.isEmpty(region) ? {} : { ...region, type: _regionType };
  this.calculateErrors();
}

function updateRegionType(selectedValue, index) {
  this.teamAssignments[index].region.type = selectedValue;
}

async function initRegions() {
  let resp = [];
  if (_.isEmpty(this.standardRegions)) {
    resp = await commonService.getCommonLov('USA_REGIONS');
  }
  this.standardRegions = resp.map((region) => (
    { region: region.displayValue, states: region.value, value: region.displayValue }
  ));
  this.standardRegions = this.standardRegions.concat([
    { region: 'CANADA', states: [], value: 'CANADA' },
    { region: 'MEXICO', states: [], value: 'MEXICO' },
  ]);
}

function emailError(index, email) {
  if (_.filter(this.teamAssignments, { email }).length > 1) {
    this.teamAssignments[index].emailError = 'This team inbox is already in use';
    return;
  }
  this.teamAssignments[index].emailError = '';
}

function calculateErrors() {
  this.validTeams = true;
  this.teamAssignments.forEach((team, index) => {
    this.emailError(index, team.email);
    if (!_.isEmpty(team.emailError)) {
      this.validTeams = false;
    }
    if (!team.mode) team.mode = '';
  });
  this.$emit('validTeams', this.validTeams);
  if (this.validTeams) {
    this.$emit('customerTeamAssignments', this.teamAssignments);
  }
}

function getColor(name) {
  return _colors[name];
}

function displayStandardRegion(region) {
  let displayText = `${_.startCase(_.toLower(region.region || region.name))}`;
  const statesString = !_.isEmpty(region.states) ? `${region.states.join(', ')}` : '';
  const countriesString = !_.isEmpty(region.countries) ? `, ${region.countries.join(', ')}` : '';
  if (statesString || countriesString) {
    displayText = `${displayText} - (${statesString}${countriesString})`;
  }
  return displayText;
}

function closeDialog() {
  this.dialog = false;
}

/**
 * @function - handler function for data changes after user clicked on Save Changes button
 * @param {*} details - detailed object of what changed
 */
function handleDifferencesInData(details) {
  const changes = { teamAssignmentChanged: false, teamRegionChanged: false, teamModeChanged: false };
  // mapping to JSON.
  const originalTeam = {};
  details.originalEmail.forEach((e) => {
    originalTeam[e.email] = e;
  });
  _.map(details.newTeamEmail, (e) => {
    if (!originalTeam[e.email]) {
      changes.teamAssignmentChanged = true;
      if (!_.isEmpty(e.region)) {
        changes.teamRegionChanged = true;
      }
      if (!_.isEmpty(e.mode)) {
        changes.teamModeChanged = true;
      }
      return null;
    }
    if (originalTeam[e.email].email === e.email && originalTeam[e.email].mode !== e.mode) {
      changes.teamModeChanged = true;
    }
    if (originalTeam[e.email].email === e.email && !_.isEqual(originalTeam[e.email].region, e.region)) {
      changes.teamRegionChanged = true;
    }
    return null;
  });
  if (changes.teamModeChanged) {
    setGoogleAnalytics('Team Assignment Mode changed');
  }
  if (changes.teamRegionChanged) {
    setGoogleAnalytics('Team Assignment Region changed');
  }
  if (changes.teamAssignmentChanged) {
    setGoogleAnalytics('New Email added in Team Inbox');
  }
}
export default {
  name: 'TeamAssignments',
  components: {
    hgAutocomplete,
    regionDropdown,
    regionType
  },
  data: () => ({
    header: [
      { text: 'TEAM INBOXES', value: 'email', width: '30%' },
      { text: 'REGION', value: 'region', width: '15%' },
      { text: 'REGION TYPE', value: 'region.type', width: '30%' },
      { text: 'MODE', value: 'mode', width: '15%' },
    ],
    originalTeamAssignments: [],
    tableOptions: {
      itemsPerPage: 3,
      multiSort: false,
      mustSort: false,
    },
    expandText: '',
    skeletonLoader: {
      'team-assignment-table': 'team-assignment-thead, divider, team-assignment-tbody',
      'team-assignment-tbody': 'team-assignment-table-row-divider@3',
      'team-assignment-table-row-divider': 'team-assignment-table-row, divider',
      'team-assignment-table-row': 'table-cell@3',
      'team-assignment-thead': 'heading@3',
    },
    modes: ModesEnum.map((mode) => mode.text),
    CdnImagesEnum,
    inboxText: '',
    forceUpdate: 0,
    standardRegions: [],
    validTeams: false,
    addInboxForm: false,
    rules: {
      required: (value) => !!value || 'Required e-mail',
      email: (value) => {
        const pattern = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return pattern.test(value) || 'Invalid e-mail';
      },
    },
    dialog: false,
  }),
  props: {
    loading: {
      type: Boolean,
      default: true,
    },
    customerData: {
      type: Object,
      default: {},
    },
    mode: {
      type: String,
      default: 'VIEW',
    },
    teamAssignments: {
      type: Array,
      default: () => [],
    },
  },
  watch: {
    mode(newMode) {
      if (newMode === 'EDIT') {
        this.header.push({ text: '', value: 'delete', sortable: false });
        this.originalTeamAssignments = _.cloneDeep(this.teamAssignments);
        this.originalCustomerData = _.cloneDeep(this.customerData);
      } else if (newMode === 'VIEW') {
        this.teamAssignments = _.cloneDeep(this.originalTeamAssignments);
        this.header.pop();
      } else if (newMode === 'SAVED') {
        handleDifferencesInData({
          originalEmail: this.originalTeamAssignments,
          newTeamEmail: this.teamAssignments,
        });
        this.header.pop();
      } else {
        this.header.pop();
      }
      this.expandText = assignmentsHelperService.updateExpansionText(this.teamAssignments, this.tableOptions, 'Inboxes');
    },
    teamAssignments: {
      handler: function update() {
        this.$nextTick(function updateAssignmentsText() {
          this.expandText = assignmentsHelperService.updateExpansionText(this.teamAssignments, this.tableOptions, 'Inboxes');
        });
      },
    },
  },
  mounted() {
    this.$nextTick(function init() {
      const options = assignmentsHelperService.initExpansionText(this.teamAssignments, this.tableOptions, 'Inboxes');
      this.expandText = options.expansionText;
      this.tableOptions.itemsPerPage = options.itemsPerPage;
      this.initRegions();
      this.originalTeamAssignments = _.cloneDeep(this.teamAssignments);
      this.calculateErrors();
    });
  },
  methods: {
    getCdnImageUrl,
    addInbox,
    removeInbox,
    updateRegion,
    initRegions,
    viewMore,
    emailError,
    calculateErrors,
    getColor,
    displayStandardRegion,
    updateRegionType,
  },
};
