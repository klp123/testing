import _ from 'lodash';
import Vue from 'vue';
import {
  HgMomentService,
  GoogleAnalyticsService,
} from '@hubgroup/hg-om-shared-services';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import CustomerInfo from '../customer-info/customer-info.vue';
import Rules from '../rules/rules.vue';
import TeamAssignments from '../team-assignments/team-assignments.vue';
import IndividualAssignments from '../individual-assignments/individual-assignments.vue';
import customerService from '../../services/customer.service';
/**
 * retrieve data from service based off customer ERPId
 * @param {string} customerId
 * @return {object} customer object from mongoDB
 */
async function trackCustomerChanges(customerId, disableLoading) {
  try {
    if (!disableLoading) this.loading = true;
    if (!customerId) {
      this.loading = false;
      this.customerData = {};
      return;
    }
    this.setupCustomerEdiSettingsInit();
    const customerEdiSettingsResponse = await customerService.getCustomerEdiSettings(customerId);
    this.customerEdiSettings = (customerEdiSettingsResponse.data) ? customerEdiSettingsResponse.data : _.cloneDeep(this.customerEdiSettingsInit);
    this.loading = false;
    return {};
  } catch (error) {
    this.loading = false;
    this.customerEdiSettings = this.customerEdiSettingsInit;
    HgNotificationService.errorMessage('Failed to get customer details');
    return {};
  }
}

function setupCustomerEdiSettingsInit() {
  _.set(this.customerEdiSettingsInit, 'customerId', _.get(this.customerData, 'id', ''));
  _.set(this.customerEdiSettingsInit, 'erpCustomerId', _.get(this.customerData, 'erpCustomerID', ''));
  _.set(this.customerEdiSettingsInit, 'customerName', _.get(this.customerData, 'name', ''));
}
async function getCustomerTeamAssignments(customerId, disableLoading) {
  try {
    this.teamAssignmentsData = {};
    if (!disableLoading) this.loading = true;
    if (!customerId) {
      this.loading = false;
      this.teamAssignmentsData = {};
      this.teamName = '';
      this.lastSaved = { time: '', user: '' };
      return;
    }

    const resp = await customerService.getCustomerTeamAssignmetData(customerId);
    this.teamAssignmentsData = _.get(resp, 'data.customerAssignments', {});
    this.customerData.individualAssignments = _.get(resp, 'data.customerAssignments.individualAssignments', []);
    this.customerData.teamAssignments = _.get(resp, 'data.customerAssignments.teamAssignments', []);
    this.customerData.teamName = _.get(resp, 'data.customerAssignments.teamName', '');
    const lastSavedBy = _.get(resp, 'data.customerAssignments.modifiedBy', '-').toUpperCase();
    const lastSavedTime = HgMomentService.formatTime(_.get(resp, 'data.customerAssignments.modifiedDateTime', ''));
    this.lastSaved = { time: lastSavedTime, user: lastSavedBy };
    this.teamName = _.get(resp, 'data.customerAssignments.teamName', '');
    this.loading = false;
    return resp.data.customerAssignments;
  } catch (error) {
    this.loading = false;
    HgNotificationService.errorMessage('Failed to get customer details');
    return {};
  }
}

function setGoogleAnalytics(details) {
  GoogleAnalyticsService.event(Vue, 'Metric', 'Maintenance', details);
}

/**
 * Re-routes the user to the associated location maintenance
 * screen pre filtered to customer ID
 * @return {null}
 */
function openLocation() {
  this.$router.push({ name: 'Location', params: { customer: { name: this.customerData.name, id: this.customerId } } });
  setGoogleAnalytics('View Customer Location visited');
}

/**
 * toggles view for edit
 * @return {null}
 */
function toggleEdit(isCancel) {
  if (this.mode === 'VIEW' || this.mode === 'SAVED') {
    this.mode = 'EDIT';
  } else {
    this.mode = 'VIEW';
    if (isCancel) {
      this.resetCustomerData();
    }
  }
}

async function resetCustomerData() {
  await this.getCustomerTeamAssignments(this.customerId, true);
  await this.trackCustomerChanges(this.customerId, true);
}

async function saveChanges() {
  try {
    const rulesValid = this.$refs.rulesRef.validate();
    if (rulesValid) {
      this.lastSaved.time = HgMomentService.formatTime(new Date());
      const user = JSON.parse(localStorage.getItem('user') || {});
      this.lastSaved.user = _.get(user, 'username', 'N/A').toUpperCase();
      this.customerData.lastSaved = this.lastSaved;
      if (this.deletedCustomerData.individualAssignments) {
        // eslint-disable-next-line operator-linebreak
        this.customerData.deletedIndividualAssignments =
        this.deletedCustomerData.individualAssignments;
      }
      this.customerEdiSettings = await customerService.updateCustomerEdiSettings(this.customerEdiSettings, this.customerData.id);
      this.customerEdiSettings = _.get(this.customerEdiSettings, 'data', this.customerEdiSettingsInit);
      await customerService.postCustomerAssignments(this.customerData);
      HgNotificationService.successMessage('Saved updates successfully');
      this.deletedCustomerData = { individualAssignments: [] };
      this.teamName = this.customerData.teamName;
      this.mode = 'SAVED';
    }
  } catch (err) {
    // Show Custom error message from API if it has any
    if (_.has(err, 'response.data.message')) {
      const message = JSON.parse(err.response.data.message);
      HgNotificationService.errorMessage(`Failed to save changes. ${message.details.map((e) => e.message).join(', ')}`);
    } else {
      HgNotificationService.errorMessage(err.message);
    }
  }
}

function setTeamValidity(event) {
  this.teamValidity = event;
}

function setCustomerTeamAssignments(event) {
  this.customerData.teamAssignments = event;
}

function setIndividualValidity(event) {
  this.individualValidity = event;
}

function setCustomerIndividualAssignments(event) {
  this.customerData.individualAssignments = event;
}
function setDeleteCustomerIndividualAssignments(event) {
  this.deletedCustomerData.individualAssignments = event;
}

function getUserEntitlements() {
  const userObj = localStorage.getItem('user');
  const userEntitlements = _.get(JSON.parse(userObj), 'userEntitlements', []);
  const canEdit = _.find(userEntitlements, { code: 'TA_EDIT' });
  this.entitlements = !_.isEmpty(canEdit);
}

export default {
  name: 'CustomerDetails',
  components: {
    CustomerInfo,
    TeamAssignments,
    IndividualAssignments,
    Rules
  },
  data: () => ({
    mode: 'VIEW',
    entitlements: false,
    customerEdiSettings: {},
    customerEdiSettingsInit: {
      customerId: '',
      erpCustomerId: '',
      customerName: '',
      rules: {
        isTimeBasedAcceptance: false,
        timeSlot: '',
        tenderStatus: '',
        autoAccept: [],
        autoReject: []
      }
    },
    ediRulesValid: {
      valid: false,
    },
    teamName: '',
    deletedCustomerData: {},
    teamAssignmentsData: {},
    loading: true,
    teamValidity: true,
    individualValidity: true,
    lastSaved: {
      time: '',
      user: '',
    },
  }),
  props: {
    customerId: {
      type: String,
      default: '',
    },
    customerData: {
      type: Object,
      default: () => ({})
    }
  },
  filters: {
    titleCase(value) {
      if (!value || !value.trim()) return '-';

      return _.startCase(_.toLower(value));
    },
  },
  watch: {
    customerId: {
      handler(newCustomerId) {
        this.trackCustomerChanges(newCustomerId);
        this.getCustomerTeamAssignments(newCustomerId);
        this.mode = 'VIEW';
      },
    }
  },
  methods: {
    trackCustomerChanges,
    getCustomerTeamAssignments,
    openLocation,
    toggleEdit,
    resetCustomerData,
    saveChanges,
    setTeamValidity,
    setIndividualValidity,
    setCustomerTeamAssignments,
    setCustomerIndividualAssignments,
    setDeleteCustomerIndividualAssignments,
    getUserEntitlements,
    setupCustomerEdiSettingsInit,
    setGoogleAnalytics
  },
  mounted() {
    this.$nextTick(async () => {
      await this.getCustomerTeamAssignments(this.customerId);
      this.getUserEntitlements();
    });
  },
};
