<template>
  <v-card>
    <v-card-title class="form-header">
      <v-row justify="space-between">
        <v-col class="pl-6">
          <v-skeleton-loader
            v-if="loading"
            class="py-1"
            type="text"
            width="75"
          />
          <div v-else>{{ customerData.name }}</div>
        </v-col>
        <v-col
          cols="3"
          class="expansion clickable word-break justify-end"
          v-on:click="openLocation"
          v-if="customerId"
          >View Customer Locations
        </v-col>
        <v-col
          cols="1"
          class="expansion clickable edit"
          v-if="mode != 'EDIT' && entitlements && customerId"
          v-on:click="toggleEdit"
          >Edit</v-col
        >
      </v-row>
    </v-card-title>
    <v-divider class="my-1 primary_border"></v-divider>
    <v-card-text>
      <CustomerInfo :loading="loading" :customerData="customerData" :teamName="teamName" />
    </v-card-text>
    <v-divider class="my-1 primary_border"></v-divider>
    <v-card-text>
      <template v-if="!loading">
        <h1 class="form-header pb-2 pl-3">Rules</h1>
        <Rules
          :mode="mode"
          :ediRules="customerEdiSettings.rules"
          ref="rulesRef"
          :valid="ediRulesValid"
        ></Rules>
      </template>
    </v-card-text>
    <v-divider class="my-1 primary_border"></v-divider>
    <v-card-text>
      <h1 class="form-header pb-2 pl-3">Assignments</h1>
      <IndividualAssignments
        :loading="loading"
        :customerData="customerData"
        :teamAssignmentsName="teamName"
        :individualAssignments="teamAssignmentsData.individualAssignments"
        :mode="mode"
        @validIndividuals="setIndividualValidity($event)"
        @customerIndividualAssignments="setCustomerIndividualAssignments($event)"
        @deleteCustomerIndividualAssignments="setDeleteCustomerIndividualAssignments($event)"
      />
      <v-divider class="my-1 primary_border"></v-divider>
      <TeamAssignments
        :loading="loading"
        :customerData="customerData"
        :mode="mode"
        :teamAssignments="teamAssignmentsData.teamAssignments"
        @validTeams="setTeamValidity($event)"
        @customerTeamAssignments="setCustomerTeamAssignments($event)"
      />
    </v-card-text>
    <v-card-actions>
      <v-container>
        <v-row>
          <v-col cols="2" v-if="mode === 'EDIT'">
            <hg-lib-btn
              class="pl-3"
              title="Cancel"
              type="secondary"
              @click.native="toggleEdit(true)"
            />
          </v-col>
          <v-col cols="5" class="ml-auto my-auto label justify-end">
            <label>{{ `Last Updated: ${lastSaved.time} by ${lastSaved.user}` }}</label>
          </v-col>
          <v-col cols="2" v-if="mode === 'EDIT'">
            <hg-lib-btn
              :disabled="!teamValidity || !individualValidity"
              title="Save Changes"
              type="primary"
              @click.native="saveChanges()"
            />
          </v-col>
        </v-row>
      </v-container>
    </v-card-actions>
  </v-card>
</template>

<script src="./customer-details-tab.js"></script>
<style src="./customer-details-tab.sass" lang="sass" scoped></style>
