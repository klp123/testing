<template>
  <v-container class="container">
    <v-list class="listItems">
      <v-list-item
        v-on:click="onRadioItemSelected(regionType.value)"
        v-for="(regionType, index) in regionTypes"
        :key="`regionType_${index}`"
        class="listItem"
      >
        <v-list-item-action class="listItemAction">
          <div class="input-wrapper">
            <input
              ref="radio"
              type="radio"
              class="radio-button"
              :checked="isCheckedRadioItem(regionType.value)"
              :id="`id-radio-value-${regionType.value}`"
            />
          </div>
        </v-list-item-action>
        <v-list-item-content>
          <v-list-item-title class="list-title">
            {{ regionType.label }}
          </v-list-item-title>
        </v-list-item-content>
      </v-list-item>
    </v-list>
  </v-container>
</template>

<script src='./region-type.js' />
<style src='./region-type.sass' lang='sass' scoped />
