import regionTypes from '../../../../../enums/region-types.enum';

function onRadioItemSelected(value) {
  this.selectedItem = value;
  this.$emit('regionTypeSelected', value);
}

function isCheckedRadioItem(value) {
  if (!this.selectedItem || !value) return false;
  return this.selectedItem === value;
}

export default {
  name: 'RegionType',
  data: () => ({
    regionTypes,
    selectedItem: ''
  }),
  mounted() {
    this.$nextTick(function init() {
      this.selectedItem = this.selectedRegionType;
    });
  },
  props: {
    selectedRegionType: {
      type: String,
      default: regionTypes[1].value,
    },
  },
  methods: {
    onRadioItemSelected,
    isCheckedRadioItem,
  },
};
