/* eslint-disable prefer-destructuring */
import _ from 'lodash';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import states from '../../../../../enums/states.enum';
import commonService from '../../../../../services/common.service';
import countries, { countryList } from '../../../../../enums/countries.enum';

function onClickOutsideDialog(isMenuOpen) {
  if (!isMenuOpen) {
    this.shown = false;
  }
}

function onRadioItemSelected(value) {
  this.selectedItem = value;
  this.selectedItems = [];
  this.updateDisplayData();
  this.$emit('valueSelected', this.selectedItem);
}

function onListItemSelected() {
  this.updateDisplayData();
  this.selectedItem = {};
  this.$emit('valueSelected', this.selectedItems);
}

function isCheckedRadioItem(value) {
  if (!this.selectedItem || !value) return false;

  return (this.selectedItem.value === value || this.selectedItem.name === value);
}

function isCheckedList(value, isCountryItem) {
  if (_.isEmpty(this.selectedItems) || !value) return false;
  if (isCountryItem) {
    return this.selectedItems.some((item) => countryList.includes(item));
  }

  return true;
}

function isCheckedListItem(value) {
  if (!this.selectedItems.includes(value)) return false;

  return true;
}

function updateDisplayData() {
  if (!_.isEmpty(this.selectedItems)) {
    this.displayData = `Custom - (${this.selectedItems.join(', ')})`;
  } else {
    this.displayData = this.displayStandardRegion(this.selectedItem);
  }
}

function getColor(name) {
  return _colors[name];
}

function initData() {
  if (_.isEmpty(this.inputRegion)) {
    this.selectedItem = {};
  } else {
    this.selectedItem = this.inputRegion;
  }
  if (this.inputRegion.name === 'custom') {
    const _states = _.get(this.inputRegion, 'states', []);
    const _countries = _.get(this.inputRegion, 'countries', []);
    this.selectedItems = [..._states, ..._countries];
  }
  this.updateDisplayData();
}

async function initRegions() {
  let resp = [];
  if (_.isEmpty(this.standardRegions)) {
    resp = await commonService.getCommonLov('USA_REGIONS');
  }
  this.standardRegions = resp.map((region) => (
    { region: region.displayValue, states: region.value, value: region.displayValue }
  ));
  this.standardRegions = this.standardRegions.concat([
    { region: 'CANADA', countries: ['CAN'], value: 'CANADA' },
    { region: 'MEXICO', countries: ['MEX'], value: 'MEXICO' },
  ]);
}

function displayStandardRegion(region) {
  let displayText = `${_.startCase(_.toLower(region.region || region.name))}`;
  const statesString = !_.isEmpty(region.states) ? `${region.states.join(', ')}` : '';
  const countriesString = !_.isEmpty(region.countries) ? `${region.countries.join(', ')}` : '';
  if (statesString || countriesString) {
    displayText = `${displayText} - (${statesString}${(statesString && countriesString) ? ', ' : ''}${countriesString})`;
  }
  return displayText;
}

function clearInput() {
  this.selectedItem = {};
  this.selectedItems = [];
  this.updateDisplayData();
  this.$emit('valueSelected', '');
}

export default {
  name: 'RegionDropdown',
  components: {
  },
  data: () => ({
    shown: false,
    standardRegions: [],
    customRegions: states,
    customCountries: countries,
    selectedItem: {},
    selectedItems: [],
    displayData: '',
  }),
  props: {
    inputRegion: {
      type: Object,
      default: {},
    },
    disabled: {
      type: String,
      default: '',
    },
  },
  mounted() {
    this.$nextTick(async function init() {
      await this.initRegions();
      this.initData();
    });
  },
  methods: {
    onClickOutsideDialog,
    isCheckedRadioItem,
    onRadioItemSelected,
    onListItemSelected,
    isCheckedListItem,
    isCheckedList,
    getColor,
    updateDisplayData,
    initData,
    initRegions,
    displayStandardRegion,
    clearInput,
  },
};
