<template>
  <v-menu
    offset-y
    @input="onClickOutsideDialog"
    :close-on-click="true"
    :close-on-content-click="false"
    :disabled="disabled.length > 0"
  >
    <template v-slot:activator="{ on, attrs }">
      <div>
        <label
          color="primary"
          dark
          v-bind="attrs"
          v-on="on"
          :disabled="disabled.length > 0"
          v-on:click="if (disabled.length === 0) shown = !shown;"
          app
          class="label-filter"
          v-bind:class="{
            'label-filter-active': shown,
            'clickable': disabled.length <= 0,
          }"
        >
          <label
            v-bind:class="{ 'clickable': disabled.length <= 0 }"
            class="input-ellipse"
            >{{ displayData }}</label
          >
            <v-icon
              v-if="displayData"
              v-bind:class="{ 'label-active': shown }"
              medium
              @click.native.stop="clearInput()"
              >mdi-close
            </v-icon>
            <v-icon
              v-bind:class="{ 'label-active': shown }"
              medium
              v-if="!shown"
            >
              mdi-chevron-down
            </v-icon>
            <v-icon
              v-bind:class="{ 'label-active': shown }"
              medium
              v-if="shown"
            >
              mdi-chevron-up
            </v-icon>
        </label>
      </div>
    </template>
    <v-card
      v-bind:class="{ 'label-filter-inactive': !shown }"
      class="menu-dialog"
      ref="filterContent"
    >
      <v-container class="dropdown-menu">
        <v-row class="dropdown-menu-row">
          <input
            type="radio"
            class="radio-button"
            disabled
            :checked="selectedItem.states && selectedItem.states.length"
          />
          <label class="list-title">Standard Region</label>
        </v-row>
        <v-list>
          <v-list-item
            v-on:click="onRadioItemSelected(region)"
            v-for="(region, index) in standardRegions"
            :key="`standard${index}`"
            class="clickable"
          >
            <v-list-item-action>
              <div class="input-wrapper">
                <input
                  ref="radio"
                  type="radio"
                  class="radio-button"
                  :checked="isCheckedRadioItem(region.value)"
                  :id="`id-radio-value-${region.value}`"
                />
              </div>
            </v-list-item-action>
            <v-list-item-content>
              <v-list-item-title class="list-title">
                {{ displayStandardRegion(region) }}
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
        <v-row class="dropdown-menu-row">
          <input
            type="radio"
            class="radio-button"
            disabled
            :checked="isCheckedList(selectedItems)"
          />
          <label class="list-title">Custom Region</label>
        </v-row>
        <v-list-item
          v-for="(region, index) in customRegions"
          :key="`custom${index}`"
        >
          <v-list-item-action>
            <v-checkbox
              v-model="selectedItems"
              @click="onListItemSelected()"
              :color="getColor('color_primary_blue')"
              :value="region.state"
              :checked="isCheckedListItem(region.state)"
            ></v-checkbox>
          </v-list-item-action>
          <v-list-item-content>
            <v-list-item-title class="list-title">
              {{ region.state }} - {{ region.label }}
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        <v-row class="dropdown-menu-row pb-2">
          <input
            type="radio"
            class="radio-button"
            disabled
            :checked="isCheckedList(selectedItems, true)"
          />
          <label class="list-title">Custom Region of Country + State(s)</label>
        </v-row>
        <v-list-item
          v-for="(region, index) in customCountries"
          :key="`custom_country_${index}`"
        >
          <v-list-item-action>
            <v-checkbox
              v-model="selectedItems"
              @click="onListItemSelected()"
              :color="getColor('color_primary_blue')"
              :value="region.country"
              :checked="isCheckedListItem(region.country)"
            ></v-checkbox>
          </v-list-item-action>
          <v-list-item-content>
            <v-list-item-title class="list-title">
              {{ region.country }} - {{ region.label }}
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        <v-list-item
          v-for="(region, index) in customRegions"
          :key="`custom_country_state_${index}`"
        >
          <v-list-item-action>
            <v-checkbox
              v-model="selectedItems"
              @click="onListItemSelected()"
              :color="getColor('color_primary_blue')"
              :value="region.state"
              :checked="isCheckedListItem(region.state)"
            ></v-checkbox>
          </v-list-item-action>
          <v-list-item-content>
            <v-list-item-title class="list-title">
              {{ region.state }} - {{ region.label }}
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-container>
    </v-card>
  </v-menu>
</template>

<script src='./region-dropdown.js' />
<style src='./region-dropdown.sass' lang='sass' scoped />
