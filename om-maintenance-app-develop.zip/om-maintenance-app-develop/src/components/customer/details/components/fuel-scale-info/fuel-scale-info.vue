<template>
  <v-container>
    <v-row>
      <v-col cols="3">
        <h2 class="form-sub-header">PUBLISHED DATE</h2>
        <span class="form-label">{{ fuelScaleData.publishDateTime.dateTime | formatDate }}</span>
      </v-col>
      <v-col cols="2">
        <h2 class="form-sub-header">MODE</h2>
        <span class="form-label">{{ fuelScaleData.transportMode }}</span>
      </v-col>
      <v-col cols="2">
        <h2 class="form-sub-header">EQUIP TYPE</h2>
        <span class="form-label"
          >{{ fuelScaleData.equipment.equipmentType }}
          {{ fuelScaleData.equipment.length.amount }}</span
        >
      </v-col>
      <v-col cols="2">
        <h2 class="form-sub-header">COUNTRY</h2>
        <span class="form-label">{{ fuelScaleData.country }}</span>
      </v-col>
      <v-col cols="2">
        <h2 class="form-sub-header">STATUS</h2>
        <span
          :class="[
            'form-label',
            {
              activeStatus: fuelScaleData.status === 'ACTIVE',
              inactiveStatus: fuelScaleData.status === 'INACTIVE',
              expiredStatus: fuelScaleData.status === 'EXPIRED',
              futureStatus: isFuture(fuelScaleData.publishDateTime.dateTime)
            }
          ]"
          >{{ (fuelScaleData.status == 'INACTIVE') && isFuture(fuelScaleData.publishDateTime.dateTime) ? "FUTURE" : fuelScaleData.status }}</span
        >
      </v-col>
      <v-col cols="1">
        <v-menu offset-y>
          <template v-slot:activator="{ on }">
            <v-btn icon v-on="on">
              <v-icon>mdi-dots-horizontal</v-icon>
            </v-btn>
          </template>
          <v-list>
            <v-list-item @click="exportData('CSV')">
              <v-list-item-title>Export to CSV</v-list-item-title>
            </v-list-item>
            <v-list-item @click="exportData('Excel')">
              <v-list-item-title>Export to Excel</v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>
      </v-col>
    </v-row>
  </v-container>
</template>

<script src="./fuel-scale-info.js" />
<style src="./fuel-scale-info.sass" lang="sass" scoped />
