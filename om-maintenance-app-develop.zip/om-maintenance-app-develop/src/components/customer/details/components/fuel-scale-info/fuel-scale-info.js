import _ from 'lodash';
import Vue from 'vue';
import { GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import moment from 'moment';
import fileDownloadService from '../../../../../services/customer/file-download.service';

async function exportData(format) {
  const dataField = [
    ['customerId', 'transportMode', 'minDoeRate', 'maxDoeRate', 'rateQualifier', 'rateValue']
  ];

  this.fuelScaleData.fuelScales.forEach((fuelScale) => {
    dataField.push([
      this.fuelScaleData.customer.id,
      this.fuelScaleData.transportMode,
      fuelScale.minDoeRate,
      fuelScale.maxDoeRate,
      fuelScale.rateQualifier,
      fuelScale.rateValue
    ]);
  });

  if (format === 'CSV') {
    fileDownloadService.downloadFileAsCSV(dataField, this.fuelScaleData.fileName);
    GoogleAnalyticsService.event(Vue, 'Export file', 'Customer-Fuel-Scale-Detail', 'Export CSV file');
  } else if (format === 'Excel') {
    GoogleAnalyticsService.event(Vue, 'Export file', 'Customer-Fuel-Scale-Detail', 'Export excel file');
    fileDownloadService.downloadFileAsExcel(dataField, this.fuelScaleData.fileName);
  }
}

export default {
  name: 'FuelScaleInfo',
  data: () => ({}),
  methods: {
    exportData
  },
  computed: {
    // to check if "publishDateTime" is in the future
    isFuture() {
      return (dateTime) => {
        const centralTimeNow = moment().tz('America/Chicago');
        const publishDateTime = moment(dateTime);
        return publishDateTime.isAfter(centralTimeNow);
      };
    },
  },
  props: {
    fuelScaleData: {
      type: Object,
      default: {}
    }
  },
  filters: {
    titleCase(value) {
      return (!value || !value.trim()) ? '-' : _.startCase(_.toLower(value));
    },
    formatDate(value) {
      return (!value || !value.trim()) ? '-' : moment(value).format('MM/DD/YY');
    }
  }
};
