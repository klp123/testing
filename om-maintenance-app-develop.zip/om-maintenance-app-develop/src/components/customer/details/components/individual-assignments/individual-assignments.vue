<template>
  <v-container>
    <v-row class="pb-0 team-selection">
      <v-col cols="3">
        <h2 class="form-sub-header-alt">Team Assignment</h2>
        <v-skeleton-loader
          v-if="loading"
          type="text"
          width="100"
          class="my-1"
        />
        <span v-else class="form-label">{{ teamAssignmentsName }}</span>
      </v-col>
      <v-col cols="4"></v-col>
      <v-col cols="5" class="pb-0 pt-1" v-if="mode == 'EDIT'">
        <h2 class="form-sub-header-alt">Add/Replace Team Assignment</h2>
        <v-skeleton-loader
          v-if="loading"
          type="text"
          width="150"
          class="my-1"
        />
        <hg-autocomplete
          v-else
          ref="teamNameAutoComplete"
          placeholder="Type to search teams..."
          :items="teamNames"
          :itemText="formatTeamText"
          :itemValue="formatTeamValue"
          @input="updateTeamAssignment($event)"
          clearable
        />
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="6" class="pt-3 pl-3" v-if="mode == 'EDIT'">
        <h2 class="form-sub-header-alt">Add Individual Assignment</h2>
        <v-row dense>
          <v-col cols="6">
            <v-skeleton-loader
              v-if="loading"
              type="text"
              width="150"
              class="my-1"
            />
            <hg-autocomplete
              v-else
              class="pt-3 team-auto-complete"
              clearable
              :hideDetails="true"
              ref="individualAutoComplete"
              placeholder="Type to search individual..."
              @onSearchTextChanged="individualAutocompleteSearchTextChanged($event)"
              @input="updateSelectedValue($event)"
              :itemValue="formatIndividualValue"
              :items="individuals"
              :itemText="formatIndividualText"
            />
          </v-col>
          <v-col cols="2">
            <v-btn
              plain
              :color="getColor('secondary')"
              :ripple="false"
              class="clickable add-btn mt-6"
              :disabled="!(individualSelection.value)"
              @click="addInbox()"
            >
              Add
            </v-btn>
          </v-col>
        </v-row>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="12">
        <div v-if="loading" class="px-1">
          <v-skeleton-loader
            :types="skeletonLoader"
            type="team-assignment-table"
            class="team-assignment-skeleton mb-1"
          />
          <v-skeleton-loader type="text" width="150" class="mb-1" />
        </div>
        <div v-else>
          <v-data-table
            :headers="header"
            :items="individualAssignments"
            :options="tableOptions"
            hide-default-footer
            class="elevation-0 hg-table"
          >
            <template v-slot:item.email="props">
              <v-col>
                <v-row>
                  <label>{{ props.item.fullname }}</label>
                </v-row>
                <v-row>
                  <label class="table-sub-header">{{ props.item.email }}</label>
                </v-row>
                <v-row v-if="mode === 'EDIT'">
                  <label class="error-state">{{ props.item.emailError }}</label>
                </v-row>
              </v-col>
            </template>
            <template v-if="mode === 'EDIT'" v-slot:item.region="props">
              <div>
                <region-dropdown
                  :inputRegion="props.item.region"
                  :ref="`${props.index}-indivudual-region-dropdown`"
                  :key="`${props.index}-indivudual-${forceUpdate}`"
                  :disabled="props.item.mode || ''"
                  @valueSelected="updateRegion($event, props.index)"
                />
              </div>
            </template>
            <template v-else v-slot:item.region="props">
              <div>
                {{ displayStandardRegion(props.item.region) }}
              </div>
            </template>
            <template v-if="mode === 'EDIT'" v-slot:item.region.type="props">
              <div v-if=!!(props.item.region.name)>
                <region-type
                  :selectedRegionType="props.item.region.type"
                  :key="`${props.index}-individual-region-type-${forceUpdate}`"
                  @regionTypeSelected="updateRegionType($event, props.index)"
                />
              </div>
            </template>
            <template v-else v-slot:item.region.type="props">
              <div class="regionType">
                {{ props.item.region.type }}
              </div>
            </template>
            <template v-if="mode === 'EDIT'" v-slot:item.mode="props">
              <v-select
                dense
                v-model="props.item.mode"
                :items="modes"
                :disabled="!!(props.item.region.name)"
                outlined
                hide-details="true"
                class="mode-select"
                append-icon="mdi-chevron-down"
                clearable
              ></v-select>
            </template>
            <template v-if="mode === 'EDIT'" v-slot:item.delete="props">
              <v-btn icon @click="removeInbox(props.index)">
                <img :src="getCdnImageUrl(CdnImagesEnum.delete_icon)" />
              </v-btn>
            </template>
          </v-data-table>
          <span class="clickable expansion mt-2" v-on:click="viewMore">{{
            expandText
          }}</span>
        </div>
      </v-col>
    </v-row>
  </v-container>
</template>

<script src='./individual-assignments.js' />
<style src='./individual-assignments.sass' lang='sass' scoped />
