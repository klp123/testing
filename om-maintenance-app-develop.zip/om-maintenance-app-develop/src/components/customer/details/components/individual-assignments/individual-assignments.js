/* eslint-disable arrow-body-style */
/* eslint-disable max-len */
/* eslint-disable no-plusplus */
import _ from 'lodash';
import Vue from 'vue';
import { ImageLoaderService, GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import { CdnImagesEnum, AppSetupEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import assignmentsHelperService from '../../services/assignments-helper.service';
import regionDropdown from '../region-dropdown/region-dropdown.vue';
import regionType from '../region-type/region-type.vue';
import hgAutocomplete from '../../../../shared/drop-downs/hg-autocomplete/hg-autocomplete.vue';
import commonService from '../../../../../services/common.service';
import { countryList } from '../../../../../enums/countries.enum';
import regionTypes from '../../../../../enums/region-types.enum';
import ModesEnum from '../../../../../enums/modes.enum';
import prefService from '../../../../../services/preferences/preferences.service';

/**
 * gets image from hubgroup CDN
 * @param {String} imageName
 * @return {String} image URL
 */
function getCdnImageUrl(imageName) {
  return ImageLoaderService.getCdnImageUrl(imageName);
}

/**
 * @function - used for setting google analytics
 * @param {*} details - event message that needs to be send for ga
 */
function setGoogleAnalytics(details) {
  GoogleAnalyticsService.event(Vue, 'Metric', 'Maintenance', details);
}

/**
 * gets teamNames from LOV collectiom and sets autocomplete
 * value to current customers team
 * @return {null}
 */
async function initTeamNames() {
  if (_.isEmpty(this.teamNames)) {
    this.teamNames = await commonService.getCommonLov('AM_TEAMS');
  }
  if (this.mode === 'EDIT') {
    const associatedTeam = _.find(this.teamNames, { displayValue: this.customerData.teamName || '' });
    this.$refs.teamNameAutoComplete.search = _.get(associatedTeam, 'displayValue', '');
    this.$refs.teamNameAutoComplete.value = _.get(associatedTeam, 'value', null);
  }
}

function formatTeamText(team) {
  if (!team || !team.displayValue) return '';
  return team.displayValue;
}

function formatTeamValue(team) {
  if (!team || !team.value) return '';
  return team.value;
}

function updateTeamAssignment(teamSelection) {
  this.customerData.teamName = teamSelection || '';
}

function viewMore() {
  const options = assignmentsHelperService.viewMore(this.individualAssignments, this.tableOptions, 'Individuals');
  this.expandText = options.expansionText;
  this.tableOptions.itemsPerPage = options.itemsPerPage;
}

function addInbox() {
  this.individualAssignments.push({
    email: `${this.individualSelection.value}`,
    fullname: `${this.individualSelection.text}`.toUpperCase(),
    region: {},
    mode: '',
    username: `${this.individualSelection.username}`,
  });
  if (this.tableOptions.itemsPerPage !== 99) {
    const options = assignmentsHelperService.viewMore(this.individualAssignments, this.tableOptions, 'Individuals');
    this.expandText = options.expansionText;
    this.tableOptions.itemsPerPage = options.itemsPerPage;
  } else {
    this.expandText = assignmentsHelperService.updateExpansionText(this.individualAssignments, this.tableOptions, 'Individuals');
  }
  this.clearDropdownSelection();
  this.calculateErrors();
  this.forceUpdate++;
}

function removeInbox(removedInbox) {
  this.deletedIndividualAssignments.push(this.individualAssignments[removedInbox]);
  this.individualAssignments.splice(removedInbox, 1);
  this.expandText = assignmentsHelperService.updateExpansionText(this.individualAssignments, this.tableOptions, 'Individuals');
  this.calculateErrors();
  this.clearDropdownSelection();
  setGoogleAnalytics('Individual Assignment Deleted');
  this.forceUpdate++;
}

function updateRegion(selectedRegion, regionIndex) {
  const standardRegion = _.find(this.standardRegions, selectedRegion);
  const _regionType = _.get(this.individualAssignments, `${regionIndex}.region.type`, regionTypes[1].value);
  let region = {};
  if (_.isArray(selectedRegion)) {
    const countries = [];
    const states = [];
    selectedRegion.map((item) => {
      if (countryList.includes(item)) {
        countries.push(item);
      } else {
        states.push(item);
      }
      return null;
    });
    region = { name: 'custom', states, countries };
  } else if (standardRegion) {
    region = { name: standardRegion.region, states: standardRegion.states ? standardRegion.states : [], countries: standardRegion.countries ? standardRegion.countries : [] };
  } else {
    region = {};
  }
  this.individualAssignments[regionIndex].region = _.isEmpty(region) ? {} : { ...region, type: _regionType };
  this.calculateErrors();
}

function updateRegionType(selectedValue, index) {
  this.individualAssignments[index].region.type = selectedValue;
}

async function initRegions() {
  let resp = [];
  if (_.isEmpty(this.standardRegions)) {
    resp = await commonService.getCommonLov('USA_REGIONS');
  }
  this.standardRegions = resp.map((region) => (
    { region: region.displayValue, states: region.value, value: region.displayValue }
  ));
  this.standardRegions = this.standardRegions.concat([
    { region: 'CANADA', countries: ['CAN'], value: 'CANADA' },
    { region: 'MEXICO', countries: ['MEX'], value: 'MEXICO' },
  ]);
}

async function initIndividuals() {
  const individualSearchData = await prefService.listUsers() || [];
  if (!_.isEmpty(individualSearchData)) {
    this.individuals = individualSearchData;
  }
}

async function individualAutocompleteSearchTextChanged($event) {
  const searchText = $event;
  if (searchText && searchText.length >= AppSetupEnum.MINIMUM_SEARCH_CHARACTER) {
    const reqPayload = {
      query: {
        quickSearch: searchText,
      },
      limit: 15,
      page: 1,
    };
    const individualSearchData = await prefService.listUsers(reqPayload) || [];
    if (!_.isEmpty(individualSearchData)) {
      this.individuals = individualSearchData;
    }
  }
}

function updateSelectedValue(event) {
  if (event === null) {
    this.clearDropdownSelection();
  }
  const selectedIndividual = this.individuals.filter((item) => item.value === event);
  if (!_.isEmpty(selectedIndividual)) [this.individualSelection] = selectedIndividual;
}

function clearDropdownSelection() {
  if (_.get(this, '$refs.individualAutoComplete', null)) {
    this.$refs.individualAutoComplete.value = '';
  }
  // clear current selection
  this.individualSelection = {};
}

function formatIndividualText(item) {
  if (!item || !item.text) return '';
  return item.text.toUpperCase();
}

function formatIndividualValue(item) {
  if (!item || !item.value) return '';
  return item.value;
}

function calculateErrors() {
  this.validIndividuals = true;
  this.individualAssignments.forEach((individual, index) => {
    this.emailError(index, individual.email);
    if (!_.isEmpty(individual.emailError)) {
      this.validIndividuals = false;
    }
    if (!individual.mode) individual.mode = '';
  });
  this.$emit('validIndividuals', this.validIndividuals);
  if (this.validIndividuals) {
    this.$emit('customerIndividualAssignments', this.individualAssignments);
  }
  if (this.deletedIndividualAssignments.length > 0) {
    this.$emit('deleteCustomerIndividualAssignments', this.deletedIndividualAssignments);
  }
}

function emailError(index, email) {
  if (_.filter(this.individualAssignments, { email }).length > 1) {
    this.individualAssignments[index].emailError = 'This email is already associated with a mode or region';
    return;
  }
  this.individualAssignments[index].emailError = '';
}

function getColor(name) {
  return _colors[name];
}

function displayStandardRegion(region) {
  let displayText = `${_.startCase(_.toLower(region.region || region.name))}`;
  const statesString = !_.isEmpty(region.states) ? `${region.states.join(', ')}` : '';
  const countriesString = !_.isEmpty(region.countries) ? `${region.countries.join(', ')}` : '';
  if (statesString || countriesString) {
    displayText = `${displayText} - (${statesString}${(statesString && countriesString) ? ', ' : ''}${countriesString})`;
  }
  return displayText;
}

/**
 * @function - handler function for data changes after user clicked on Save Changes button
 * @param {*} details - detailed object of what changed
 */
function handleDifferencesInData(details) {
  const originalTeamName = details.originalCustomerTeamName || null;
  const newTeamName = details.newCustomerTeamName || null;

  if ((originalTeamName || newTeamName) && originalTeamName !== newTeamName) {
    setGoogleAnalytics('Team name changed');
  }
  const changes = {
    individualAssignmentWithoutModeRegion: false,
    individualAssignmentWithMode: false,
    individualAssignmentWithRegion: false,
    individualRegionChanged: false,
    individualModeChanged: false
  };
  // Original Object map to JSON.
  const originalAssignment = {};
  details.oldIndividualAssignment.forEach((e) => {
    originalAssignment[e.email] = { ...e };
  });
  _.map(details.newIndividualAssignment, (newAssignment) => {
    if (!originalAssignment[newAssignment.email]) {
      if (!_.isEmpty(newAssignment.region)) {
        changes.individualAssignmentWithRegion = true;
      } else if (!_.isEmpty(newAssignment.mode)) {
        changes.individualAssignmentWithMode = true;
      } else {
        changes.individualAssignmentWithoutModeRegion = true;
      }
      return null;
    }
    if (originalAssignment[newAssignment.email].email === newAssignment.email && originalAssignment[newAssignment.email].mode !== newAssignment.mode) {
      changes.individualModeChanged = true;
    }
    if (originalAssignment[newAssignment.email].email === newAssignment.email && !_.isEqual(originalAssignment[newAssignment.email].region, newAssignment.region)) {
      changes.individualRegionChanged = true;
    }
    return null;
  });
  if (changes.individualModeChanged) {
    setGoogleAnalytics('Individual Assignment Mode changed');
  }
  if (changes.individualRegionChanged) {
    setGoogleAnalytics('Individual Assignment Region changed');
  }
  if (changes.individualAssignmentWithoutModeRegion) {
    setGoogleAnalytics('Individual Assignments changes (without mode or Region)');
  }
  if (changes.individualAssignmentWithMode) {
    setGoogleAnalytics('Individual Assignment change with mode');
  }
  if (changes.individualAssignmentWithRegion) {
    setGoogleAnalytics('Individual Assignment change with Region');
  }
}
export default {
  name: 'IndividualAssignments',
  components: {
    regionDropdown,
    hgAutocomplete,
    regionType,
  },
  data: () => ({
    header: [
      { text: 'INDIVIDUAL ASSIGNMENTS', value: 'email', width: '30%' },
      { text: 'REGION', value: 'region', width: '15%' },
      { text: 'REGION TYPE', value: 'region.type', width: '30%' },
      { text: 'MODE', value: 'mode', width: '15%' },
    ],
    originalIndividualAssignments: [],
    deletedIndividualAssignments: [],
    originalCustomerName: '',
    tableOptions: {
      itemsPerPage: 3,
      multiSort: false,
      mustSort: false,
    },
    individuals: [],
    teamNames: [],
    modes: ModesEnum.map((mode) => mode.text),
    CdnImagesEnum,
    expandText: '',
    individualSelection: {},
    forceUpdate: 0,
    skeletonLoader: {
      'team-assignment-table': 'team-assignment-thead, divider, team-assignment-tbody',
      'team-assignment-tbody': 'team-assignment-table-row-divider@3',
      'team-assignment-table-row-divider': 'team-assignment-table-row, divider',
      'team-assignment-table-row': 'table-cell@3',
      'team-assignment-thead': 'heading@3',
    },
    validIndividuals: false,
    standardRegions: [],
  }),
  props: {
    loading: {
      type: Boolean,
      default: true,
    },
    customerData: {
      type: Object,
      default: {},
    },
    teamAssignmentsName: {
      type: String,
      default: '',
    },
    individualAssignments: {
      type: Array,
      default: () => [],
    },
    mode: {
      type: String,
      default: 'VIEW',
    },
  },
  watch: {
    mode(newMode) {
      if (newMode === 'EDIT') {
        this.$nextTick(function init() {
          this.initTeamNames();
        });
        this.header.push({ text: '', value: 'delete', sortable: false });
        this.originalIndividualAssignments = _.cloneDeep(this.individualAssignments);
        this.originalCustomerName = _.cloneDeep(this.customerData.teamName);
      } else if (newMode === 'VIEW') {
        this.individualAssignments = _.cloneDeep(this.originalIndividualAssignments);
        this.customerData.teamName = _.cloneDeep(this.originalCustomerName);
        this.header.pop();
      } else if (newMode === 'SAVED') {
        this.deletedIndividualAssignments = [];
        handleDifferencesInData({
          oldIndividualAssignment: this.originalIndividualAssignments,
          newIndividualAssignment: this.individualAssignments,
          originalCustomerTeamName: this.originalCustomerName,
          newCustomerTeamName: this.customerData.teamName
        });
        this.header.pop();
      } else {
        this.header.pop();
      }
      this.expandText = assignmentsHelperService.updateExpansionText(this.individualAssignments, this.tableOptions, 'Individuals');
    },
    individualAssignments: {
      handler: function update() {
        this.$nextTick(function updateAssignmentsText() {
          this.expandText = assignmentsHelperService.updateExpansionText(this.individualAssignments, this.tableOptions, 'Individuals');
        });
      },
    },
    customerData: {
      handler: function init() {
        this.$nextTick(function initCustomerData() {
          this.initTeamNames();
        });
      },
      deep: true,
    },
  },
  mounted() {
    this.$nextTick(function init() {
      const options = assignmentsHelperService.initExpansionText(this.individualAssignments, this.tableOptions, 'Individuals');
      this.expandText = options.expansionText;
      this.tableOptions.itemsPerPage = options.itemsPerPage;
      this.initTeamNames();
      this.initRegions();
      this.initIndividuals();
      this.originalIndividualAssignments = _.cloneDeep(this.individualAssignments);
      this.originalCustomerName = _.cloneDeep(this.customerData.teamName);
      this.calculateErrors();
    });
  },
  methods: {
    viewMore,
    addInbox,
    removeInbox,
    initTeamNames,
    initIndividuals,
    individualAutocompleteSearchTextChanged,
    formatIndividualValue,
    clearDropdownSelection,
    updateSelectedValue,
    formatTeamText,
    formatTeamValue,
    updateTeamAssignment,
    getCdnImageUrl,
    updateRegion,
    updateRegionType,
    formatIndividualText,
    calculateErrors,
    emailError,
    getColor,
    initRegions,
    displayStandardRegion,
  },
};
