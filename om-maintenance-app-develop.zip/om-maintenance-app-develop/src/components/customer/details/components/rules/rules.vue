<template>
  <v-container>
    <v-row class="mb-2">
      <div class="integration-settings-container">
        <v-row class="pl-3">
          <h2 class="form-sub-header-alt">Integration Settings</h2>
        </v-row>
        <v-row class="pl-3 pr-3" v-if="mode === 'EDIT'">
          <div class="edi-container section-border">
            <v-row class="pb-2">
              <h1 class="form-header mt-4 ml-4">Electronic Data Interchange (EDI)</h1>
            </v-row>
            <v-form v-model="valid.valid" ref="customerEdiRulesForm">
              <div class="pl-4 pr-4">
                <v-row>
                  <v-col cols="12" class="mt-3 mb-4">
                      <v-col class="edi-rules-form-fields-container">
                        <v-row>
                          <v-col cols="5" class="pr-0">
                            <h1 class="form-header">EDI Tender time-based acceptance</h1>
                          </v-col>
                          <v-col cols="1" class="pt-0 pb-2 pr-0 pl-0 mt-n2">
                            <v-switch
                              hide-details
                              color="primary"
                              :input-value="ediRules.isTimeBasedAcceptance"
                              @change="toggleTimeBasedAcceptance()"
                            >
                            </v-switch>
                          </v-col>
                          <v-col cols="3" />
                          <v-col cols="3" class="pt-2 pl-8">
                            <v-btn
                              @click="addTimeBasedAction"
                              :disabled="isAddMoreDisabled()"
                              class="add-btn"
                              text
                            >
                              Add More +
                            </v-btn>
                          </v-col>
                        </v-row>
                        <v-divider class="primary_border mt-2 mb-6"> </v-divider>
                        <v-row>
                          <v-col cols="3" class="pl-3 pt-5 pb-0">
                            <h2 class="mb-1 form-sub-header">
                              Business Hours
                            </h2>
                          </v-col>
                          <v-col cols="3" class="pl-2 pt-5 pb-0">
                            <h2 class="mb-1 form-sub-header">
                              After Hours
                            </h2>
                          </v-col>
                          <v-col cols="2" class="pl-1 pt-5 pb-0">
                            <h2 class="mb-1 form-sub-header">
                              Mode<span class="mandatory">*</span>
                            </h2>
                          </v-col>
                          <v-col cols="3" class="pl-2 pt-0 pb-3">
                            <h2 class="mb-1 form-sub-header">
                              When the EDI tender expires, the order should<span class="mandatory"
                                >*</span
                              >
                            </h2>
                          </v-col>
                        </v-row>
                        <v-row>
                          <v-row
                            v-for="(timeBasedAction, index) in ediRules.timeBasedActions"
                            :key="`time_based_action_${index}`"
                            class="pl-0 pb-0 pt-0 pr-0 mb-2"
                          >
                            <v-col cols="3" class="pt-0 pr-0 pl-6 pb-0">
                              <v-select
                                dense
                                :items="customerEdiRulesEnum.timeSlots"
                                outlined
                                item-text="label"
                                item-value="value"
                                append-icon="mdi-chevron-down"
                                v-model="timeBasedAction.timeSlot"
                                :rules="ediRules.isTimeBasedAcceptance ? [busOrAfterHrsReqValidation(index)] : []"
                                :disabled="!ediRules.isTimeBasedAcceptance"
                                clearable
                              >
                              </v-select>
                            </v-col>
                            <v-col cols="3" class="pt-0 pr-1  pb-0">
                              <v-select
                                dense
                                :items="customerEdiRulesEnum.timeSlots"
                                outlined
                                item-text="label"
                                item-value="value"
                                append-icon="mdi-chevron-down"
                                v-model="timeBasedAction.afterHours"
                                :rules="ediRules.isTimeBasedAcceptance ? [busOrAfterHrsReqValidation(index)] : []"
                                :disabled="!ediRules.isTimeBasedAcceptance"
                                clearable
                              >
                              </v-select>
                            </v-col>
                            <v-col cols="2" class="pt-0 pr-1 pl-1 pb-2">
                              <v-select
                                dense
                                :items="getModesList(index)"
                                outlined
                                item-text="label"
                                item-value="value"
                                append-icon="mdi-chevron-down"
                                v-model="timeBasedAction.mode"
                                :rules="ediRules.isTimeBasedAcceptance ? [modeRules(timeBasedAction.mode, index)] : []"
                                :disabled="!ediRules.isTimeBasedAcceptance"
                                clearable
                              />
                            </v-col>
                            <v-col cols="3" class="pt-0 pr-1 pl-1 pb-2">
                              <v-select
                                dense
                                :items="customerEdiRulesEnum.tenderStatus"
                                outlined
                                item-text="label"
                                item-value="value"
                                class="mode-select"
                                append-icon="mdi-chevron-down"
                                v-model="timeBasedAction.tenderStatus"
                                :rules="ediRules.isTimeBasedAcceptance ? [rules.tenderStatus] : []"
                                :disabled="!ediRules.isTimeBasedAcceptance"
                                clearable
                              >
                              </v-select>
                            </v-col>
                            <v-col cols="1" class="pt-2 pr-1 pl-2 pb-2">
                              <button
                                v-if="index > 0"
                                @click.prevent="deleteTimeBasedAction(index)"
                              >
                                <img
                                  :id="`time-based-action-delete-${index}`"
                                  class="trash-icon-delete"
                                  :src="getIcon(cdnImagesEnum.delete_icon)"
                                />
                              </button>
                            </v-col>
                          </v-row>
                        </v-row>
                      </v-col>
                      <v-col cols="12" class="pb-0 pt-4 pl-0 pr-0">
                        <v-col cols="12" class="edi-rules-form-fields-container">
                          <v-row class="mt-0">
                            <v-col cols="12" class="pb-0 pt-0">
                              <h1 class="form-header">EDI Changes</h1>
                            </v-col>
                          </v-row>
                          <v-row>
                            <v-col cols="4" class="pb-0 pt-1">
                              <h2 class="mb-1 form-sub-header">Auto Accept</h2>
                              <v-col cols="12" class="pl-0 pt-0">
                                <multi-selector-dropdown
                                  ref="autoAcceptDropdown"
                                  :optionsListEnum="customerEdiRulesEnum.autoAccept"
                                  @selectedItems="handleSelectedItems('autoAccept', $event)"
                                  :selectedOptions="
                                    Array.isArray(ediRules.autoAccept) ? ediRules.autoAccept : []
                                  "
                                />
                              </v-col>
                            </v-col>
                            <v-col cols="4" class="pt-1">
                              <h2 class="mb-1 form-sub-header">Auto Reject</h2>
                              <v-col cols="12" class="pl-0 pt-0">
                                <multi-selector-dropdown
                                  ref="autoRejectDropdown"
                                  :optionsListEnum="customerEdiRulesEnum.autoReject"
                                  @selectedItems="handleSelectedItems('autoReject', $event)"
                                  :selectedOptions="
                                    Array.isArray(ediRules.autoReject) ? ediRules.autoReject : []
                                  "
                                />
                              </v-col>
                            </v-col>
                          </v-row>
                        </v-col>
                      </v-col>

                  </v-col>
                </v-row>
              </div>
            </v-form>
          </div>
        </v-row>
        <v-row class="pl-3 pr-3" v-else>
          <div class="edi-container section-border">
            <v-row class="pb-2">
              <h1 class="form-header mt-4 ml-4">Electronic Data Interchange (EDI)</h1>
            </v-row>
            <v-row class="edi-rule-details-container">
              <v-row>
                <v-col cols="12" class="pl-5 pt-0">
                  <v-col class="edi-rules-form-fields-container">
                    <v-row class="pt-3 pl-3">
                      <v-col cols="12">
                        <v-row class="rule-details-label">
                          EDI Tender time-base acceptance :
                          <span class="rule-details-label-bold ml-1">
                            {{ getTimeBasedAcceptance()}}
                          </span>
                        </v-row>
                      </v-col>
                    </v-row>
                    <v-row class="pt-3 pl-3">
                      <v-col cols="2">
                        <v-row class="rule-details-label">Business Hours</v-row>
                      </v-col>
                      <v-col cols="2">
                        <v-row class="rule-details-label">After Hours</v-row>
                      </v-col>
                      <v-col cols="2" class="pl-1">
                        <v-row class="rule-details-label">Mode</v-row>
                      </v-col>
                      <v-col cols="6" class="pl-1 mb-2">
                        <v-row class="rule-details-label">
                          When the EDI tender expires, the order should
                        </v-row>
                      </v-col>
                    </v-row>
                    <v-row
                      v-for="(timeBasedAction, index) in ediRules.timeBasedActions"
                      :key="`time_based_action_read_${index}`"
                    >
                      <v-col cols="2" class="mb-3 pl-6">
                        <v-row class="rule-details-label-bold">
                          {{ getTimeBasedLabel(index, 'timeSlot', 'timeSlots') }}
                        </v-row>
                      </v-col>
                      <v-col cols="2" class="mb-3 pl-6">
                        <v-row class="rule-details-label-bold">
                          {{ getTimeBasedLabel(index, 'afterHours', 'timeSlots') }}
                        </v-row>
                      </v-col>
                      <v-col cols="2" class="mb-3">
                        <v-row class="rule-details-label-bold">
                          {{ getModeLabel(index, 'mode') }}
                        </v-row>
                      </v-col>
                      <v-col cols="6" class="mb-3">
                        <v-row class="rule-details-label-bold">
                          {{ getTimeBasedLabel(index, 'tenderStatus', 'tenderStatus') }}
                        </v-row>
                      </v-col>
                    </v-row>
                  </v-col>
                </v-col>
                <v-col cols="12" class="pt-0 pl-5">
                  <v-col cols="12" class="edi-rules-form-fields-container">
                    <v-row class="rule-details-label pt-3 pl-3"> EDI Changes </v-row>
                    <v-row class="rule-details-label-bold">
                      <v-col cols="2"> Auto Accept: </v-col>
                      <v-col cols="2" class="ml-n5">
                        {{ getEdiChanges('autoAccept') }}
                      </v-col>
                      <v-col cols="2"> </v-col>
                      <v-col cols="2"> Auto Reject: </v-col>
                      <v-col cols="2" class="ml-n5">
                        {{ getEdiChanges('autoReject') }}
                      </v-col>
                    </v-row>
                  </v-col>
                </v-col>
              </v-row>
            </v-row>
          </div>
        </v-row>
      </div>
    </v-row>
    <v-row class="mb-2 rule-selection" v-if="mode === 'EDIT'">
      <v-col cols="3">
        <h1 class="form-sub-header-alt">Billing Rules</h1>
      </v-col>
    </v-row>
  </v-container>
</template>

<script src="./rules.js" />
<style src="./rules.sass" lang="sass" scoped />
