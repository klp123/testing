import _ from 'lodash';
import Vue from 'vue';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import { GoogleAnalyticsService, ImageLoaderService } from '@hubgroup/hg-om-shared-services';
import cdnImagesEnum from '@hubgroup/hg-vue-oc-util-lib/src/enums/cdn-images.enum';
import customerEdiRulesEnum from '../../../../../enums/customer-edi-rules.enum';
import acceptanceRuleModesEnum from '../../../../../enums/acceptance-rule-modes.enum';
import MultiSelectorDropdown from '../multi-selector-dropdown/multi-selector-dropdown.vue';

function getColor(name) {
  return _colors[name];
}

function getIcon(iconName) {
  return ImageLoaderService.getCdnImageUrl(iconName);
}

/**
 * @function - used for setting google analytics
 * @param {*} details - event message that needs to be send for ga
 */
function setGoogleAnalytics(details) {
  // #TODO check where it can be used
  GoogleAnalyticsService.event(Vue, 'Metric', 'Maintenance', details);
}

function toggleTimeBasedAcceptance() {
  this.ediRules.isTimeBasedAcceptance = !this.ediRules.isTimeBasedAcceptance;
}

function getItemLabel(sourceObject, index, objectKey) {
  const val = sourceObject ? sourceObject.find((item) => item.value === _.get(this.ediRules, `timeBasedActions.${index}.${objectKey}`)) : {};
  return _.get(val, 'label', '');
}

function getTimeBasedLabel(index, objectKey, enumKey) {
  return this.getItemLabel(this.customerEdiRulesEnum[enumKey], index, objectKey);
}

function getModeLabel(index, objectKey) {
  return this.getItemLabel(this.acceptanceRuleModesEnum, index, objectKey);
}

function getEdiChanges(filter) {
  const autoSelected = _.get(this.ediRules, filter, []);
  const processedSelected = [];
  if (!autoSelected && autoSelected.length <= 0) return '';
  _.forEach(autoSelected, (selectedItem) => {
    const actions = customerEdiRulesEnum[filter];
    const requiredAction = _.filter(actions, (action) => action.value === selectedItem);
    const label = _.get(requiredAction, '[0].label');
    processedSelected.push(label);
  });
  return (processedSelected.length > 0) ? processedSelected.join(', ') : '';
}

function getTimeBasedAcceptance() {
  return (this.ediRules.isTimeBasedAcceptance) ? 'Yes' : 'No';
}

function addTimeBasedAction() {
  this.ediRules.timeBasedActions.push({
    mode: '',
    tenderStatus: '',
    timeSlot: '',
    afterHours: ''
  });
}

function handleSelectedItems(action, event) {
  _.set(this.ediRules, action, event);
}

function validate() {
  return this.$refs.customerEdiRulesForm.validate();
}

function isValid() {
  this.$refs.customerEdiRulesForm.validate();
  return this.valid.valid;
}

function getModesList(index) {
  if (index > 0) {
    const [, ...result] = acceptanceRuleModesEnum;
    return result;
  }
  return acceptanceRuleModesEnum;
}

function isAddMoreDisabled() {
  const { isTimeBasedAcceptance, timeBasedActions = [] } = this.ediRules;
  return !isTimeBasedAcceptance
    || timeBasedActions.length >= 3
    || timeBasedActions.some((item) => item && item.mode === acceptanceRuleModesEnum[0].value);
}

function deleteTimeBasedAction(index) {
  if (index > -1) {
    this.ediRules.timeBasedActions.splice(index, 1);
  }
}

function isDuplicateMode(value, itemIndex) {
  const timeBasedActions = _.get(this.ediRules, 'timeBasedActions', []);
  return timeBasedActions.some((item, index) => item && item.mode === value && index !== itemIndex);
}

function isAllModeSelected(index) {
  if (index === 0) return false;
  const timeBasedActions = _.get(this.ediRules, 'timeBasedActions', []);
  const allModeSelected = _.get(timeBasedActions, '0.mode', '') === acceptanceRuleModesEnum[0].value;
  return allModeSelected && timeBasedActions.length > 1;
}

function modeRules(value, index) {
  return (!value && 'Mode is Required')
  || (this.isDuplicateMode(value, index) && `Rule for mode ${value} already exists`)
  || (this.isAllModeSelected(index) && 'Rule for *ALL modes already exists')
  || true;
}

function busOrAfterHrsReqValidation(index) {
  const timeBasedActions = _.get(this.ediRules, 'timeBasedActions', []);
  const { timeSlot, afterHours } = timeBasedActions[index];
  return ((timeSlot === null) && (afterHours === null) && 'Either Business Hours or After Hours is mandatory')
  || true;
}

export default {
  name: 'Rules',
  components: {
    MultiSelectorDropdown
  },
  data: () => ({
    cdnImagesEnum,
    customerEdiRulesEnum,
    acceptanceRuleModesEnum,
    isTimeBasedAcceptance: false,
    rules: {
      tenderStatus: (value) => !!value || 'Tender Status is Required',
    }
  }),
  props: {
    mode: {
      type: String,
      default: 'VIEW',
    },
    ediRules: {
      type: Object,
      default: () => ({}),
    },
    valid: {
      type: Object,
      default: false,
      required: false,
    }
  },
  methods: {
    toggleTimeBasedAcceptance,
    setGoogleAnalytics,
    getTimeBasedLabel,
    getModeLabel,
    getEdiChanges,
    getItemLabel,
    getTimeBasedAcceptance,
    handleSelectedItems,
    validate,
    isValid,
    getIcon,
    getColor,
    addTimeBasedAction,
    isAddMoreDisabled,
    deleteTimeBasedAction,
    isDuplicateMode,
    isAllModeSelected,
    modeRules,
    getModesList,
    busOrAfterHrsReqValidation
  },
};
