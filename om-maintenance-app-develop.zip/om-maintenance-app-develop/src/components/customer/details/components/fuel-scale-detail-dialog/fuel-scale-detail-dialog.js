import _ from 'lodash';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import FuelScaleInfo from '../fuel-scale-info/fuel-scale-info.vue';

function getColor(name) {
  return _colors[name];
}

function closeDialog() {
  this.showDialog = false;
  this.$emit('closeDialog');
}

export default {
  name: 'FuelScaleDetail',
  components: {
    FuelScaleInfo
  },
  data: () => ({
    showDialog: true,
    options: {
      width: 800,
      zIndex: 200
    },
    fuelHeader: [
      { text: 'Minimum', value: 'minDoeRate', width: '25%' },
      { text: 'Maximum', value: 'maxDoeRate', width: '25%' },
      { text: 'Rate Qualifier', value: 'rateQualifier', width: '25%' },
      { text: 'Rate Value', value: 'rateValue', width: '25%' },
    ],
    displayedCustomer: ''
  }),
  props: {
    fuelScaleData: {
      type: Object,
      default: () => ({}),
      required: true
    }
  },
  created() {
    const customerId = _.get(this.fuelScaleData, 'customer.id', null);
    const customerName = _.get(this.fuelScaleData, 'customer.name', null);
    if (customerId && customerName) {
      this.displayedCustomer = `${customerName} ${customerId}`;
    }
  },
  methods: {
    getColor,
    closeDialog,
  },
  filters: {
    titleCase(value) {
      return (!value || !value.trim()) ? '-' : _.startCase(_.toLower(value));
    },
  },
};
