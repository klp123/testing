<template>
  <div class="modal-wrapper">
    <v-layout justify-center>
      <v-dialog
        v-model="showDialog"
        :max-width="options.width"
        :style="{ zIndex: options.zIndex }"
        @keydown.esc="cancel"
        @click:outside="closeDialog"
      >
        <v-card>
          <v-card-title class="modal-header"
            >Fuel scales details for {{ displayedCustomer | titleCase }}
            <v-spacer></v-spacer>
            <v-icon @click="closeDialog()">mdi-close</v-icon>
          </v-card-title>
          <v-divider class="my-1 primary_border"></v-divider>
          <v-card-text>
            <v-container fluid fill-height grid-list-md>
              <v-row>
                <FuelScaleInfo :fuelScaleData="fuelScaleData" />
              </v-row>
              <v-row>
                <v-data-table
                  :headers="fuelHeader"
                  :items="fuelScaleData.fuelScales"
                  hide-default-footer
                  class="hg-table"
                  disable-pagination
                  fixed-header
                ></v-data-table
              ></v-row>
            </v-container>
          </v-card-text>
        </v-card>
      </v-dialog>
    </v-layout>
  </div>
</template>

<script src="./fuel-scale-detail-dialog.js" />
<style src="./fuel-scale-detail-dialog.sass" lang="sass" scoped />
