<template>
  <v-card>
    <v-card-title class="form-header">
      <v-row justify="space-between">
        <v-col class="pl-6">
          <v-skeleton-loader v-if="loading" class="py-1" type="text" width="75" />
          <div v-else>{{ customerData.name | titleCase }}, {{ customerData.id }}</div>
        </v-col>
        <v-col class="text-right">
          <hg-table-metadata
            :showAlertRiskLevelCounts="false"
            :totalResults="fuelScale.length || 0"
            :refreshTime="lastRefreshedDate"
            page="Customer - Maintainance"
            @onRefreshClick="loadFuelScale(customerFuelScalePayload)"
            :loading="loading"
            id="cm-meta-data"
          />
          <v-btn
            text
            medium
            color="secondary"
            class="font-weight-bold text-capitalize"
            @click.native="fuelUploadDialog = true"
            v-oc-entitlements="[
              [accessorialsEntitlements.ACCS_CREATE, accessorialsEntitlements.ACCS_EDIT],
              token
            ]"
          >
            Upload
          </v-btn>
          <UploadDialog
            v-if="fuelUploadDialog"
            :customerId="customerId"
            :customerData="customerData"
            @closeDialog="closeFuelUploadDialog"
          />
        </v-col>
      </v-row>
    </v-card-title>
    <v-divider class="my-1 primary_border"></v-divider>
    <div class="wrapper" id="fuel-scale-grid">
      <div class="fuel-scale-table-container">
        <v-data-table
          :headers="headers"
          :items="fuelScale"
          item-key="_id"
          hide-default-footer
          class="elevation-0 hg-table"
          :loading="loading"
          id="fuel-scale-grid"
          disable-pagination
          fixed-header
        >
          <template v-slot:item="{ item }">
            <tr
              @click="activeRow(item)"
              :key="item._id"
              :class="{
                'active-row': item._id === activeFuelScaleId
              }"
            >
              <td>
                <v-skeleton-loader v-if="loading" class="py-1" type="text" width="75" />
                <label
                  v-if="!loading"
                  class="fuel-scale-date bold-font"
                  :id="`fuel-scale-date-${item.publishDateTime.dateTime}`"
                  >{{ item.publishDateTime.dateTime | formatDate }}</label
                >
              </td>
              <td>
                <v-skeleton-loader v-if="loading" class="py-1" type="text" width="75" />
                <label
                  v-if="!loading"
                  class="fuel-scale-mode medium-font"
                  :id="`fuel-scale-mode-${item.transportMode}`"
                  >{{ item.transportMode }}</label
                >
              </td>
              <td>
                <v-skeleton-loader v-if="loading" class="py-1" type="text" width="75" />
                <label
                  v-if="!loading"
                  class="fuel-scale-equip-type regular-font"
                  :id="`fuel-scale-id-${item.equipment.equipmentType}`"
                  >{{ item.equipment.equipmentType }} {{ item.equipment.length.amount }}</label
                >
              </td>
              <td>
                <v-skeleton-loader v-if="loading" class="py-1" type="text" width="75" />
                <label
                  v-if="!loading"
                  class="fuel-scale-country regular-font"
                  :id="`fuel-scale-country-${item.country}`"
                  >{{ item.country }}</label
                >
              </td>
              <td>
                <v-skeleton-loader v-if="loading" class="py-1" type="text" width="75" />
                <label
                  v-if="!loading"
                  :class="{
                    activeStatus: item.status === 'ACTIVE',
                    inactiveStatus: item.status === 'INACTIVE',
                    expiredStatus: item.status === 'EXPIRED',
                    futureStatus: isFuture(item.publishDateTime.dateTime)
                  }"
                  :id="`fuel-scale-status-${item.status}`"
                  >{{
                    item.status == 'INACTIVE' && isFuture(item.publishDateTime.dateTime)
                      ? 'FUTURE'
                      : item.status
                  }}</label
                >
                <!-- class="fuel-scale-status bold-font" -->
              </td>
              <td>
                <v-skeleton-loader v-if="loading" class="py-1" type="text" width="75" />
                <v-menu offset-y v-if="!loading">
                  <template v-slot:activator="{ on }">
                    <v-btn icon v-on="on">
                      <v-icon>mdi-dots-horizontal</v-icon>
                    </v-btn>
                  </template>
                  <v-list>
                    <v-list-item @click="exportData(item, 'CSV')">
                      <v-list-item-title>Export to CSV</v-list-item-title>
                    </v-list-item>
                    <v-list-item @click="exportData(item, 'Excel')">
                      <v-list-item-title>Export to Excel</v-list-item-title>
                    </v-list-item>
                  </v-list>
                </v-menu>
              </td>
            </tr>
          </template>
        </v-data-table>
        <FuelScaleDialog
          v-if="fuelScaleDialog && customerData"
          :fuelScaleData="selectedRowData"
          @closeDialog="closeFuelScaleDialog"
        />
      </div>
    </div>
  </v-card>
</template>

<script src="./customer-fuel-scale-tab.js"></script>
<style src="./customer-fuel-scale-tab.sass" lang="sass" scoped></style>
