import _ from 'lodash';
import Vue from 'vue';
import { GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import moment from 'moment';
import accessorialsEntitlements from '@hubgroup/hg-om-shared-services/src/enums/entitlements.enum';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import customerFuelScaleEnum from '../../../../../enums/customer-fuel-scale-headers.enum';
import fuelScaleService from '../../services/fuel-scale.service';
import UploadDialog from '../../../../accessorial-fuel-schedules/upload-dialog/upload-dialog.vue';
import FuelScaleDialog from '../fuel-scale-detail-dialog/fuel-scale-detail-dialog.vue';
import fileDownloadService from '../../../../../services/customer/file-download.service';
import HgTableMetadata from '../../../../shared/hg-table-metadata/hg-table-metadata.vue';

async function loadFuelScale(customer) {
  try {
    this.loading = true;
    GoogleAnalyticsService.event(Vue, 'Get fuel scale', 'Customer-Fuel-Scale-Detail', 'Fetch fuel Scale history of customer', { accessorials_fuel_customer: _.get(this.customerData, 'name', '') });
    const resp = await fuelScaleService.customerFuelScale(customer);
    this.fuelScale = resp.data || [];
    this.lastRefreshedDate = new Date();
    this.loading = false;
  } catch (err) {
    if (err.message && err.message !== RequestErrorTypesEnum.CANCEL_REQUEST) {
      HgNotificationService.errorMessage('Error while filtering customers.');
      this.loading = false;
    }
  }
}

function activeRow(item) {
  this.activeFuelScaleId = item._id;
  this.selectedRowData = item;
  this.openFuelScaleDialog();
  GoogleAnalyticsService.event(Vue, 'Selected fuel scale', 'Customer-Fuel-Scale-Detail', 'Fuel scale selected to view detail');
}

function closeFuelUploadDialog() {
  this.fuelUploadDialog = false;
  GoogleAnalyticsService.event(Vue, 'Close dialog', 'Customer-Fuel-Scale', 'Customer fuel scale upload dialog closed ');
}

function openFuelScaleDialog() {
  this.fuelScaleDialog = true;
  GoogleAnalyticsService.event(Vue, 'Open dialog', 'Customer-Fuel-Scale', 'Customer fuel scale detail dialog open');
}

function closeFuelScaleDialog() {
  this.fuelScaleDialog = false;
  this.activeFuelScaleId = '';
  GoogleAnalyticsService.event(Vue, 'Close dialog', 'Customer-Fuel-Scale', 'Customer fuel scale detail dialog closed');
}

async function exportData(item, format) {
  const dataField = [
    ['customerId', 'transportMode', 'minDoeRate', 'maxDoeRate', 'rateQualifier', 'rateValue']
  ];

  item.fuelScales.forEach((fuelScale) => {
    dataField.push([
      item.customer.id,
      item.transportMode,
      fuelScale.minDoeRate,
      fuelScale.maxDoeRate,
      fuelScale.rateQualifier,
      fuelScale.rateValue
    ]);
  });

  if (format === 'CSV') {
    fileDownloadService.downloadFileAsCSV(dataField, item.fileName);
    GoogleAnalyticsService.event(Vue, 'Export file', 'Customer-Fuel-Scale-Detail', 'Export CSV file for customer', { accessorials_fuel_customer: _.get(this.customerData, 'name', '') });
  } else if (format === 'Excel') {
    fileDownloadService.downloadFileAsExcel(dataField, item.fileName);
    GoogleAnalyticsService.event(Vue, 'Export file', 'Customer-Fuel-Scale-Detail', 'Export excel file for customer', { accessorials_fuel_customer: _.get(this.customerData, 'name', '') });
  }
}

export default {
  name: 'CustomerFuelScale',
  components: {
    UploadDialog,
    FuelScaleDialog,
    HgTableMetadata
  },
  data: () => ({
    loading: false,
    headers: customerFuelScaleEnum,
    fuelScale: [],
    activeFuelScaleId: '',
    tableKey: Math.random(),
    fuelUploadDialog: false,
    fuelScaleDialog: false,
    tableData: [],
    selectedRowData: {},
    accessorialsEntitlements,
    token: localStorage.getItem('jwt'),
    lastRefreshedDate: new Date(),
    customerFuelScalePayload: {
      customer: {
        id: ''
      }
    }
  }),
  methods: {
    loadFuelScale,
    activeRow,
    closeFuelUploadDialog,
    openFuelScaleDialog,
    closeFuelScaleDialog,
    exportData
  },
  computed: {
    // to check if "publishDateTime" is in the future
    isFuture() {
      return (dateTime) => {
        const centralTimeNow = moment().tz('America/Chicago');
        const publishDateTime = moment(dateTime);
        return publishDateTime.isAfter(centralTimeNow);
      };
    },
  },
  props: {
    customerId: {
      type: String,
      default: ''
    },
    customerData: {
      type: Object,
      default: () => ({})
    }
  },
  filters: {
    titleCase(value) {
      return (!value || !value.trim()) ? '-' : _.startCase(_.toLower(value));
    },
    formatDate(value) {
      return (!value || !value.trim()) ? '-' : moment(value).format('MM/DD/YY');
    }
  },
  watch: {
    customerId: {
      handler(newCustomerId) {
        this.customerFuelScalePayload.customer.id = newCustomerId;
        this.loadFuelScale(this.customerFuelScalePayload);
        GoogleAnalyticsService.event(Vue, 'Tab fuel scale', 'Customer-Fuel-Scale-Detail', 'Customer fuel scale tab visited');
      }
    }
  },
  mounted() {
    this.$nextTick(async () => {
      this.customerFuelScalePayload.customer.id = this.customerId;
      this.loadFuelScale(this.customerFuelScalePayload);
    });
  }
};
