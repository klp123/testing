<template>
  <v-menu
    offset-y
    @input="onClickOutsideDialog"
    :close-on-click="true"
    :close-on-content-click="false"
    :disabled="disabled"
  >
    <template v-slot:activator="{ on, attrs }">
      <div class="labelWrapper">
        <label
          color="primary"
          dark
          v-bind="attrs"
          v-on="on"
          :disabled="disabled"
          v-on:click="if (!disabled) shown = !shown;"
          app
          class="label-filter"
          v-bind:class="{
            'label-filter-active': shown,
            clickable: !disabled
          }"
        >
          <label v-bind:class="{ clickable: !disabled }" class="input-ellipse">{{
            disabled ? '' : displayData
          }}</label>
          <v-icon v-bind:class="{ 'label-active': shown }" medium v-if="!shown">
            mdi-chevron-down
          </v-icon>
          <v-icon v-bind:class="{ 'label-active': shown }" medium v-if="shown">
            mdi-chevron-up
          </v-icon>
        </label>
      </div>
    </template>
    <v-card
      v-bind:class="{ 'label-filter-inactive': !shown }"
      class="menu-dialog"
      ref="filterContent"
    >
      <v-container class="dropdown-menu">
        <v-list-item
          v-for="(item, index) in optionsListEnum"
          :key="`${item}${index}`"
        >
          <v-list-item-action>
            <v-checkbox
              v-model="selectedItems"
              @click="onListItemSelected(item)"
              :color="getColor('color_primary_blue')"
              :value="item.value"
              :input-value="isSelected(item)"
              :checked="isCheckedListItem(item.value)"
            ></v-checkbox>
          </v-list-item-action>
          <v-list-item-content>
            <v-list-item-title class="list-title">
              {{ item.label }}
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-container>
    </v-card>
  </v-menu>
</template>

<script src="./multi-selector-dropdown.js" />
<style src="./multi-selector-dropdown.sass" lang="sass" scoped />
