/* eslint-disable prefer-destructuring */
import _ from 'lodash';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';

function onClickOutsideDialog(isMenuOpen) {
  if (!isMenuOpen) {
    this.shown = false;
  }
}

function onListItemSelected() {
  this.updateDisplayData();
  this.selectedItem = {};
  this.$emit('selectedItems', this.selectedItems);
}

function isSelected(item) {
  if (this.selectedItems) {
    return this.selectedItems.findIndex((el) => el === item) > -1;
  }
  return -1;
}

function isCheckedListItem(value) {
  if (!this.selectedItems.includes(value)) return false;

  return true;
}

function updateDisplayData() {
  if (!_.isEmpty(this.selectedItems)) {
    if (this.selectedItems.length > 1) {
      this.displayData = `${this.showItemsList[this.selectedItems[0]]} + ${this.selectedItems.length - 1} more`;
    } else this.displayData = this.showItemsList[this.selectedItems[0]];
  } else this.displayData = '';
}

function getColor(name) {
  return _colors[name];
}

function initData() {
  this.selectedItems = this.selectedOptions;
  this.updateDisplayData();
}

export default {
  name: 'MultiSelectorDropdown',
  components: {
  },
  data: () => ({
    shown: false,
    selectedItem: {},
    selectedItems: [],
    displayData: '',
    showItemsList: {}
  }),
  props: {
    selectedOptions: {
      type: Array,
      default: () => [],
    },
    optionsListEnum: {
      type: Array,
      default: () => [],
    },
    disabled: {
      type: Boolean,
      default: false,
    }
  },
  mounted() {
    this.showItemsList = this.optionsListEnum.reduce((obj, curr) => {
      obj[curr.value] = curr.label;
      return obj;
    }, {});
    this.initData();
  },
  methods: {
    onClickOutsideDialog,
    onListItemSelected,
    isCheckedListItem,
    getColor,
    updateDisplayData,
    initData,
    isSelected
  },
};
