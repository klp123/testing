<template>
  <v-container>
    <v-row>
      <v-col cols="3">
        <h2 class="form-sub-header">NAME</h2>
        <v-skeleton-loader v-if="loading" class="py-1" type="text" width="125" />
        <span v-else class="form-label">{{ customerData.name }}</span>
      </v-col>
      <v-col cols="2">
        <h2 class="form-sub-header">SYSCON</h2>
        <v-skeleton-loader v-if="loading" class="py-1" type="text" width="75" />
        <span v-else class="form-label">{{ customerData._id || "-" }}</span>
      </v-col>
      <v-col cols="2">
        <h2 class="form-sub-header">ERP ID</h2>
        <v-skeleton-loader v-if="loading" class="py-1" type="text" width="75" />
        <span v-else class="form-label">{{
          customerData.erpCustomerID || "-"
        }}</span>
      </v-col>
      <v-col cols="2">
        <h2 class="form-sub-header">TEAM</h2>
        <v-skeleton-loader v-if="loading" class="py-1" type="text" width="75" />
        <span v-else class="form-label">{{
          teamName || "-"
        }}</span>
      </v-col>
      <v-col cols="2">
        <h2 class="form-sub-header">STATUS</h2>
        <v-skeleton-loader v-if="loading" class="py-1" type="text" width="75" />
        <span v-else class="form-label">{{
          customerStatus[customerData.status && customerData.status.toUpperCase()] || "-"
        }}</span>
      </v-col>
    </v-row>
  </v-container>
</template>

<script src='./customer-info.js' />
<style src='./customer-info.sass' lang='sass' scoped />
