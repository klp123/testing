import _ from 'lodash';

export default {
  name: 'CustomerInfo',
  components: {
  },
  data: () => ({
    customerStatus: {
      A: 'Active',
      P: 'Prospect',
      R: 'Prospect',
      D: 'Inactive',
      X: 'Inactive',
      I: 'Inactive',
    },
  }),
  props: {
    loading: {
      type: Boolean,
      default: true,
    },
    customerData: {
      type: Object,
      default: {},
    },
    teamName: {
      type: String,
      default: '',
    },
  },
  filters: {
    titleCase(value) {
      return _.startCase(_.toLower(value));
    },
  },
  mounted() {
  },
  methods: {
  },
};
