<template>
  <v-container>
    <v-tabs v-model="activeTab" background-color="transparent" color="secondary">
      <v-tab
        v-for="(tab, index) in tabs"
        :key="index"
        text
        medium
        class="font-weight-bold text-capitalize"
      >
        {{ tab.name }}
      </v-tab>
      <v-tab-item v-for="(tab, index) in tabs" :key="index">
        <component
          :is="tab.component"
          :customerId="customerId"
          :customerData="customerData"
          v-if="activeTab === index"
        ></component>
      </v-tab-item>
    </v-tabs>
  </v-container>
</template>

<script src="./customer-details.js"></script>
<style src="./customer-details.sass" lang="sass" scoped></style>
