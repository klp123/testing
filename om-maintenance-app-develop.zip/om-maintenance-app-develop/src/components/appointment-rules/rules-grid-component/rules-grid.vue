<template>
  <div>
    <HgConfirmActionModal ref="confirm" />
    <div class="headingContainer">
      <v-row>
        <div class="heading">
          <label>Rules</label>
        </div>
        <v-col cols="6" />
        <label class="resultsCount"
          >Total Results: <b>{{ counts.total }}</b></label
        >
      </v-row>
    </div>
    <div class="wrapper">
      <div class="rules-table-container table-content">
        <v-data-table
          :headers="headers"
          :items="appointmentRules"
          :server-items-length="totalRules"
          :loading="loading"
          item-key="ruleId"
          :hide-default-footer="true"
          class="hg-table row-pointer"
          fixed-header
          height="70vh"
        >
          <template v-slot:item="{ item, index }">
            <tr :key="item.ruleId" class="regular-font" v-on:click="viewRule(item)">
              <td>
                <label>{{ item.ruleId }}</label>
              </td>
              <td>
                <label>
                  {{ item.customer.id }}
                  <br>
                  <v-tooltip bottom>
                  <template v-slot:activator="{ on, attrs }">
                      <div class="customer-name" v-bind="attrs" v-on="on">
                        {{ item.customer && item.customer.name }}
                      </div>
                    </template>
                    <span class="tooltip">{{ item.customer && item.customer.name }}</span>
                  </v-tooltip>
                </label>
              </td>
              <td>
                <label>{{ item.ruleType }}</label>
              </td>
              <td>
                <label>{{ formatRuleTrigger(item) }}</label>
              </td>
              <td >
                  <label class = "content-4-lines">{{ formatMode(item.modes) }}</label>
              </td>
              <td >
                  <label class = "content-4-lines">{{ formatEquipmentTypes(item.equipmentTypes) }}</label>
              </td>
              <td>
                  <label
                    class="content-4-lines"
                    v-bind:class="{
                      'content-2-lines': formatLocationText(item, 'Exclude').length
                    }"
                  >
                    {{ formatLocationText(item, 'Include') }}
                  </label>
                  <label
                    class="content-4-lines"
                    v-bind:class="{
                      'content-2-lines': formatLocationText(item, 'Include').length
                    }"
                  >
                    {{ formatLocationText(item, 'Exclude') }}
                  </label>
              </td>
              <td>
                <label
                    class="content-4-lines"
                    v-bind:class="{
                      'content-2-lines': formatLocationText(item, 'Exclude', true).length
                    }"
                  >
                    {{ formatLocationText(item, 'Include', true) }}
                  </label>
                  <label
                    class="content-4-lines"
                    v-bind:class="{
                      'content-2-lines': formatLocationText(item, 'Include', true).length
                    }"
                  >
                    {{ formatLocationText(item, 'Exclude', true) }}
                  </label>
              </td>
              <td>
                <label>{{ formatAppointmentRule(item, 'FROM') }}</label>
              </td>
              <td>
                <label>{{
                  (item.fromAppointmentRule && item.fromAppointmentRule.hours) > 0
                    ? `+${item.fromAppointmentRule.hours}`
                    : item.fromAppointmentRule.hours
                }}</label>
              </td>
              <td>
                <label>{{ formatAppointmentRule(item, 'TO') }}</label>
              </td>
              <td>
                <label>{{
                  (item.toAppointmentRule && item.toAppointmentRule.hours) > 0
                    ? `+${item.toAppointmentRule.hours}`
                    : item.toAppointmentRule.hours
                }}</label>
              </td>
              <td>
                <label>{{ item.statCount ? item.statCount : 0 }}</label>
              </td>
              <td>
                <label
                  >Created By: <span class="audit">{{ formatAuditValue(item) }}</span></label
                >
                <br />
                <label
                  >Updated By: <span class="audit">{{ formatAuditValue(item, true) }}</span></label
                >
              </td>
              <td>
                <div class="active-switch actions-onOff">
                  <v-switch
                    :key="`${item.ruleId}_${forceRender}`"
                    hide-details
                    :disabled="!entitlements.canEdit"
                    class="mx-2"
                    color="secondary"
                    :input-value="isActiveRule(item.status)"
                    @click.stop=""
                    @change="updateRuleStatus(item, index)"
                  >
                  </v-switch>
                  <label v-if="isActiveRule(item.status)" class="actionItems">On</label>
                </div>
              </td>
              <td >
                <div class="actions" v-if="!isLoadingLovData">
                  <label class="actionItems" v-if="entitlements.canEdit" @click.stop="editRule(item)">Edit</label>
                  <label class="actionItems" v-if="entitlements.canCreate" @click.stop="copyRule(item)">Copy</label>
                </div>
              </td>
            </tr>
          </template>
        </v-data-table>
      </div>
      <div class="pagination">
        <div>
          <hg-pagination
            @paginationChanged="paginationChanged($event)"
            :totalCounts="counts.total"
            :showingCounts="counts.showing"
            id="pagination-appointment-rules-maintenance"
            ref="appointmentRulePaginationComponent"
          />
        </div>
        <div></div>
      </div>
    </div>
  </div>
</template>

<script src="./rules-grid.js"></script>
<style src="./rules-grid.sass" lang="sass" scoped></style>
