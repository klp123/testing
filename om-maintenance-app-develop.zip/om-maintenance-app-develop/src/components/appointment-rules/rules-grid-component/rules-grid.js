import _ from 'lodash';
import Vue from 'vue';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import { HgMomentService, GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import HgConfirmActionModal from '../../shared/hg-confirm-modal/hg-confirm-modal.vue';
import hgPagination from '../../shared/hg-pagination/hg-pagination.vue';
import appointmentRulesService from '../../../services/appointment-rules/appointment-rules.service';
import appointmentRulesEnum from '../../../enums/appointment-rules.enum';

const rulesData = {
  appointmentRules: [],
  totalRules: 0,
  loading: false,
  headers: [
    {
      text: 'RULE ID',
      value: 'ruleId',
      sortable: false,
      width: '8%'
    },
    {
      text: 'CUSTOMER NAME',
      value: 'customer.name',
      sortable: false,
      width: '12%'
    },
    {
      text: 'TYPE',
      value: 'ruleType',
      sortable: false,
      width: '2%'
    },
    {
      text: 'TRIGGER',
      value: 'ruleTrigger',
      sortable: false,
      width: '8%'
    },
    {
      text: 'MODE',
      value: 'modes',
      sortable: false,
      width: '2%'
    },
    {
      text: 'EQUIPMENT',
      value: 'equipmentTypes',
      sortable: false,
      width: '2%'
    },
    {
      text: 'FROM',
      value: 'fromLocation',
      sortable: false,
      width: '8%'
    },
    {
      text: 'TO',
      value: 'toLocation',
      sortable: false,
      width: '8%'
    },
    {
      text: 'FROM APPT RULE',
      value: 'fromAppointmentRule.fromApptRule',
      sortable: false,
      width: '8%'
    },
    {
      text: '+/- HOURS',
      value: 'fromAppointmentRule.hours',
      sortable: false,
      width: '2%'
    },
    {
      text: 'TO APPT RULE',
      value: 'toAppointmentRule.fromApptRule',
      sortable: false,
      width: '8%'
    },
    {
      text: '+/- HOURS',
      value: 'toAppointmentRule.hours',
      sortable: false,
      width: '2%'
    },
    {
      text: 'TIMES USED(30 D)',
      value: 'usageDateTime',
      sortable: false,
      width: '2%'
    },
    {
      text: 'AUDIT',
      value: 'audit',
      sortable: false,
      width: '18%'
    },
    {
      text: 'RULE ON/OFF',
      value: 'status',
      sortable: false,
      width: '4%'
    },
    {
      text: 'ACTIONS',
      value: '',
      sortable: false,
      width: '6%'
    }
  ],
  forceRender: 0,
  counts: {},
  filters: {},
  pagination: {},
  selectedAppointmentRuleType: '',
  selectedAppointmentRuleTypeLabel: ''
};

function setGoogleAnalytics(details) {
  GoogleAnalyticsService.event(Vue, 'Auto-appointment rules', 'Maintenance', details);
}

async function unsavedWorkCheckPrompt() {
  const viewStatus = this.$store.getters['appointmentRulesStore/getViewFormState'];
  if (viewStatus) {
    return this.$store.dispatch('appointmentRulesStore/updateFormResetStatus', true);
  }
  const formOpenState = this.$store.getters['appointmentRulesStore/getFormOpenState'];
  if (!formOpenState) return false;
  const { HEADER, BODY, CONFIRM_BUTTON_TEXT } = appointmentRulesEnum.MODALS.EDIT;
  const discardChanges = await this.$refs.confirm.open(HEADER, BODY, CONFIRM_BUTTON_TEXT);
  if (discardChanges) this.$store.dispatch('appointmentRulesStore/updateFormResetStatus', true);
  return !discardChanges;
}

async function activateFutureRuleCheck() {
  const { HEADER, BODY, CONFIRM_BUTTON_TEXT } = appointmentRulesEnum.MODALS.ACTIVATE_FUTURE_RULE;
  const discardChanges = await this.$refs.confirm.open(HEADER, BODY, CONFIRM_BUTTON_TEXT);
  return !discardChanges;
}

async function updateRuleStatus(item) {
  if (await this.unsavedWorkCheckPrompt()) {
    this.forceRerender();
    return;
  }

  const currentDate = new Date();
  const {
    ruleId, status, ruleEndDate, ruleStartDate
  } = item;
  const lastDateOfRule = new Date(ruleEndDate);
  const firstDateOfRule = new Date(ruleStartDate);

  const payload = {
    ruleId,
    resetDates: false,
    resetStartDate: false,
  };

  if ((currentDate < firstDateOfRule) && status === appointmentRulesEnum.APPOINTMENT_RULE_STATUS.INACTIVE) {
    if (await this.activateFutureRuleCheck()) {
      this.forceRerender();
      return;
    }
    payload.resetStartDate = true;
  }

  if ((currentDate > lastDateOfRule) && status === appointmentRulesEnum.APPOINTMENT_RULE_STATUS.INACTIVE) {
    payload.resetDates = true;
  }

  try {
    const ruleStatus = status === appointmentRulesEnum.APPOINTMENT_RULE_STATUS.ACTIVE
      ? appointmentRulesEnum.APPOINTMENT_RULE_STATUS.INACTIVE
      : appointmentRulesEnum.APPOINTMENT_RULE_STATUS.ACTIVE;
    payload.ruleStatus = ruleStatus;
    await appointmentRulesService.updateRuleStatus(payload);
    await this.loadAppointmentRules();
    HgNotificationService.successMessage('Successfully changed rule status');
    setGoogleAnalytics(`Changed rule status to ${ruleStatus}`);
  } catch (error) {
    this.forceRerender();
    HgNotificationService.errorMessage('Failed to change rule status');
  }
}

function paginationChanged(pagination) {
  this.pagination.page = pagination.page;
  this.pagination.limit = pagination.limit;
  this.loadAppointmentRules();
  this.$store.dispatch('appointmentRulesStore/updatePagination', pagination);
}

function formatAuditValue(item, isUpdateItem) {
  let result = '';
  if (isUpdateItem) {
    const { modifiedBy, modifiedDateTime } = item;
    result = `${modifiedBy} ${HgMomentService.formatTime(modifiedDateTime)}`;
  } else {
    const { createdBy, createdDateTime } = item;
    result = `${createdBy} ${HgMomentService.formatTime(createdDateTime)}`;
  }
  return result;
}

const formatLocationText = (item, type, isToLocation) => {
  let locationItems = [];
  let isAllLocationSelected = false;
  if (isToLocation) {
    const { toAllLocations, toLocation } = item;
    isAllLocationSelected = toAllLocations;
    locationItems = toLocation;
  } else {
    const { fromAllLocations, fromLocation } = item;
    isAllLocationSelected = fromAllLocations;
    locationItems = fromLocation;
  }
  if (isAllLocationSelected && type === 'Include') return 'ALL';
  let includeString = '';
  let excludeString = '';
  locationItems.forEach((locationItem) => {
    const locationValue = _.get(locationItem, 'searchValue', '');
    if (!locationValue) return;
    if (locationItem.exclude) {
      excludeString = excludeString ? `${excludeString}, ${locationValue}` : locationValue;
    } else {
      includeString = includeString ? `${includeString}, ${locationValue}` : locationValue;
    }
  });
  includeString = includeString ? `Include ${includeString}` : '';
  excludeString = excludeString ? `Exclude ${excludeString}` : '';
  return type === 'Include' ? includeString : excludeString;
};

const getDisplayValueTrigger = (item) => (item && item.displayValue.value) || '';

function formatRuleTrigger(item) {
  const { ruleType, ruleTrigger } = item;
  return getDisplayValueTrigger(
    _.get(this.lovData.triggersEnum, `${ruleType}`, []).find((el) => el.value === ruleTrigger)
  );
}

const formatEquipmentTypes = (equipments = []) => {
  let equipmentString = '';
  Array.isArray(equipments) && equipments.forEach((item) => {
    const strVal = `${item.type}${item.length}`;
    if (!equipmentString.includes(strVal)) equipmentString = equipmentString ? `${equipmentString}, ${strVal}` : strVal;
  });
  return equipmentString;
};

const formatMode = (mode = []) => {
  let modeString = '';
  mode = _.union(mode);
  Array.isArray(mode) && mode.forEach((item) => {
    const strVal = `${item}`;
    modeString = modeString ? `${modeString}, ${strVal}` : strVal;
  });
  return modeString;
};

const getDisplayValueRule = (item) => (item && item.displayValue) || '';

function formatAppointmentRule(item, type) {
  const { ruleType } = item;
  let apptRuleVal = '';
  if (type === 'TO') {
    apptRuleVal = _.get(item, 'toAppointmentRule.toApptRule', '');
  } else {
    apptRuleVal = _.get(item, 'fromAppointmentRule.fromApptRule', '');
  }
  return getDisplayValueRule(
    _.get(this.lovData.appointmentRulesEnum, `${ruleType}.${type}`, []).find(
      (el) => el.value === apptRuleVal
    )
  );
}

async function loadAppointmentRules() {
  try {
    this.loading = true;
    const response = (
      await appointmentRulesService.filterAppointmentRules(this.filters, this.pagination)
    ).data;
    this.appointmentRules = response.data;
    this.totalRules = this.appointmentRules.length;
    const counts = {
      total: response.meta.total,
      showing: response.meta.limit * (response.meta.page - 1) + this.appointmentRules.length
    };
    this.$store.dispatch('appointmentRulesStore/updateCounts', counts);
    this.loading = false;
  } catch (err) {
    if (!(err.message && err.message === RequestErrorTypesEnum.CANCEL_REQUEST)) {
      HgNotificationService.errorMessage('Error while filtering appointment rules');
      this.loading = false;
    }
  }
}

async function editRule(data) {
  if (await this.unsavedWorkCheckPrompt()) return;
  this.$store.dispatch('appointmentRulesStore/updateEditStatus', true);
  this.$store.dispatch('appointmentRulesStore/updateEditFormData', _.cloneDeep(data));
}

async function copyRule(data) {
  if (await this.unsavedWorkCheckPrompt()) return;
  this.$store.dispatch('appointmentRulesStore/updateCopyStatus', true);
  this.$store.dispatch('appointmentRulesStore/updateCopyRuleData', _.cloneDeep(data));
}

async function viewRule(data) {
  if (await this.unsavedWorkCheckPrompt()) return;
  this.$store.dispatch('appointmentRulesStore/updateViewStatus', true);
  this.$store.dispatch('appointmentRulesStore/updateViewFormData', _.cloneDeep(data));
  setGoogleAnalytics('View auto appointment rule');
}

/* async function deleteRule(ruleId) {
  try {
    const ruleStatus = appointmentRulesEnum.APPOINTMENT_RULE_STATUS.DELETED;
    const payload = {
      ruleId,
      resetDates: false,
      ruleStatus
    };
    await appointmentRulesService.updateRuleStatus(payload);
    HgNotificationService.successMessage('Appointment rule deleted successfully');
    setGoogleAnalytics('Appointment rule deleted');
    this.loadAppointmentRules();
  } catch (error) {
    HgNotificationService.errorMessage('Failed to delete appointment rule');
  }
}

async function showDeleteConfirmationModal(ruleId) {
  if (await this.unsavedWorkCheckPrompt()) return;
  const { HEADER, BODY, CONFIRM_BUTTON_TEXT } = appointmentRulesEnum.MODALS.DELETE;
  const response = await this.$refs.confirm.open(HEADER, BODY, CONFIRM_BUTTON_TEXT);
  if (response) {
    this.deleteRule(ruleId);
  }
} */

function isActiveRule(status) {
  return status === appointmentRulesEnum.APPOINTMENT_RULE_STATUS.ACTIVE;
}

function forceRerender() {
  this.forceRender++;
}

export default {
  name: 'RulesGridComponent',
  components: {
    hgPagination,
    HgConfirmActionModal
  },
  data: () => rulesData,
  methods: {
    loadAppointmentRules,
    paginationChanged,
    formatAuditValue,
    formatLocationText,
    formatRuleTrigger,
    formatAppointmentRule,
    updateRuleStatus,
    editRule,
    copyRule,
    viewRule,
    isActiveRule,
    unsavedWorkCheckPrompt,
    activateFutureRuleCheck,
    setGoogleAnalytics,
    forceRerender,
    formatEquipmentTypes,
    formatMode
  },
  computed: {
    gridRefreshStatus() {
      return this.$store.getters['appointmentRulesStore/getRefreshGrid'];
    },
    isLoadingLovData() {
      return this.$store.getters['appointmentRulesStore/getLoadingLovData'];
    }
  },
  watch: {
    filters: {
      handler() {
        this.$store.dispatch('appointmentRulesStore/updatePagination', {
          page: 1,
          limit: this.pagination.limit
        });
        this.loadAppointmentRules();
      },
      deep: true
    },
    pagination: {
      handler() {
        this.loadAppointmentRules();
      },
      deep: true
    },
    gridRefreshStatus(value) {
      if (value) {
        this.loadAppointmentRules();
        this.$store.dispatch('appointmentRulesStore/updateRefreshGrid', false);
      }
    }
  },
  props: {
    lovData: {
      type: Object,
      default: _.cloneDeep(appointmentRulesService.lovDataTemplate)
    },
    entitlements: {
      type: Object,
      default: _.cloneDeep(appointmentRulesService.defaultEntitlements)
    }
  },
  async created() {
    this.filters = this.$store.getters['appointmentRulesStore/getFilters'];
    this.pagination = this.$store.getters['appointmentRulesStore/getPagination'];
    this.counts = this.$store.getters['appointmentRulesStore/getCounts'];
    await this.loadAppointmentRules();
  }
};
