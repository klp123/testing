import _ from 'lodash';
import Vue from 'vue';
import { AppSetupEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import { GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import HgSearchBar from '../../shared/filters/hg-search-bar/hg-search-bar.vue';
import HgRadioFilter from '../../shared/filters/hg-radio-filter/hg-radio-filter.vue';
import HgQuickSearch from '../../shared/filters/hg-quick-search/hg-quick-search.vue';
import customerService from '../../../services/orders/customer.service';
import appointmentRulesEnum from '../../../enums/appointment-rules.enum';
import filterService from '../../../services/filters/filters.service';

const filterParams = filterService.appointmentRuleFilterParams;
filterParams.ruleType.items = appointmentRulesEnum.APPOINTMENT_RULE_TYPES;

const quickSearchValue = '';
/**
 * Calls api to search customer
 * Searches if searchText is 3 or more character long or searchText is empty
 * For empty searchText, api will give first 50 items sorted by customer name
 * Api searches customer in customer collection in OperationDB
 * @param {*} searchText
 * @param {*} initialSearch
 */
async function customerSearchTextChanged(searchText) {
  this.loadingCustomersList = true;
  if (!searchText || searchText.length >= AppSetupEnum.MINIMUM_SEARCH_CHARACTER) {
    try {
      this.customer.items = await customerService.searchCustomers(searchText);
      this.loadingCustomersList = false;
    } catch (e) {
      this.loadingCustomersList = false;
    }
  } else {
    this.loadingCustomersList = false;
  }
}

function setGoogleAnalytics(details) {
  GoogleAnalyticsService.event(Vue, 'Auto-appointment rules', 'Maintenance', details);
}

function onFilterSelected(selectedItem) {
  let gaDetails;
  switch (selectedItem.key) {
    case 'ruleType':
      gaDetails = `Filtering by ${selectedItem.text} rule type`;
      break;
    case 'customer':
      gaDetails = 'Filtering by customer';
      break;
    case 'ruleId':
      gaDetails = 'Filtering by Rule Id';
      break;
    default:
      break;
  }
  this.$store.dispatch('appointmentRulesStore/updateFilter', selectedItem);
  this.setLocalStorageFilter();
  this.$emit('appointmentRuleFilterChanged');
  setGoogleAnalytics(gaDetails);
}

function onSearchTextChange(cmd) {
  if (cmd === 'CLEAR_ALL') {
    this.quickSearchValue = '';
  }
  if (this.quickSearchValue && this.quickSearchValue.trim().length > 2) {
    this.onFilterSelected({
      value: this.quickSearchValue,
      key: 'ruleId',
      text: `${this.quickSearchValue.trim()}`,
      label: 'Rule Id'
    });
  }
}

function onFilterUnselected(filter) {
  if (filter) {
    this.$store.dispatch('appointmentRulesStore/removeFilter', filter);
  } else {
    this.$store.dispatch('appointmentRulesStore/removeFilter');
  }
  this.setLocalStorageFilter();
}

function isFiltersEmpty() {
  const filters = this.$store.getters['appointmentRulesStore/getFilters'];
  const allEmpty = Object.values(filters).every((value) => {
    if (_.isEmpty(value)) return true;
    return false;
  });
  return allEmpty;
}

function customerFilterClosed() {
  customerSearchTextChanged.bind(this)('');
}

function selectedFilter(filterType) {
  return filterType
    ? this.$store.getters['appointmentRulesStore/getFilters'][filterType]
    : this.$store.getters['appointmentRulesStore/getFilters'];
}

function clearFilter(filter) {
  this.onFilterUnselected(filter);
}

function clearAllFilter() {
  this.onFilterUnselected();
}

function setLocalStorageFilter() {
  const currentAppointmentRulesFilter = this.$store.getters['appointmentRulesStore/getFilters'];
  localStorage.setItem(
    'currentAppointmentRulesFilter',
    JSON.stringify(currentAppointmentRulesFilter)
  );
}

async function selectLocalStorageFilter() {
  const currentAppointmentRulesFilter = localStorage.getItem('currentAppointmentRulesFilter')
    ? JSON.parse(localStorage.getItem('currentAppointmentRulesFilter'))
    : null;
  if (currentAppointmentRulesFilter) {
    Object.values(currentAppointmentRulesFilter).forEach((ftr) => {
      if (ftr && ftr.length) {
        ftr.forEach((element) => {
          if (element.value) {
            this.onFilterSelected(element);
          }
        });
      }
    });
  }
}

function renderFilters(filter) {
  Object.values(filter).forEach((ftr) => {
    if (ftr && ftr.length) {
      ftr.forEach((element) => {
        this.$store.dispatch('appointmentRulesStore/updateFilter', element);
        this.setLocalStorageFilter();
      });
    }
  });
}

// @group FILTERS
// Filter component holds all filter components and breadcrumbs for showing active filters.
export default {
  name: 'AppointmentRulesFilterComponent',
  data: () => ({
    loadingCustomersList: false,
    ...filterParams,
    quickSearchValue
  }),
  props: {},
  components: {
    HgSearchBar,
    HgRadioFilter,
    HgQuickSearch
  },
  methods: {
    customerFilterClosed,
    customerSearchTextChanged,
    clearFilter,
    clearAllFilter,
    onFilterSelected,
    onFilterUnselected,
    selectedFilter,
    renderFilters,
    setLocalStorageFilter,
    isFiltersEmpty,
    selectLocalStorageFilter,
    setGoogleAnalytics,
    onSearchTextChange
  },
  mounted() {
    customerSearchTextChanged.bind(this)('');
    this.selectLocalStorageFilter();
  }
};
