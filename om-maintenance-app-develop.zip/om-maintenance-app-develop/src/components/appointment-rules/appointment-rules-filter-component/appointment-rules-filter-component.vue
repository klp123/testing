<template>
  <div class="filter-container">
    <div class="d-grid">
      <div class="filter-components" id="filter-components">
        <hg-lib-menu-search-bar
          :items="customer.items || []"
          :filterKey="customer.filterKey"
          :placeholder="customer.placeholder"
          :selectedItems="selectedFilter('customer')"
          :menuLabel="customer.filterLabel"
          :loading="loadingCustomersList"
          @searchTextChanged="customerSearchTextChanged($event)"
          @searchItemSelected="onFilterSelected($event)"
          @searchItemUnSelected="onFilterUnselected($event)"
          @filterClosed="customerFilterClosed"
          id="customer-filter"
        />
        <hg-lib-menu-radio-list
          :menuLabel="ruleType.filterLabel"
          :options="ruleType.items || []"
          :selectedValue="selectedFilter('ruleType') && selectedFilter('ruleType').length ? selectedFilter('ruleType')[0] : {}"
          @onItemSelected="onFilterSelected($event)"
          @onUnItemSelected="onFilterUnselected($event)"
          id="rule-type"
        />
        <v-text-field
        class="ruleId"
        v-model="quickSearchValue"
        v-debounce:1500="onSearchTextChange"
        :placeholder="`Search by Rule Id`"
        prepend-inner-icon="mdi-magnify"
        clearable
        @click:clear="onSearchTextChange('CLEAR_ALL')"
        outlined
        color="highlight"
        dense
        ></v-text-field>
      </div>
    </div>
    <div class="current-filters">
      <hg-lib-filter-bread-crumb-display
        :selectedFilters="selectedFilter()"
        @clearFilters="clearFilter($event)"
        @clearAllFilters="clearAllFilter()"
      />
    </div>
  </div>
</template>
<script src="./appointment-rules-filter-component.js"></script>
<style src="./appointment-rules-filter-component.sass" lang="sass" scoped></style>
