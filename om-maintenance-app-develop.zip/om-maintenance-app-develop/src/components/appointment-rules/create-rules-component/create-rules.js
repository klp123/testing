import Vue from 'vue';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import { ImageLoaderService, GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import * as _ from 'lodash';
import VueTimepicker from 'vue2-timepicker';
import moment from 'moment';
import { CdnImagesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import hgAutocomplete from '../../shared/drop-downs/hg-autocomplete/hg-autocomplete.vue';
import HgMultiSelect from '../../shared/filters/hg-multi-select/hg-multi-select.vue';
import DatetimePickerComponent from '../../shared/datetime-picker/datetime-picker.vue';
import customerService from '../../../services/customer/customer.service';
import locationService from '../../../services/location/location.service';
import appointmentRulesService from '../../../services/appointment-rules/appointment-rules.service';
import appointmentRulesEnum from '../../../enums/appointment-rules.enum';
import ruleTemplate from './ruleTemplate';
import HgConfirmActionModal from '../../shared/hg-confirm-modal/hg-confirm-modal.vue';

const getTodayDate = () => moment(new Date()).tz('America/Chicago').format().split('T')[0];

const data = {
  showForm: false,
  formData: _.cloneDeep(ruleTemplate),
  processingForm: false,
  appointmentRuleTypesEnum: appointmentRulesEnum.APPOINTMENT_RULE_TYPES,
  maxApptsPerDayError: '',
  selectToTimeError: '',
  selectFromTimeError: '',
  maxApptsPerDayConflict: '',
  maxApptsConflictCounter: 0,
  appointmentFromHoursError: '',
  appointmentToHoursError: '',
  appointmentRuleError: '',
  duplicateToLocationsError: '',
  duplicateFromLocationsError: '',
  customerList: [],
  equipmentsEnum: [],
  allEquipmentsEnum: [],
  weekdaysEnum: appointmentRulesEnum.WEEKDAYS,
  yesOrNoEnum: appointmentRulesEnum.YES_NO,
  plusMinusEnum: appointmentRulesEnum.PLUS_MINUS,
  loadingCustomers: false,
  isDockHoursDisabled: false,
  isToHoursDisabled: false,
  isToHoursSignDisabled: false,
  isFromHoursDisabled: false,
  dateTimeRangeConfig: {
    start: {
      maxDate: null,
      minDate: getTodayDate(),
      disabled: false,
      required: false
    },
    end: {
      maxDate: null,
      minDate: getTodayDate(),
      disabled: false,
      required: false
    }
  },
  isValidDateTime: {
    start: true,
    end: true
  },
  CdnImagesEnum,
  forceRender: 0
};

/**
 * gets image from hubgroup CDN
 * @param {String} imageName
 * @return {String} image URL
 */
function getCdnImageUrl(imageName) {
  return ImageLoaderService.getCdnImageUrl(imageName);
}

/**
 *
 * @param {*} name color name
 * @returns color codes
 */
function getColor(name) {
  return _colors[name];
}

function forceRerender() {
  this.forceRender++;
}

function setGoogleAnalytics(details) {
  GoogleAnalyticsService.event(Vue, 'Auto-appointment rules', 'Maintenance', details);
}

function addLocationItem(key) {
  this.formData[key].push({
    searchValue: '',
    exclude: false,
    locationList: []
  });
}

function removeLocationItem(key, index) {
  this.formData[key].splice(index, 1);
}

function isAllLocationCheckDisabled(key, allLocationKey) {
  const locationItemsFilled = this.formData[key].some((item) => item.searchValue);
  if (this.formData[allLocationKey] && locationItemsFilled) this.formData[allLocationKey] = false;
  return locationItemsFilled;
}

function isCheckedRadioItem(value) {
  return this.formData.isApptRequired === value;
}

function formatDropdownLabel(item) {
  return item.displayValue;
}

function formatDropdownLabelSorted(item) {
  return item.displayValue.value;
}

function formatDropdownValue(item) {
  return item.value;
}

function formatDropdownText(item) {
  return item.text;
}

function getTriggerItems() {
  const triggerItems = this.formData.ruleType ? _.get(this.lovData.triggersEnum, `${this.formData.ruleType}`, []) : [];
  return _.orderBy(triggerItems, (rule) => rule.displayValue.sort, ['asc']);
}

const filterAppointmentRules = (appointmentRules, filterItems) => _.filter(appointmentRules, (rule) => !(filterItems.includes(rule.value)));

function getAppointmentRules(type) {
  const { ruleTrigger, ruleType, modes } = this.formData;
  const {
    RULE_TRIGGERS,
    APPOINTMENT_RULE_TYPES,
    OUTCOME_TYPE,
    RULE_OUTCOMES,
    RAIL_CUTOFF_MODES
  } = appointmentRulesEnum;
  const {
    CLEVENT,
    NTEVENT,
    TAEVENT,
    MANUAL_ORDER_ACCEPTED,
    ELECTRONIC_ORDER_ACCEPTED,
  } = RULE_TRIGGERS;
  const {
    PC_DATETIME,
    EDI_ACK_DATETIME,
    SDA_DATETIME,
    TA_DATETIME,
    COMPLETE_LOADING_DATETIME,
    NOTIFY_DATETIME,
    LATEST_SUGGESTED_DATETIME,
    RAILCUTOFF_DATETIME
  } = RULE_OUTCOMES;

  const selectedModes = modes.map((el) => el.value);
  let appointmentRules = ruleType ? _.get(this.lovData.appointmentRulesEnum, `${ruleType}.${type}`, []) : [];

  if (ruleType === APPOINTMENT_RULE_TYPES[0].value) {
    if ([MANUAL_ORDER_ACCEPTED, ELECTRONIC_ORDER_ACCEPTED].includes(ruleTrigger)) {
      appointmentRules = filterAppointmentRules(appointmentRules, [PC_DATETIME, LATEST_SUGGESTED_DATETIME]);
    }
    if (ruleTrigger !== ELECTRONIC_ORDER_ACCEPTED) {
      appointmentRules = filterAppointmentRules(appointmentRules, [EDI_ACK_DATETIME]);
    }
    if (type === OUTCOME_TYPE.TO && !selectedModes.some((item) => RAIL_CUTOFF_MODES.includes(item))) {
      appointmentRules = filterAppointmentRules(appointmentRules, [RAILCUTOFF_DATETIME]);
    }
    if (ruleTrigger !== CLEVENT) {
      appointmentRules = filterAppointmentRules(appointmentRules, [COMPLETE_LOADING_DATETIME]);
    } else {
      appointmentRules = filterAppointmentRules(appointmentRules, [PC_DATETIME]);
    }
  }
  if (ruleType === APPOINTMENT_RULE_TYPES[1].value) {
    if (type === OUTCOME_TYPE.FROM && ruleTrigger !== NTEVENT) {
      appointmentRules = filterAppointmentRules(appointmentRules, [NOTIFY_DATETIME]);
    }
    if (ruleTrigger !== TAEVENT) {
      appointmentRules = filterAppointmentRules(appointmentRules, [TA_DATETIME]);
    }
    if ([MANUAL_ORDER_ACCEPTED, ELECTRONIC_ORDER_ACCEPTED].includes(ruleTrigger)) {
      appointmentRules = filterAppointmentRules(appointmentRules, [SDA_DATETIME]);
    }
  }
  return appointmentRules;
}

function validateSelectedAppointmentRules(typeKey, filteredAppointmentRulesList) {
  const formValueKey = `${typeKey}AppointmentRule`;
  const selectedAppointmentRule = _.get(this.formData, `${formValueKey}.${typeKey}ApptRule`);
  const possibleAppointmentRuleValues = filteredAppointmentRulesList.map((item) => item.value);

  if (!possibleAppointmentRuleValues.includes(selectedAppointmentRule)) {
    this.formData[formValueKey] = _.cloneDeep(ruleTemplate[formValueKey]);
  }
}

function updateFormData(value, key) {
  this.formData[key] = value;
}

function onMultiSelectChange(item, isAdded, key) {
  if (item.displayValue === 'ALL') {
    this.formData[key] = [];
  }
  if (isAdded) {
    if (!this.formData[key].includes(item)) {
      this.formData[key].push(item);
    }
  } else {
    const existingItemIndex = this.formData[key].findIndex((el) => el.value === item.value);
    this.formData[key].splice(existingItemIndex, 1);
  }
}

function onModeChange(...props) {
  this.onMultiSelectChange(...props, 'modes');
  this.equipmentsEnum = [];
  this.allEquipmentsEnum = [];
  if (this.formData.modes && this.formData.modes.length) {
    const items = this.formData.modes.map((item) => item.value);
    this.equipmentsEnum = appointmentRulesService.getEquipmentTypes(items);
    this.equipmentsEnum.push(appointmentRulesService.getEquipmentTypes(items));
    this.equipmentsEnum = _.flatten(this.equipmentsEnum);
    this.allEquipmentsEnum = _.unionBy((this.equipmentsEnum || []), this.equipmentsEnum, 'displayValue');
  } else {
    this.equipmentsEnum = [];
    this.allEquipmentsEnum = [];
    this.formData.equipmentTypes = [];
  }
}

function onEquipmentChange(...props) {
  this.onMultiSelectChange(...props, 'equipmentTypes');
}

function onRuleTypeChange(value) {
  if (this.formData.ruleType && this.formData.ruleType !== value) {
    this.formData.ruleTrigger = '';
    this.formData.fromAppointmentRule = _.cloneDeep(ruleTemplate.fromAppointmentRule);
    this.formData.toAppointmentRule = _.cloneDeep(ruleTemplate.toAppointmentRule);
    this.forceRerender();
  }
  this.formData.ruleType = value;
}

function onDateTimeChange(value, key) {
  this.formData[key] = value;
  if (key === 'ruleStartDate') {
    if (value) {
      [this.dateTimeRangeConfig.end.minDate] = moment(value).add(1, 'd').toISOString().split('T');
    }
  }
}

function setValidDateTime(value, key) {
  this.isValidDateTime[key] = value;
}

async function handleResetCustomer(defaultCustomer) {
  const { HEADER, BODY, CONFIRM_BUTTON_TEXT } = appointmentRulesEnum.MODALS.CHANGE_CUSTOMER;
  const confirmReset = await this.$refs.confirm.open(HEADER, BODY, CONFIRM_BUTTON_TEXT);
  if (!confirmReset) {
    this.formData.customer = defaultCustomer;
    this.onSearchTextChanged({
      value: (defaultCustomer.id ? defaultCustomer.id : defaultCustomer.value) || '',
      searchText: (defaultCustomer.id ? `${defaultCustomer.name}, ${defaultCustomer.id}` : `${defaultCustomer.name}, ${defaultCustomer.value}`) || '',
      name: defaultCustomer.name,
      label: 'Customer',
      type: 'customer',
      prepopulate: false
    });
    return;
  }
  this.formData.toLocation = _.cloneDeep(ruleTemplate.toLocation);
  this.formData.fromLocation = _.cloneDeep(ruleTemplate.fromLocation);
  this.formData.toAllLocations = _.cloneDeep(ruleTemplate.toAllLocations);
  this.formData.fromAllLocations = _.cloneDeep(ruleTemplate.fromAllLocations);
}

function hasLocationDataFilled() {
  const {
    toLocation, fromLocation, fromAllLocations, toAllLocations
  } = this.formData;
  return toLocation.length > 1 || fromLocation.length > 1
    || (_.get(toLocation, '0.searchValue')) || (_.get(fromLocation, '0.searchValue'))
    || toAllLocations || fromAllLocations;
}

async function onValueSelected(selectedData, index) {
  const { value, type } = selectedData;
  const { text } = value || {};
  if (type === 'customer') {
    const defaultCustomer = this.formData.customer || {};
    this.formData.customer = value;
    if ((defaultCustomer) && (!value || defaultCustomer.value !== value.value) && this.hasLocationDataFilled()) {
      await this.handleResetCustomer(defaultCustomer);
    }
  } else if (type === 'toLocation' || type === 'fromLocation') {
    this.formData[type][index].value = value;
    this.formData[type][index].searchValue = value ? text : '';
    if (!value) this.formData[type][index].exclude = false;
  }
}
/**
 * toggle the form
 */
function toggleForm(value) {
  this.showForm = value;
  this.$store.dispatch('appointmentRulesStore/updateFormOpenStatus', value);
}

function cancelForm() {
  this.toggleForm(false);
  if (this.isCopyingRule) {
    this.$store.dispatch('appointmentRulesStore/updateCopyRuleData', {});
    this.$store.dispatch('appointmentRulesStore/updateCopyStatus', false);
  }
  if (this.isEditForm) {
    this.$store.dispatch('appointmentRulesStore/updateEditFormData', {});
    this.$store.dispatch('appointmentRulesStore/updateEditStatus', false);
  }
  if (this.isViewForm) {
    this.$store.dispatch('appointmentRulesStore/updateViewFormData', {});
    this.$store.dispatch('appointmentRulesStore/updateViewStatus', false);
  }
  this.resetForm();
}

async function editRule() {
  this.$store.dispatch('appointmentRulesStore/updateViewFormData', {});
  this.$store.dispatch('appointmentRulesStore/updateViewStatus', false);
  this.$store.dispatch('appointmentRulesStore/updateEditStatus', true);
  this.$store.dispatch('appointmentRulesStore/updateEditFormData', _.cloneDeep(this.formData));
}

async function copyRule() {
  this.$store.dispatch('appointmentRulesStore/updateViewFormData', {});
  this.$store.dispatch('appointmentRulesStore/updateViewStatus', false);
  this.$store.dispatch('appointmentRulesStore/updateCopyStatus', true);
  this.$store.dispatch('appointmentRulesStore/updateCopyRuleData', _.cloneDeep(this.formData));
}

function toggleHoursDiffType(type) {
  const currentVal = this.formData[type].diffType;
  if (currentVal === this.plusMinusEnum[0].value) {
    this.formData[type].diffType = this.plusMinusEnum[1].value;
  } else {
    this.formData[type].diffType = this.plusMinusEnum[0].value;
  }
}
const isLocationIdValue = (val) => appointmentRulesEnum.PATTERNS.LOCATION_ID.test(val);
const containsLocationId = (locations) => !!locations.filter((location) => isLocationIdValue(location.searchValue)).length;

async function onSearchTextChanged(eventData, index) {
  const { type, searchText, prepopulate } = eventData;
  try {
    if (!type) return;
    let searchTextVal = '';
    if (type === 'customer') {
      if (searchText.length === 0 && this.isCopyingRule) {
        return;
      }
      this.loadingCustomers = true;
      searchTextVal = _.split(searchText, ',', 1)[0].trim();
      this.customerList = await customerService.searchCustomers(searchTextVal);
      if (this.isViewForm || this.isEditForm) {
        this.customerList = this.customerList.splice(this.customerList.findIndex((customer) => customer.value === searchTextVal), 1);
      }
      if (prepopulate) {
        [this.formData.customer] = this.customerList;
      }
      this.loadingCustomers = false;
    } else {
      searchTextVal = (searchText || '').trim();
      if (!searchTextVal) return;
      if (prepopulate) {
        const [city, state] = searchTextVal.split(', ');
        const selectedVal = {
          text: searchTextVal,
          value: { city, state }
        };
        const { text } = selectedVal || {};
        const formDataValue = this.formData[type][index];
        formDataValue.value = selectedVal || {};
        formDataValue.searchValue = text || '';
        formDataValue.locationList = [selectedVal];
        return;
      }
      const locationListData = isLocationIdValue(searchTextVal)
        ? await locationService.searchCustomerLocations(
          searchTextVal,
          this.formData.customer.id || this.formData.customer.value
        )
        : await locationService.searchCityStates(searchTextVal);
      this.formData[type][index].locationList = locationListData;
    }
    return;
  } catch (error) {
    console.log(`Error when performing ${type} search`, error);
  }
}

async function initialiseData() {
  this.loadingCustomers = true;
  this.customerList = await customerService.searchCustomers();
  this.loadingCustomers = false;
}

function checkFormValidations() {
  let isValid = true;
  this.isToHoursSignDisabled = false;
  this.isToHoursDisabled = false;
  this.isFromHoursDisabled = false;
  const digitPattern = appointmentRulesEnum.PATTERNS.ONLY_DIGITS;
  const { ACTUAL_FROM_DATETIME, DOCK_CLOSING_DATETIME, USERSPECIFIED_DATETIME } = appointmentRulesEnum.RULE_OUTCOMES;
  this.maxApptsPerDayError = '';
  this.appointmentFromHoursError = '';
  this.appointmentToHoursError = '';
  this.appointmentRuleError = '';
  this.maxApptsPerDayConflict = '';
  this.duplicateToLocationsError = '';
  this.duplicateFromLocationsError = '';
  this.selectFromTimeError = '';
  this.selectToTimeError = '';
  const {
    ruleType,
    ruleTrigger,
    customer,
    fromAppointmentRule,
    toAppointmentRule,
    equipmentTypes,
    modes,
    maxApptsPerDay,
    fromLocation,
    toLocation,
    toAllLocations,
    fromAllLocations
  } = this.formData;
  const { hours: toAppointmentHours } = toAppointmentRule;
  const { hours: fromAppointmentHours } = fromAppointmentRule;
  if (!(containsLocationId(fromLocation) || containsLocationId(toLocation))) {
    this.formData.considerDockHours = false;
    this.isDockHoursDisabled = true;
  } else {
    this.isDockHoursDisabled = false;
  }
  this.formData.toAppointmentRule.diffType = this.plusMinusEnum[0].value;
  if (toAppointmentRule.toApptRule === ACTUAL_FROM_DATETIME) {
    this.isToHoursSignDisabled = true;
  }
  if (toAppointmentRule.toApptRule === DOCK_CLOSING_DATETIME || toAppointmentRule.toApptRule === 'RAILCUTOFF_DATETIME') {
    this.formData.toAppointmentRule.diffType = this.plusMinusEnum[1].value;
    this.isToHoursSignDisabled = true;
  }
  if (toAppointmentRule.toApptRule === USERSPECIFIED_DATETIME) {
    isValid = this.formData.toAppointmentRule.userTime;
  } else {
    this.formData.toAppointmentRule.userTime = '';
  }
  const isFromTimeEmpty = _.values(this.formData.fromAppointmentRule.userTime).every(_.isEmpty);
  const isToTimeEmpty = _.values(this.formData.toAppointmentRule.userTime).every(_.isEmpty);
  if (!isFromTimeEmpty) {
    this.isFromHoursDisabled = true;
    this.formData.fromAppointmentRule.hours = 0;
  }
  if (!isToTimeEmpty) {
    this.isToHoursDisabled = true;
    this.formData.toAppointmentRule.hours = 0;
  }
  if (maxApptsPerDay.some((item) => (!digitPattern.test(item) || parseInt(item, 10) > 999 || parseInt(item, 10) < 0) && (item !== null && item !== ''))
  ) {
    this.maxApptsPerDayError = appointmentRulesEnum.VALIDATION_ERRORS.MAX_APPT_PER_DAY.INVALID_VALUE;
    isValid = false;
  }
  if (((ruleType === appointmentRulesEnum.APPOINTMENT_RULE_TYPES[0].value && !containsLocationId(fromLocation))
    || (ruleType === appointmentRulesEnum.APPOINTMENT_RULE_TYPES[1].value && !containsLocationId(toLocation)))) {
    if (maxApptsPerDay.some((item) => parseInt(item, 10) > 0)) {
      this.maxApptsPerDayError = appointmentRulesEnum.VALIDATION_ERRORS.MAX_APPT_PER_DAY.SPECIFIC_LOCATION;
      isValid = false;
    }
    if (toAppointmentRule.toApptRule === DOCK_CLOSING_DATETIME) {
      this.appointmentRuleError = appointmentRulesEnum.VALIDATION_ERRORS.SPECIFIC_LOCATION_DOCK_CLOSING;
      isValid = false;
    }
  }
  if (toAppointmentHours && (!digitPattern.test(toAppointmentHours)
    || parseInt(toAppointmentHours, 10) < 0 || parseInt(toAppointmentHours, 10) > 72)) {
    this.appointmentToHoursError = appointmentRulesEnum.VALIDATION_ERRORS.APPT_HOURS;
    isValid = false;
  }
  if (fromAppointmentHours && (!digitPattern.test(fromAppointmentHours)
    || parseInt(fromAppointmentHours, 10) < 0 || parseInt(fromAppointmentHours, 10) > 72)) {
    this.appointmentFromHoursError = appointmentRulesEnum.VALIDATION_ERRORS.APPT_HOURS;
    isValid = false;
  }
  if (this.formData.fromAppointmentRule.userTime && /[a-z]/i.test(this.formData.fromAppointmentRule.userTime)) {
    this.selectFromTimeError = appointmentRulesEnum.VALIDATION_ERRORS.SELECT_TIME_ERROR;
    isValid = false;
  }
  if (this.formData.toAppointmentRule.userTime && /[a-z]/i.test(this.formData.toAppointmentRule.userTime)) {
    this.selectToTimeError = appointmentRulesEnum.VALIDATION_ERRORS.SELECT_TIME_ERROR;
    isValid = false;
  }
  if (
    !(
      ruleType
      && ruleTrigger
      && customer && (customer.id || customer.value)
      && equipmentTypes.length
      && modes.length
      && toAppointmentRule
      && toAppointmentRule.toApptRule
      && fromAppointmentRule
      && fromAppointmentRule.fromApptRule
      && (_.filter(toLocation, (location) => location.searchValue !== '').length || toAllLocations)
      && (_.filter(fromLocation, (location) => location.searchValue !== '').length || fromAllLocations)
      && this.isValidDateTime.start
      && this.isValidDateTime.end
    )
  ) {
    isValid = false;
  }
  return isValid;
}

const formatLocationPayload = (locationData) => {
  const result = locationData.map((item) => {
    const { searchValue, exclude } = item;
    if (!searchValue) return null;
    return { searchValue, exclude };
  });
  return result.filter(Boolean);
};

function resetForm() {
  this.maxApptsPerDayError = '';
  this.appointmentFromHoursError = '';
  this.appointmentToHoursError = '';
  this.appointmentRuleError = '';
  this.maxApptsPerDayConflict = '';
  this.duplicateToLocationsError = '';
  this.duplicateFromLocationsError = '';
  this.selectFromTimeError = '';
  this.selectToTimeError = '';
  this.formData = _.cloneDeep(ruleTemplate);
}

function mapSelectedEquipment(equipmentTypes) {
  let equipments = this.equipmentsEnum.filter((obj1) => equipmentTypes.find((obj2) => obj1.displayValue === obj2.displayValue));
  equipments = _.unionBy((equipments || []), equipments, 'value.code');
  return equipments.map((item) => (item.value));
}

function formatPayload() {
  const formattedPayload = _.cloneDeep(this.formData);
  const {
    fromLocation,
    toLocation,
    maxApptsPerDay,
    fromAppointmentRule,
    toAppointmentRule,
    customer,
    equipmentTypes,
    modes,
    ruleStartDate,
    ruleEndDate
  } = this.formData;
  const { hours: fromHours, diffType: fromDiffType } = fromAppointmentRule;
  const { hours: toHours, diffType: toDiffType } = toAppointmentRule;
  const fromHoursVal = (fromHours && !this.isFromHoursDisabled) ? parseInt(fromHours, 10) : 0;
  const toHoursVal = toHours ? parseInt(toHours, 10) : 0;
  formattedPayload.fromAppointmentRule.fromApptRule = fromAppointmentRule.fromApptRule || '';
  formattedPayload.fromAppointmentRule.userTime = fromAppointmentRule.userTime ? _.replace(fromAppointmentRule.userTime, /[A-Za-z]/g, '0') : '';
  formattedPayload.toAppointmentRule.toApptRule = toAppointmentRule.toApptRule || '';
  formattedPayload.toAppointmentRule.userTime = toAppointmentRule.userTime ? _.replace(toAppointmentRule.userTime, /[A-Za-z]/g, '0') : '';
  formattedPayload.fromAppointmentRule.hours = fromDiffType === this.plusMinusEnum[1].value ? -fromHoursVal : fromHoursVal;
  formattedPayload.toAppointmentRule.hours = toDiffType === this.plusMinusEnum[1].value ? -toHoursVal : toHoursVal;
  formattedPayload.toLocation = formatLocationPayload(toLocation);
  formattedPayload.fromLocation = formatLocationPayload(fromLocation);
  formattedPayload.maxApptsPerDay = maxApptsPerDay.map((item) => parseInt(item, 10));
  formattedPayload.customer = { name: customer.name, id: customer.value };
  formattedPayload.equipmentTypes = this.mapSelectedEquipment(equipmentTypes);
  formattedPayload.modes = modes.map((item) => item.value);
  formattedPayload.ruleEndDate = ruleEndDate || '';
  formattedPayload.ruleStartDate = ruleStartDate || '';
  return formattedPayload;
}

/**
 * If form is valid then submit formatted payload else validate the form
 */
async function submit() {
  this.maxApptsPerDayConflict = '';
  try {
    this.processingForm = true;
    const updateMessage = this.isEditForm ? 'updated' : 'created';
    if (this.isEditForm) {
      await appointmentRulesService.updateAppointmentRule(this.formatPayload());
      setGoogleAnalytics('Edit auto appointment rule');
      this.$store.dispatch('appointmentRulesStore/updateEditStatus', false);
      this.$store.dispatch('appointmentRulesStore/updateEditFormData', {});
    } else {
      await appointmentRulesService.postAppointmentRule(this.formatPayload());
      if (this.isCopyingRule) {
        this.$store.dispatch('appointmentRulesStore/updateCopyStatus', false);
        this.$store.dispatch('appointmentRulesStore/updateCopyRuleData', {});
        setGoogleAnalytics('Copy auto appointment rule');
      } else {
        setGoogleAnalytics('Created auto appointment rule');
      }
    }
    HgNotificationService.successMessage(`Appointment rule ${updateMessage} successfully`);
    this.processingForm = false;
    this.$store.dispatch('appointmentRulesStore/updateRefreshGrid', true);
    this.toggleForm(false);
    this.resetForm();
  } catch (error) {
    this.processingForm = false;
    console.error('error in submit function: ', error);
    if (error.response.data.message === 'Duplicate rule') {
      const conflictingRuleId = error.response.data.errorCode.cause.join(', ');
      const BODY = appointmentRulesEnum.MODALS.DUPLICATE.BODY + conflictingRuleId;
      const { CONFIRM_BUTTON_TEXT } = appointmentRulesEnum.MODALS.DUPLICATE;
      await this.$refs.confirm.open(error.response.data.message, BODY, CONFIRM_BUTTON_TEXT);
    } else if (error.response.data.message === 'Location conflicts') {
      this.locationConflicts(error.response.data.errorCode.cause);
    } else if (error.response.data.message === 'Duplicate location') {
      this.duplicateLocation(error.response.data.errorCode.cause);
    } else {
      HgNotificationService.errorMessage(Vue, 'Error when saving appointment rule data');
    }
  }
}

function locationConflicts(conflicts) {
  this.maxApptsPerDayConflict = appointmentRulesEnum.VALIDATION_ERRORS.MAX_APPT_PER_DAY.CONFLICT;

  const locationType = (_.get(this.formData, 'ruleType', '') === appointmentRulesEnum.APPOINTMENT_RULE_TYPES[0].value) ? 'from' : 'to';

  const daysWithConflict = _.get(conflicts, 'colidingIndexes', []);
  const locationsWithConflict = _.get(conflicts, 'locationIds', []);

  this.maxApptsConflictCounter = daysWithConflict.lenght + locationsWithConflict.length;

  daysWithConflict.forEach((day) => {
    const element = this.$refs[`maxAppointmentPerDay_${day}`][0].$el;
    element.classList.add('error-class');
  });
  locationsWithConflict.forEach((location) => {
    const locationComponent = this.$refs[`${locationType}_${location}_autocomplete`][0].$children[0].$el;
    locationComponent.classList.add('error-class');
  });
}

function duplicateLocation(locations) {
  const fromLocations = _.get(locations, 'fromLocations', {});
  const toLocations = _.get(locations, 'toLocations', {});

  if (!_.isEmpty(fromLocations)) {
    this.duplicateFromLocationsError = appointmentRulesEnum.VALIDATION_ERRORS.DUPLICATE_LOCATIONS;
    Object.entries(fromLocations).forEach(([key, values]) => {
      values.forEach((value, index) => {
        const locationComponent = this.$refs[`from_${key}_autocomplete`][index].$children[0].$el;
        locationComponent.classList.add('error-class');
      });
    });
  }

  if (!_.isEmpty(toLocations)) {
    this.duplicateToLocationsError = appointmentRulesEnum.VALIDATION_ERRORS.DUPLICATE_LOCATIONS;
    Object.entries(toLocations).forEach(([key, values]) => {
      values.forEach((value, index) => {
        const locationComponent = this.$refs[`to_${key}_autocomplete`][index].$children[0].$el;
        locationComponent.classList.add('error-class');
      });
    });
  }
}

function addLocationForm(key, length) {
  const locationDefaultItem = {
    searchValue: '',
    exclude: false,
    locationList: []
  };
  if (length === 0) {
    this.formData[key] = [{ ...locationDefaultItem }];
    return;
  }
  for (let i = 0; i < length - 1; i++) {
    this.formData[key].push({ ...locationDefaultItem });
  }
}

function setFormData(formData) {
  const customerVal = formData.customer;
  this.formData.customer = {
    key: 'customer',
    label: 'Customer',
    name: customerVal.name,
    text: (customerVal.id ? `${customerVal.name}, ${customerVal.id}` : `${customerVal.name}, ${customerVal.value}`) || '',
    value: (customerVal.id ? customerVal.id : customerVal.value) || '',
  };
  this.onSearchTextChanged({
    value: (customerVal.id ? customerVal.id : customerVal.value) || '',
    searchText: (customerVal.id ? `${customerVal.name}, ${customerVal.id}` : `${customerVal.name}, ${customerVal.value}`) || '',
    name: customerVal.name,
    label: 'Customer',
    type: 'customer',
    prepopulate: false
  });
  const formKeys = Object.keys(formData);
  formKeys.forEach((key) => {
    const formDataValue = _.cloneDeep(formData[key]);
    if (key === 'customer' || key === 'considerDockHours' || key === 'equipmentTypes') {
      return;
    }
    if (key === 'toLocation' || key === 'fromLocation') {
      this.handleLocationPrepopulate(formDataValue, key);
      return;
    }
    if (key === 'modes') {
      const equipmentValues = _.cloneDeep(formData.equipmentTypes);
      this.handleModeEquipmentPrepopulate(formDataValue, equipmentValues);
      return;
    }
    if (key === 'fromAppointmentRule' || key === 'toAppointmentRule') {
      formDataValue.diffType = parseInt(formDataValue.hours, 10) >= 0
        ? appointmentRulesEnum.PLUS_MINUS[0].value
        : appointmentRulesEnum.PLUS_MINUS[1].value;
      formDataValue.hours = !Number.isNaN(parseInt(formDataValue.hours, 10)) ? Math.abs(parseInt(formDataValue.hours, 10)) : 0;
    }
    this.formData[key] = formDataValue;
  });
  if (this.formData.toLocation.length > 1) this.formData.toLocation = _.filter(this.formData.toLocation, (location) => location.searchValue !== '');
  if (this.formData.fromLocation.length > 1) this.formData.fromLocation = _.filter(this.formData.fromLocation, (location) => location.searchValue !== '');
  // evaluate at the end to make this bypass location checks
  this.formData.considerDockHours = _.cloneDeep(formData.considerDockHours);
}

function handleModeEquipmentPrepopulate(modeValues, equipmentValues) {
  modeValues = _.union(modeValues);
  if (_.isEmpty(this.lovData.modesEnum)) return;
  this.lovData.modesEnum.forEach((item) => {
    if (modeValues.indexOf(item.displayValue) > -1) {
      this.onModeChange(item, true);
    }
  });
  const equipmentTypeDisplayValues = equipmentValues.map((item) => `${item.type}${item.length}`);
  this.allEquipmentsEnum = _.unionBy((this.allEquipmentsEnum || []), this.allEquipmentsEnum, 'displayValue');
  this.allEquipmentsEnum.forEach((item) => {
    if (equipmentTypeDisplayValues.indexOf(item.displayValue) > -1) {
      this.onEquipmentChange(item, true);
    }
  });
}

function handleLocationPrepopulate(formDataValue, key) {
  this.addLocationForm(key, formDataValue.length);
  formDataValue.forEach((locationItem, index) => {
    this.formData[key][index].exclude = locationItem.exclude;
    this.onSearchTextChanged(
      {
        type: key,
        searchText: locationItem.searchValue || '',
        prepopulate: true
      },
      index
    );
  });
}

export default {
  name: 'CreateRulesComponent',
  components: {
    VueTimepicker,
    hgAutocomplete,
    DatetimePickerComponent,
    HgConfirmActionModal,
    HgMultiSelect
  },
  data: () => data,
  props: {
    lovData: {
      type: Object,
      default: _.cloneDeep(appointmentRulesService.lovDataTemplate)
    },
    entitlements: {
      type: Object,
      default: _.cloneDeep(appointmentRulesService.defaultEntitlements)
    }
  },
  async created() {
    const isFormOpen = this.$store.getters['appointmentRulesStore/getFormOpenState'];
    if (!isFormOpen) {
      if (this.showForm) {
        this.cancelForm();
      }
      await this.initialiseData();
    }
  },
  computed: {
    toAppointmentRulesList() {
      return this.getAppointmentRules(appointmentRulesEnum.OUTCOME_TYPE.TO);
    },
    fromAppointmentRulesList() {
      return this.getAppointmentRules(appointmentRulesEnum.OUTCOME_TYPE.FROM);
    },
    isValidForm() {
      return this.checkFormValidations();
    },
    isEditForm() {
      return this.$store.getters['appointmentRulesStore/getEditFormState'];
    },
    isViewForm() {
      return this.$store.getters['appointmentRulesStore/getViewFormState'];
    },
    isCopyingRule() {
      return this.$store.getters['appointmentRulesStore/getIsCopyingRule'];
    },
    shouldResetForm() {
      return this.$store.getters['appointmentRulesStore/getFormResetState'];
    }
  },
  watch: {
    isEditForm: {
      handler() {
        const editStatus = this.$store.getters['appointmentRulesStore/getEditFormState'];
        if (editStatus) {
          this.toggleForm(true);
          const editFormData = this.$store.getters['appointmentRulesStore/getEditFormData'];
          this.setFormData(editFormData);
        }
      }
    },
    isViewForm: {
      handler() {
        const viewStatus = this.$store.getters['appointmentRulesStore/getViewFormState'];
        if (viewStatus) {
          this.toggleForm(true);
          const viewFormData = this.$store.getters['appointmentRulesStore/getViewFormData'];
          this.setFormData(viewFormData);
        }
      }
    },
    isCopyingRule: {
      handler(val) {
        if (val) {
          this.toggleForm(true);
          const copyRuleData = this.$store.getters['appointmentRulesStore/getCopyRuleData'];
          this.setFormData(copyRuleData);
        }
      }
    },
    shouldResetForm: {
      handler(val) {
        if (val) {
          this.cancelForm();
          this.$store.dispatch('appointmentRulesStore/updateFormResetStatus', false);
        }
      }
    },
    toAppointmentRulesList: {
      handler(val) {
        this.validateSelectedAppointmentRules(appointmentRulesEnum.OUTCOME_TYPE.TO.toLowerCase(), val);
      }
    },
    fromAppointmentRulesList: {
      handler(val) {
        this.validateSelectedAppointmentRules(appointmentRulesEnum.OUTCOME_TYPE.FROM.toLowerCase(), val);
      }
    }
  },
  methods: {
    toggleForm,
    cancelForm,
    getColor,
    removeLocationItem,
    submit,
    initialiseData,
    formatDropdownLabel,
    formatDropdownLabelSorted,
    formatDropdownText,
    formatDropdownValue,
    updateFormData,
    addLocationItem,
    getAppointmentRules,
    getTriggerItems,
    isCheckedRadioItem,
    toggleHoursDiffType,
    getCdnImageUrl,
    isAllLocationCheckDisabled,
    onSearchTextChanged,
    onDateTimeChange,
    onValueSelected,
    checkFormValidations,
    formatLocationPayload,
    resetForm,
    mapSelectedEquipment,
    formatPayload,
    setFormData,
    onModeChange,
    onEquipmentChange,
    onMultiSelectChange,
    setValidDateTime,
    addLocationForm,
    setGoogleAnalytics,
    onRuleTypeChange,
    forceRerender,
    handleModeEquipmentPrepopulate,
    handleLocationPrepopulate,
    locationConflicts,
    duplicateLocation,
    handleResetCustomer,
    hasLocationDataFilled,
    validateSelectedAppointmentRules,
    copyRule,
    editRule
  }
};
