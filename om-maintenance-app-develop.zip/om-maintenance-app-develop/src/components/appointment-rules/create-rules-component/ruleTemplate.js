import appointmentRulesEnum from '../../../enums/appointment-rules.enum';

const ruleTemplate = {
  ruleType: '',
  maxApptsPerDay: [null, null, null, null, null, null, null],
  ruleStartDate: '',
  ruleEndDate: '',
  isApptRequired: appointmentRulesEnum.YES_NO[0].value,
  fromAllLocations: false,
  toAllLocations: false,
  considerDockHours: false,
  customer: {
    id: '',
    name: ''
  },
  modes: [],
  ruleTrigger: '',
  equipmentTypes: [],
  fromAppointmentRule: {
    fromApptRule: '',
    hours: 0,
    userTime: '',
    diffType: appointmentRulesEnum.PLUS_MINUS[0].value
  },
  toAppointmentRule: {
    toApptRule: '',
    hours: 0,
    userTime: '',
    diffType: appointmentRulesEnum.PLUS_MINUS[0].value
  },
  fromLocation: [
    {
      searchValue: '',
      exclude: false,
      locationList: []
    }
  ],
  toLocation: [
    {
      searchValue: '',
      exclude: false,
      locationList: []
    }
  ]
};

export default ruleTemplate;
