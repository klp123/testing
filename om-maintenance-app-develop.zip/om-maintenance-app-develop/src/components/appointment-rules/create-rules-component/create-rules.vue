<template>
  <div>
    <HgConfirmActionModal ref="confirm" />
    <v-card>
      <v-card-title>
        <v-row justify="space-between">
          <v-col cols="11" class="pt-4">
            <label class="title" v-if="isEditForm || isViewForm">
              <div v-if="isEditForm || isViewForm">
                <label class="ruleId-label" v-if="isViewForm"> View</label>
                <label class="ruleId-label" v-if="isEditForm"> Edit</label>
                <label class="ruleId"> Rule ID: {{ formData.ruleId }} </label>
              </div>
              Customer: {{ formData.customer.name }} ({{
                formData.customer &&
                (formData.customer.id || formData.customer.value)
              }})
            </label>
            <label class="title ruleId-label" v-else>Create</label>
          </v-col>
          <v-col cols="1">
            <div class="section">
              <v-card-actions class="actionItems">
                <hg-lib-btn
                  v-if="!showForm && entitlements.canCreate"
                  title="Create Rule"
                  type="primary"
                  @click.native="toggleForm(true)"
                />
                <v-tooltip top v-if="isViewForm && entitlements.canEdit">
                    <template v-slot:activator="{ on, attrs }">
                      <v-btn
                        v-bind="attrs"
                        v-on="on"
                        icon
                        class="info-icon info-icon-tooltip mr-5"
                        width="24"
                        @click="editRule()"
                      >
                            <img
                              style = "width:25px;height:25px"
                              :src="getCdnImageUrl(CdnImagesEnum.edit_icon)"
                            />
                      </v-btn>
                    </template>
                    <span
                      >Edit Rule</span
                    >
                  </v-tooltip>
                  <v-tooltip top v-if="isViewForm && entitlements.canCreate">
                    <template v-slot:activator="{ on, attrs }">
                      <v-btn
                        v-bind="attrs"
                        v-on="on"
                        icon
                        class="info-icon info-icon-tooltip"
                        width="24"
                        @click="copyRule()"
                      >
                        <i aria-hidden="true"  class="v-icon notranslate mdi mdi-content-copy theme--light" style="font-size: 26px;"></i>
                      </v-btn>
                    </template>
                    <span
                      >Copy Rule</span
                    >
                  </v-tooltip>
              </v-card-actions>
            </div>
          </v-col>
        </v-row>
      </v-card-title>
      <div v-if="showForm && !(isEditForm || isViewForm)" class="customerName">
        <label class="field-label">CUSTOMER NAME AND #</label>
        <img
          class="label-required"
          :src="getCdnImageUrl(CdnImagesEnum.required_icon)"
        />
        <HgAutocomplete
          clearable
          :searchType="'customer'"
          :key="`${formData.customer}_${forceRender}`"
          returnObject
          :placeholder="'Search for customer name or id'"
          :items="customerList || []"
          :itemText="'text'"
          :backgroundColor="getColor('color_white')"
          :prepopulateItem="formData.customer"
          @onSearchTextChanged="onSearchTextChanged($event)"
          @onValueSelected="onValueSelected($event)"
          id="customer-autocomplete"
        />
      </div>
      <div v-if="showForm">
        <v-form
          class="appointmentRuleCreateForm"
          ref="appointmentRuleCreateForm"
        >
          <div class="mainForm">
            <div class="label-section">
              <div>
                <label class="title">Rule Conditions</label>
              </div>
              <div />
              <div>
                <label class="title pl-3">Rule Outcome</label>
              </div>
            </div>
            <div id="form-detail-view">
              <div class="section">
                <div class="section-body main-section-details">
                  <div class="section-border">
                    <div class="section">
                      <div class="section-body section-details">
                        <div>
                          <div class="mandatoryItems">
                            <label class="section-label"
                              >PICKUP OR DELIVERY</label
                            >
                            <img
                              class="label-required"
                              :src="getCdnImageUrl(CdnImagesEnum.required_icon)"
                            />
                          </div>
                          <div
                            class="section-value"
                            v-bind:class="{
                              'view-read-only': isViewForm
                            }"
                          >
                            <hg-autocomplete
                              :disabled=isViewForm
                              :searchType="'ruleType'"
                              ref="appointmentTypeInput"
                              :items="appointmentRuleTypesEnum"
                              :itemText="formatDropdownText"
                              :itemValue="formatDropdownValue"
                              :defaultValue="formData.ruleType"
                              @input="onRuleTypeChange($event)"
                              clearable
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="section">
                      <div class="section-body">
                        <div>
                          <div class="mandatoryItems">
                            <label class="section-label">TRIGGER</label>
                            <img
                              class="label-required"
                              :src="getCdnImageUrl(CdnImagesEnum.required_icon)"
                            />
                          </div>
                          <div
                            class="section-value"
                            v-bind:class="{
                              'view-read-only': isViewForm
                            }"
                          >
                            <hg-autocomplete
                              :disabled=isViewForm
                              :key="`${formData.ruleTrigger}_${forceRender}`"
                              :searchType="'triggerInput'"
                              ref="triggerInput"
                              :items="getTriggerItems()"
                              :itemText="formatDropdownLabelSorted"
                              :itemValue="formatDropdownValue"
                              :defaultValue="formData.ruleTrigger"
                              @input="updateFormData($event, 'ruleTrigger')"
                              clearable
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="section">
                      <div class="section-body">
                        <div>
                          <div class="mandatoryItems">
                            <label class="section-label">MODE</label>
                            <img
                              class="label-required"
                              :src="getCdnImageUrl(CdnImagesEnum.required_icon)"
                            />
                          </div>
                          <div
                            v-if="!isViewForm"
                            class="section-value"
                            v-bind:class="{
                              'view-read-only': isViewForm
                            }"
                          >
                            <HgMultiSelect
                              ref="modeInput"
                              :disabled=isViewForm
                              :items="lovData.modesEnum || []"
                              :selectedItems="formData.modes"
                              @onItemChecked="onModeChange($event, true)"
                              @onItemUnchecked="onModeChange($event, false)"
                            />
                          </div>
                          <div v-if="isViewForm">
                            <span class = "chip-manual-style" v-for="(item, index) in formData.modes" :key="index">
                                {{ item.displayValue }}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="section pt-3 pb-6">
                      <div class="section-body">
                        <div>
                          <div class="mandatoryItems">
                            <label class="section-label">EQUIPMENT</label>
                            <img
                              class="label-required"
                              :src="getCdnImageUrl(CdnImagesEnum.required_icon)"
                            />
                          </div>
                          <div
                            v-if="!isViewForm"
                            class="section-value"
                            v-bind:class="{
                              'view-read-only': isViewForm
                            }"
                          >
                            <HgMultiSelect
                              ref="equipmentInput"
                              :disabled="!(formData.modes.length) || isViewForm"
                              :items="allEquipmentsEnum || []"
                              :selectedItems="formData.equipmentTypes"
                              @onItemChecked="onEquipmentChange($event, true)"
                              @onItemUnchecked="
                                onEquipmentChange($event, false)
                              "
                            />
                          </div>
                          <div v-if="isViewForm">
                            <span class = "chip-manual-style" v-for="(item, index) in formData.equipmentTypes" :key="index">
                                {{ item.displayValue }}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="location-form-items">
                    <div class="section section-border">
                      <div class="section-body">
                        <div>
                          <div class="mandatoryItems">
                            <label class="section-label">
                              FROM
                              <span class="errorDetails" v-if="duplicateFromLocationsError">{{
                              duplicateFromLocationsError
                             }}</span>
                            </label>
                            <img
                              class="label-required"
                              :src="getCdnImageUrl(CdnImagesEnum.required_icon)"
                            />
                          </div>
                          <div
                            v-for="(location, index) of formData.fromLocation"
                            :key="`from_${location.searchValue}_${index}`"
                          >
                            <div
                              class="locationContainer section-value mb-5"
                              v-bind:class="{
                                'view-read-only': isViewForm
                              }"
                              >
                              <HgAutocomplete
                                clearable
                                returnObject
                                :key="`from_${location.searchValue}_${index}_autocomplete`"
                                :ref="`from_${location.searchValue}_autocomplete`"
                                :searchType="'fromLocation'"
                                :placeholder="'Enter City or Location ID…'"
                                :prepopulateItem="
                                  formData.fromLocation[index].value
                                "
                                :items="
                                  formData.fromLocation[index].locationList ||
                                  []
                                "
                                :itemText="'text'"
                                :backgroundColor="getColor('color_white')"
                                :disabled="
                                  !(
                                    formData.customer &&
                                    (formData.customer.id ||
                                      formData.customer.value)
                                  ) || isViewForm
                                "
                                @onSearchTextChanged="
                                  onSearchTextChanged($event, index)
                                "
                                @onValueSelected="
                                  onValueSelected($event, index)
                                "
                                id="location-autocomplete"
                              />
                              <v-checkbox
                                class="ma-0 ml-1 pa-0 mt-2 checkbox-label"
                                hide-details
                                :color="getColor('color_primary_blue')"
                                :disabled="
                                  !formData.fromLocation[index].searchValue || isViewForm
                                "
                                v-model="formData.fromLocation[index].exclude"
                                v-bind:class="{
                                  disabledCheckboxLabel:
                                    !formData.fromLocation[index].searchValue
                                }"
                                :label="'Exclude'"
                              ></v-checkbox>
                              <v-checkbox
                                v-if="index === 0"
                                class="ma-0 pa-0 pr-0 mr-0 mt-2 checkbox-label text-center"
                                :color="getColor('color_primary_blue')"
                                v-bind:class="{
                                  disabledCheckboxLabel:
                                    isAllLocationCheckDisabled(
                                      'fromLocation',
                                      'fromAllLocations'
                                    )
                                }"
                                hide-details
                                v-model="formData.fromAllLocations"
                                :disabled="
                                  isAllLocationCheckDisabled(
                                    'fromLocation',
                                    'fromAllLocations'
                                  ) || isViewForm
                                "
                                :label="'All'"
                              ></v-checkbox>
                              <div class="addLocation mt-2 ml-2" v-if="index === 0 && !(isViewForm)">
                                <label class="pointerEvent" @click="addLocationItem('fromLocation')">
                                  Add
                                </label>
                              </div>
                              <div v-if="formData.fromLocation.length > 1" class="ml-1">
                                <v-btn
                                  v-if="!isViewForm"
                                  icon
                                  @click="
                                    removeLocationItem('fromLocation', index)
                                  "
                                >
                                  <img
                                    :src="
                                      getCdnImageUrl(CdnImagesEnum.delete_icon)
                                    "
                                  />
                                </v-btn>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div>
                    <div class="section">
                      <div class="section-border section-body">
                        <div>
                          <div class="mandatoryItems">
                            <label class="section-label">
                              TO
                              <span class="errorDetails" v-if="duplicateToLocationsError">{{
                              duplicateToLocationsError
                             }}</span>
                            </label>

                            <img
                              class="label-required"
                              :src="getCdnImageUrl(CdnImagesEnum.required_icon)"
                            />
                          </div>
                          <div
                            v-for="(location, index) of formData.toLocation"
                            :key="`to_${location.searchValue}_${index}`"
                          >
                            <div
                              class="locationContainer section-value mb-5"
                              v-bind:class="{
                                'view-read-only': isViewForm
                              }"
                              >
                              <HgAutocomplete
                                clearable
                                returnObject
                                :key="`to_${location.searchValue}_${index}_autocomplete`"
                                :ref="`to_${location.searchValue}_autocomplete`"
                                :searchType="'toLocation'"
                                :placeholder="'Enter City or Location ID…'"
                                :prepopulateItem="
                                  formData.toLocation[index].value
                                "
                                :items="
                                  formData.toLocation[index].locationList || []
                                "
                                :itemText="'text'"
                                :backgroundColor="getColor('color_white')"
                                :disabled="
                                  !(
                                    formData.customer &&
                                    (formData.customer.id ||
                                      formData.customer.value)
                                  ) || isViewForm
                                "
                                @onSearchTextChanged="
                                  onSearchTextChanged($event, index)
                                "
                                @onValueSelected="
                                  onValueSelected($event, index)
                                "
                                id="location-autocomplete"
                              />
                              <v-checkbox
                                class="ma-0 ml-1 pa-0 pr-0 mr-0 mt-2 checkbox-label"
                                :color="getColor('color_primary_blue')"
                                hide-details
                                :disabled="
                                  !formData.toLocation[index].searchValue || isViewForm
                                "
                                v-model="formData.toLocation[index].exclude"
                                v-bind:class="{
                                  disabledCheckboxLabel:
                                    !formData.toLocation[index].searchValue
                                }"
                                :label="'Exclude'"
                              ></v-checkbox>
                              <v-checkbox
                                v-if="index === 0"
                                class="ma-0 pa-0 pr-0 mr-0 mt-2 checkbox-label"
                                :color="getColor('color_primary_blue')"
                                v-bind:class="{
                                  disabledCheckboxLabel:
                                    isAllLocationCheckDisabled(
                                      'toLocation',
                                      'toAllLocations'
                                    )
                                }"
                                hide-details
                                v-model="formData.toAllLocations"
                                :disabled="
                                  isAllLocationCheckDisabled(
                                    'toLocation',
                                    'toAllLocations'
                                  ) || isViewForm
                                "
                                :label="'All'"
                              ></v-checkbox>
                              <div class="addLocation mt-2 ml-2" v-if="index === 0 && !(isViewForm)">
                                <label class="pointerEvent" @click="addLocationItem('toLocation')">
                                  Add
                                </label>
                              </div>
                              <div v-if="formData.toLocation.length > 1" class="ml-1">
                                <v-btn
                                  v-if="!isViewForm"
                                  icon
                                  @click="
                                    removeLocationItem('toLocation', index)
                                  "
                                >
                                  <img
                                    :src="
                                      getCdnImageUrl(CdnImagesEnum.delete_icon)
                                    "
                                  />
                                </v-btn>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="section-border">
                    <div class="section">
                      <div class="section-body appointmentRuleSection">
                        <div>
                          <div class="mandatoryItems">
                            <label class="section-label"
                              >FROM APPOINTMENT RULE</label
                            >
                            <img
                              class="label-required"
                              :src="getCdnImageUrl(CdnImagesEnum.required_icon)"
                            />
                          </div>
                          <div
                            class="section-value"
                            v-bind:class="{
                              'view-read-only': isViewForm
                            }"
                          >
                            <hg-autocomplete
                              :disabled= isViewForm
                              :key="`${formData.fromAppointmentRule.fromApptRule}_${forceRender}`"
                              :searchType="'fromAppointmentRule'"
                              ref="fromAppointmentRuleInput"
                              :items="fromAppointmentRulesList"
                              :itemText="formatDropdownLabel"
                              :itemValue="formatDropdownValue"
                              :defaultValue="
                                formData.fromAppointmentRule.fromApptRule
                              "
                              v-model="
                                formData.fromAppointmentRule.fromApptRule
                              "
                              clearable
                            />
                          </div>
                        </div>
                        <div>
                          <div class="section-label">HOURS +/-</div>
                          <div
                            class="hoursDiffWrapper"
                            v-bind:class="{
                              'view-read-only': isViewForm || isFromHoursDisabled
                            }"
                          >
                            <v-btn
                              class="hoursDiffButton"
                              v-bind:class="{
                                'disabledDateTime': isViewForm || isFromHoursDisabled
                              }"
                              :disabled="isViewForm || isFromHoursDisabled"
                              @click="
                                toggleHoursDiffType('fromAppointmentRule')
                              "
                            >
                              {{ formData.fromAppointmentRule.diffType }}
                              <v-icon
                                :disabled="isViewForm || isFromHoursDisabled"
                              >mdi-chevron-down</v-icon>
                            </v-btn>
                            <v-text-field
                              onkeypress='return event.charCode >= 48 && event.charCode <= 57'
                              :disabled="isViewForm || isFromHoursDisabled"
                              hide-details="true"
                              outlined
                              dense
                              type="number"
                              hide-spin-buttons
                              v-model="formData.fromAppointmentRule.hours"
                            ></v-text-field>
                          </div>
                          <label
                            class="errorDetails"
                            v-if="appointmentFromHoursError"
                            >{{ appointmentFromHoursError }}</label
                          >
                        </div>
                      </div>
                      <div class="section">
                      <div class="section-body appointmentRuleSection">
                        <v-row class="pb-3">
                          <v-col>
                            <div class="section-label">Select Time</div>
                            <div
                              class="section-value"
                              v-bind:class="{
                                'view-read-only': isViewForm
                              }"
                            >
                              <vue-timepicker
                                :disabled=isViewForm
                                auto-scroll
                                manual-input
                                close-on-complete
                                v-model="formData.fromAppointmentRule.userTime"
                                :key="forceRender"
                                @change="onDateTimeChange()"
                                drop-direction="up"
                                format="HH:mm"
                                input-width="125px"
                              ></vue-timepicker>
                            </div>
                            <label class="errorDetails" v-if="selectFromTimeError">{{
                              selectFromTimeError
                            }}</label>
                          </v-col>
                        </v-row>
                      </div>
                    </div>
                      <div class="appointmentFlags">
                        <v-checkbox
                          class="ma-0 pa-0 checkbox-label"
                          hide-details
                          :color="getColor('color_primary_blue')"
                          v-model="formData.considerDockHours"
                          :disabled="isDockHoursDisabled || isViewForm"
                          :label="'Consider Dock Hours'"
                          v-bind:class="{
                            disabledCheckboxLabel: isDockHoursDisabled
                          }"
                        ></v-checkbox>
                        <v-tooltip top>
                          <template v-slot:activator="{ on, attrs }">
                            <v-btn
                              v-bind="attrs"
                              v-on="on"
                              icon
                              class="info-icon info-icon-tooltip"
                              width="24"
                            >
                              <v-icon size="large" class="arrow"
                                >mdi-information-outline</v-icon
                              >
                            </v-btn>
                          </template>
                          <span
                            >Specific location Id is required for dock
                            hours</span
                          >
                        </v-tooltip>
                      </div>
                    </div>
                    <div class="section">
                      <div class="section-body appointmentRuleSection">
                        <div>
                          <div class="mandatoryItems">
                            <label class="section-label"
                              >TO APPOINTMENT RULE</label
                            >
                            <img
                              class="label-required"
                              :src="getCdnImageUrl(CdnImagesEnum.required_icon)"
                            />
                          </div>
                          <div
                            class="section-value"
                            v-bind:class="{
                              'view-read-only': isViewForm
                            }"
                          >
                            <hg-autocomplete
                              :disabled= isViewForm
                              :key="`${formData.toAppointmentRule.toApptRule}_${forceRender}`"
                              :searchType="'toAppointmentRule'"
                              ref="toAppointmentRuleInput"
                              :items="toAppointmentRulesList"
                              :itemText="formatDropdownLabel"
                              :itemValue="formatDropdownValue"
                              :defaultValue="
                                formData.toAppointmentRule.toApptRule
                              "
                              v-model="formData.toAppointmentRule.toApptRule"
                              clearable
                            />
                          </div>
                        </div>
                        <div>
                          <div class="section-label">HOURS +/-</div>
                          <div
                            class="hoursDiffWrapper"
                            v-bind:class="{
                              'view-read-only': isViewForm || isToHoursDisabled
                            }"
                          >
                            <v-btn
                              class="hoursDiffButton"
                              v-bind:class="{
                                'disabledDateTime': isViewForm || isToHoursSignDisabled || isToHoursDisabled
                              }"
                              :disabled="isViewForm || isToHoursDisabled"
                              @click="toggleHoursDiffType('toAppointmentRule')"
                            >
                              {{ formData.toAppointmentRule.diffType }}
                              <v-icon
                                :disabled="isViewForm || isToHoursSignDisabled || isToHoursDisabled"
                              >mdi-chevron-down</v-icon>
                            </v-btn>
                            <v-text-field
                              onkeypress='return event.charCode >= 48 && event.charCode <= 57'
                              :disabled="isViewForm || isToHoursDisabled"
                              hide-details="true"
                              outlined
                              dense
                              hide-spin-buttons
                              type="number"
                              v-model="formData.toAppointmentRule.hours"
                            ></v-text-field>
                        </div>
                        <label
                            class="errorDetails"
                            v-if="appointmentToHoursError"
                            >{{ appointmentToHoursError }}</label
                          >
                      </div>
                    </div>
                    <div class="section">
                      <div class="section-body appointmentRuleSection">
                        <v-row class="pb-3" v-if="formData.toAppointmentRule.toApptRule === 'USERSPECIFIED_DATETIME'">
                          <v-col>
                            <div class="mandatoryItems pb-0">
                              <label class="section-label">Select Time</label>
                              <img
                                class="label-required"
                                :src="
                                  getCdnImageUrl(CdnImagesEnum.required_icon)
                                "
                              />
                            </div>
                            <div
                              class="section-value"
                              v-bind:class="{
                                'view-read-only': isViewForm
                              }"
                            >
                              <vue-timepicker
                                :disabled=isViewForm
                                auto-scroll
                                close-on-complete
                                manual-input
                                v-model="formData.toAppointmentRule.userTime"
                                drop-direction="up"
                                format="HH:mm"
                                input-width="125px"
                              ></vue-timepicker>
                            </div>
                            <label class="errorDetails" v-if="selectToTimeError">{{
                              selectToTimeError
                            }}</label>
                          </v-col>
                        </v-row>
                      </div>
                    </div>
                    <label class="errorDetails" v-if="appointmentRuleError">{{
                      appointmentRuleError
                    }}</label>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="actionsContainer">
            <div class="section">
              <label class="section-label"
                ># OF MAX APPOINTMENTS PER DAY<span class="optionalText">
                  <i> -optional</i>
                  <v-tooltip top>
                    <template v-slot:activator="{ on, attrs }">
                      <v-btn
                        v-bind="attrs"
                        v-on="on"
                        icon
                        class="info-icon info-icon-tooltip"
                        width="24"
                      >
                        <v-icon size="large" class="arrow"
                          >mdi-information-outline</v-icon
                        >
                      </v-btn>
                    </template>
                    <span
                      >Specific location ID is needed for updating this
                      field</span
                    >
                  </v-tooltip>
                </span></label
              >
              <div class="appointmentDays">
                <div
                  v-for="(appointmentPerDay, index) of weekdaysEnum"
                  :key="appointmentPerDay.label"
                  :class="{
                    'striped-class': index % 2 === 1
                  }"
                >
                  <div>
                    <label class="section-sub-header pl-1 pr-1">{{
                      appointmentPerDay.label
                    }}</label
                    ><br />
                    <div
                      class="appointmentCount"
                      v-bind:class="{
                        'view-read-only': isViewForm
                      }"
                    >
                      <v-text-field
                        :disabled=isViewForm
                        :ref="`maxAppointmentPerDay_${index}`"
                        hide-details="true"
                        outlined
                        dense
                        type="number"
                        maxlength="3"
                        hide-spin-buttons
                        v-model="formData.maxApptsPerDay[index]"
                      ></v-text-field>
                    </div>
                  </div>
                </div>
              </div>
              <label class="errorDetails" v-if="maxApptsPerDayError">{{
                maxApptsPerDayError
              }}</label>
            </div>
            <div class="section maxConflicts">
              <label class="errorDetails" style="font-weight: bold" v-if="maxApptsPerDayConflict">
                {{
                maxApptsPerDayConflict
              }}
              </label>
            </div>
            <div class="section pt-5">
              <label class="section-label"
                >RULE START DATE
                <span class="optionalText">
                  <i> -optional</i>
                  <v-btn icon height="18" width="24">
                    <v-icon size="large" class="arrow"
                      >mdi-information-outline</v-icon
                    >
                  </v-btn>
                </span>
              </label>
              <div
                class="timePickerWrapper"
                v-bind:class="{
                  'disabledDateTime view-read-only': isViewForm
                }"
              >
                <DatetimePickerComponent
                  ref="startDatetimePicker"
                  :dateTime="formData.ruleStartDate"
                  :config="dateTimeRangeConfig.start"
                  @dateTimeChanged="onDateTimeChange($event, 'ruleStartDate')"
                  @isValidDateTime="setValidDateTime($event, 'start')"
                />
              </div>
            </div>
            <div class="section pt-5">
              <label class="section-label"
                >RULE END DATE
                <span class="optionalText">
                  <i> -optional</i>
                  <v-btn icon height="18" width="24">
                    <v-icon size="large" class="arrow"
                      >mdi-information-outline</v-icon
                    >
                  </v-btn>
                </span>
              </label>
              <div
                class="timePickerWrapper"
                v-bind:class="{
                  'disabledDateTime view-read-only': isViewForm
                }"
              >
                <DatetimePickerComponent
                  ref="endDatetimePicker"
                  :dateTime="formData.ruleEndDate"
                  :config="dateTimeRangeConfig.end"
                  @dateTimeChanged="onDateTimeChange($event, 'ruleEndDate')"
                  @isValidDateTime="setValidDateTime($event, 'end')"
                />
              </div>
            </div>
            <div class="section pt-5">
              <label class="section-label">IS AN APPOINTMENT REQUIRED?</label>
              <v-list class="listItems" :disabled=isViewForm>
                <v-list-item
                  v-on:click="
                    updateFormData(optionType.value, 'isApptRequired')
                  "
                  v-for="(optionType, index) in yesOrNoEnum"
                  :key="`optionType_${index}`"
                  class="listItem"
                >
                  <v-list-item-action class="listItemAction">
                    <div class="input-wrapper">
                      <input
                        ref="radio"
                        type="radio"
                        class="radio-button"
                        :checked="isCheckedRadioItem(optionType.value)"
                        :id="`id-radio-value-${optionType.value}`"
                      />
                    </div>
                  </v-list-item-action>
                  <v-list-item-content>
                    <v-list-item-title class="list-title">
                      {{ optionType.label }}
                    </v-list-item-title>
                  </v-list-item-content>
                </v-list-item>
              </v-list>
            </div>
            <div class="section pt-10">
              <v-card-actions class="actionItems">
                <hg-lib-btn
                  :title="'Cancel'"
                  :type="'secondary'"
                  :disabled="false"
                  @click.native="cancelForm()"
                  id="cancel-form"
                />
                <hg-lib-btn
                  v-if="!(isEditForm || isViewForm)"
                  :title="'Create Rule'"
                  :type="'primary'"
                  :disabled="processingForm || !isValidForm"
                  @click.native="submit()"
                  id="submit-appointment-rule"
                />
                <hg-lib-btn
                  v-if="isEditForm"
                  :title="'Save Changes'"
                  :type="'primary'"
                  :disabled="processingForm || !isValidForm"
                  @click.native="submit()"
                  id="submit-appointment-rule"
                />
              </v-card-actions>
            </div>
          </div>
          </div>
        </v-form>
      </div>
    </v-card>
  </div>
</template>

<script src="./create-rules.js"></script>
<style src="./create-rules.sass" lang="sass" scoped></style>
