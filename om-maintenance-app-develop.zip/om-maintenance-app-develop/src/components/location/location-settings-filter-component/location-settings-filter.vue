<template>
    <div class="filter-container">
      <div class="d-flex justify-space-between">
        <div class="filter-components" id="filter-components">
          <hg-lib-menu-search-bar
            :items="filterParams.location.items || []"
            :filterKey="filterParams.location.filterKey"
            :placeholder="filterParams.location.placeholder"
            :menuLabel="filterParams.location.filterLabel"
            :selectedItems="selectedFilter('location')"
            :loading="loadingLocation"
            @searchTextChanged="locationTextChanged($event, 'Location')"
            @searchItemSelected="onFilterSelected($event)"
            @searchItemUnSelected="onFilterUnSelected($event)"
            @filterClosed="searchBarFilterClosed('LOCATION')"
            id="location-filter"
          />

          <hg-radio-field
            :subComponents="filterParams.status.subComponents || []"
            :filterLabel="filterParams.status.filterLabel"
            :selectedFields="selectedStatus"
            @onItemSelected="onFilterSelected($event)"
            @onUnItemSelected="onFilterUnSelected($event)"
          />

           <hg-lib-menu-search-bar
            :items="filterParams.customer.items || []"
            :filterKey="filterParams.customer.filterKey"
            :placeholder="filterParams.customer.placeholder"
            :menuLabel="filterParams.customer.filterLabel"
            :selectedItems="selectedFilter('customer')"
            :loading="loadingCustomersList"
            @searchTextChanged="customerSearchTextChanged($event)"
            @searchItemSelected="onFilterSelected($event)"
            @searchItemUnSelected="onFilterUnSelected($event)"
            @filterClosed="searchBarFilterClosed('CUSTOMER')"
            id="customer-filter"
          />
        </div>

        <div class="action-menu d-flex">
          <div class="d-flex flex-column">
            <hg-quick-search
              :quickSearchTypeState="
                filterParams.quickSearch.selectedSearchType
              "
              :selectedItems="selectedFilter('quickSearch')"
              @quickSearchChange="onFilterSelected($event)"
              @quickSearchTypeChange="onQuicksearchTypeChange($event)"
              :searchTypeList="filterParams.quickSearch.searchTypeList"
              :defaultSearchType="filterParams.quickSearch.defaultSearchType"
              id="quick-search"
            ></hg-quick-search>
          </div>
        </div>
      </div>

      <div class="current-filters">
        <hg-filter-display
          :selectedFilters="selectedFilter()"
          @clearFilters="onFilterUnSelected($event)"
          @clearAllFilters="onFilterUnSelected()"
        />
      </div>
    </div>
</template>

<script src="./location-settings-filter.js"></script>
<style src="./location-settings-filter.sass" lang="sass" scoped></style>
