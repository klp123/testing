import { AppSetupEnum } from '@hubgroup/hg-om-shared-services';
import FiltersService from '../../../services/filters/filters.service';
import HgSearchBar from '../../shared/filters/hg-search-bar/hg-search-bar.vue';
import HgQuickSearch from '../../shared/filters/hg-quick-search/hg-quick-search.vue';
import HgFilterDisplay from '../../shared/filters/hg-filter-display/hg-filter-display.vue';
import HgRadioField from '../../shared/filters/hg-radio-field/hg-radio-field.vue';
import customerService from '../../../services/orders/customer.service';
import locationService from '../../../services/location/location.service';
import localStorageService from '../../../services/local-storage/local-storage.service';

function redirectTo(url) {
  if (url) {
    this.$emit('redirectTo', url);
  }
}

async function customerSearchTextChanged(searchText) {
  this.loadingCustomersList = true;
  // Search only if search text length is greater than 2
  if (!searchText || searchText.length >= AppSetupEnum.MINIMUM_SEARCH_CHARACTER) {
    try {
      this.filterParams.customer.items = await customerService.searchCustomers(searchText);
      this.loadingCustomersList = false;
      this.searchBarKey = Math.random();
    } catch (e) {
      this.loadingCustomersList = false;
    }
  } else {
    this.loadingCustomersList = false;
  }
}

async function locationTextChanged(searchText, stop) {
  this.loadingLocation = true;
  searchText = (searchText || '').trim();
  if (searchText) {
    try {
      this.filterParams[stop.toLowerCase()].items = await
      locationService.searchLocation(searchText, stop);
      this.loadingLocation = false;
    } catch (e) {
      this.loadingLocation = false;
    }
  } else {
    this.loadingLocation = false;
  }
}

function onFilterSelected(selectedItem) {
  // Update filter in store
  this.$store.dispatch('locationSettingsStore/updateFilter', selectedItem);
  this.$store.dispatch('locationSettingsStore/updateResetPage', true);
  this.setLocalStorageFilter();
}

function onFilterUnSelected(filter) {
  if (filter) {
    // remove filter by catogory
    this.$store.dispatch('locationSettingsStore/removeFilter', filter);
  } else {
    // remove all filters
    this.$store.dispatch('locationSettingsStore/removeFilter');
  }
  this.$store.dispatch('locationSettingsStore/updateResetPage', true);
  this.setLocalStorageFilter();
}

function setLocalStorageFilter() {
  localStorageService.setLocalStorage('currentLocationSettingsFilter', this.$store.getters['locationSettingsStore/getFilters']);
}

async function selectLocalStorageFilter() {
  localStorageService.applyFilterFromLocalStorage('currentLocationSettingsFilter', this.onFilterSelected);
}

function selectedFilter(filterType) {
  return filterType ? this.$store.getters['locationSettingsStore/getFilters'][filterType] : this.$store.getters['locationSettingsStore/getFilters'];
}

function selectedStatus() {
  return {
    status: this.$store.getters['locationSettingsStore/getFilters'].status[0] || {},
  };
}

function searchBarFilterClosed(target) {
  switch (target) {
    case 'LOCATION':
      this.filterParams.location.items = [];
      break;

    case 'CUSTOMER':
      this.filterParams.customer.items = [];
      break;
    default:
      break;
  }
}

function onQuicksearchTypeChange(searchType) {
  this.filterParams.quickSearch.selectedSearchType = searchType;
}

const initData = {
  loadingLocation: false,
  loadingCustomersList: false,
  filterParams: FiltersService.locSetttingsFilterParams,
  searchBarKey: Math.random(),
};

// @vuese
// @group MAINTENANCE
// Location Settings Filter
export default {
  name: 'LocationSettingsFilter',
  data: () => (initData),
  components: {
    HgSearchBar,
    HgQuickSearch,
    HgRadioField,
    HgFilterDisplay,
  },
  props: {
    params: {
      type: Object,
      default: {},
    },
  },
  methods: {
    // @vuese
    // Used fire event on menu item click
    // @arg (url) clicked url
    redirectTo,
    // @vuese
    // Search customer if text changes on  search field
    // @arg (searchText)
    customerSearchTextChanged,
    // @vuese
    // Search location if text changes on  search field
    // @arg (searchText)
    locationTextChanged,
    // @vuese
    // Set filter to store if filter changes
    // @arg (selectedFileter)
    onFilterSelected,
    // @vuese
    // Remove filter from store
    // @arg (removedFilter)
    onFilterUnSelected,
    // @vuese
    // Get Selected filter
    // @arg (filterKey)
    selectedFilter,
    // @vuese
    // Sets filter to local storage
    setLocalStorageFilter,
    // @vuese
    // Apply filter from Local Storage
    selectLocalStorageFilter,
    // @vuese
    // Reset items on search bar closed
    // @arg (target)
    searchBarFilterClosed,
    onQuicksearchTypeChange,
  },
  computed: {
    selectedStatus,
  },
  mounted() {
    this.$nextTick(function init() {
      const item = {
        key: 'customer',
        label: 'Customer',
        text: `${this.params.customer.name}, ${this.params.customer.id}`,
        value: `${this.params.customer.id}`,
      };
      this.onFilterSelected(item);
    });
  },
  created() {
    selectLocalStorageFilter.bind(this)();
  },
};
