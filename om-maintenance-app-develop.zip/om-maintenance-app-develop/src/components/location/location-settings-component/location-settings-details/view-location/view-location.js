import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import { UtilitiesService } from '@hubgroup/hg-om-shared-services';
import { CountryPhoneCodesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';

function getColor(name) {
  return _colors[name];
}

function formatPhone(phoneNumber, countryCode) {
  if (!phoneNumber) return '-';
  const { code = '' } = CountryPhoneCodesEnum.find((c) => c.value === countryCode) || {};
  let formatPhoneNumber = `${phoneNumber.substring(0, 3)}-${phoneNumber.substring(3, 6)}-${phoneNumber.substring(6, 10)}`;
  if (code) {
    formatPhoneNumber = `(${code}) ${formatPhoneNumber}`;
  }

  return phoneNumber.length > 10 ? `${formatPhoneNumber} - Ext. ${phoneNumber.substring(10)}` : formatPhoneNumber;
}

// @vuese
// @group MAINTENANCE
// View page for location settings
export default {
  name: 'ViewLocation',
  props: {
    // Location settings object
    locationSettings: {
      type: Object,
      required: false,
      default: () => [],
    },
  },
  filters: {
    Titlecase(value) {
      return UtilitiesService.titleCase(value);
    },
  },
  methods: {
    // @vuese
    // Gets color for given color name
    // @arg (name) color name
    getColor,
    // @vuese
    // Formats phone number in countryCode-phoneNumber-extension
    // @arg (phoneNumber, countryCode)
    formatPhone,
  },
};
