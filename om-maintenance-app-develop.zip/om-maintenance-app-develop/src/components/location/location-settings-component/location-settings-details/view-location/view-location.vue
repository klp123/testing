<template>
  <div id="location-settings-detail-view">
    <div class="section">
      <div class="section-header">Details</div>
      <div class="section-body loc-details">
        <div>
          <div class="section-label">CUSTOMER NAME</div>
          <div class="section-value">
            <span v-if="locationSettings && locationSettings.customerName">
              {{ locationSettings.customerName || "-" }}
            </span>
            <span v-else>-</span>
          </div>
        </div>

        <div>
          <div class="section-label">CUSTOMER LOCATION ID</div>
          <div class="section-value">
            <span v-if="locationSettings && locationSettings.locationDetails">{{
              locationSettings.locationDetails.locationId || "-"
            }}</span>
            <span v-else>-</span>
            <p
              v-if="
                locationSettings &&
                locationSettings.locationDetails &&
                locationSettings.locationDetails.address
              "
              class="address ma-0"
            >
              {{ locationSettings.locationDetails.address }}
            </p>
          </div>
        </div>

        <div>
          <div class="section-label">CITY/STATE</div>
          <div class="section-value">
            <span
              v-if="
                locationSettings &&
                locationSettings.locationDetails &&
                (locationSettings.locationDetails.city ||
                  locationSettings.locationDetails.state)
              "
            >
              {{ locationSettings.locationDetails.city | Titlecase }}
              <span v-if="locationSettings.locationDetails.state">, </span>
              {{ locationSettings.locationDetails.state }}
            </span>
            <span v-else>-</span>
          </div>
        </div>

        <div>
          <div class="section-label">ZIP CODE</div>
          <div class="section-value">
            <span v-if="locationSettings && locationSettings.locationDetails">
              {{ locationSettings.locationDetails.postalCode || "-" }}
            </span>
            <span v-else>-</span>
          </div>
        </div>

        <div>
          <div class="section-label">COUNTRY</div>
          <div class="section-value">
            <span v-if="locationSettings && locationSettings.locationDetails">{{
              locationSettings.locationDetails.country || "-"
            }}</span>
            <span v-else>-</span>
          </div>
        </div>

        <div>
          <div class="section-label">LOCATION STATUS</div>
          <div class="section-value">
            <span v-if="locationSettings && locationSettings.locationDetails">{{
              locationSettings.locationDetails.status || "-"
            }}</span>
            <span v-else>-</span>
          </div>
        </div>
      </div>

      <div>
        <div class="section-sub-header margin-to-12">LOADING DOCK HOURS</div>
        <div class="section-body dock-hours" v-if="locationSettings">
          <div
            v-for="(day, index) of locationSettings.pickup.hours"
            :key="day.label"
          >
            <div
              class="padding-5"
              :class="{
                'striped-class': index % 2 === 1,
              }"
            >
              <label class="section-label">{{ day.label }}</label
              ><br />
              <label class="dock-hours-value">
                <label v-if="day.closed">Closed</label>
                <label v-if="!day.closed">{{ day.interval1 }}</label>
              </label>

              <label class="dock-hours-value" v-if="day.interval2">
                <br />
                <label v-if="!day.closed">{{ day.interval2 }}</label>
              </label>
            </div>
          </div>

          <!-- <div>
            <label class="section-label">CAN GO EARLY</label><br />
            <label class="section-value">
              <label v-if="locationSettings.pickup.canGoEarly">Yes</label>
              <label v-if="!locationSettings.pickup.canGoEarly"
                >No</label
              > </label
            ><br />
            <label class="section-label">CAN GO LATE</label><br />
            <label class="section-value">
              <label v-if="locationSettings.pickup.canGoLate">Yes</label>
              <label v-if="!locationSettings.pickup.canGoLate">No</label>
            </label>
          </div> -->
        </div>
      </div>

      <div>
        <div class="section-sub-header">UNLOADING DOCK HOURS</div>
        <div class="section-body dock-hours" v-if="locationSettings">
          <div
            v-for="(day, index) of locationSettings.delivery.hours"
            :key="day.label"
          >
            <div
              class="padding-5"
              :class="{
                'striped-class': index % 2 === 1,
              }"
            >
              <label class="section-label">{{ day.label }}</label
              ><br />
              <label class="dock-hours-value">
                <label v-if="day.closed">Closed</label>
                <label v-if="!day.closed">{{ day.interval1 }}</label>
              </label>

              <label class="dock-hours-value" v-if="day.interval2">
                <br />
                <label v-if="!day.closed">{{ day.interval2 }}</label>
              </label>
            </div>
          </div>

          <!-- <div>
            <label class="section-label">CAN GO EARLY</label><br />
            <label class="section-value">
              <label v-if="locationSettings.delivery.canGoEarly">Yes</label>
              <label v-if="!locationSettings.delivery.canGoEarly"
                >No</label
              > </label
            ><br />
            <label class="section-label">CAN GO LATE</label><br />
            <label class="section-value">
              <label v-if="locationSettings.delivery.canGoLate">Yes</label>
              <label v-if="!locationSettings.delivery.canGoLate">No</label>
            </label>
          </div> -->
        </div>
      </div>
    </div>

    <div class="border"></div>

    <div class="section">
      <div class="section-header">Contacts</div>
      <div>
        <div
          class="section-body contact-details"
          v-for="(contact, index) in locationSettings.appointmentContacts"
          :key="index"
        >
          <div>
            <div class="section-label">CONTACT NAME</div>
            <div class="section-field-wrapper">
              <label class="section-value">
                <span>{{ contact.name ? contact.name : "-" | Titlecase }}</span>
              </label>
            </div>
          </div>

          <div>
            <div class="section-label">CONTACT PHONE #</div>
            <div class="section-field-wrapper">
              <label class="section-value">
                <span v-if="contact.phone">
                  {{
                    formatPhone(contact.phone.value, contact.phone.countryCode)
                  }}
                </span>
                <span v-else>-</span>
              </label>
            </div>
          </div>

          <div>
            <div class="section-label">CONTACT EMAIL</div>
            <div class="section-field-wrapper">
              <label class="section-value">
                <span>{{ contact.email || "-" }}</span>
              </label>
            </div>
          </div>

          <div>
            <div class="section-label">WEBSITE PORTAL</div>
            <div class="section-field-wrapper">
              <label class="section-value">
                <span>{{ contact.websitePortal || "-" }}</span>
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="border"></div>

    <div class="section">
      <div class="section-header">Additional Details</div>
      <div class="section-sub-header margin-to-12">LIVE LOAD/DROP RULES</div>
      <div>
        <div
          class="section-body contact-details"
          v-for="(loadDropRule, index) in locationSettings.loadDropRules"
          :key="index"
        >
          <div>
            <div class="section-label">MODE</div>
            <div class="section-field-wrapper">
              <label class="section-value">
                <span>{{ loadDropRule.mode ? loadDropRule.mode : "-" }}</span>
              </label>
            </div>
          </div>
          <div>
            <div class="section-label">STOP TYPE</div>
            <div class="section-field-wrapper">
              <label class="section-value">
                <span>{{ loadDropRule.stopType ? loadDropRule.stopType : "-" }}</span>
              </label>
            </div>
          </div>
          <div>
            <div class="section-label">LOADING TYPE</div>
            <div class="section-field-wrapper">
              <label class="section-value">
                <span>{{ loadDropRule.loadingType ? loadDropRule.loadingType : "-" }}</span>
              </label>
            </div>
          </div>
        </div>
      </div>
      <div>
        <div class="section-sub-header margin-to-12">GENERAL INSTRUCTIONS</div>
        <div class="general-instruction">
          <span
            v-if="
              locationSettings &&
              locationSettings.generalInstructions &&
              locationSettings.generalInstructions.internalNotes
            "
            >{{ locationSettings.generalInstructions.internalNotes }}</span
          >
          <span v-else>-</span>
        </div>
      </div>
    </div>
    <div class="actions">
      <div></div>
      <div>
        <label class="last-updated-message"
          >Last Updated: {{ locationSettings.modifiedDate }}
          <span v-if="locationSettings.modifiedBy">
            by {{ locationSettings.modifiedBy }}</span
          >
        </label>
      </div>
    </div>
  </div>
</template>

<script src="./view-location.js"></script>
<style src="./view-location.sass" lang="sass" scoped></style>