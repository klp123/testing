import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import { UtilitiesService } from '@hubgroup/hg-om-shared-services';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import _ from 'lodash';
import ViewLocation from './view-location/view-location.vue';
import EditLocation from './edit-location/edit-location.vue';
import locationSettingsService from '../../../../services/location/location-settings.service';

function getColor(name) {
  return _colors[name];
}

async function loadLocationSettings(location) {
  if (!location || !location.locationId) return;
  try {
    this.locationSettings = await locationSettingsService.getLocationSettingsFormObject(this.location);
    // clone location setting for form object
    this.editingLocationSettingsFormObject = _.cloneDeep(this.locationSettings);
    this.editTabKey = Math.random();
    // Resets loading and unloading hours same on Location settings Edit page
    if (this.$refs.editLocationSettings) {
      this.$refs.editLocationSettings.enableUnloadDockHours();
    }
  } catch (error) {
    HgNotificationService.errorMessage('Failed to load location settings');
  }
}

async function updateLocationSettings(locSettings) {
  try {
    const locationSettings = await
    locationSettingsService.updateLocationSettings(locSettings,
      this.location.locationId, this.location.customerId);
    this.locationSettings = locationSettingsService.getLocationSettingsFormObject(locationSettings);
    this.editTabKey = Math.random();
    this.$emit('updatedLocationSettings', locationSettings);
    HgNotificationService.successMessage('Successfully updated location settings');
    this.resetMode();
  } catch (err) {
    // Show Custom error message from API if it has any
    if (_.has(err, 'response.data.message')) {
      const message = JSON.parse(err.response.data.message);
      HgNotificationService.errorMessage(`Failed to update location settings. ${message.details.map((e) => e.message).join(', ')}`);
    } else {
      HgNotificationService.errorMessage(err.message);
    }
  }
}

function updateLocationSettingsForm(locationSettings) {
  // update currently editing location-settings form object
  this.editingLocationSettingsFormObject = locationSettings;
}

function closeEditForm() {
  // restore location-settings to original (clear form object changes from edit)
  this.editingLocationSettingsFormObject = this.locationSettings;
}

function resetMode() {
  this.mode = 'VIEW';
}

const data = {
  mode: 'VIEW',
  locationSettings: null,
  editTabKey: Math.random(),
  editingLocationSettingsFormObject: {},
  closeEditForm,
};

// @vuese
// @group MAINTENANCE
// Maintenance page for Location settings
export default {
  name: 'LocationSettingsDetails',
  data: () => (data),
  props: {
    location: {
      type: Object,
      required: false,
      default: () => [],
    },
  },
  components: {
    ViewLocation,
    EditLocation,
  },
  filters: {
    Titlecase(value) {
      return UtilitiesService.titleCase(value);
    },
  },
  watch: {
    location: {
      handler(newValue) {
        this.loadLocationSettings(newValue);
      },
    },
  },
  methods: {
    // @vuese
    // Gets color for given color name
    // @arg (name) color name
    getColor,
    // @vuese
    // Load location settings
    loadLocationSettings,
    // @vuese
    // Update Location settings to API
    updateLocationSettings,
    // @vuese
    // Reset Location Settings Mode to View
    resetMode,
    updateLocationSettingsForm,
  },
};
