<template>
  <v-form v-model="valid.valid" ref="dockForm">
    <div class="days">
      <!-- Dock Hours section starts here -->
      <div
        v-for="(day, index) of getDockHours.hours"
        :key="day.label"
        class="day"
        :class="{
          'striped-class': index % 2 === 1,
        }"
      >
        <div>
          <label class="day-label">{{ day.label }}</label
          ><br />
          <div class="form-controls dock-hours-field">
            <div>
              <v-text-field
                hide-details="true"
                outlined
                dense
                type="text"
                :color="getColor('color_primary_blue')"
                v-model="day.interval1"
                :rules="[
                  day.rules.checkInterval,
                  day.rules.required(day.closed),
                ]"
                @change="dockHoursChanged('interval1', $event, day.label)"
                :disabled="day.closed || day.is24Hour"
              ></v-text-field>
            </div>

            <div></div>
          </div>

          <div
            class="form-controls interval2 dock-hours-field"
            v-if="day.hasOwnProperty('interval2')"
          >
            <div>
              <v-text-field
                outlined
                dense
                type="text"
                hide-details="true"
                :color="getColor('color_primary_blue')"
                v-model="day.interval2"
                :rules="[
                  day.rules.checkInterval,
                  day.rules.checkOverlapInterval(day.interval1, day.interval2),
                  day.rules.required(day.closed),
                ]"
                @change="dockHoursChanged('interval2', $event, day.label)"
              ></v-text-field>
            </div>

            <div>
              <v-img
                class="remove-interval"
                max-height="15"
                max-width="15"
                :src="getIcon('delete_icon')"
                @click="removeInterval(day.label)"
              ></v-img>
            </div>
          </div>

          <div>
            <label class="add-window">
              <span
                v-if="
                  !day.hasOwnProperty('interval2') &&
                  !day.is24Hour &&
                  !day.closed
                "
                @click="addInterval(day.label)"
              >
                Add Window
              </span>
            </label>
          </div>
        </div>
      </div>
      <!-- Dock Hours section ends here -->

      <!-- 24Hours and Closed section starts here -->
      <div
        v-for="(day, index) in getDockHours.hours"
        :key="`${day.label}1`"
        class="closed-all-day"
      >
        <div
          :class="{
            'striped-class': index % 2 === 1,
          }"
        >
          <div class="field-wrapper">
            <v-checkbox
              v-if="!day.closed"
              v-model="day.is24Hour"
              dense
              :label="'24 hr'"
              hide-details="true"
              :color="getColor('color_primary_blue')"
              class="checkbox-label"
              @change="is24HourChanged($event, day.label)"
            ></v-checkbox>
          </div>

          <div class="field-wrapper">
            <v-checkbox
              v-if="!day.is24Hour"
              v-model="day.closed"
              :label="'Closed'"
              dense
              hide-details="true"
              :color="getColor('color_primary_blue')"
              class="checkbox-label"
              @change="closedHoursChanged($event, day.label)"
            ></v-checkbox>
          </div>
        </div>
      </div>
      <!-- 24Hours and Closed section ends here -->
    </div>

    <!-- Can go early/late section starts here -->
    <div class="go-early-late">
      <!-- <div>
        <label class="section-label">CAN GO EARLY</label>
        <div class="early-late">
          <v-radio-group
            v-model="getDockHours.canGoEarly"
            @change="updateCanGo('EARLY', $event)"
          >
            <v-radio
              dense
              :label="`No`"
              :value="false"
              :color="getColor('color_primary_blue')"
            ></v-radio>
            <v-radio
              dense
              :label="`Yes`"
              :value="true"
              :color="getColor('color_primary_blue')"
            ></v-radio>
          </v-radio-group>
        </div>
        <div class="early-late-hours dock-hours-field">
          <v-text-field
            outlined
            :height="20"
            dense
            type="text"
            :color="getColor('color_primary_blue')"
            :disabled="true"
            v-model="getDockHours.canGoEarlyMinutes"
            :rules="[
              getDockHours.rules.canGoEarlyLate(getDockHours.canGoEarly),
            ]"
            @change="updateCanGoHours('EARLY', $event)"
          />
        </div>
        <label class="hours">hours</label>
      </div>
      <div>
        <label class="section-label">CAN GO LATE</label>
        <div class="early-late">
          <v-radio-group
            v-model="getDockHours.canGoLate"
            @change="updateCanGo('LATE', $event)"
          >
            <v-radio
              dense
              :label="`No`"
              :value="false"
              :color="getColor('color_primary_blue')"
            ></v-radio>
            <v-radio
              dense
              :label="`Yes`"
              :value="true"
              :color="getColor('color_primary_blue')"
            ></v-radio>
          </v-radio-group>
        </div>

        <div class="early-late-hours dock-hours-field">
          <v-text-field
            outlined
            :height="20"
            dense
            type="text"
            :color="getColor('color_primary_blue')"
            v-model="getDockHours.canGoLateMinutes"
            :disabled="true"
            :rules="[getDockHours.rules.canGoEarlyLate(getDockHours.canGoLate)]"
            @change="updateCanGoHours('LATE', $event)"
          />
        </div>

        <label class="hours">hours</label>
      </div>
      <div></div>-->
    </div>
    <!-- Can go early/late section ends here -->
  </v-form>
</template>

<script src="./dock-hours-control.js"></script>
<style src="./dock-hours-control.sass" lang="sass" scoped></style>
