import _ from 'lodash';
import { ImageLoaderService, UtilitiesService } from '@hubgroup/hg-om-shared-services';
import { CountryPhoneCodesEnum, MasksEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import { HgDdTextField } from '@hubgroup/hg-vue-library/src/components';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import images from '@hubgroup/hg-vue-library/src/assets/images/_image.loader';
import cdnImagesEnum from '@hubgroup/hg-vue-om-util-lib/src/enums/cdn-images.enum';
import DockHoursControl from './dock-hours-control/dock-hours-control.vue';
import HgButton from '../../../../shared/buttons/hg-button/hg-button.vue';
import locationSettingsService from '../../../../../services/location/location-settings.service';
import commonService from '../../../../../services/common.service';
import appointmentRulesEnum from '../../../../../enums/appointment-rules.enum';

function getColor(name) {
  return _colors[name];
}

function getImage(iconName) {
  return images[iconName];
}

/**
 *
 * @param {*} name icon name
 * @returns icon svgs
 */
function getIcon(iconName) {
  return ImageLoaderService.getCdnImageUrl(iconName);
}

function getDockHours(type) {
  return (type === 'DOCK') ? _.get(this.locationSettingsFormData, 'pickup.hours', []) : _.get(this.locationSettingsFormData, 'delivery.hours', []);
}

function formatDropdownValue(item) {
  return item.value;
}

function formatDropdownText(item) {
  return item.displayValue;
}

function checkDuplicates() {
  if (!this.locationSettingsFormData || !this.locationSettingsFormData.loadDropRules || (this.locationSettingsFormData.loadDropRules.length < 2)) {
    this.duplicateLoadDropRuleExists = false;
    return;
  }
  const rules = this.locationSettingsFormData.loadDropRules;
  // checking the duplicate load drop rule in the array. Duplicate if mode and stopType are matching.
  this.duplicateLoadDropRuleExists = _.uniqWith(rules, (arrVal, othVal) => (arrVal.mode === othVal.mode)
    && (arrVal.stopType === othVal.stopType || !arrVal.stopType || !othVal.stopType)).length !== rules.length;
  return this.duplicateLoadDropRuleExists;
}

function addInterval(day, type = 'DOCK') {
  let weekDay;
  if (type === 'DOCK') {
    weekDay = this.locationSettingsFormData.pickup.hours.find((d) => d.label === day.day);
  } else {
    weekDay = this.locationSettingsFormData.delivery.hours.find((d) => d.label === day.day);
  }
  _.set(weekDay, 'interval2', '');
  this.locationSettingsFormData = _.cloneDeep(this.locationSettingsFormData);
}

function removeInterval(day, type = 'DOCK') {
  let weekDay;
  if (type === 'DOCK') {
    weekDay = this.locationSettingsFormData.pickup.hours.find((d) => d.label === day.day);
  } else {
    weekDay = this.locationSettingsFormData.delivery.hours.find((d) => d.label === day.day);
  }
  delete weekDay.interval2;
  this.locationSettingsFormData = _.cloneDeep(this.locationSettingsFormData);
}

function canGoChanged(value, type = 'DOCK') {
  let stop;
  if (type === 'DOCK') {
    stop = this.locationSettingsFormData.pickup;
  } else {
    stop = this.locationSettingsFormData.delivery;
  }

  if (value.type === 'EARLY') {
    _.set(stop, 'canGoEarly', value.value);
    if (!value.value) {
      _.set(stop, 'canGoEarlyMinutes', null);
    }
  } else {
    _.set(stop, 'canGoLate', value.value);
    if (!value.value) {
      _.set(stop, 'canGoLateMinutes', null);
    }
  }
}

function canGoHoursChanged(value, type = 'DOCK') {
  let stop;
  if (type === 'DOCK') {
    stop = this.locationSettingsFormData.pickup;
  } else {
    stop = this.locationSettingsFormData.delivery;
  }

  if (value.type === 'EARLY') {
    _.set(stop, 'canGoEarlyMinutes', value.value);
  } else {
    _.set(stop, 'canGoLateMinutes', value.value);
  }
}

function is24HourChanged(row, type = 'DOCK') {
  let weekDay;
  if (type === 'DOCK') {
    weekDay = this.locationSettingsFormData.pickup.hours.find((d) => d.label === row.day);
  } else {
    weekDay = this.locationSettingsFormData.delivery.hours.find((d) => d.label === row.day);
  }

  if (row.checked) {
    _.set(weekDay, 'interval1', '00:01-23:59');
    _.set(weekDay, 'closed', false);
    _.set(weekDay, 'is24Hour', true);
    delete weekDay.interval2;
  } else {
    _.set(weekDay, 'is24Hour', false);
  }
  this.locationSettingsFormData = _.cloneDeep(this.locationSettingsFormData);
}

function closedHoursChanged(row, type = 'DOCK') {
  let weekDay;
  if (type === 'DOCK') {
    weekDay = this.locationSettingsFormData.pickup.hours.find((d) => d.label === row.day);
  } else {
    weekDay = this.locationSettingsFormData.delivery.hours.find((d) => d.label === row.day);
  }

  if (row.checked) {
    _.set(weekDay, 'interval1', '');
    _.set(weekDay, 'is24Hour', false);
    _.set(weekDay, 'closed', true);
    delete weekDay.interval2;
  } else {
    _.set(weekDay, 'closed', false);
  }
  this.locationSettingsFormData = _.cloneDeep(this.locationSettingsFormData);
}

function makeSameDockHours($event) {
  if ($event) {
    this.tab = 'tab-1';
    this.locationSettingsFormData.delivery = _.cloneDeep(this.locationSettingsFormData.pickup);
  }
}

function updateLocationSettings() {
  this.$refs.dockHours.validate();
  this.checkDuplicates();
  if (this.isValid && !this.duplicateLoadDropRuleExists) {
    const updatedLocationSettings = _.cloneDeep(this.locationSettingsFormData);
    // remove empty contacts and fields
    const cleansedContacts = this.cleanseContacts();
    if (_.isEmpty(cleansedContacts)) delete updatedLocationSettings.appointmentContacts;
    else _.set(updatedLocationSettings, 'appointmentContacts', cleansedContacts);
    this.$emit('updateLocationSettings', updatedLocationSettings);
  }
}

function cleanseContacts() {
  const contacts = _.cloneDeep(_.get(this, 'locationSettingsFormData.appointmentContacts', []));
  const cleansedContacts = [];
  // remove empty contacts and fields
  if (contacts.length) {
    contacts.forEach((contact) => {
      if (contact.rules) delete contact.rules;
      if (!contact.email) delete contact.email;
      if (!contact.name) delete contact.name;
      if (!contact.websitePortal) delete contact.websitePortal;
      if (_.has(contact, 'phone') && !contact.phone.value) delete contact.phone;
      if (!_.isEmpty(contact)) cleansedContacts.push(contact);
    });
  }
  return cleansedContacts;
}

function isValid() {
  this.$refs.locSettingsForm.validate();
  const isValidDockHours = this.$refs.dockHours.isValid();
  const isValidUndockHours = this.$refs.undockHours.isValid();
  const isValidLocHours = this.$refs.locSettingsForm.value;

  return isValidDockHours && isValidUndockHours && isValidLocHours;
}

function hoursChanged(row, type = 'DOCK') {
  let weekDay;
  if (type === 'DOCK') {
    weekDay = this.locationSettingsFormData.pickup.hours.find((d) => d.label === row.day);
  } else {
    weekDay = this.locationSettingsFormData.delivery.hours.find((d) => d.label === row.day);
  }
  _.set(weekDay, row.interval, row.value);
  this.locationSettingsFormData = _.cloneDeep(this.locationSettingsFormData);
}

const data = {
  tab: null,
  locFormValid: false,
  dockValid: {
    valid: false,
  },
  undockValid: {
    valid: false,
  },
  disableUnloadingDockHours: false,
  selectedTab: 'TAB1',
  locationSettingsFormData: null,
  countryCodeList: CountryPhoneCodesEnum,
  masksEnum: MasksEnum,
  locationContacts: [],
  loadDropRules: [],
  modes: [],
  duplicateLoadDropRuleExists: false,
  cdnImagesEnum
};

function setLocationSettingFormData(formData) {
  const formattedformData = _.cloneDeep(formData);

  // format appointmentContacts
  if (_.get(formData, 'appointmentContacts', null) && formData.appointmentContacts.length) {
    const formattedContacts = formData.appointmentContacts.map((contact) => {
      if (contact.name) {
        return {
          ...contact,
          name: UtilitiesService.titleCase(contact.name),
        };
      }
      return contact;
    });
    _.set(formattedformData, 'appointmentContacts', formattedContacts);
  }

  this.locationSettingsFormData = formattedformData;
}

function enableUnloadDockHours() {
  this.disableUnloadingDockHours = false;
}

function addContactInputFieldsRow() {
  // get empty contact object and add to location settings form contacts
  const newLocationSettings = _.cloneDeep(this.locationSettingsFormData);
  const contactFormObject = _.cloneDeep(locationSettingsService.getContactFormObject());
  newLocationSettings.appointmentContacts.push(contactFormObject);
  this.$emit('updateLocationSettingsForm', newLocationSettings);
}

function removeContact(index) {
  // remove selected contact by index
  const newLocationSettings = _.cloneDeep(this.locationSettingsFormData);
  newLocationSettings.appointmentContacts.splice(index, 1);
  // add empty input row if none left
  if (newLocationSettings.appointmentContacts
    && _.isEmpty(newLocationSettings.appointmentContacts)) {
    const contactFormObject = _.cloneDeep(locationSettingsService.getContactFormObject());
    newLocationSettings.appointmentContacts.push(contactFormObject);
  }
  this.$emit('updateLocationSettingsForm', newLocationSettings);
}

function removeLoadDropRule(index) {
  // remove selected loadDropRule by index
  const newLocationSettings = _.cloneDeep(this.locationSettingsFormData);
  newLocationSettings.loadDropRules.splice(index, 1);
  this.$emit('updateLocationSettingsForm', newLocationSettings);
}

function addLoadDropRuleInputFieldsRow() {
  // get empty loadDropRule object and add to location settings form loadDropRules
  const newLocationSettings = _.cloneDeep(this.locationSettingsFormData);
  const loadDropRuleFormObject = _.cloneDeep(locationSettingsService.getLoadDropRuleFormObject());
  if (!newLocationSettings.loadDropRules) newLocationSettings.loadDropRules = [];
  newLocationSettings.loadDropRules.push(loadDropRuleFormObject);
  this.$emit('updateLocationSettingsForm', newLocationSettings);
}

// @vuese
// @group MAINTENANCE
// Update page for Location settings
export default {
  name: 'EditLocation',
  data: () => (data),
  props: {
    // Location settings object
    locationSettings: {
      type: Object,
      required: false,
      default: () => [],
    },
  },
  components: {
    DockHoursControl,
    HgDdTextField,
    HgButton,
  },
  computed: {
    isValid,
  },
  watch: {
    locationSettings: {
      handler(newValue) {
        this.setLocationSettingFormData(newValue);
      },
    },
    'locationSettingsFormData.loadDropRules': {
      handler() {
        this.checkDuplicates();
      }
    }
  },
  filters: {
    Titlecase(value) {
      return UtilitiesService.titleCase(value);
    },
  },
  created() {
    setLocationSettingFormData.bind(this)(this.locationSettings);
    commonService.getCommonLov(appointmentRulesEnum.LOV_TYPES.MODES).then((response) => {
      this.modes = response;
    });
  },
  methods: {
    // @vuese
    // Gets color for given color name
    // @arg (name) color name
    getColor,
    // @vuese
    // Gets dock hours
    getDockHours,
    // @vuese
    // Emits event updateLocationSettings to submit to API
    // @arg (name) color name
    updateLocationSettings,
    // @vuese
    // Adds interval2 for given day
    // @arg (day) color name
    addInterval,
    // @vuese
    // Removes interval2 from given day
    // @arg (day) color name
    removeInterval,
    // @vuese
    // Removes hours from interval
    // @arg (day)
    is24HourChanged,
    // @vuese
    // Check if dock hour form is valid
    closedHoursChanged,
    // @vuese
    // Sets hours for given interval and day
    hoursChanged,
    // @vuese
    // Make Dock and Undock hours same
    makeSameDockHours,
    // @vuese
    // Sets location settings form data
    setLocationSettingFormData,
    // @vuese
    // Updates CanGo Early/Late hour
    canGoChanged,
    // @vuese
    // Updates CanGo Early/Late hour hours
    canGoHoursChanged,
    // @vuese
    // Enable Unloading Dock hours
    enableUnloadDockHours,
    getImage,
    addContactInputFieldsRow,
    removeContact,
    cleanseContacts,
    addLoadDropRuleInputFieldsRow,
    removeLoadDropRule,
    formatDropdownValue,
    formatDropdownText,
    checkDuplicates,
    getIcon
  },
};
