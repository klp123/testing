<template>
  <div>
    <v-form
      v-model="locFormValid"
      ref="locSettingsForm"
      v-if="locationSettingsFormData"
    >
      <!-- Details section starts here -->
      <div class="section">
        <div class="section-header">Details</div>
        <div class="section-body loc-details">
          <div>
            <div class="section-label">CUSTOMER NAME</div>
            <div class="section-value">
              <span v-if="locationSettings && locationSettings.customerName">
                {{ locationSettings.customerName || "-" }}
              </span>
              <span v-else>-</span>
            </div>
          </div>

          <div>
            <div class="section-label">CUSTOMER LOCATION ID</div>
            <div class="section-value">
              <span
                v-if="locationSettings && locationSettings.locationDetails"
                >{{ locationSettings.locationDetails.locationId || "-" }}</span
              >
              <span v-else>-</span>
              <p
                v-if="
                  locationSettings &&
                  locationSettings.locationDetails &&
                  locationSettings.locationDetails.address
                "
                class="address ma-0"
              >
                {{ locationSettings.locationDetails.address }}
              </p>
            </div>
          </div>

          <div>
            <div class="section-label">CITY/STATE</div>
            <div class="section-value">
              <span
                v-if="
                  locationSettings &&
                  locationSettings.locationDetails &&
                  (locationSettings.locationDetails.city ||
                    locationSettings.locationDetails.state)
                "
              >
                {{ locationSettings.locationDetails.city | Titlecase }}
                <span v-if="locationSettings.locationDetails.state">, </span>
                {{ locationSettings.locationDetails.state }}
              </span>
              <span v-else>-</span>
            </div>
          </div>

          <div>
            <div class="section-label">ZIP CODE</div>
            <div class="section-value">
              <span v-if="locationSettings && locationSettings.locationDetails">
                {{ locationSettings.locationDetails.postalCode || "-" }}
              </span>
              <span v-else>-</span>
            </div>
          </div>

          <div>
            <div class="section-label">COUNTRY</div>
            <div class="section-value">
              <span
                v-if="locationSettings && locationSettings.locationDetails"
                >{{ locationSettings.locationDetails.country || "-" }}</span
              >
              <span v-else>-</span>
            </div>
          </div>

          <div>
            <div class="section-label">LOCATION STATUS</div>
            <div class="section-value">
              <span
                v-if="locationSettings && locationSettings.locationDetails"
                >{{ locationSettings.locationDetails.status || "-" }}</span
              >
              <span v-else>-</span>
            </div>
          </div>
        </div>
      </div>
      <!-- Details section ends here -->

      <div class="border"></div>
      <!-- Dock hours section starts here -->
      <div
        v-if="
          locationSettingsFormData.pickup && locationSettingsFormData.delivery
        "
      >
        <div class="dock-hours-tab">
          <div>
            <v-tabs
              v-model="tab"
              icons-and-text
              height="30px"
              :color="getColor('color_dark_gray')"
            >
              <v-tab href="#tab-1" @click="selectedTab = 'TAB1'">
                LOADING DOCK HOURS
              </v-tab>
              <v-tab
                href="#tab-2"
                @click="selectedTab = 'TAB2'"
                :disabled="disableUnloadingDockHours"
              >
                UNLOADING DOCK HOURS
              </v-tab>
            </v-tabs>
          </div>

          <div>
            <v-checkbox
              :label="'Keep loading and unloading times the same'"
              dense
              :color="getColor('color_primary_blue')"
              @change="makeSameDockHours($event)"
              v-model="disableUnloadingDockHours"
            ></v-checkbox>
          </div>
        </div>

        <v-tabs-items v-model="tab">
          <v-tab-item :value="'tab-1'" :eager="true">
            <dock-hours-control
              ref="dockHours"
              :dockHours="locationSettingsFormData.pickup"
              @addInterval="addInterval($event)"
              @removeInterval="removeInterval($event)"
              @is24HourChanged="is24HourChanged($event)"
              @closedHoursChanged="closedHoursChanged($event)"
              @hoursChanged="hoursChanged($event)"
              @canGoChanged="canGoChanged($event)"
              @canGoHoursChanged="canGoHoursChanged($event)"
              :valid="dockValid"
            />
          </v-tab-item>
          <v-tab-item :value="'tab-2'" :eager="true">
            <dock-hours-control
              ref="undockHours"
              :dockHours="locationSettingsFormData.delivery"
              @addInterval="addInterval($event, 'UNDOCK')"
              @removeInterval="removeInterval($event, 'UNDOCK')"
              @is24HourChanged="is24HourChanged($event, 'UNDOCK')"
              @closedHoursChanged="closedHoursChanged($event, 'UNDOCK')"
              @hoursChanged="hoursChanged($event, 'UNDOCK')"
              @canGoChanged="canGoChanged($event, 'UNDOCK')"
              @canGoHoursChanged="canGoHoursChanged($event, 'UNDOCK')"
              :valid="undockValid"
            />
          </v-tab-item>
        </v-tabs-items>
      </div>
      <!-- Dock hours section ends here -->

      <div class="border"></div>
      <!-- Contacts section starts here -->
      <div class="section">
        <div class="section-header">Contacts</div>

        <div class="align-self-start add-button">
          <v-btn
            class="btn-no-bg-color font-size-12"
            :color="getColor('color_primary_blue')"
            text
            @click="addContactInputFieldsRow()"
            >Add Contact</v-btn
          >
        </div>

        <div v-if="locationSettingsFormData.appointmentContacts">
          <div
            class="section-body contact-details"
            v-for="(
              contact, index
            ) in locationSettingsFormData.appointmentContacts"
            v-bind:key="index"
          >
            <div>
              <div class="section-label">CONTACT NAME</div>
              <div class="section-field-wrapper">
                <v-text-field
                  outlined
                  dense
                  :color="getColor('color_primary_blue')"
                  v-model="contact.name"
                  :rules="[
                    contact.rules.name(),
                  ]"
                ></v-text-field>
              </div>
            </div>

            <div>
              <div class="section-label">CONTACT PHONE #</div>
              <div class="section-field-wrapper">
                <hg-dd-text-field
                  :ddModel="contact.phone"
                  :typeList="countryCodeList"
                  :textPlaceholder="'Phone number'"
                  :textMask="masksEnum.PHONE"
                />
              </div>
            </div>

            <div>
              <div class="section-label">CONTACT EMAIL</div>
              <div class="section-field-wrapper">
                <v-text-field
                  outlined
                  dense
                  :color="getColor('color_primary_blue')"
                  v-model="contact.email"
                  :rules="[
                    contact.rules.email(),
                  ]"
                ></v-text-field>
              </div>
            </div>

            <div>
              <div class="section-label">WEBSITE PORTAL</div>
              <div class="section-field-wrapper">
                <v-text-field
                  outlined
                  dense
                  :color="getColor('color_primary_blue')"
                  v-model="contact.websitePortal"
                  :rules="[
                    contact.rules.webUrl(),
                  ]"
                ></v-text-field>
              </div>
            </div>

            <div class="d-flex contact-actions">
              <v-btn
                v-if="index !== 0"
                @click="removeContact(index)"
                text
                class="btn-no-bg-color delete-contact-button ml-0"
              >
                <v-img
                  class="pa-0"
                  max-height="15"
                  max-width="15"
                  :src="getImage('delete_icon')"
                ></v-img>
              </v-btn>
            </div>
          </div>
        </div>
      </div>
      <!-- Contacts section ends here -->

      <div class="border"></div>

      <!-- Additional Details section starts here -->
      <div class="section additional">
        <div class="section-header">Additional Details</div>
        <div class="general-instruction">
          <div class="section-sub-header margin-to-12">
            LIVE LOAD/DROP RULES <v-btn
            class="btn-no-bg-color font-size-12"
            :color="getColor('color_primary_blue')"
            text
            @click="addLoadDropRuleInputFieldsRow()"
            >Add Rule</v-btn
          >
          <div>
          </div>
          </div>
          <div v-if="duplicateLoadDropRuleExists" class="error-msg">Rule for this combination already exists. Please modify.</div>
          <div class="section-body load-drop-rules-section" style="margin-bottom: 12px;" v-for="(
              loadDropRule, index
            ) in locationSettingsFormData.loadDropRules"
            v-bind:key="index">
            <div class="section-field">
              <div class="section-label" style="display: flex;">MODE  <v-img
                  style="display: flex;"
                  max-height="10"
                  max-width="10"
                  :src="getIcon(cdnImagesEnum.required_icon)"
                ></v-img></div>
              <div class="section-field-wrapper">
               <v-select :items="modes"
                :itemText="formatDropdownText"
                :itemValue="formatDropdownValue"
                v-model="loadDropRule.mode"
                item-text="label"
                class="search-dropdown"
                color="highlight"
                dense
                required
                :rules="[(v) => !!v || 'Mode is required']"
                filled
                ></v-select>
              </div>
            </div>
            <div class="section-field">
              <div class="section-label">STOP TYPE</div>
              <div class="section-field-wrapper">
               <v-select :items="['Pick Up','Delivery']"
                v-model="loadDropRule.stopType"
                item-text="label"
                class="search-dropdown"
                color="highlight"
                dense
                filled
                ></v-select>
              </div>
            </div>
            <div class="section-field">
              <div class="section-label" style="display: flex;">LOADING TYPE  <v-img
                  style="display: flex;"
                  max-height="10"
                  max-width="10"
                  :src="getIcon(cdnImagesEnum.required_icon)"
                ></v-img></div>
              <div class="section-field-wrapper">
               <v-select :items="['Live','Drop']"
                v-model="loadDropRule.loadingType"
                item-text="label"
                class="search-dropdown"
                color="highlight"
                dense
                filled
                required
                :rules="[(v) => !!v || 'Loading Type is required']"
                ></v-select>
              </div>
            </div>
            <div>
              <v-btn
                @click="removeLoadDropRule(index)"
                text
                style="min-height: 100%"
                class="btn-no-bg-color delete-contact-button ml-0"
              >
                <v-img
                  class="pa-0"
                  max-height="15"
                  max-width="15"
                  :src="getImage('delete_icon')"
                ></v-img>
              </v-btn>
            </div>
          </div>
        </div>
        <div class="general-instruction">
          <div class="section-sub-header margin-to-12">
            GENERAL INSTRUCTIONS
          </div>
          <v-textarea
            solo
            :color="getColor('color_primary_blue')"
            row-height="16"
            :auto-grow="true"
            v-model="locationSettingsFormData.generalInstructions.internalNotes"
          ></v-textarea>
        </div>
      </div>
      <!-- Additional Details section ends here -->

      <!-- Actions section starts here -->
      <div class="actions">
        <div></div>
        <div>
          <label class="last-updated-message"
            >Last Updated: {{ locationSettingsFormData.modifiedDate }}
            <span v-if="locationSettingsFormData.modifiedBy">
              by {{ locationSettingsFormData.modifiedBy }}</span
            >
          </label>
        </div>
        <div>
          <hg-button
            title="Save Changes"
            type="primary"
            @click.native="updateLocationSettings()"
          ></hg-button>
        </div>
      </div>
      <!-- Actions section ends here -->
    </v-form>
  </div>
</template>

<script src="./edit-location.js"></script>
<style src="./edit-location.sass" lang="sass" scoped></style>
