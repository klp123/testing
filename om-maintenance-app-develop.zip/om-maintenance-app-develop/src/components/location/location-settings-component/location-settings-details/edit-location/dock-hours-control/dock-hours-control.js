import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import images from '@hubgroup/hg-vue-library/src/assets/images/_image.loader';
import _ from 'lodash';

function getColor(name) {
  return _colors[name];
}

function getIcon(iconName) {
  return images[iconName];
}

function addInterval(day) {
  this.$emit('addInterval', {
    day,
  });
}

function removeInterval(day) {
  this.$emit('removeInterval', {
    day,
  });
}

function is24HourChanged($event, day) {
  this.$emit('is24HourChanged', {
    checked: $event,
    day,
  });
}

function validate() {
  return this.$refs.dockForm.validate();
}

function closedHoursChanged($event, day) {
  this.$emit('closedHoursChanged', {
    checked: $event,
    day,
  });
}

function isValid() {
  this.$refs.dockForm.validate();
  return this.valid.valid;
}

function getValue() {
  return this.getWeekDays;
}

function dockHoursChanged(interval, $event, day) {
  this.$emit('hoursChanged', { interval, value: $event, day });
}

function updateCanGo(type, $event) {
  this.$emit('canGoChanged', { type, value: $event });
}

function updateCanGoHours(type, $event) {
  this.$emit('canGoHoursChanged', { type, value: $event });
}

const data = {
  weekDays: null,
  weekDays1: null,
};

// @vuese
// @group MAINTENANCE
// Component for dock hours field
export default {
  name: 'DockHoursControl',
  data: () => (data),
  props: {
    // Modal for dock hours
    dockHours: {
      type: Object,
      default: {},
      required: false,
    },
    // Modal for validity of form
    valid: {
      type: Object,
      default: false,
      required: false,
    },
  },
  methods: {
    // @vuese
    // Gets color for given color name
    // @arg (name) color name
    getColor,
    // @vuese
    // Gets icon for given name
    // @arg (name) icon name
    getIcon,
    // @vuese
    // Adds interval2 for the given day
    // @arg (day)
    addInterval,
    // @vuese
    // Removes interval2 from the given day
    // @arg (day)
    removeInterval,
    // @vuese
    // Adds 00:01-23:59 is 24 hours is checked
    // Removes closed
    // @arg (day)
    is24HourChanged,
    // @vuese
    // Removes hours from interval
    // @arg (day)
    closedHoursChanged,
    // @vuese
    // Check if dock hour form is valid
    isValid,
    // @vuese
    // Gets value for the dock hour form
    getValue,
    // @vuese
    // Updates value and validity for dock hours changed
    // @arg (day)
    dockHoursChanged,
    // @vuese
    // Validates the dock hour form
    validate,
    // @vuese
    // Updates CanGo Early/Late
    updateCanGo,
    // @vuese
    // Updates CanGo Early/Late hour
    updateCanGoHours,
  },
  computed: {
    getDockHours: {
      get() {
        return _.cloneDeep(this.dockHours);
      },
      set(value) {
        this.$emit('listchange', value);
      },
    },
  },
};
