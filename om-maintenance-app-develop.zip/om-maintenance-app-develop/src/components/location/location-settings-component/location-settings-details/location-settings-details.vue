<template>
  <div class="location-details">
    <div class="details-header">
      <div class="title">{{ location.name | Titlecase }}</div>
      <div>
        <span
          v-if="mode === 'EDIT'"
          @click="
            closeEditForm();
            mode = 'VIEW';
          "
          class="action"
          ><v-icon>mdi-close</v-icon></span
        >
        <span v-if="mode === 'VIEW'" @click="mode = 'EDIT'" class="action"
          >Edit</span
        >
      </div>
    </div>
    <div class="border"></div>
    <div class="body">
      <view-location
        v-if="mode === 'VIEW' && locationSettings"
        :locationSettings="locationSettings"
      />
      <edit-location
        v-if="mode === 'EDIT'"
        :locationSettings="editingLocationSettingsFormObject"
        @updateLocationSettings="updateLocationSettings($event)"
        @updateLocationSettingsForm="updateLocationSettingsForm($event)"
        :key="editTabKey"
        ref="editLocationSettings"
      />
    </div>
  </div>
</template>

<script src="./location-settings-details.js"></script>
<style src="./location-settings-details.sass" lang="sass" scoped></style>
