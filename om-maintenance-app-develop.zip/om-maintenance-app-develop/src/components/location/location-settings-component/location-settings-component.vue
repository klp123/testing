<template>
  <div class="location-settings">
    <div class="location-settings-body">
      <div class="location-settings-grid">
        <div class="meta-data">
          <hg-table-metadata
            :totalResults="totalLocationsCount"
            :refreshTime="lastRefreshedDate"
            page="Appointments Grid"
            @onRefreshClick="loadLocations()"
          />
        </div>

        <location-settings-grid
          :locations="locations"
          :loading="loading"
          @selectedLocation="setSelectedLocation($event)"
          :key="gridKey"
        />
      </div>

      <div class="location-settings-details">
        <div v-if="!selectedLocation.locationId">No Location Settings selected</div>
        <location-settings-details
          v-else
          :location="selectedLocation"
          ref="locSettingsDetails"
          @updatedLocationSettings="updatedLocationSettings($event)"
        />
      </div>
    </div>

    <div class="location-settings-footer">
      <div>
        <location-settings-footer
          :totalCounts="totalLocationsCount"
          :locationCounts="locationCounts"
          @paginationChanged="paginationChanged($event)"
        />
      </div>
      <div></div>
    </div>
  </div>
</template>

<script src="./location-settings-component.js"></script>
<style src="./location-settings-component.sass" lang="sass" scoped></style>
