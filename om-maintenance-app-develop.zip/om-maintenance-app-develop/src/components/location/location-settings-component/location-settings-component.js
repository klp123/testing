/* eslint-disable no-irregular-whitespace */
import _ from 'lodash';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import LocationSettingsGrid from './location-settings-grid/location-settings-grid.vue';
import LocationSettingsFooter from './location-settings-footer/location-settings-footer.vue';
import LocationSettingsDetails from './location-settings-details/location-settings-details.vue';
import HgTableMetadata from '../../shared/hg-table-metadata/hg-table-metadata.vue';
import locationSettingsService from '../../../services/location/location-settings.service';

const locationData = {
  locations: [],
  // Total Locations shown
  locationCounts: 0,
  // Total Locations on mongo
  totalLocationsCount: 0,
  loading: false,
  filters: null,
  options: {
    page: 1,
    limit: 20,
  },
  gridKey: Math.random(),
  selectedLocation: {},
  locDetailsKey: Math.random(),
  lastRefreshedDate: new Date(),
};

function getColor(name) {
  return _colors[name];
}

function paginationChanged(pagination) {
  this.options.page = pagination.page;
  this.options.limit = pagination.limit;
  this.loadLocations();
}

function setSelectedLocation(location) {
  this.selectedLocation = _.cloneDeep(location);
  // Resets Location Settings to View Mode
  if (this.$refs.locSettingsDetails) {
    this.$refs.locSettingsDetails.resetMode();
  }

  this.locDetailsKey = Math.random();
}

function setFilterVariable() {
  // Set filter from store to local variable to watch change
  this.filters = this.$store.getters['locationSettingsStore/getFilters'];
}

function updatedLocationSettings(locationSettings) {
  const index = this.locations.findIndex(
    (loc) => loc.locationId === locationSettings.locationId
    && loc.customerId === locationSettings.customerId,
  );
  if (index > -1) {
    this.locations[index] = locationSettings;
    this.selectedLocation = locationSettings;
  }
  this.gridKey = Math.random();
}

async function loadLocations() {
  this.loading = true;
  this.locations = [];
  this.selectedLocation = {};
  try {
    const locations = await locationSettingsService.filterLocationSettings(
      this.filters,
      this.options,
    );
    this.locations = locations.data || [];
    if (this.locations.length) {
      this.setSelectedLocation(this.locations[0]);
    }

    this.totalLocationsCount = _.get(locations, 'meta.total', 0);
    // Set location counts including previous page count
    this.locationCounts = (this.options.page - 1) * this.options.limit + this.locations.length;
    this.lastRefreshedDate = new Date();
    this.loading = false;
  } catch (err) {
    HgNotificationService.errorMessage('Failed to get locations.');
  }
}

// @vuese
// @group MAINTENANCE
// Maintenance page for Location settings
export default {
  name: 'LocationSettingsComponent',
  data: () => locationData,
  components: {
    LocationSettingsGrid,
    LocationSettingsFooter,
    LocationSettingsDetails,
    HgTableMetadata,
  },
  methods: {
    // @vuese
    // Gets color for given color name
    // @arg (name) color name
    getColor,
    // @vuese
    // Load Locations with filters and meta data
    loadLocations,
    // @vuese
    // Reload the page on page change
    // @arg (pagination) pagination info with page and limit
    paginationChanged,
    // @vuese
    // Set selected location for details section
    // @arg (location)
    setSelectedLocation,
    // @vuese
    // Set filter variable with store filter value
    setFilterVariable,
    // @vuese
    // Update Location on grid after its been updated on details page
    updatedLocationSettings,
  },
  watch: {
    filters: {
      handler() {
        this.options.page = 1;
        this.loadLocations();
      },
      deep: true,
    },
  },
  mounted() {
    this.setFilterVariable();
    this.loadLocations();
  },
};
