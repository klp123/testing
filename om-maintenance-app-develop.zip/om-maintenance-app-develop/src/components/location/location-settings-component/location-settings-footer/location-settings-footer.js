import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import { GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import Vue from 'vue';

const optionsData = {
  rowsPerPageItems: [10, 20, 30, 40, 50, 100],
  options: {
    page: 1,
    limit: 20,
  },
};

function getColor(name) {
  return _colors[name];
}

function totalPages() {
  return Math.ceil(this.totalCounts / this.options.limit);
}

function itemsPerPageChanged() {
  GoogleAnalyticsService.event(Vue, 'Change Pagination Count', 'Location Maintenance', this.options.limit);
  this.resetPage();
}

function resetPage() {
  this.options.page = 1;
}

// @vuese
// @group MAINTENANCE
// Maintenance page for Location settings
export default {
  name: 'LocationSettingsFooter',
  data: () => (optionsData),
  props: {
    totalCounts: {
      type: Number,
      required: false,
      default: () => [],
    },
    locationCounts: {
      type: Number,
      required: false,
      default: () => [],
    },
  },
  watch: {
    options: {
      handler(newVal) {
        this.$emit('paginationChanged', newVal);
      },
      deep: true,
    },
    checkResetPage() {
      if (this.$store.getters['locationSettingsStore/getResetPage']) {
        this.$store.dispatch('locationSettingsStore/updateResetPage', false);
        this.resetPage();
      }
    },
  },
  computed: {
    totalPages,
    checkResetPage() {
      return this.$store.getters['locationSettingsStore/getResetPage'];
    },
  },
  methods: {
    // @vuese
    // Gets color for given color name
    // @arg (name) color name
    getColor,
    itemsPerPageChanged,
    resetPage,
  },
};
