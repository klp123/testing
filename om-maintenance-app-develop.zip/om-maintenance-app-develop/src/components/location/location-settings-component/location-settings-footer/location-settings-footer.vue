<template>
   <div class="footer">
      <div class="pagination-info text">
        Showing {{ locationCounts }} of {{ totalCounts }} Locations
      </div>
      <div class="divider"></div>
      <div class="pagination-dropdown">
        <div class="text">Groups per Page</div>
        <div>
          <v-select
            :items="rowsPerPageItems"
            v-model="options.limit"
            label="Solo field"
            class="select-items-per-page"
            dense
            solo
            @change="itemsPerPageChanged()"
            whitespace="false"
          ></v-select>
        </div>
      </div>
      <div class="pagination-page-numbers">
        <v-pagination
          :length="totalPages"
          v-model="options.page"
          class="custom-pagination"
          :color="getColor('color_primary_blue')"
          total-visible="5"
        ></v-pagination>
      </div>
    </div>
</template>

<script src="./location-settings-footer.js"></script>
<style src="./location-settings-footer.sass" lang="sass" scoped></style>
