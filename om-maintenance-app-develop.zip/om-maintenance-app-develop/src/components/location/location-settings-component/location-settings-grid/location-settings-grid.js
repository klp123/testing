import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import _ from 'lodash';
import { UtilitiesService } from '@hubgroup/hg-om-shared-services';

function getColor(name) {
  return _colors[name];
}

function setSelectedLocation(location) {
  this.activeLocation = location;
  this.$emit('selectedLocation', location);
}

function isActiveLocation(location) {
  if (!this.activeLocation) {
    // if there is no active location selected
    // First location will be the selected location
    const firstLoc = _.first(this.locations);
    if (firstLoc) {
      return firstLoc.locationId === location.locationId
      && firstLoc.customerId === location.customerId;
    }
  } else {
    return this.activeLocation.locationId === location.locationId
    && this.activeLocation.customerId === location.customerId;
  }
  return false;
}

const data = {
  activeLocation: null,
  headers: [
    {
      text: 'LOCATION NAME',
      sortable: false,
    },
    { text: 'LOCATION ID', sortable: false },
    { text: 'CUSTOMER NUMBER', sortable: false },
    { text: 'CITY/STATE', sortable: false },
    { text: 'STATUS', value: 'Status', sortable: false },
  ],
};

// @vuese
// @group MAINTENANCE
// Maintenance page for Location settings
export default {
  name: 'LocationSettingsGrid',
  data: () => (data),
  props: {
    locations: {
      type: Array,
      required: false,
      default: () => [],
    },
    loading: {
      type: Boolean,
      required: false,
      default: false,
    },
  },
  watch: {
    locations: {
      handler(newVal) {
        if (newVal && newVal.length) {
          this.setSelectedLocation(newVal[0]);
        }
      },
    },
  },
  filters: {
    Titlecase(value) {
      return UtilitiesService.titleCase(value);
    },
  },
  methods: {
    // @vuese
    // Gets color for given color name
    // @arg (name) color name
    getColor,
    // @vuese
    // Sets the selected Location and emits selected event
    // @arg (location) selected location
    setSelectedLocation,
    isActiveLocation,
  },
};
