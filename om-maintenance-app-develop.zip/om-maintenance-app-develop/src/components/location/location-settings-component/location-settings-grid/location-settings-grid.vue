<template>
  <div class="location-settings">
    <v-data-table
      :headers="headers"
      :items="locations"
      :server-items-length="locations.length"
      :items-per-page-options="5"
      :hide-default-footer="true"
      :loading="loading"
      hide-action
      class="hg-table"
      item-key="title">
      <template  v-slot:item="{ item }">
        <tr @click="setSelectedLocation(item)"
            :class="{
              'active-row':isActiveLocation(item)
            }"
            :key="Math.random()">
          <td class="bold">{{ item.name | Titlecase }}</td>
          <td>{{ item.locationId }}</td>
          <td>
            <label v-if="item.customerId">{{ item.customerId }}</label>
            <label v-if="!item.customerId">-</label>
          </td>
          <td>
            {{ item.city | Titlecase }}<span v-if="item.state">, </span> {{ item.state }}
          </td>
          <td>
            <span v-if="item.status">{{ item.status  | Titlecase }}</span>
            <span v-else>-</span>
          </td>
        </tr>
      </template>
    </v-data-table>
  </div>
</template>

<script src="./location-settings-grid.js"></script>
<style src="./location-settings-grid.sass" lang="sass" scoped></style>
