import _ from 'lodash';
import Vue from 'vue';
import { GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import moment, { months } from 'moment';
import AutomatedFuelScheduleEnum from '../../../../enums/automated-fuel-schedule.enum';

function increment() {
  this.count++;
}

function decrement() {
  this.count--;
}

function buttonToggle(event) {
  this.isActive = [false, false, false, false, false, false, false];
  this.customScheduleData.selectedDay = event.currentTarget.value;
  this.isActive.splice(event.currentTarget.value, 1, true);
  this.$emit('customFrequencyDay', this.customScheduleData.selectedDay);
}

function frequencyHandler(type, event) {
  let customSchedulePayload = {};
  if (type === 'cadence' && event === 'MONTH' && this.customScheduleData.count) {
    customSchedulePayload = {
      type: this.customScheduleData.selectedCadenceOption,
      interval: this.customScheduleData.count
    };
  } else if (type === 'cadence' && event === 'WEEK' && this.customScheduleData.count) {
    customSchedulePayload = {
      type: this.customScheduleData.selectedCadenceOption,
      interval: this.customScheduleData.count * 7
    };
  }
  if (type === 'interval' && this.customScheduleData.selectedCadenceOption === 'MONTH' && event) {
    customSchedulePayload = {
      type: this.customScheduleData.selectedCadenceOption,
      interval: this.customScheduleData.count
    };
  } else if (type === 'interval' && this.customScheduleData.selectedCadenceOption === 'WEEK' && event) {
    customSchedulePayload = {
      type: this.customScheduleData.selectedCadenceOption,
      interval: this.customScheduleData.count * 7
    };
  }
  this.$emit('customFrequency', customSchedulePayload);
  GoogleAnalyticsService.event(Vue, 'Frequency updated', 'Frequency-Fuel-Schedule', `Frequency data updates ${type} and ${event} `);
}

function initToggle() {
  const day = moment(this.defaultDate).day();
  this.customScheduleData.selectedDay = day;
  this.isActive = [false, false, false, false, false, false, false];
  this.isActive.splice(day, 1, true);
  if (this.isCustomScheduleDefault === true) {
    this.customScheduleData.count = 1;
    this.customScheduleData.selectedCadenceOption = '';
  } else if (_.get(this.interval, 'type') === 'DAY' && _.isInteger(this.interval.amount)) {
    this.customScheduleData.count = _.get(this.interval, 'amount') / 7;
    this.customScheduleData.selectedCadenceOption = 'WEEK';
  } else if (_.get(this.interval, 'type') === 'MONTH' && _.isInteger(this.interval.amount)) {
    this.customScheduleData.count = _.get(this.interval, 'amount');
    this.customScheduleData.selectedCadenceOption = 'MONTH';
  }
}

export default {
  name: 'Custom-schedule-frequency',
  components: {},
  data: () => ({
    customScheduleData: {
      count: 1,
      selectedCadenceOption: '',
      selectedDay: ''
    },
    AutomatedFuelSchedule: AutomatedFuelScheduleEnum,
    isActive: [false, false, false, false, false, false, false],
    rules: {
      select: [(v) => !!v || 'Required*'],
      text: [(v) => !!v || 'Required*']
    }
  }),
  props: {
    defaultDate: {
      required: false,
    },
    interval: {
      type: Object,
      required: false
    },
    isCustomScheduleDefault: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  mounted() {
    this.initToggle();
  },
  watch: {
    defaultDate() {
      this.initToggle();
    }
  },
  methods: {
    increment,
    decrement,
    buttonToggle,
    initToggle,
    frequencyHandler
  }
};
