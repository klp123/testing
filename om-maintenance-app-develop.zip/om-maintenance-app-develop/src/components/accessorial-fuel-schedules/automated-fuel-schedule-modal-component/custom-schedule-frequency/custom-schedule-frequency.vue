<template>
  <v-card>
    <div class="wrapper">
      <div class="title">
        Enter Custom Occurance
      </div>
      <div class="customSchedule">
        <div class="w-15 mr-4">
          <v-subheader class="subheader">Interval</v-subheader>
          <v-text-field v-model.number="customScheduleData.count" dense outlined single-line type="number" min=1
            @click:append-outer="increment" @click:prepend="decrement" @change="frequencyHandler('interval', $event)"
            :rules="rules.text" />
        </div>
        <div class="w-20 mr-6">
          <v-subheader class="subheader">Interval Type</v-subheader>
          <v-select v-model="customScheduleData.selectedCadenceOption" attach :items="AutomatedFuelSchedule.CADENCE_LIST"
            item-text="displayValue" item-value="value" dense outlined @change="frequencyHandler('cadence', $event)"
            :rules="rules.select" />
        </div>
        <div class="btnGroup">
          <div>
            <v-subheader class="subheader">Process day of week</v-subheader>
          </div>
          <div class="btns">
            <v-btn class="circleBtn" v-for="day in AutomatedFuelSchedule.DAYS_OF_WEEK_LIST" :key="day.value"
              :value="day.value" :class="{ activeBtn: isActive[day.value] }" fab outlined depressed small
              @click="buttonToggle($event)">
              {{ day.displayValue }}
            </v-btn>
          </div>
        </div>
      </div>
    </div>
  </v-card>
</template>

<script src="./custom-schedule-frequency.js"></script>
<style src="./custom-schedule-frequency.sass" lang="sass" scoped></style>