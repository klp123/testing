import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import moment from 'moment';
import _ from 'lodash';
import Vue from 'vue';
import { GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import commonService from '../../../services/common.service';
import DatetimePickerComponent from '../../shared/datetime-picker/datetime-picker.vue';
import CustomScheduleFrequency from './custom-schedule-frequency/custom-schedule-frequency.vue';
import AutomatedScheduleType from './automated-schedule-type/automated-schedule-type.vue';
import AutomatedFuelScheduleService from '../../../services/accessorial-fuel-schedules/automated-fuel-schedule.service';
import AutomatedFuelScheduleEnum from '../../../enums/automated-fuel-schedule.enum';
import fuelScaleService from '../../customer/details/services/fuel-scale.service';

function onDateTimeChange(date) {
  if (date) {
    this.formData.startDateTime.dateTime = moment(date).startOf('day').format('MM/DD/YY').toString();
    this.dayCalculator();
    this.setFrequencies();
    this.fetchRelatedFuelScales();
  }
}

function closeAutomatedFuelScheduleModal() {
  this.$emit('afsClosed');
  this.isEditForm = false;
  this.isDisabled = false;
  GoogleAnalyticsService.event(Vue, 'Close dialog', 'Automated-Fuel-Schedule', 'Closed AFS dialog');
  this.showAutomatedFuelScheduleModal = false;
}

async function fetchRegions() {
  try {
    const regions = await commonService.getCommonLov('OM_ACCESSORIALS_DOE_REGION');
    if (regions) {
      this.regions = regions;
    }
  } catch (error) {
    if (error.message && error.message !== RequestErrorTypesEnum.CANCEL_REQUEST) {
      HgNotificationService.errorMessage(`Could not fetch DOE Regions due to error: ${error}`);
    }
  }
}

async function fetchFuelScheduleData(customerDetails) {
  try {
    const priorFuelScheduleData = await AutomatedFuelScheduleService.getFuelSchedule(customerDetails._id);
    GoogleAnalyticsService.event(Vue, 'Fetch schedule', 'Automated-Fuel-Schedule', 'Fetched fuel schedule', { accessorials_fuel_customer: _.get(customerDetails, 'customer.name', '') });
    if (priorFuelScheduleData) {
      const priorFuelSchedule = priorFuelScheduleData[0];
      this.priorFuelData = {
        chargeCodeIdentifier: _.get(priorFuelSchedule, 'chargeCodeIdentifier'),
        _id: _.get(priorFuelSchedule, '_id'),
        customer: _.get(priorFuelSchedule, 'customer'),
        type: _.get(priorFuelSchedule, 'type'),
        transportMode: _.get(priorFuelSchedule, 'transportMode'),
        equipment: _.get(priorFuelSchedule, 'equipment'),
        country: _.get(priorFuelSchedule, 'country'),
        frequency: _.get(priorFuelSchedule, 'frequency'),
        interval: _.get(priorFuelSchedule, 'interval'),
        doeRegion: _.get(priorFuelSchedule, 'doeRegion'),
        doeRateType: _.get(priorFuelSchedule, 'doeRateType'),
        doeRounded: _.get(priorFuelSchedule, 'doeRounded'),
        doePrecision: _.get(priorFuelSchedule, 'doePrecision'),
        doeAdjustment: _.get(priorFuelSchedule, 'doeAdjustment'),
        doeTimeframe: _.get(priorFuelSchedule, 'doeTimeframe'),
        formula: _.get(priorFuelSchedule, 'formula'),
        notifications: _.get(priorFuelSchedule, 'notifications'),
        remarks: _.get(priorFuelSchedule, 'remarks'),
        scheduleType: _.get(priorFuelSchedule, 'scheduleType'),
        startDateTime: {
          dateTime: _.get(priorFuelSchedule, 'startDateTime.dateTime')
        },
        fuelScaleIdentifier: _.get(priorFuelSchedule, 'fuelScaleIdentifier')
      };
      this.initFormData();
      this.isEditForm = true;
      this.isDisabled = this.priorFuelData.type === 'H';
      this.datePickerConfig.disabled = this.isEditForm && this.isDisabled;
      if (this.datePickerConfig.disabled) {
        this.datePickerConfig.minDate = '';
      }
    }
  } catch (error) {
    if (error.message && error.message !== RequestErrorTypesEnum.CANCEL_REQUEST) {
      HgNotificationService.errorMessage(`Could not fetch fuel schedule due to error: ${error}`);
    }
  }
}

async function fetchRelatedFuelScales() {
  try {
    const fuelScaleParamsPayload = {
      customer: _.get(this.selectedCustomerDetails, 'customer'),
      transportMode: _.get(this.selectedCustomerDetails, 'transportMode'),
      equipment: _.get(this.selectedCustomerDetails, 'equipment'),
      type: _.get(this.selectedCustomerDetails, 'type'),
      publishDateTime: {
        dateTime: moment(this.formData.startDateTime.dateTime).tz('America/Chicago').startOf('day').toISOString()
      }
    };

    const fuelScaleData = await fuelScaleService.customerFuelScale(fuelScaleParamsPayload);
    this.fuelScaleList = fuelScaleData.data || [];
  } catch (error) {
    if (error.message && error.message !== RequestErrorTypesEnum.CANCEL_REQUEST) {
      HgNotificationService.errorMessage(`Could not fetch fuel scale data due to error: ${error}`);
    }
  }
}

function initFormData() {
  if (this.priorFuelData) {
    this.formData = _.cloneDeep(this.priorFuelData);
    const frequency = _.get(this.priorFuelData, 'frequency');
    const intervalAmount = _.get(this.priorFuelData, 'interval.amount');
    const intervalType = _.get(this.priorFuelData, 'interval.type');
    if (frequency === 'DATE' || (intervalAmount === 1 && intervalType === 'MONTH')) {
      this.selectedFrequency = 'DATE';
      this.isCustomScheduleDefault = true;
    } else if ((frequency === 'INTERVAL' && intervalAmount === 7 && intervalType === 'DAY')) {
      this.selectedFrequency = 'WEEKLY';
      this.isCustomScheduleDefault = true;
    } else if ((frequency === 'INTERVAL' && intervalAmount === 14 && intervalType === 'DAY')) {
      this.selectedFrequency = 'BIWEEKLY';
      this.isCustomScheduleDefault = true;
    } else {
      this.selectedFrequency = 'CUSTOM';
    }
  }
}

function doeRateTypeHandler(radioData) {
  this.formData.doeRateType = radioData;
}

function doeAdjustmentHandler(doeAdjustmentOptions) {
  this.formData.doeAdjustment = _.get(doeAdjustmentOptions, 'doeAdjustment');
  this.formData.fuelScaleIdentifier = _.get(doeAdjustmentOptions, 'fuelScaleIdentifier');
  this.formData.formula = _.get(doeAdjustmentOptions, 'formula');
}

function rateHandler(timeframe, selectedDoeTimeFrame) {
  if (timeframe === 'publishedTimeframeUpdate') {
    this.formData.doeTimeframe = selectedDoeTimeFrame;
  }
}

function dayCalculator() {
  if (this.formData.startDateTime.dateTime) {
    this.day = moment(this.formData.startDateTime.dateTime).format('dddd');
  }
}

function dateSuffix(date) {
  switch (date) {
    case 1:
      return `${date}st`;
    case 21:
      return `${date}st`;
    case 31:
      return `${date}st`;
    case 2:
      return `${date}nd`;
    case 22:
      return `${date}nd`;
    case 3:
      return `${date}rd`;
    case 23:
      return `${date}rd`;
    default:
      return `${date}th`;
  }
}

function setFrequencies() {
  const selectedDate = moment(this.formData.startDateTime.dateTime).date();
  this.frequencies = [
    {
      display: `On the ${dateSuffix(selectedDate)} of every month`,
      value: 'DATE'
    },
    {
      display: `Weekly on ${this.day}`,
      value: 'WEEKLY'
    },
    {
      display: `Every other ${this.day}`,
      value: 'BIWEEKLY'
    },
    {
      display: 'Custom',
      value: 'CUSTOM'
    }
  ];
}

function frequncyHandler(intervalType) {
  if (intervalType === 'DATE') {
    this.formData.frequency = 'DATE';
    this.formData.interval.type = 'MONTH';
    this.formData.interval.amount = 1;
  } else if (intervalType === 'WEEKLY') {
    this.formData.frequency = 'INTERVAL';
    this.formData.interval.type = 'DAY';
    this.formData.interval.amount = 7;
  } else if (intervalType === 'BIWEEKLY') {
    this.formData.frequency = 'INTERVAL';
    this.formData.interval.type = 'DAY';
    this.formData.interval.amount = 14;
  } else if (intervalType === 'CUSTOM') {
    this.formData.frequency = 'INTERVAL';
    this.formData.interval.type = '';
    this.formData.interval.amount = 1;
  }
  if (this.selectedFrequency !== 'CUSTOM') {
    this.isCustomScheduleDefault = true;
  }
}

function customDayHandler(scheduleIntervalDay) {
  const dayCalc = scheduleIntervalDay - moment(this.formData.startDateTime.dateTime).days();
  const date = moment(this.formData.startDateTime.dateTime).add(dayCalc, 'd').toDate();
  this.formData.startDateTime.dateTime = date.toString();
}

function customFrequencyHandler(customSchedule) {
  if (customSchedule) {
    this.formData.interval.type = customSchedule.type === 'MONTH' ? customSchedule.type : 'DAY';
    this.formData.interval.amount = customSchedule.interval;
  }
}

function precision(precisionChoice) {
  this.formData.doePrecision = parseInt(precisionChoice, 10);
}

function isFormValid(form, priorForm, validRequirements) {
  // CHECK REQUIRED FIELDS IN CHILD COMPONENTS
  const isInvalidForm = (form.doeAdjustment === 'FORMULA' && !form.formula) || (form.doeRateType && _.isEmpty(form.doeTimeframe)) || !validRequirements || (form.doeAdjustment === 'SCALE' && !form.fuelScaleIdentifier);
  if (isInvalidForm) {
    return false;
  }
  // DETECT CHANGES
  if (_.isEqual(form, priorForm)) {
    return HgNotificationService.errorMessage('No changes detected. Please make updates before submitting.');
  }
  return true;
}

async function postAutomatedFuelSchedule(formData, editForm = false) {
  try {
    if (formData) {
      formData = { ...formData, startDateTime: { dateTime: moment(formData.startDateTime.dateTime).tz('America/Chicago') } };
      await AutomatedFuelScheduleService.createFuelSchedule(formData);
      const action = editForm ? 'UPDATE' : 'CREATE';
      GoogleAnalyticsService.event(Vue, `${action} schedule`, 'Automated-Fuel-Schedule', `${action} AFS`, {
        accessorials_fuel_customer: _.get(formData, 'customer.name', ''),
        accessorials_fuel_mode: _.get(formData, 'transportMode', ''),
        accessorials_fuel_country: _.get(formData, 'country', ''),
        accessorials_fuel_equipment: formData.equipment ? _.get(formData, 'equipment.equipmentType', '') + _.get(formData, 'equipment.length.amount', '') : ''
      });
      HgNotificationService.successMessage('Successfully submitted a fuel schedule.');
    }
  } catch (err) {
    console.error('Error when submitting AFS', err.message);
    if (err.message && err.message !== RequestErrorTypesEnum.CANCEL_REQUEST) {
      HgNotificationService.errorMessage('Error while fetching accessorials fuel schedules');
    }
  }
}

async function submit() {
  try {
    if (isFormValid(this.formData, this.priorFuelData, this.$refs.afsForm.validate())) {
      // MAIN SUBMIT LOGIC
      await postAutomatedFuelSchedule(this.formData, this.isEditForm);
      this.$emit('afsClosed');
    }
  } catch (error) {
    if (error.message && error.message !== RequestErrorTypesEnum.CANCEL_REQUEST) {
      HgNotificationService.errorMessage(`Could not submit form due to error: ${error}`);
    }
  }
}

async function calcFuelSchedule() {
  try {
    if (isFormValid(this.formData, null, this.$refs.afsForm.validate())) {
      let payload = _.cloneDeep(this.formData);
      if (!_.get(payload, 'nextRunDateTime.dateTime') || _.get(payload, 'startDateTime.dateTime') !== this.priorFuelData.startDateTime) {
        payload = { ...payload, nextRunDateTime: _.get(payload, 'startDateTime') };
      }
      this.calculationResults = '';
      const calcRateData = await AutomatedFuelScheduleService.calculateFuelSchedule(payload);
      GoogleAnalyticsService.event(Vue, 'Calculate schedule', 'Automated-Fuel-Schedule', 'Calculated AFS', {
        accessorials_fuel_customer: _.get(payload, 'customer.name', ''),
        accessorials_fuel_mode: payload.transportMode,
        accessorials_fuel_country: payload.country,
        accessorials_fuel_equipment: payload.equipment ? _.get(payload, 'equipment.equipmentType', '') + _.get(payload, 'equipment.length.amount', '') : ''
      });
      if (calcRateData.error || !calcRateData.doeProcessedRate || !calcRateData.newFuelRate) {
        HgNotificationService.errorMessage(`Could not calculate rate due to error: ${calcRateData.error || 'Missing required data points'}`);
      } else if (calcRateData.doeProcessedRate && calcRateData.newFuelRate) {
        this.calculationResults = calcRateData;
      }
    }
  } catch (error) {
    if (error.message && error.message !== RequestErrorTypesEnum.CANCEL_REQUEST) {
      HgNotificationService.errorMessage(`Could not calculate rate due to error: ${error}`);
    }
  }
}

export default {
  name: 'AutomatedFuelScheduleModal',
  components: {
    DatetimePickerComponent,
    CustomScheduleFrequency,
    AutomatedScheduleType
  },
  data: () => ({
    moment,
    lodash: _,
    showAutomatedFuelScheduleModal: true,
    valid: false,
    timeMenu: false,
    notifications: false,
    widgets: false,
    regions: [],
    day: '',
    hours: 0,
    selectedFrequency: 'DATE',
    frequencies: [],
    isCustomScheduleDefault: false,
    doeRoundingOptions: AutomatedFuelScheduleEnum.ROUNDING_OPTION_LIST,
    calculationResults: '',
    isEditForm: false,
    fuelScaleList: [],
    isDisabled: false,
    datePickerConfig: {
      disabled: false,
      minDate: moment(new Date()).tz('America/Chicago').format().split('T')[0]
    },
    formData: {
      _id: '',
      chargeCodeIdentifier: '',
      customer: {
        name: '',
        id: '',
      },
      type: '',
      transportMode: '',
      equipment: '',
      country: '',
      frequency: 'DATE',
      interval: {
        type: 'MONTH',
        amount: 1
      },
      doeAdjustment: '',
      doePrecision: 4,
      doeProcessedRate: 0,
      doeRegion: 'NATIONAL',
      doeRateType: 'PUBLISHED_RATE',
      doeRounded: true,
      doeTimeframe: {
        month: '',
        weekOfMonth: '',
        weekFromCurrent: ''
      },
      formula: '',
      notifications: [],
      remarks: '',
      scheduleType: 'AUTO',
      startDateTime: {
        dateTime: moment().toDate()
      },
      fuelScaleIdentifier: ''
    },
    priorFuelData: '',
    rules: {
      minText: [(v) => (!!v && (v >= 1 && v <= 4)) || 'Required* \n Min: 1']
    }
  }),
  props: {
    selectedCustomerDetails: {
      type: Object,
      default: () => ({})
    },
    showDialogToggle: {
      type: Boolean,
      default: false
    }
  },
  created() {
    this.fetchRegions();
    this.fetchFuelScheduleData(this.selectedCustomerDetails);
  },
  mounted() {
    this.dayCalculator();
    this.setFrequencies();
    this.formData.chargeCodeIdentifier = _.get(this.selectedCustomerDetails, '_id');
    this.formData.customer = _.get(this.selectedCustomerDetails, 'customer');
    this.formData.type = _.get(this.selectedCustomerDetails, 'type');
    this.formData.country = _.get(this.selectedCustomerDetails, 'country');
    this.formData.transportMode = _.get(this.selectedCustomerDetails, 'transportMode');
    this.formData.equipment = _.get(this.selectedCustomerDetails, 'equipment');
  },
  methods: {
    submit,
    closeAutomatedFuelScheduleModal,
    onDateTimeChange,
    fetchRegions,
    doeRateTypeHandler,
    dayCalculator,
    setFrequencies,
    customFrequencyHandler,
    customDayHandler,
    rateHandler,
    isFormValid,
    doeAdjustmentHandler,
    dateSuffix,
    frequncyHandler,
    fetchFuelScheduleData,
    initFormData,
    precision,
    calcFuelSchedule,
    fetchRelatedFuelScales
  }
};
