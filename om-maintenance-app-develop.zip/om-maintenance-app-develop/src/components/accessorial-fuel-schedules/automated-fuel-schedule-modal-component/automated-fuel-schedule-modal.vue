<template>
  <div class="blocker">
    <v-dialog v-model="showAutomatedFuelScheduleModal" width="670px" height="90%" hide-overlay
      transition="dialog-bottom-transition" persistent>
      <v-overlay class="overlayHeight">
      </v-overlay>
      <v-card class="modalHeight" elevation="2">
        <div class="wrapper">
          <div class="toolbarTitle">
            <div class="mw-50">
              <div>
                Automated Fuel Schedule
              </div>
              <div class="requiredSubtitle">
                {{ isDisabled ? 'Hub default AFS are locked*' : 'All Fields are required*' }}
              </div>
            </div>
            <div class="mw-50">
              <div class="d-flex flex-row justify-space-between">
                <v-tooltip top nudge-bottom="15" class="d-flex flex-row customerDetails">
                  <template v-slot:activator="{ on, attrs }" class="d-flex flex-row customerDetails">
                    <div class="text-truncate"
                      v-if="selectedCustomerDetails.customer && selectedCustomerDetails.customer.name && selectedCustomerDetails.customer.id"
                      v-bind="attrs" v-on="on">
                      {{ selectedCustomerDetails.customer.name }} - {{
                        selectedCustomerDetails.customer.id }}
                    </div>
                    <div v-else>{{ '' }}</div>
                  </template>
                  <span
                    v-if="selectedCustomerDetails.customer && selectedCustomerDetails.customer.name && selectedCustomerDetails.customer.id">
                    {{ selectedCustomerDetails.customer.name }} - {{
                      selectedCustomerDetails.customer.id }}</span>
                </v-tooltip>
                <v-btn @click="closeAutomatedFuelScheduleModal()" icon>
                  <v-icon id="modal-close">mdi-close</v-icon>
                </v-btn>
              </div>
              <div class="d-flex customerSubtitle">
                <div class="pr-3"><strong>Mode:</strong> {{ lodash.get(selectedCustomerDetails, 'transportMode') }}</div>
                <div class="pr-3"><strong>Type:</strong> {{ lodash.get(selectedCustomerDetails, 'type') }}</div>
                <div><strong>Country:</strong> {{ lodash.get(selectedCustomerDetails, 'country') }}</div>
              </div>
            </div>
          </div>
          <hr class="my-3" />
          <template>
            <v-form :disabled="isDisabled" ref="afsForm"  v-model="valid" @submit.prevent="submit">
              <v-row>
                <v-col cols="6">
                  <div>
                    <div id="dateTimePickerAnchor">
                      <div class="body-header">Start Date & Time</div>
                      <v-subheader class="pa-0 ma-0">Select Date</v-subheader>
                      <DatetimePickerComponent :config="datePickerConfig" @dateTimeChanged="onDateTimeChange($event)"
                      :dateTime="moment(formData.startDateTime.dateTime).format('MM/DD/YY')" :required="true" :minRule="true"
                      checkIfValidDate />
                    </div>
                  </div>
                </v-col>
                <v-col cols="6">
                  <div>
                    <div class="body-header">DOE Region</div>
                    <v-subheader class="pa-0 ma-0">Select Region</v-subheader>
                    <v-select v-model="formData.doeRegion" hide-details attach :items="regions" item-text="displayValue"
                      outlined dense />
                  </div>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="6">
                  <div>
                    <div class="body-header">Schedule Frequency</div>
                    <v-subheader class="pa-0 ma-0">Select Frequency of schedule</v-subheader>
                    <v-select v-model="selectedFrequency" attach @change="frequncyHandler($event)" :items="frequencies"
                      item-text="display" item-value="value" outlined dense />
                  </div>
                </v-col>
                <v-col cols="6">
                  <div class="body-header">Rounding Option</div>
                  <v-subheader class="pa-0 ma-0">Utilize Rounding and Precision Amount</v-subheader>
                  <v-row>
                    <v-col cols="6">
                      <v-switch class="" v-model="formData.doeRounded" hide-details color="var(--v-secondary-base)" inset
                        :label="`${formData.doeRounded ? 'Yes' : 'No'}`" />
                    </v-col>
                    <v-col cols="6">
                      <v-text-field v-model="formData.doePrecision" type="number" :maxlength="1" placeholder="No." :min="1"
                        :max="4" hint="min:1 max:4" outlined dense :rules="rules.minText"
                        @change="precision($event)"></v-text-field>
                    </v-col>
                  </v-row>
                </v-col>
              </v-row>
              <v-row v-if="selectedFrequency === 'CUSTOM'">
                <v-col cols="12">
                  <div>
                    <custom-schedule-frequency @customFrequency="customFrequencyHandler($event)"
                      @customFrequencyDay="customDayHandler($event)" :defaultDate="formData.startDateTime.dateTime"
                      :interval="priorFuelData.interval" :isCustomScheduleDefault="isCustomScheduleDefault" />
                  </div>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12">
                  <div>
                    <div class="body-header">Schedule Type</div>
                    <v-radio-group v-model="formData.scheduleType" row mandatory >
                      <v-radio active-class="radioSelected" default label="Automated" value="AUTO" color="var(--v-secondary-base)" />
                      <v-radio active-class="radioSelected" label="Manual" value="MANUAL" color="var(--v-secondary-base)"/>
                    </v-radio-group>
                  </div>
                  <div v-if="formData.scheduleType === 'AUTO'">
                    <automatedScheduleType @doeAdjustment="doeAdjustmentHandler($event)"
                      @doeRateTypeChange="doeRateTypeHandler($event)"
                      @publishedTimeframeUpdate="rateHandler('publishedTimeframeUpdate', $event)"
                      :priorDoeRateType="priorFuelData.doeRateType" :priorDoeTimeframe="priorFuelData.doeTimeframe"
                      :priorDoeFormula="priorFuelData.formula" :priorDoeAdjustment="priorFuelData.doeAdjustment"
                      :priorFuelScaleIdentifier="priorFuelData.fuelScaleIdentifier" :fuelScaleList="fuelScaleList"
                      :isHubDefault="selectedCustomerDetails.type === 'H'" :isDisabled="isDisabled"/>
                  </div>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12">
                  <div>
                    <div class="body-header">
                      Remarks
                    </div>
                    <v-subheader class="pa-0">Add your remarks below</v-subheader>
                    <v-textarea v-model="formData.remarks" auto-grow outlined clearable :counter="150" :maxlength="150"
                      name="remarks" :value="formData.remarks">
                    </v-textarea>
                  </div>
                </v-col>
              </v-row>
              <v-row v-if="calculationResults">
                <v-col cols="12" class="calcResults">
                  <div>
                    {{ `DOE Rate: ${calculationResults.doeProcessedRate}` }}
                  </div>
                  <div>
                    {{ `Calculated Rate: ${calculationResults.newFuelRate}` }}
                  </div>
                  <hr />
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12">
                  <div class="d-flex justify-space-between">
                    <div>
                      <hg-lib-btn class="mr-3" title="Test AFS" type="primary" @click.native="calcFuelSchedule()" />
                    </div>
                    <div class="d-flex justify-end">
                      <hg-lib-btn class="mr-3 cancelBtn" title="Cancel" type="secondary"
                        @click.native="closeAutomatedFuelScheduleModal()" />
                      <hg-lib-btn :disabled="isDisabled" :title="isEditForm ? 'Save' : 'Create'" type="primary" @click.native="submit()" />
                    </div>
                  </div>
                </v-col>
              </v-row>
            </v-form>
          </template>
        </div>
      </v-card>
    </v-dialog>
  </div>
</template>

<script src="./automated-fuel-schedule-modal.js"></script>
<style src="./automated-fuel-schedule-modal.sass" lang="sass" scoped></style>
