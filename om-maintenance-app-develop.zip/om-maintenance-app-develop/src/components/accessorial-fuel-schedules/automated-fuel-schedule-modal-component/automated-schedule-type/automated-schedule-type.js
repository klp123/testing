import _ from 'lodash';
import moment from 'moment';
import Vue from 'vue';
import { GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import RequestErrorTypesEnum from '@hubgroup/hg-vue-om-util-lib/src/enums/request-error-types.enum';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import commonService from '../../../../services/common.service';
import AutomatedFuelScheduleEnum from '../../../../enums/automated-fuel-schedule.enum';
import fuelScaleDetailDialog from '../../../customer/details/components/fuel-scale-detail-dialog/fuel-scale-detail-dialog.vue';

const FormulaParser = require('hot-formula-parser').Parser;

async function fetchLOVLists() {
  try {
    const doeRateCalcTypeList = await commonService.getCommonLov('OM_ACCESSORIALS_RATE_TYPE');
    if (doeRateCalcTypeList) {
      this.doeRateCalcTypeOptions = doeRateCalcTypeList;
    }
    const doeFormulaOptionList = await commonService.getCommonLov('OM_ACCESSORIALS_DOE_MODIFIER');
    if (doeFormulaOptionList) {
      this.doeFormulaOptions = doeFormulaOptionList;
    }
  } catch (error) {
    if (error.message && error.message !== RequestErrorTypesEnum.CANCEL_REQUEST) {
      HgNotificationService.errorMessage(`Could not fetch Frequencies due to error: ${error}`);
    }
  }
}

function clearPublishedData() {
  this.publishedTimeframe.selectedPublishedMonth = '';
  this.publishedTimeframe.selectedPublishedWeek = '';
  this.publishedTimeframe.selectedPublishedWeekOfMonth = '';
  const selectedDoeTimeFrame = {
    month: '',
    weekFromCurrent: '',
    weekOfMonth: ''
  };
  this.$emit('publishedTimeframeUpdate', selectedDoeTimeFrame);
  GoogleAnalyticsService.event(Vue, 'Clear DOE rates', 'DOE-Rate-Fuel-Schedules', 'Published rate removed');
}

function clearScheduleTypeStates() {
  this.selectedPublishedRateOption = '';
  this.selectedMonthToAvg = '';
  this.selectedWeeksInMonthToAvg = '';
  this.selectedRollingAvg = '';
  this.clearPublishedData();
}

async function handleDoeAdjustment() {
  if (this.selectedFormulaRadio === 'SCALE' && !this.fuelScaleList.length) {
    HgNotificationService.errorMessage('No active fuel scales found. Please upload an active fuel scale before creating an AFS.');
  }

  this.isExpiredPriorFuelScale = false;
  this.selectedFuelScale = this.selectedFormulaRadio === 'SCALE' ? this.selectedFuelScale : '';
  this.doeFormula = this.selectedFormulaRadio === 'FORMULA' ? _.toUpper(this.doeFormula) : '';

  if (this.selectedFuelScale) {
    this.selectedFuelScaleData = this.fuelScaleList.find((fuelScale) => String(fuelScale._id) === this.selectedFuelScale);
  }

  const doeAdjustmentOptions = {
    formula: this.doeFormula,
    fuelScaleIdentifier: this.selectedFuelScale,
    doeAdjustment: this.selectedFormulaRadio !== 'NO_ADJUSTMENT' ? this.selectedFormulaRadio : ''
  };

  this.$emit('doeAdjustment', doeAdjustmentOptions);
}

function updateWeekOfMonth() {
  let selectedDoeTimeframe = {};
  this.publishedTimeframe.selectedPublishedWeek = '';
  if (this.selectedDoeRateCalcTypeRadio === 'PUBLISHED_RATE' && this.selectedPublishedRateOption === 'weekOfMonth') {
    selectedDoeTimeframe = {
      month: this.publishedTimeframe.selectedPublishedMonth,
      weekFromCurrent: '',
      weekOfMonth: this.publishedTimeframe.selectedPublishedWeekOfMonth
    };
  } else if (this.selectedDoeRateCalcTypeRadio === 'AVERAGE') {
    selectedDoeTimeframe = {
      month: this.selectedMonthToAvg,
      weekFromCurrent: '',
      weekOfMonth: this.selectedWeeksInMonthToAvg
    };
  }
  this.$emit('publishedTimeframeUpdate', selectedDoeTimeframe);
}

function updateWeekFromCurrent() {
  let selectedDoeTimeframe = {};
  this.publishedTimeframe.selectedPublishedWeekOfMonth = '';
  this.publishedTimeframe.selectedPublishedMonth = '';
  this.publishedTimeframe.selectedPublishCustomWeek = '';
  if (this.selectedDoeRateCalcTypeRadio === 'PUBLISHED_RATE') {
    if (this.selectedPublishedRateOption === 0 || this.selectedPublishedRateOption === 1) {
      this.publishedTimeframe.selectedPublishedMonth = 0;
      this.publishedTimeframe.selectedPublishedWeek = this.selectedPublishedRateOption;
      selectedDoeTimeframe = {
        month: this.publishedTimeframe.selectedPublishedMonth,
        weekFromCurrent: parseInt(this.publishedTimeframe.selectedPublishedWeek, 10),
        weekOfMonth: ''
      };
    }
  } else if (this.selectedDoeRateCalcTypeRadio === 'ROLLING_AVERAGE') {
    if (this.selectedRollingAvg !== 'Custom') {
      this.selectedNumRollingAvg = '';
      selectedDoeTimeframe = {
        month: 0,
        weekFromCurrent: parseInt(this.selectedRollingAvg, 10),
        weekOfMonth: ''
      };
    } else {
      selectedDoeTimeframe = {
        month: 0,
        weekFromCurrent: this.selectedNumRollingAvg ? parseInt(this.selectedNumRollingAvg, 10) - 1 : '',
        weekOfMonth: ''
      };
    }
  }
  this.$emit('publishedTimeframeUpdate', selectedDoeTimeframe);
}

function updateWeekFromCurrentCustom() {
  this.publishedTimeframe.selectedPublishWeek = '';
  this.publishedTimeframe.selectedPublishedMonth = 0;
  const selectedDoeTimeframe = {
    month: this.publishedTimeframe.selectedPublishedMonth,
    weekFromCurrent: parseInt(this.publishedTimeframe.selectedPublishCustomWeek, 10),
    weekOfMonth: ''
  };
  this.$emit('publishedTimeframeUpdate', selectedDoeTimeframe);
}

function initPublishedTimeframe(doeTimeframe) {
  if (doeTimeframe) {
    let selectedDoeTimeframe = {};
    if (doeTimeframe.weekFromCurrent === 0 || doeTimeframe.weekFromCurrent === 1) {
      this.selectedPublishedRateOption = doeTimeframe.weekFromCurrent;
      this.publishedTimeframe.selectedPublishedMonth = doeTimeframe.month;
      this.publishedTimeframe.selectedPublishedWeek = doeTimeframe.weekFromCurrent;
      selectedDoeTimeframe = {
        month: this.publishedTimeframe.selectedPublishedMonth,
        weekFromCurrent: this.publishedTimeframe.selectedPublishedWeek,
        weekOfMonth: ''
      };
    } else if (doeTimeframe.weekFromCurrent > 1) {
      this.selectedPublishedRateOption = 'weekFromCurrent';
      this.publishedTimeframe.selectedPublishCustomWeek = doeTimeframe.weekFromCurrent;
      this.publishedTimeframe.selectedPublishedMonth = doeTimeframe.month;
      selectedDoeTimeframe = {
        month: this.publishedTimeframe.selectedPublishedMonth,
        weekFromCurrent: this.publishedTimeframe.selectedPublishCustomWeek,
        weekOfMonth: ''
      };
    } else if (doeTimeframe.weekOfMonth) {
      this.selectedPublishedRateOption = 'weekOfMonth';
      this.publishedTimeframe.selectedPublishedMonth = doeTimeframe.month;
      this.publishedTimeframe.selectedPublishedWeekOfMonth = doeTimeframe.weekOfMonth;
      selectedDoeTimeframe = {
        month: this.publishedTimeframe.selectedPublishedMonth,
        weekFromCurrent: '',
        weekOfMonth: this.publishedTimeframe.selectedPublishedWeekOfMonth
      };
    }
    this.$emit('publishedTimeframeUpdate', selectedDoeTimeframe);
  }
}

function isFormulaValid(formula) {
  let errorMessage = '';
  const isDOEVariableNotPresent = !formula.includes('DOE');
  if (!formula) {
    errorMessage = '*Required';
  } else if (isDOEVariableNotPresent) {
    errorMessage = '*Require variable: DOE';
  } else {
    // eslint-disable-next-line no-useless-escape
    const regex = /[^DOE\/\+\-\*\(\)\. 0-9]+/g;
    const isInvalidRegex = formula.match(regex);
    // Formula Parser to validate that the format is proper
    const parser = new FormulaParser();
    parser.setVariable('DOE', 1);
    const adjustedFuelRate = parser.parse(formula);
    const isInvalidFormulaFormat = adjustedFuelRate.error || (adjustedFuelRate.result === true || adjustedFuelRate.result === false);
    if (isInvalidRegex || isInvalidFormulaFormat) {
      errorMessage = '*Invalid formula';
    }
  }
  return errorMessage || true;
}

function closeFuelScaleDisplay() {
  this.showDialogToggle = false;
}

export default {
  name: 'Automated-schedule-type',
  components: {
    fuelScaleDetailDialog
  },
  data: () => ({
    moment,
    AutomatedFuelSchedule: AutomatedFuelScheduleEnum,
    selectedDoeRateCalcTypeRadio: 'PUBLISHED_RATE',
    doeRateCalcTypeOptions: [],
    selectedFormulaRadio: 'NO_ADJUSTMENT',
    doeFormulaOptions: [],
    selectedPublishedRateOption: '',
    publishedTimeframe: {
      selectedPublishedMonth: '',
      selectedPublishedWeek: '',
      selectedPublishedWeekOfMonth: '',
      selectedPublishCustomWeek: '',
    },
    selectedMonthToAvg: '',
    selectedWeeksInMonthToAvg: '',
    selectedRollingAvg: '',
    selectedNumRollingAvg: '',
    doeFormula: '',
    isScheduleTypeValid: false,
    selectedFuelScale: '',
    selectedFuelScaleData: {},
    isPrepopulatedFuelScale: false,
    isExpiredPriorFuelScale: false,
    showDialogToggle: false,
    rules: {
      select: [(v) => (!!v || v === 0) || 'Required*'],
      formulaText: [isFormulaValid],
      minText: [(v) => (!!v && v >= 2) || 'Required* \n Min: 2']
    }
  }),
  props: {
    priorDoeTimeframe: {
      type: Object,
      default: () => ({})
    },
    priorDoeRateType: {
      type: String,
      default: 'PUBLISHED_RATE'
    },
    priorDoeFormula: {
      type: String,
      default: ''
    },
    priorDoeAdjustment: {
      type: String,
      default: ''
    },
    priorFuelScaleIdentifier: {
      type: String,
      default: ''
    },
    fuelScaleList: {
      type: Array,
      default: () => ([])
    },
    isHubDefault: {
      type: Boolean,
      default: false
    },
    isDisabled: {
      type: Boolean,
      default: false
    }
  },
  created() {
    this.fetchLOVLists();
  },
  watch: {
    priorDoeTimeframe() {
      this.selectedDoeRateCalcTypeRadio = this.priorDoeRateType;
      if (this.selectedDoeRateCalcTypeRadio === 'PUBLISHED_RATE') {
        this.initPublishedTimeframe(this.priorDoeTimeframe);
      }
      if (this.selectedDoeRateCalcTypeRadio === 'AVERAGE') {
        this.selectedMonthToAvg = this.priorDoeTimeframe.month;
        this.selectedWeeksInMonthToAvg = this.priorDoeTimeframe.weekOfMonth;
      }
      if (this.selectedDoeRateCalcTypeRadio === 'ROLLING_AVERAGE') {
        if (this.priorDoeTimeframe.weekFromCurrent === 1 || this.priorDoeTimeframe.weekFromCurrent === 3) {
          this.selectedRollingAvg = this.priorDoeTimeframe.weekFromCurrent;
        } else {
          this.selectedRollingAvg = 'Custom';
          this.selectedNumRollingAvg = this.priorDoeTimeframe.weekFromCurrent + 1;
        }
      }
    },
    priorDoeAdjustment() {
      if (this.priorDoeAdjustment === '' || this.priorDoeAdjustment === 'NO_ADJUSTMENT') {
        this.selectedFormulaRadio = 'NO_ADJUSTMENT';
      } else {
        this.selectedFormulaRadio = this.priorDoeAdjustment;
      }
    },
    priorDoeFormula() {
      this.doeFormula = this.priorDoeFormula;
    },
    fuelScaleList() {
      if (this.priorFuelScaleIdentifier && this.fuelScaleList.find((fuelScale) => String(fuelScale._id) === this.priorFuelScaleIdentifier)) {
        this.selectedFuelScale = this.priorFuelScaleIdentifier;
        this.isPrepopulatedFuelScale = true;
      } else {
        this.isExpiredPriorFuelScale = true;
      }

      if (this.selectedFuelScale) {
        this.selectedFuelScaleData = this.fuelScaleList.find((fuelScale) => String(fuelScale._id) === this.selectedFuelScale);
      }

      if (!this.isPrepopulatedFuelScale) {
        this.selectedFuelScale = '';
        this.selectedFuelScaleData = {};
      }
      this.isPrepopulatedFuelScale = false;
    }
  },
  methods: {
    fetchLOVLists,
    clearScheduleTypeStates,
    handleDoeAdjustment,
    clearPublishedData,
    initPublishedTimeframe,
    updateWeekFromCurrent,
    updateWeekOfMonth,
    updateWeekFromCurrentCustom,
    isFormulaValid,
    closeFuelScaleDisplay
  }
};
