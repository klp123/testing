<template>
  <div flat class="scheduleType px-3 pt-3">
    <div>
      <div class="body-header">Select DOE Regional Rate to Utilize for Schedule</div>
      <div>
        <v-radio-group
          class="rateRadio"
          v-model="selectedDoeRateCalcTypeRadio"
          row
          mandatory
          @change="
            $emit('doeRateTypeChange', $event);
            clearScheduleTypeStates();
          "
        >
          <v-radio
            v-for="option in doeRateCalcTypeOptions"
            active-class="radioSelected"
            :key="`${option.value}`"
            :label="`${option.displayValue}`"
            :value="`${option.value}`"
            color="var(--v-secondary-base)"
          />
        </v-radio-group>
      </div>
      <div v-if="selectedDoeRateCalcTypeRadio === 'PUBLISHED_RATE'">
        <v-subheader class="pa-0 body-header">Select DOE published rate to use</v-subheader>
        <v-select
          class="select"
          v-model="selectedPublishedRateOption"
          attach
          :items="AutomatedFuelSchedule.PUBLISHED_RATE_LIST"
          item-text="displayValue"
          item-value="value"
          outlined
          :rules="rules.select"
          dense
          @change="updateWeekFromCurrent()"
        />
        <div
          class="d-flex"
          v-if="selectedPublishedRateOption === AutomatedFuelSchedule.PUBLISHED_RATE_LIST[3].value"
        >
          <div class="pr-8 w-50">
            <v-subheader class="pa-0 body-header">Select DOE month</v-subheader>
            <v-select
              class="select"
              v-model="publishedTimeframe.selectedPublishedMonth"
              attach
              :items="AutomatedFuelSchedule.SCHEDULE_TYPE_MONTH_LIST"
              item-text="displayValue"
              item-value="value"
              outlined
              @change="updateWeekOfMonth()"
              :rules="rules.select"
              dense
            />
          </div>
          <div class="w-50">
            <v-subheader class="pa-0 body-header">Select week of the month</v-subheader>
            <v-select
              class="select"
              v-model="publishedTimeframe.selectedPublishedWeekOfMonth"
              attach
              :items="AutomatedFuelSchedule.PUBLISHED_WEEK_LIST"
              item-text="displayValue"
              item-value="value"
              outlined
              @change="updateWeekOfMonth()"
              :rules="rules.select"
              dense
            />
          </div>
        </div>
        <div
          class="d-flex"
          v-if="selectedPublishedRateOption === AutomatedFuelSchedule.PUBLISHED_RATE_LIST[2].value"
        >
          <div class="w-115p pl-0 pr-8 pt-3">
            <v-text-field
              class="textAlign-center"
              v-model="publishedTimeframe.selectedPublishCustomWeek"
              background-color="var(--v-color_gray_lightest-base)"
              type="number"
              :maxlength="3"
              placeholder="No."
              hint="Min: 2"
              @change="updateWeekFromCurrentCustom()"
              min="2"
              outlined
              :rules="rules.minText"
              dense
            ></v-text-field>
          </div>
          <div class="alignSelf-center body-header"># of weeks from current</div>
        </div>
      </div>
      <div class="d-flex" v-if="selectedDoeRateCalcTypeRadio === 'AVERAGE'">
        <div class="w-50 pr-8">
          <v-subheader class="pa-0 body-header">Select month to average</v-subheader>
          <v-select
            class="select"
            v-model="selectedMonthToAvg"
            attach
            :items="AutomatedFuelSchedule.SCHEDULE_TYPE_MONTH_LIST"
            item-text="displayValue"
            item-value="value"
            outlined
            :rules="rules.select"
            dense
            @change="updateWeekOfMonth()"
          />
        </div>
        <div class="w-50">
          <v-subheader class="pa-0 body-header">Select weeks of month to average</v-subheader>
          <v-select
            class="select"
            v-model="selectedWeeksInMonthToAvg"
            attach
            :items="AutomatedFuelSchedule.WEEKS_IN_MONTH_TO_AVERAGE_LIST"
            item-text="displayValue"
            item-value="value"
            outlined
            :rules="rules.select"
            dense
            @change="updateWeekOfMonth()"
          />
        </div>
      </div>
      <div v-if="selectedDoeRateCalcTypeRadio === 'ROLLING_AVERAGE'">
        <v-subheader class="pa-0 body-header">Select rolling average duration</v-subheader>
        <div>
          <v-select
            class="select"
            v-model="selectedRollingAvg"
            attach
            :items="AutomatedFuelSchedule.ROLLING_AVERAGE_DURATION_LIST"
            item-text="displayValue"
            item-value="value"
            outlined
            :rules="rules.select"
            dense
            @change="updateWeekFromCurrent()"
          />
        </div>
        <div class="d-flex" v-if="selectedRollingAvg === 'Custom'">
          <div class="w-115p pl-0 pr-8 pt-3">
            <v-text-field
              class="textAlign-center"
              v-model="selectedNumRollingAvg"
              type="number"
              hint="Min: 2"
              :min="2"
              :maxlength="3"
              background-color="var(--v-color_gray_lightest-base)"
              placeholder="No."
              @change="updateWeekFromCurrent()"
              outlined
              :rules="rules.minText"
              dense
            ></v-text-field>
          </div>
          <div class="alignSelf-center body-header"># of rolling weeks including current</div>
        </div>
      </div>
      <hr />
      <div class="body-header">DOE Regional Rate Type</div>
      <v-radio-group
        class="formulaRadio"
        v-model="selectedFormulaRadio"
        row
        mandatory
        @change="handleDoeAdjustment()"
      >
        <v-radio
          v-for="option in doeFormulaOptions"
          :key="`${option.value}`"
          :label="`${option.displayValue}`"
          :value="`${option.value}`"
          color="var(--v-secondary-base)"
        />
      </v-radio-group>
      <div v-if="selectedFormulaRadio === 'SCALE'">
        <v-subheader class="pa-0 body-header">Select fuel scale</v-subheader>
        <v-select
          class="select"
          v-model="selectedFuelScale"
          attach
          :items="fuelScaleList"
          item-value="_id"
          @change="handleDoeAdjustment()"
          outlined
          :rules="rules.select"
          dense
        >
          <template slot="item" slot-scope="data">
            {{ data.item.country }} - {{ data.item.transportMode }} -
            {{ data.item.equipment.equipmentCode }} -
            {{ moment(data.item.publishDateTime.dateTime).format('MM/DD/YYYY') }}
          </template>
          <template slot="selection" slot-scope="data">
            {{ data.item.country }} - {{ data.item.transportMode }} -
            {{ data.item.equipment.equipmentCode }} -
            {{ moment(data.item.publishDateTime.dateTime).format('MM/DD/YYYY') }}
          </template>
        </v-select>
      </div>
      <div
        class="clickable expansion mb-1"
        v-if="selectedFormulaRadio === 'SCALE' && selectedFuelScale && selectedFuelScaleData"
        v-on:click="showDialogToggle = true"
      >
        View selected fuel scale
      </div>
      <div
        class="requiredSubtitle pb-1"
        v-if="!isHubDefault && priorFuelScaleIdentifier && isExpiredPriorFuelScale"
      >
        *Currently using expired fuel scale. Please choose an active scale if updating.
      </div>
      <fuelScaleDetailDialog
        v-if="showDialogToggle"
        :fuelScaleData="selectedFuelScaleData"
        @closeDialog="closeFuelScaleDisplay()"
      />
      <div v-if="selectedFormulaRadio === 'FORMULA'">
        <v-subheader class="pa-0 body-header">Add DOE formula</v-subheader>
        <v-text-field
          v-model="doeFormula"
          auto-grow
          outlined
          clearable
          :counter="50"
          :maxlength="50"
          @change="handleDoeAdjustment()"
          :rules="rules.formulaText"
          dense
        >
        </v-text-field>
      </div>
    </div>
  </div>
</template>

<script src="./automated-schedule-type.js"></script>
<style src="./automated-schedule-type.sass" lang="sass" scoped></style>
