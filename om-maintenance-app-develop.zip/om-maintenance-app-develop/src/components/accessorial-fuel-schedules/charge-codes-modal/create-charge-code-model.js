import * as _ from 'lodash';
import moment from 'moment';
import serviceTypeEnum from '@hubgroup/hg-vue-oc-util-lib/src/enums/service-types.enum';

const getTodayDate = () => moment(new Date()).tz('America/Chicago').format().split('T')[0];

const formData = {
  customer: null,
  transportMode: null,
  country: null,
  equipment: null,
  chargeCode: null,
  rateQualifier: null,
  effectiveDateTime: {},
  expiredDateTime: {},
  rates: [],
  layoverType: null,
  serviceType: null,
  railScac: null,
  rampScac: null,
  bundleCode: null,
  vendor: null,
  hubDefault: {
    id: null,
    name: null
  },
  type: 'C',
  specialTerms: null,
  notes: null,
  locations: [],
  minimumRate: null,
  maximumRate: null,
  isFreeDays999: null,
  freeHolidays: null,
  freeDays: null,
  freeTime: null,
  freeTimeType: null,
  freeCutOffTime: null,
  freeWeekendType: null,
  reloads: null,
  startEvent: null,
  endEvent: null
};

const chargeCodeInitialData = {
  showAsfModal: false,
  loadingCustList: false,
  loadingChargeCodesList: false,
  formData: _.cloneDeep(formData),
  customer: {
    items: [],
    key: 'customer',
    placeholder: 'Search Customers',
    searchType: 'customer',
    menuLabel: 'CUSTOMER',
  },
  chargeCode: {
    items: [],
    key: 'chargeCode',
    placeholder: 'Search Charge Code',
    searchType: 'chargeCode',
    menuLabel: 'CHARGE CODE',
  },
  transportMode: {
    modes: [],
    key: 'transportMode',
    placeholder: 'Select Mode',
    menuLabel: 'MODE',
  },
  equipmentType: {
    equipmentTypes: [],
    key: 'equipmentType',
    menuLabel: 'EQUIPMENT TYPE',
    placeholder: 'Search Equipment Types',
  },
  effectiveDateTime: '',
  expiredDateTime: '',
  effectiveDateConfig: {
    label: 'EFFECTIVE DATE',
    maxDate: null,
    minDate: getTodayDate(),
    disabled: false,
    required: true
  },
  expiredDateConfig: {
    label: 'EXPIRATION DATE',
    maxDate: null,
    minDate: getTodayDate(),
    disabled: false,
    required: true
  },
  serviceType: {
    serviceTypes: [..._.cloneDeep(Object.keys(serviceTypeEnum).map((key) => ({
      displayValue: key,
      value: serviceTypeEnum[key]
    })))],
    key: 'serviceType',
    menuLabel: 'Service Type',
    placeholder: 'Search Service Types',
  },
  railScac: {
    items: [],
    key: 'railScac',
    menuLabel: 'RAIL SCAC',
    placeholder: 'Enter RailSCAC',
  },
  rampScac: {
    items: [],
    key: 'rampScac',
    menuLabel: 'RAMP SCAC',
    placeholder: 'Enter RampSCAC',
  },
  rateQualifier: {
    rateQualifiers: [],
    key: 'rateQualifier',
    menuLabel: 'RATE QUALIFIER',
    placeholder: 'Search Rate Qualifier',
    searchType: 'rateQualifiers',
  },
  rates: [{
    rateValue: '',
    rateLimit: '',
  }],
  layoverType: {
    key: 'layoverType',
    searchType: 'layoverType',
    menuLabel: 'LAYOVER TYPE',
    placeholder: 'Select Layover',
  },
  bundleCode: {
    bundleCodes: [],
    key: 'bundleCode',
    searchType: 'bundleCode',
    menuLabel: 'BUNDLE CODE',
    placeholder: 'Search Bundle Code',
  },
  vendor: {
    items: [],
    key: 'vendor',
    searchType: 'vendor',
    menuLabel: 'VENDOR/CARRIER',
    placeholder: 'Search Vendor/Carrier',
  },
  hubDefault: {
    key: 'hubDefault',
    menuLabel: 'HUB DEFAULT NAME',
    placeholder: 'Enter HubDefault',
  },
  hubDefaultToggle: {
    key: 'hubDefaultToggle',
    menuLabel: 'CREATE HUB DEFAULT',
  },
  specialTerms: {
    key: 'specialTerms',
    menuLabel: 'SPECIAL TERMS',
    placeholder: 'Select Special Terms',
    items: [{ displayValue: 'Manifest', value: 'MANIFEST' }, { displayValue: 'Averaging Agreement', value: 'AVERAGING_AGREEMENT' }]
  },
  notes: {
    key: 'notes',
    menuLabel: 'NOTES',
    placeholder: 'Enter Notes',
  },
  minimumRate: {
    key: 'minimumRate',
    menuLabel: 'MINIMUM RATE',
    placeholder: 'Enter Minimum Rate',
  },
  maximumRate: {
    key: 'maximumRate',
    menuLabel: 'MAXIMUM RATE',
    placeholder: 'Enter Maximum Rate',
  },
  freeHolidays: {
    key: 'freeHolidays',
    menuLabel: 'HOLIDAYS FREE',
    placeholder: 'Select Holidays Free',
    items: ['Yes', 'No'],
  },
  freeDays: {
    key: 'freeHolidays',
    menuLabel: 'FREE DAYS',
    placeholder: 'Select Free Days',
    items: [],
  },
  freeCutOffTime: {
    key: 'freeCutOffTime',
    menuLabel: 'FREE TIME CUT OFF',
    placeholder: 'Enter Free Time CutOFF',
    format: '^([1-9]|0[1-9]|1[0-2]):[0-5][0-9] ([AaPp][Mm])$'
  },
  freeTimeType: {
    items: [
      { text: 'Free Time', value: 'TIME' },
      { text: 'Free Days', value: 'DAY' }
    ],
    key: 'freeTimeType',
    menuLabel: 'FREE TIME TYPE',
    placeholder: 'Select Free Time Type',
  },
  freeTime: {
    key: 'freeTime',
    menuLabel: 'FREE TIME',
    placeholder: 'Enter Free Time',
    format: '^(?:[01]\\d|2[0-3]):[0-5]\\d$'
  },
  reloads: {
    key: 'reloads',
    menuLabel: 'RELOADS',
    placeholder: 'Enter Reload days',
  },
  freeWeekendType: {
    weekendTypes: [],
    key: 'freeWeekendType',
    menuLabel: 'FREE WEEKEND TYPE',
    placeholder: 'Select Free Weekend Type',
  },
  startEvent: {
    key: 'startEvent',
    menuLabel: 'START EVENT',
    placeholder: 'Select Start Event',
    items: [],
  },
  endEvent: {
    key: 'endEvent',
    menuLabel: 'END EVENT',
    placeholder: 'Select  End Event',
    items: [],
  },
  locations: [{
    selectedLocation: {},
    StopType: 'Origin',
    searchItems: [],
    placeholder: 'Search Locations',
    searchType: 'location',
    menuLabel: 'Location',
    cities: {
      selectedCity: {
        City: null,
        State: null,
        PostalCode: null,
        CountryCode: null,
      },
      StopType: '',
      searchItems: [],
      placeholder: 'Search Cities',
      searchType: 'cities',
      menuLabel: 'City',
    },
  }, {
    selectedLocation: {},
    StopType: 'Destination',
    searchItems: [],
    placeholder: 'Search Locations',
    searchType: 'location',
    menuLabel: 'Location',
    cities: {
      selectedCity: {
        City: null,
        State: null,
        PostalCode: null,
        CountryCode: null,
      },
      StopType: '',
      searchItems: [],
      placeholder: 'Search Cities',
      searchType: 'cities',
      menuLabel: 'City',
    },
  }],
};

function getChargeCodeInitialData() {
  return _.cloneDeep(chargeCodeInitialData);
}

export default {
  getChargeCodeInitialData,
};
