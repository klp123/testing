import moment from 'moment';
import { v4 } from 'uuid';
import * as _ from 'lodash';
import Vue from 'vue';
import VueTimepicker from 'vue2-timepicker';
import { RequestErrorTypesEnum, AppSetupEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import filterNamesEnum from '@hubgroup/hg-vue-oc-util-lib/src/enums/filter-names.enum';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import cdnImagesEnum from '@hubgroup/hg-vue-oc-util-lib/src/enums/cdn-images.enum';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import { ImageLoaderService, GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import serviceTypeEnum from '@hubgroup/hg-vue-oc-util-lib/src/enums/service-types.enum';
import commonUtilityService from '@hubgroup/hg-vue-oc-util-lib/src/utils/common-utility.service';
import LocalFilterNamesEnum from '../../../enums/filter-names.enum';
import commonService from '../../../services/common.service';
import DatetimePickerComponent from '../../shared/datetime-picker/datetime-picker.vue';
import RatesComponent from './rates-component/rates-component.vue';
import LocationsComponent from './locations-component/locations-component.vue';
import hgAutocomplete from '../../shared/drop-downs/hg-autocomplete/hg-autocomplete.vue';
import customerService from '../../../services/customer/customer.service';
import customerAcessorialsService from '../../../services/accessorial-fuel-schedules/customer-acessorials.service';
import createChargeCodeModel from './create-charge-code-model';
import chargeCodesService from '../../../services/accessorial-fuel-schedules/charge-codes.service';
import timeZoneService from '../../../services/accessorial-fuel-schedules/time-zone.service';

async function loadFiltersList(newData) {
  try {
    newData.transportMode.modes = await commonService.getCommonLov(filterNamesEnum.MODES);
    const bundleCodes = await commonService.getCommonLov(LocalFilterNamesEnum.OM_ACCESSORIALS_BUNDLE_CODES);
    newData.bundleCode.bundleCodes = bundleCodes.map((v) => ({ code: v.value, description: v.displayValue })).sort((a, b) => {
      if (a.code < b.code) {
        return -1;
      }
      if (a.code > b.code) {
        return 1;
      }
      return 0;
    });
    const weekendTypes = await commonService.getCommonLov(LocalFilterNamesEnum.OM_ACCESSORIALS_FREE_WEEK_END_TYPES);
    newData.freeWeekendType.weekendTypes = weekendTypes.map((v) => v.value);
    newData.startEvent.items = await commonService.getCommonLov(LocalFilterNamesEnum.OM_ACCESSORIALS_EVENT_CODES);
    newData.endEvent.items = await commonService.getCommonLov(LocalFilterNamesEnum.OM_ACCESSORIALS_EVENT_CODES);
    newData.rampScac.items = await commonService.getCommonLov(LocalFilterNamesEnum.OM_ACCESSORIALS_RAMP_SCAC);
    return newData;
  } catch (e) {
    console.error('Error when setting beforemount data', e);
  }
}

function onTimeChange(timeEvent, fieldName, regex) {
  if (timeEvent.displayTime) {
    if (timeEvent.displayTime.match(regex)) {
      this.chargeCodeInitialData.formData[`${fieldName}`] = timeEvent.displayTime;
    }
  } else {
    this.chargeCodeInitialData.formData[`${fieldName}`] = '';
  }
}

function onEffectiveDateTimeChange(value) {
  if (value) {
    this.chargeCodeInitialData.formData.effectiveDateTime = {
      dateTime: moment(value).format('MM/DD/YY')
    };
    if (moment(this.chargeCodeInitialData.formData.effectiveDateTime.dateTime)
      > moment(this.chargeCodeInitialData.formData.expiredDateTime.dateTime)) {
      this.chargeCodeInitialData.formData.expiredDateTime.dateTime = null;
    }

    if (moment(this.chargeCodeInitialData.formData.effectiveDateTime.dateTime) > moment().startOf('day')) {
      this.chargeCodeInitialData.expiredDateConfig.minDate = moment(value).startOf('day').toISOString();
    } else {
      this.chargeCodeInitialData.expiredDateConfig.minDate = moment().startOf('day').toISOString();
    }
    this.shown = false;
  } else {
    this.chargeCodeInitialData.formData.effectiveDateTime.dateTime = null;
  }
}

function onExpiredDateTimeChange(value) {
  if (value) {
    this.chargeCodeInitialData.formData.expiredDateTime = {
      dateTime: moment(value).format('MM/DD/YY')
    };
    this.shown = false;
  } else {
    this.chargeCodeInitialData.formData.expiredDateTime.dateTime = null;
  }
}

async function submit() {
  this.formValid = false;
  if (!this.isEditForm && await this.checkAccessorialFuelExists()) {
    this.showChargeCodeExistsDialog.dialog = true;
  } else {
    await this.postChargeCodeDetails();
  }
  this.formValid = true;
}

function getSelectedEquipmentList() {
  const equipments = _.get(this.chargeCodeInitialData.formData, 'equipment');
  if (!equipments || equipments.length === 0) {
    return [null];
  }
  return equipments;
}

async function checkAccessorialFuelExists() {
  try {
    this.loading = true;
    const locations = this.$refs.locationsComponent && this.$refs.locationsComponent.getSelectedLocations();
    const originLocation = locations && locations.find((location) => location.StopType === 'Origin');
    const destinationLocation = locations && locations.find((location) => location.StopType === 'Destination');
    const equipments = this.getSelectedEquipmentList().map((item) => item && `${item.equipmentType}${item.length.amount}`);
    const filters = {
      chargeCodes: [{ value: _.get(this.chargeCodeInitialData.formData, 'chargeCode.code') }],
      effectiveDateTime: [{ value: timeZoneService.cstStartOf(_.get(this.chargeCodeInitialData.formData, 'effectiveDateTime.dateTime'), true, 'MM/DD/YY') }],
      type: [{ value: _.get(this.chargeCodeInitialData.formData, 'type') }],
      customer: [{ value: _.get(this.chargeCodeInitialData.formData, 'customer.id') }],
      mode: [{ value: _.get(this.chargeCodeInitialData.formData, 'transportMode') }],
      equipment: [{ value: equipments }],
      vendorId: [{ value: _.get(this.chargeCodeInitialData.formData, 'vendor.id') }],
      railScac: [{ value: _.get(this.chargeCodeInitialData.formData, 'railScac') }],
      rampScac: [{ value: _.get(this.chargeCodeInitialData.formData, 'rampScac.value') }],
      bundleCode: [{ value: _.get(this.chargeCodeInitialData.formData, 'bundleCode.code') }],
      serviceType: [{ value: _.get(this.chargeCodeInitialData.formData, 'serviceType') }],
      originId: [{ value: _.get(originLocation, 'LocationID') }],
      originCity: [{ value: _.get(originLocation, 'City') }],
      originState: [{ value: _.get(originLocation, 'State') }],
      originPostalCode: [{ value: _.get(originLocation, 'PostalCode') }],
      destinationId: [{ value: _.get(destinationLocation, 'LocationID') }],
      destinationCity: [{ value: _.get(destinationLocation, 'City') }],
      destinationState: [{ value: _.get(destinationLocation, 'State') }],
      destinationPostalCode: [{ value: _.get(destinationLocation, 'PostalCode') }]
    };

    GoogleAnalyticsService.event(Vue, 'Search fuel rates', 'Charge-Codes', 'Search for customer fuel rates', {
      accessorial_customer: _.get(this.chargeCodeInitialData.formData, 'customer.name'),
      accessorials_fuel_mode: filters.mode,
      accessorials_fuel_equipment: filters.equipment
    });

    const resp = await customerAcessorialsService.customerAccesorialFuel(filters, { page: 1, limit: 2 });
    let recordExists = false;
    _.map(_.get(resp, 'data.data') || [], (item) => {
      if (item._id !== this.chargeCodeInitialData.formData._id) {
        recordExists = true;
      }
    });
    this.loading = false;
    return recordExists;
  } catch (err) {
    if (err.message && err.message !== RequestErrorTypesEnum.CANCEL_REQUEST) {
      HgNotificationService.errorMessage('Error while validating accessorials fuel exists or not');
    }
    this.loading = false;
  }
}

async function postChargeCodeDetails() {
  try {
    this.loading = true;
    const formattedPayload = this.formatPayload();
    const response = await chargeCodesService.saveChargeCodeData(formattedPayload);
    const action = this.isEditForm ? 'UPDATE' : 'CREATE';
    GoogleAnalyticsService.event(Vue, `${action} charge code`, 'Charge-Codes', `Charge code ${action}`, {
      accessorials_fuel_customer: _.get(formattedPayload, 'customer.name', ''),
      accessorials_fuel_mode: _.get(formattedPayload, 'transportMode', ''),
      accessorials_fuel_country: _.get(formattedPayload, 'country', ''),
      accessorials_fuel_equipment: formattedPayload.equipment
        ? _.get(formattedPayload, 'equipment.equipmentType', '') + _.get(formattedPayload, 'equipment.length.amount', '') : '',
      accessorials_charge_code: _.get(formattedPayload, 'chargeCode.description', '')
    });
    this.loading = false;
    if (_.get(response, 'data.status')) {
      this.closeDialog();
      HgNotificationService.successMessage(_.get(response, 'data.message'));
      this.$store.dispatch('customerAccessorialFuelStore/updateRefreshGrid', true);
    } else {
      HgNotificationService.errorMessage(_.get(response, 'data.message'));
    }
  } catch (err) {
    if (err.message && err.message !== RequestErrorTypesEnum.CANCEL_REQUEST) {
      HgNotificationService.errorMessage('Error while saving accessorials charge codes.');
    }
    this.loading = false;
  }
}

async function confirmUpsertChargeCode() {
  this.showChargeCodeExistsDialog.dialog = false;
  await this.postChargeCodeDetails();
}

function cancelUpsertChargeCode() {
  this.showChargeCodeExistsDialog.dialog = false;
}

function formatPayload() {
  const formattedPayload = {
    publishDateTime: {
      dateTime: timeZoneService.cstDateTime(new Date())
    }
  };
  Object.keys(this.chargeCodeInitialData.formData).forEach((key) => {
    const fieldData = this.chargeCodeInitialData.formData[key];
    if (fieldData && !formattedPayload[key]) {
      switch (key) {
        case 'rates':
          // eslint-disable-next-line no-case-declarations
          const rates = this.$refs.ratesComponent && this.$refs.ratesComponent.getAllRates();
          if (rates && rates.length && this.chargeCodeInitialData.formData.chargeCode.code === '405') {
            formattedPayload[key] = [{ rateValue: rates[0].rateValue }];
          } else {
            formattedPayload[key] = rates;
          }
          break;
        case 'locations':
          formattedPayload[key] = this.$refs.locationsComponent && this.$refs.locationsComponent.getSelectedLocations();
          break;
        case 'freeHolidays':
          formattedPayload[key] = fieldData === 'Yes';
          break;
        case 'rampScac':
          formattedPayload[key] = fieldData.value;
          break;
        case 'effectiveDateTime':
          formattedPayload[key] = { dateTime: timeZoneService.cstStartOf(fieldData.dateTime, true, 'MM/DD/YY') };
          break;
        case 'expiredDateTime':
          if (fieldData.dateTime) {
            formattedPayload[key] = { dateTime: timeZoneService.cstEndOf(fieldData.dateTime, true, 'MM/DD/YY') };
          } else {
            formattedPayload[key] = { dateTime: null };
          }
          break;
        case 'freeTime':
          formattedPayload[key] = moment.duration(fieldData).asMinutes();
          break;
        case 'equipment':
          formattedPayload[key] = this.getSelectedEquipmentList();
          break;
        case 'hubDefault':
          formattedPayload[key] = { id: fieldData.id, name: fieldData.name };
          break;
        default:
          formattedPayload[key] = fieldData;
          break;
      }
    }
  });
  return formattedPayload;
}

function getColor(name) {
  return _colors[name];
}

function getIcon(iconName) {
  return ImageLoaderService.getCdnImageUrl(iconName);
}

async function onValueSelected($event) {
  try {
    if ($event && $event.value) {
      switch ($event.type) {
        case 'customer':
          this.setSelectedFormData($event, 'customer');
          break;
        case 'vendor':
          this.setSelectedFormData($event, 'vendor');
          break;
        case 'chargeCode': {
          const selectedChargeCodeVal = _.get($event, 'value.code');
          this.is405ChargeCodeFlag = selectedChargeCodeVal === '405';
          if (_.get(this.chargeCodeInitialData.formData, 'chargeCode.code') !== selectedChargeCodeVal) {
            this.chargeCodeInitialData.formData.chargeCode = $event.value;
            if (!['OPD', 'DPD', 'SRG'].includes(selectedChargeCodeVal)
            ) {
              this.resetFreeTimeTypeDetails();
            }
            this.setFreeDaysTo999();
          }
          if (!this.isEditForm && !this.isCopyForm && ['DTU', 'DTL'].includes(selectedChargeCodeVal)) {
            this.chargeCodeInitialData.formData.rateQualifier = 'PR';
            this.chargeCodeInitialData.formData.startEvent = (selectedChargeCodeVal === 'DTL') ? 'AL' : 'AD';
            this.chargeCodeInitialData.formData.endEvent = (selectedChargeCodeVal === 'DTL') ? 'CL' : 'CU';
            this.chargeCodeInitialData.formData.freeTimeType = 'TIME';
            this.chargeCodeInitialData.formData.freeTime = '02:00';
          }
          break;
        }
        case 'rampScac':
          this.chargeCodeInitialData.formData.rampScac = $event.value;
          if (!this.chargeCodeInitialData.formData.rampScac) {
            this.chargeCodeInitialData.formData.railScac = null;
          } else {
            this.chargeCodeInitialData.railScac.items = _.get($event, 'value.subOptions', []).map((v) => v.value);
          }
          break;
        default:
          break;
      }
    } else {
      this.chargeCodeInitialData.formData[`${$event.type}`] = $event.value;
    }
  } catch (error) {
    console.error('Error when fetching data on search Text for onValueSelected', error);
  }
}

function setFreeDaysTo999() {
  if (['OPD', 'DPD', 'SRG'].includes(_.get(this.chargeCodeInitialData.formData, 'chargeCode.code'))
    && this.chargeCodeInitialData.formData.rateQualifier === 'NB') {
    this.$refs.freeDays && this.$refs.freeDays.reset();
    this.chargeCodeInitialData.formData.freeTime = null;
    this.$nextTick(() => {
      this.chargeCodeInitialData.formData.freeTimeType = 'DAY';
      this.chargeCodeInitialData.formData.freeDays = '999';
      this.chargeCodeInitialData.formData.isFreeDays999 = true;
    });
  }
}

function resetFreeTimeTypeDetails() {
  this.$refs.freeDays && this.$refs.freeDays.reset();
  this.chargeCodeInitialData.formData.freeDays = null;
  this.chargeCodeInitialData.formData.freeTime = null;
  this.chargeCodeInitialData.formData.isFreeDays999 = false;
  this.chargeCodeInitialData.formData.freeTimeType = null;
}

function selectedRateQualifier(value) {
  if (value !== 'NB'
    && this.chargeCodeInitialData.formData.freeTimeType === 'DAY'
    && this.chargeCodeInitialData.formData.freeDays === '999') {
    this.resetFreeTimeTypeDetails();
  }
  this.chargeCodeInitialData.formData.rateQualifier = value;
  this.setFreeDaysTo999();
}

function onFreeTimeTypeSelected(value) {
  if (value === 'TIME') {
    this.chargeCodeInitialData.formData.freeDays = null;
  } else {
    this.chargeCodeInitialData.formData.freeTime = null;
  }
}

function setSelectedFormData($event, fieldName) {
  if (_.get($event, 'value.id') !== _.get(this.chargeCodeInitialData.formData, `${fieldName}.id`)) {
    this.chargeCodeInitialData.formData[`${fieldName}`] = {
      id: _.get($event, 'value.id'),
      name: _.get($event, 'value.name'),
      text: `${_.get($event, 'value.name')}, ${_.get($event, 'value.id')}`
    };
  }
}

async function onSearchTextChanged(searchText, type) {
  try {
    if (type === 'rampScac') {
      if (searchText && searchText.length) {
        this.chargeCodeInitialData.rampScac.items = (await commonService.getCommonLov(LocalFilterNamesEnum.OM_ACCESSORIALS_RAMP_SCAC))
          .filter((l) => l.displayValue.includes(searchText.searchText));
      } else {
        this.chargeCodeInitialData.rampScac.items = await commonService.getCommonLov(LocalFilterNamesEnum.OM_ACCESSORIALS_RAMP_SCAC);
      }
    }

    if (!searchText || searchText.searchText.length >= AppSetupEnum.MINIMUM_SEARCH_CHARACTER) {
      switch (type) {
        case 'customer':
          await this.searchCustomer(searchText, 'customer');
          break;
        case 'vendor':
          await this.searchVendor(searchText);
          break;
        case 'chargeCode':
          await this.searchChargeCode(searchText);
          break;
        default:
          break;
      }
    }
  } catch (error) {
    console.error('Error when fetching data  for onSearchTextChanged', error);
  }
}

async function searchChargeCode(searchText) {
  this.chargeCodeInitialData.chargeCode.items = (await customerAcessorialsService.getAccessorialChargeCodes(searchText.searchText, 20))
    .map((e) => ({
      code: e.value,
      description: e.name,
      text: e.text
    }));
}

async function searchVendor(searchText) {
  this.chargeCodeInitialData.loadVendorList = true;
  this.chargeCodeInitialData.vendor.items = (await customerAcessorialsService.searchCarriers(searchText.searchText))
    .map((c) => ({
      id: c.carrierId,
      name: c.carrierName,
      text: `${c.carrierName}, ${c.carrierId}`
    }));
  this.chargeCodeInitialData.loadVendorList = false;
}

async function searchCustomer(searchText, fieldName) {
  this.chargeCodeInitialData[`${fieldName}`].items = (await customerService.searchCustomers(searchText.searchText))
    .map((c) => ({
      id: c.value,
      name: c.name,
      text: `${c.name}, ${c.value}`
    }));
}

async function onModeSelected(transportMode) {
  this.chargeCodeInitialData.formData.equipment = [];
  this.chargeCodeInitialData.equipmentType.equipmentTypes = [];
  if (transportMode !== 'TL') {
    this.chargeCodeInitialData.equipmentType.equipmentTypes = (await commonUtilityService.getEquipmentTypes(transportMode)).map((e) => (
      {
        equipmentCode: e.value.code,
        equipmentType: e.value.type,
        length: {
          amount: e.value.length
        }
      }));
  } else {
    Promise.all(['PWR', 'FLT', 'REF', 'VAN'].map(async (subMode) => {
      const response = (await commonUtilityService.getEquipmentTypes(transportMode, subMode)).map((e) => (
        {
          equipmentCode: e.value.code,
          equipmentType: e.value.type,
          length: {
            amount: e.value.length
          }
        }));
      return response;
    })).then((results) => {
      this.chargeCodeInitialData.equipmentType.equipmentTypes = _.sortBy(_.uniqBy(results.flat(), 'equipmentCode'), 'equipmentCode');
    });
  }
}

function closeDialog() {
  this.resetEffectiveDateTime = false;
  this.formValid = false;
  this.is405ChargeCodeFlag = true;
  this.isEditForm = false;
  this.isCopyForm = false;
  this.showDialog = false;
  this.$emit('closeDialog', {});
  GoogleAnalyticsService.event(Vue, 'Close dialog', 'Charge-Codes', 'Charge code dialog closed');
}

function setDisplayText(field, fieldName) {
  if (field) {
    field.text = `${field.name}, ${field.id}`;
    this.chargeCodeInitialData[`${fieldName}`].items = [field];
  }
}

async function prePopulateChargeCodeModal(item, action) {
  if (action) {
    const payload = _.cloneDeep(item);
    if (action === 'EDIT') {
      this.isEditForm = true;
      let minDate = '';
      if (timeZoneService.cstDateTime(payload.effectiveDateTime.dateTime) > timeZoneService.cstEndOf(new Date().toISOString())) {
        [minDate] = moment(new Date())
          .tz('America/Chicago')
          .toISOString()
          .split('T');
      } else {
        this.chargeCodeInitialData.effectiveDateConfig.disabled = true;
      }
      this.chargeCodeInitialData.effectiveDateConfig.minDate = minDate;
    } else if (action === 'COPY') {
      this.isCopyForm = true;
      delete payload._id;
      payload.hubDefault = { id: null, name: null };
      payload.isUsingHubDefault = false;
    }
    this.checkFieldExists(payload, 'customer', 'id');
    this.checkFieldExists(payload, 'equipment', 'equipmentType');
    this.checkFieldExists(payload, 'vendor', 'id');

    this.onModeSelected(payload.transportMode);
    if (item.equipment && item.equipment.equipmentType) {
      payload.equipment = [item.equipment];
    }

    this.setDisplayText(payload.customer, 'customer');
    this.setDisplayText(payload.vendor, 'vendor');

    this.is405ChargeCodeFlag = payload.chargeCode.code === '405';
    payload.chargeCode.text = `${payload.chargeCode.description} - ${payload.chargeCode.code}`;
    this.chargeCodeInitialData.chargeCode.items = [payload.chargeCode];

    payload.rampScac = this.chargeCodeInitialData.rampScac.items.find((v) => v.value === payload.rampScac);
    payload.freeHolidays = payload.freeHolidays ? 'Yes' : 'No';
    if (!this.isEditForm && timeZoneService.cstDateTime(payload.effectiveDateTime.dateTime) < timeZoneService.cstStartOf(new Date().toISOString())) {
      payload.effectiveDateTime.dateTime = timeZoneService.cstDateTime(new Date().toISOString(), null, null, true);
      this.resetEffectiveDateTime = true;
    } else {
      payload.effectiveDateTime.dateTime = timeZoneService.cstDateTime(payload.effectiveDateTime.dateTime, null, null, true);
    }

    if (_.get(payload, 'expiredDateTime.dateTime')) {
      payload.expiredDateTime.dateTime = timeZoneService.cstDateTime(payload.expiredDateTime.dateTime, null, null, true);
    }

    if (payload.freeTimeType === 'TIME') {
      const duration = moment.duration(payload.freeTime, 'minutes').asMilliseconds();
      payload.freeTime = moment.utc(duration).format('HH:mm');
    }

    this.isHubDefault = payload.type === 'H';
    delete payload.modifiedDateTime;
    delete payload.searchFields;
    this.chargeCodeInitialData.formData = payload;
  }
}

function checkFieldExists(payload, property, nestedProperty) {
  payload[`${property}`] = _.get(payload, `${property}.${nestedProperty}`) ? payload[`${property}`] : null;
}

function updateType(event) {
  const resetData = { id: null, name: null };
  if (event) {
    this.chargeCodeInitialData.formData.customer = resetData;
  } else {
    this.chargeCodeInitialData.formData.hubDefault = resetData;
  }
  this.chargeCodeInitialData.formData.type = event ? 'H' : 'C';
}

export default {
  name: 'charge-codes-modal',
  components: {
    DatetimePickerComponent,
    RatesComponent,
    LocationsComponent,
    hgAutocomplete,
    VueTimepicker,
  },
  data: () => ({
    resetEffectiveDateTime: false,
    cdnImagesEnum,
    chargeCodeInitialData: createChargeCodeModel.getChargeCodeInitialData(),
    serviceTypeEnum,
    loading: false,
    formValid: false,
    v4,
    lodash: _,
    is405ChargeCodeFlag: true,
    isEditForm: false,
    isCopyForm: false,
    showChargeCodeExistsDialog: {
      dialog: false,
      headerText: 'Charge Code Exists',
      subText: 'Charge Code already exists. Do you want to override?'
    },
    rules: {
      required: [(value) => !!value || 'Required']
    },
    date: null,
    todayDateString: moment.tz('America/Chicago').format('YYYY-MM-DD').toString(),
    isHubDefault: false
  }),
  watch: {

  },
  props: {
    selectedCustomerAccessorial: {
      type: Object,
      default: false
    },
    action: {
      type: String,
      default: false
    }
  },
  async created() {
    this.loading = true;
    this.showDialog = true;
    this.chargeCodeInitialData = createChargeCodeModel.getChargeCodeInitialData();
    await this.loadFiltersList(this.chargeCodeInitialData);
    if (this.selectedCustomerAccessorial) {
      this.prePopulateChargeCodeModal(this.selectedCustomerAccessorial, this.action);
    }
    this.loading = false;
  },
  methods: {
    getColor,
    closeDialog,
    onModeSelected,
    onSearchTextChanged,
    getIcon,
    onEffectiveDateTimeChange,
    onValueSelected,
    submit,
    formatPayload,
    postChargeCodeDetails,
    prePopulateChargeCodeModal,
    onExpiredDateTimeChange,
    onFreeTimeTypeSelected,
    onTimeChange,
    searchCustomer,
    searchVendor,
    searchChargeCode,
    setSelectedFormData,
    setDisplayText,
    checkAccessorialFuelExists,
    confirmUpsertChargeCode,
    cancelUpsertChargeCode,
    checkFieldExists,
    setFreeDaysTo999,
    loadFiltersList,
    selectedRateQualifier,
    resetFreeTimeTypeDetails,
    getSelectedEquipmentList,
    updateType
  },
};
