<template>
  <v-card style="background-color: #F7F7F7;box-shadow: none;">
    <v-card-text>
      <div class="d-row-flex">
        <!--  Rate Qualifier -->
        <div class="mediumWidthField">
          <label class="field-label">{{ rateQualifier.menuLabel }} </label>
          <span class="d-inline-flex"> </span>
          <img class="label-required" :src="getIcon(cdnImagesEnum.required_icon)" />
          <HgAutocomplete return-object :clearable="true" :searchType="rateQualifier.searchType"
            :placeholder="rateQualifier.placeholder" :items="rateQualifier.rateQualifiers || []"
            :itemText="'displayValue'" :itemValue="'value'" :prepopulateItem="rateQualifierModel"
            :backgroundColor="getColor('color_white')" id="rate-qualifier-autocomplete"
            @onSearchTextChanged="onSearchTextChanged($event)" @onValueSelected="onValueSelected($event)"
            :rules="[rules.required]" />
        </div>
        <div>
          <div class="d-row-flex" v-for="(rate, index) in ratesList" :key="rate.id" :index="index"
            :id="`rate-${getUUID()}`" @deleteRate="deleteRate($event)">
            <!-- Rate Amount -->
            <div class="smallWidthField">
              <div>
                <label class="field-label">RATE AMOUNT ($)</label>
                <img v-if="(!is405ChargeCodeFlag && isRateAmountRequired)" class="label-required" :src="getIcon(cdnImagesEnum.required_icon)" />
                <span class="d-inline-flex"> </span>
                <v-text-field
                  v-model="rate.rateValue"
                  flat
                  dense
                  outlined
                  :disabled="isRateAmountAndRateLimitDisabled"
                  ref="rateValue"
                  color="highlight"
                  class="input-text"
                  :class="'input-text'"
                  hide-details="auto"
                  :id="'rate-value' + getUUID()"
                  :rules="(!is405ChargeCodeFlag && isRateAmountRequired) ? [rules.required] : []"
                  @keydown.enter.prevent
                  onkeypress="return (event.charCode >= 48 && event.charCode <= 57) || (event.charCode == 46)"
                >
                </v-text-field>
              </div>
            </div>
            <!-- Rate Limit -->
            <div class="smallWidthField" v-if="!is405ChargeCodeFlag">
              <div>
                <label class="field-label"> RATE LIMIT</label>
                <span class="d-inline-flex"> </span>
                <v-text-field
                  v-model="rate.rateLimit"
                  flat
                  dense
                  outlined
                  :disabled="isRateAmountAndRateLimitDisabled"
                  ref="rateLimit"
                  color="highlight"
                  class="input-text"
                  :class="'input-text'"
                  hide-details="auto"
                  :id="'rate-limit' + getUUID()"
                  maxlength="3"
                  @keydown.enter.prevent
                  onkeypress="return (event.charCode >= 48 && event.charCode <= 57) || (event.charCode == 46)">
                </v-text-field>
              </div>
            </div>
            <!--Delete icon-->
            <div v-if="index > 0 && !is405ChargeCodeFlag" class="align-self-center add-delete-icon">
              <!-- Delete Icon for Order Create -->
              <button @click.prevent="deleteRate(index)">
                <img :id="`reference-delete-${index}`" class="trash-icon-delete"
                  :src="getIcon(cdnImagesEnum.delete_icon)" />
              </button>
            </div>
          </div>
        </div>
        <!--  Layover Type -->
        <div class="pl-100" v-if="!is405ChargeCodeFlag">
          <label class="field-label">{{ layoverType.menuLabel }}</label>
          <span class="d-inline-flex"> </span>
          <HgAutocomplete :items="layoverTypeList" :itemText="'displayValue'" :itemValue="'value'" return-object
            :searchType="'selectedLayoverType'" :backgroundColor="getColor('color_white')" outlined dense flat attach
            :placeholder="'Select Layover'" :class="'input-text'" color="highlight" whitespace="false"
            :id="'rate-layoverType'" :prepopulateItem="layoverTypeModel" @onValueSelected="onValueSelected($event)" :clearable="true" />
        </div>
        <v-spacer></v-spacer>
        <!--  Add Rate  -->
        <div class="mediumWidthField d-flex align-start" v-if="!is405ChargeCodeFlag">
          <button class="actions-label order-references" @click.prevent="addRate()" id="add-rate">
            Add Rate
          </button>
        </div>
      </div>
    </v-card-text>
  </v-card>
</template>
<script src="./rates-component.js"></script>
<style src="./rates-component.sass" scoped lang="sass"></style>
