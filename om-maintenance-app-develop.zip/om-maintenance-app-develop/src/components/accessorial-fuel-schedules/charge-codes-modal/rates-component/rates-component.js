import { v4 as UUID } from 'uuid';
import Vue from 'vue';
import { ImageLoaderService, GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import cdnImagesEnum from '@hubgroup/hg-vue-oc-util-lib/src/enums/cdn-images.enum';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import commonService from '../../../../services/common.service';
import LocalFilterNamesEnum from '../../../../enums/filter-names.enum';
import createChargeCodeModel from '../create-charge-code-model';

function getColor(name) {
  return _colors[name];
}

function getIcon(iconName) {
  return ImageLoaderService.getCdnImageUrl(iconName);
}

function deleteRate(index) {
  GoogleAnalyticsService.event(Vue, 'Rate removed', 'Charge-Code-Rate', 'Rates removed from charge code');
  return index > -1 ? this.ratesList.splice(index, 1) : '';
}

function addRate() {
  try {
    const ratePayload = {
      id: UUID(),
      rateValue: '',
      rateLimit: '',
    };
    this.ratesList.push(ratePayload);
    GoogleAnalyticsService.event(Vue, 'Rate added', 'Charge-Code-Rate', 'Initial Rates added for charge code');
  } catch (error) {
    console.error('Error when adding rates', error);
  }
}
async function onValueSelected($event) {
  try {
    if ($event && $event.value) {
      switch ($event.type) {
        case 'rateQualifiers':
          if ($event.value.value === 'NB') {
            this.isRateAmountAndRateLimitDisabled = true;
            this.resetRateList('0');
          } else if ($event.value.value === 'RC') {
            this.resetRateList();
            this.isRateAmountRequired = false;
            this.isRateAmountAndRateLimitDisabled = true;
          } else {
            this.isRateAmountAndRateLimitDisabled = false;
            this.isRateAmountRequired = true;
          }
          this.$emit('selectedRateQualifier', $event.value.value);
          break;
        case 'selectedLayoverType':
          this.$emit('selectedLayoverType', $event.value.value);
          break;
        default:
          break;
      }
    }
  } catch (error) {
    console.error('Error when fetching data on search Text for onValueSelected', error);
  }
}

function resetRateList(val = null) {
  this.ratesList = [{
    id: UUID(),
    rateValue: val,
    rateLimit: val,
  }];
}

async function onSearchTextChanged(searchText) {
  const source = searchText.type;
  try {
    if (searchText.searchText.length > 0) {
      this.rateQualifier.rateQualifiers = (await this.getRateQualifiersByChargeCode())
        .filter((item) => item.displayValue.includes(searchText.searchText) || item.value.includes(searchText.searchText));
    } else {
      this.rateQualifier.rateQualifiers = await this.getRateQualifiersByChargeCode();
    }
  } catch (error) {
    console.error(`Error when fetching data on search Text for ${source}`, error);
  }
}

async function getRateQualifiersByChargeCode() {
  if (this.selectedChargeCode && this.selectedChargeCode.code === '405') {
    return (await commonService.getCommonLov(LocalFilterNamesEnum.OM_ACCESSORIALS_RATE_QUALIFIER))
      .filter((item) => ['405', 'ANY'].includes(item.parentValue));
  }
  return (await commonService.getCommonLov(LocalFilterNamesEnum.OM_ACCESSORIALS_RATE_QUALIFIER))
    .filter((item) => ['ACCESSORIAL', 'ANY'].includes(item.parentValue));
}

function getUUID() {
  return UUID();
}

function getAllRates() {
  return this.ratesList;
}

export default {
  name: 'rates-component',
  data() {
    return {
      cdnImagesEnum,
      rateQualifier: createChargeCodeModel.getChargeCodeInitialData().rateQualifier,
      rateQualifierModel: null,
      layoverType: createChargeCodeModel.getChargeCodeInitialData().layoverType,
      layoverTypeModel: null,
      isRateAmountAndRateLimitDisabled: false,
      ratesList: [{
        id: UUID(),
        rateValue: '',
        rateLimit: '',
      }],
      layoverTypeList: [
        {
          displayValue: 'TEAM - WEEKDAY',
          value: 'TWD'
        },
        {
          displayValue: 'SINGLE - WEEKDAY',
          value: 'SWD'
        },
        {
          displayValue: 'TEAM - WEEKEND',
          value: 'TWE'
        },
        {
          displayValue: 'SINGLE - WEEKEND',
          value: 'SWE'
        }
      ],
      isRateAmountRequired: true,
      rules: {
        required: (value) => (!!value || this.isRateAmountRequired) || 'Required',
      },
    };
  },
  props: {
    is405ChargeCodeFlag: false,
    selectedChargeCode: '',
    rates: {
      type: Array,
      required: true,
      default: () => [{
        id: UUID(),
        rateValue: '',
        rateLimit: '',
      }],
    },
    prepopulateRateQualifier: {
      type: String,
      required: false,
      default: () => ''
    },
    prepopulatedLayoverType: {
      type: String,
      required: false,
      default: () => ''
    }
  },
  watch: {
    rates: {
      immediate: true,
      deep: true,
      handler(newValue) {
        newValue.map((r, index) => {
          this.ratesList[index] = {
            id: UUID(),
            rateValue: `${(r.rateValue === null || r.rateValue === undefined) ? '' : r.rateValue}`,
            rateLimit: `${(r.rateLimit === null || r.rateLimit === undefined) ? '' : r.rateLimit}`
          };
        });
      }
    },
    selectedChargeCode: {
      immediate: true,
      async handler() {
        this.rateQualifier.rateQualifiers = await this.getRateQualifiersByChargeCode();
        this.rateQualifierModel = this.rateQualifier.rateQualifiers.find((item) => item.value === this.prepopulateRateQualifier);
        this.layoverTypeModel = this.layoverTypeList.find((item) => item.value === this.prepopulatedLayoverType);
      }
    },
  },
  methods: {
    addRate,
    deleteRate,
    getIcon,
    getColor,
    onSearchTextChanged,
    onValueSelected,
    getUUID,
    getAllRates,
    resetRateList,
    getRateQualifiersByChargeCode
  }
};
