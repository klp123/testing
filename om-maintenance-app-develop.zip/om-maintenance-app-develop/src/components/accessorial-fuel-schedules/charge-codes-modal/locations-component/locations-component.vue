<template>
  <div>
    <div class="d-row-flex align-items-center" style="padding: 24px 0px;">
      <div class="field modal-header">
        LOCATION(S)
      </div>
      <!-- Locations -->
    </div>
      <div
        class="d-row-flex"
        v-for="(location, index) in locationsList"
        :key="location.id"
        :index="index"
        :id="`location-${getUUID()}`"
      >
        <!-- Location Type -->
        <div class="field2">
          <div>
            <label class="field-label">LOCATION TYPE </label>
            <span class="d-inline-flex"> </span>
            <v-text-field
              flat
              dense
              outlined
              ref="locationType"
              color="highlight"
              class="input-text"
              :class="'input-text'"
              hide-details="auto"
              :name="getUUID()"
              :id="'location-type-id' + getUUID()"
              maxlength="20"
              @keydown.enter.prevent
              v-model="location.StopType"
              :disabled="true"
            >
            </v-text-field>
          </div>
        </div>
        <!-- Specific Address -->
        <div style="width: 25rem;">
          <div>
            <label class="field-label"> SPECIFIC ADDRESS</label>
            <span class="d-inline-flex"> </span>
            <HgAutocomplete
              returnObject
              :clearable="true"
              :searchType="'Address1'"
              :placeholder="'Search Address'"
              :items="location.searchItems || []"
              :itemText="'Address1'"
              :prepopulateItem="location.selectedLocation.Address1"
              :emitPrepopulateFlag="false"
              :backgroundColor="getColor('color_white')"
              @onValueSelected="onLocationValueSelected($event, location)"
              @onSearchTextChanged="onSearchTextChanged($event, location)"
              id="location-autocomplete"
              :disabled="isEditForm"
            />
          </div>
        </div>
        <!-- CITY -->
        <div class="field">
          <div>
            <label class="field-label"> CITY</label>
            <span class="d-inline-flex"> </span>
            <HgAutocomplete
              returnObject
              :clearable="true"
              :searchType="location.cities.searchType"
              :placeholder="location.cities.placeholder"
              :items="location.cities.searchItems || []"
              :itemText="'text'"
              :prepopulateItem="location.cities.selectedCity"
              :defaultValue="location.cities.selectedCity"
              :backgroundColor="getColor('color_white')"
              @onValueSelected="onLocationValueSelected($event, location)"
              @onSearchTextChanged="onSearchTextChanged($event, location)"
              id="city-autocomplete"
              :disabled="isEditForm"
            />
          </div>
        </div>
        <!-- STATE -->
        <div>
          <div>
            <label class="field-label"> STATE</label>
            <span class="d-inline-flex"> </span>
            <v-text-field
              flat
              dense
              outlined
              ref="state"
              color="highlight"
              class="input-text state-text-field"
              :class="'input-text'"
              hide-details="auto"
              :name="getUUID()"
              :id="'state-id' + getUUID()"
              maxlength="20"
              @keydown.enter.prevent
              v-model="location.cities.selectedCity.State"
              :disabled="isEditForm"
            >
            </v-text-field>
          </div>
        </div>
        <!-- Zip Code -->
        <div class="field2">
          <div>
            <label class="field-label"> ZIP CODE</label>
            <span class="d-inline-flex"> </span>
            <v-text-field
              flat
              dense
              outlined
              ref="zipCode"
              color="highlight"
              class="input-text"
              :class="'input-text'"
              hide-details="auto"
              :name="getUUID()"
              :id="'zip-code-id' + getUUID()"
              maxlength="10"
              @keydown.enter.prevent
              v-model="location.cities.selectedCity.PostalCode"
              :disabled="isEditForm"
            >
            </v-text-field>
          </div>
        </div>
        <!-- Country -->
        <div class="d-flex">
          <div>
            <label class="field-label">COUNTRY </label>
            <span class="d-inline-flex"> </span>
            <v-select
              outlined
              dense
              flat
              attach
              :clearable="true"
              :class="'input-text country-text-field'"
              color="highlight"
              :items="['USA', 'CAN', 'MEX']"
              whitespace="false"
              id="country-code-id"
              v-model="location.cities.selectedCity.CountryCode"
              :disabled="isEditForm"
            >
            </v-select>
          </div>
        </div>
      </div>
  </div>
</template>
<script src="./locations-component.js"></script>
<style src="./locations-component.sass" scoped lang="sass"></style>
