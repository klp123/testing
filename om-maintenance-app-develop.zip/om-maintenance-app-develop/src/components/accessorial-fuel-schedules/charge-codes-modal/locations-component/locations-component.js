import { v4 as UUID } from 'uuid';
import draggable from 'vuedraggable';
import * as _ from 'lodash';
import { AppSetupEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import { ImageLoaderService } from '@hubgroup/hg-om-shared-services';
import cdnImagesEnum from '@hubgroup/hg-vue-oc-util-lib/src/enums/cdn-images.enum';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import customerAcessorialsService from '../../../../services/accessorial-fuel-schedules/customer-acessorials.service';
import createChargeCodeModel from '../create-charge-code-model';

function getValue(obj, path) {
  return _.get(obj, path) || '';
}

// eslint-disable-next-line no-unused-vars
async function onLocationValueSelected(selectedLocation, location) {
  if (selectedLocation && selectedLocation.value) {
    const value = (typeof selectedLocation.value === 'string')
      ? selectedLocation.value.toLowerCase() : this.getValue(selectedLocation, 'value.Address1').toLowerCase();
    switch (selectedLocation.type) {
      case 'Address1':
        if (value && value !== this.getValue(location, 'selectedLocation.Address1').toLowerCase()) {
          location.selectedLocation = selectedLocation.value;
          location.selectedLocation.StopType = location.StopType;
          location.cities.selectedCity = {
            City: location.selectedLocation.City,
            State: location.selectedLocation.State,
            CountryCode: location.selectedLocation.CountryCode,
            PostalCode: location.selectedLocation.PostalCode,
            text: `${location.selectedLocation.City}, ${location.selectedLocation.State}, ${location.selectedLocation.CountryCode}`
          };
          location.cities.searchItems = [location.cities.selectedCity];
        }
        break;
      case 'cities':
        if (_.get(selectedLocation, 'value.City') && _.get(selectedLocation, 'value.City') !== location.cities.selectedCity.City) {
          location.cities.selectedCity = {};
          location.selectedLocation = {};
          location.searchItems = [];
          location.cities.selectedCity = {
            City: selectedLocation.value.City,
            State: selectedLocation.value.State,
            CountryCode: selectedLocation.value.CountryCode,
            PostalCode: selectedLocation.value.PostalCode,
            text: `${selectedLocation.value.City}, ${selectedLocation.value.State}, ${selectedLocation.value.CountryCode}`
          };
          location.cities.selectedCity.StopType = location.StopType;
        }
        break;
      default:
        break;
    }
  } else {
    location.selectedLocation = {};
    location.searchItems = [];
    location.cities.selectedCity = {};
    location.cities.searchItems = [];
  }
}

function getColor(name) {
  return _colors[name];
}

function getIcon(iconName) {
  return ImageLoaderService.getCdnImageUrl(iconName);
}

async function onSearchTextChanged(searchText, location) {
  const source = searchText.type;
  try {
    if (!searchText || searchText.searchText.length >= AppSetupEnum.MINIMUM_SEARCH_CHARACTER) {
      if (source === 'Address1'
        && (searchText.searchText.toLowerCase() !== this.getValue(location, 'selectedLocation.Address1').toLowerCase())) {
        location.searchItems = await customerAcessorialsService.searchLocations(searchText.searchText);
      } else if (source === 'cities') {
        location.cities.searchItems = (await customerAcessorialsService.searchCities(searchText.searchText)).map((l) => ({
          City: l.city,
          State: l.state,
          CountryCode: l.country,
          PostalCode: l.zipCode,
          text: `${l.city}, ${l.state}, ${l.country}`
        }));
      }
    }
  } catch (error) {
    console.error(`Error when fetching data on search Text for ${source}`, error);
  }
}

function getUUID() {
  return UUID();
}

function getSelectedLocations() {
  return this.locationsList.map((l) => {
    if (_.get(l, 'selectedLocation.Address1')) {
      return l.selectedLocation;
    }
    if (_.get(l, 'cities.selectedCity.City')) {
      return l.cities.selectedCity;
    }
  }).filter((ll) => ll);
}

export default {
  name: 'locations-component',
  components: {
    draggable,
  },
  data: () => ({
    cdnImagesEnum,
    locationsList: _.cloneDeep(createChargeCodeModel.getChargeCodeInitialData().locations),
  }),
  props: {
    locations: {
      type: Array,
      default: []
    },
    isEditForm: {
      type: Boolean,
      default: false
    }
  },
  watch: {
    locations: {
      immediate: true,
      deep: true,
      handler(newValue) {
        if (newValue.length) {
          newValue.map((l) => {
            const index = l.StopType === 'Origin' ? 0 : 1;
            if (!this.locationsList[index]) {
              this.locationsList.push(_.cloneDeep(createChargeCodeModel.getChargeCodeInitialData().locations[0]));
            }

            this.locationsList[index].searchItems = [_.cloneDeep(l)];
            this.locationsList[index].selectedLocation = _.cloneDeep(l);
            this.locationsList[index].cities.selectedCity = {
              City: l.City,
              State: l.State,
              CountryCode: l.CountryCode,
              PostalCode: l.PostalCode,
              StopType: l.StopType,
              text: `${l.City}, ${l.State}, ${l.CountryCode}`
            };
            this.locationsList[index].cities.searchItems = [this.locationsList[index].cities.selectedCity];
            this.locationsList[index].StopType = l.StopType;
          });
        }
      }
    }
  },
  methods: {
    getColor,
    getIcon,
    onLocationValueSelected,
    onSearchTextChanged,
    getUUID,
    getSelectedLocations,
    getValue
  }
};
