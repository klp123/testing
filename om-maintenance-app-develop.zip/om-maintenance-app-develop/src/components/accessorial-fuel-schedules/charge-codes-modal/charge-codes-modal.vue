<template>
  <div class="charge-code-container">
    <hg-alert-dialog
      v-if="showChargeCodeExistsDialog.dialog"
      :confirmationHeaderText="showChargeCodeExistsDialog.headerText"
      :confirmationSubText="showChargeCodeExistsDialog.subText"
      @confirm="confirmUpsertChargeCode()"
      @cancel="cancelUpsertChargeCode()"
    />
    <v-dialog v-model="showDialog" width="80%" persistent>
      <v-overlay v-if="loading">
        <v-progress-circular
          indeterminate
          :size="70"
          :color="getColor('color_white')"
        ></v-progress-circular>
      </v-overlay>
      <v-card elevation="2">
        <v-form ref="chargeCodeCreateForm" v-model="formValid">
          <div class="d-flex justify-space-between w-100 modal-header-container">
            <!-- Modal header -->
            <div class="modal-header">
              Customer Charge Codes
            </div>
            <v-btn @click="closeDialog()" icon>
              <v-icon id="modal-close">mdi-close</v-icon>
            </v-btn>
          </div>
          <hr class="horizontal-divider" />
          <!-- Modal Body -->
          <div class="modal-body">
            <div class="d-row-flex">
              <!--  Charge Code Description-->
              <div class="field charge-code-filter">
                <label class="field-label">{{ chargeCodeInitialData.chargeCode.menuLabel }} </label>
                <span class="d-inline-flex"> </span>
                <img class="label-required" :src="getIcon(cdnImagesEnum.required_icon)" />
                <HgAutocomplete
                  :clearable="true"
                  returnObject
                  :searchType="chargeCodeInitialData.chargeCode.searchType"
                  :placeholder="chargeCodeInitialData.chargeCode.placeholder"
                  :items="chargeCodeInitialData.chargeCode.items || []"
                  :itemText="'text'"
                  :backgroundColor="getColor('color_white')"
                  @onValueSelected="onValueSelected($event)"
                  @onSearchTextChanged="onSearchTextChanged($event, 'chargeCode')"
                  :prepopulateItem="chargeCodeInitialData.formData.chargeCode"
                  id="charge-codes-autocomplete"
                  :disabled="isEditForm"
                  :rules="rules.required"
                />
              </div>
              <!-- Customer  -->
              <div class="field customer-filter">
                <label class="field-label">{{ chargeCodeInitialData.customer.menuLabel }} </label>
                <img v-if="!isHubDefault" class="label-required" :src="getIcon(cdnImagesEnum.required_icon)" />
                <HgAutocomplete
                  returnObject
                  :clearable="true"
                  :searchType="chargeCodeInitialData.customer.searchType"
                  :placeholder="chargeCodeInitialData.customer.placeholder"
                  :items="chargeCodeInitialData.customer.items || []"
                  :itemText="'text'"
                  :emitPrepopulateFlag="false"
                  :prepopulateItem="chargeCodeInitialData.formData.customer"
                  :backgroundColor="getColor('color_white')"
                  @onSearchTextChanged="onSearchTextChanged($event, 'customer')"
                  @onValueSelected="onValueSelected($event)"
                  id="customer-autocomplete"
                  :disabled="isEditForm || isHubDefault"
                  :rules="!isHubDefault ? rules.required : []"
                />
              </div>
              <!--  Mode -->
              <div class="field mode-filter">
                <div>
                  <label class="field-label"
                    >{{ chargeCodeInitialData.transportMode.menuLabel }}
                  </label>
                  <span class="d-inline-flex"> </span>
                  <img
                    v-if="is405ChargeCodeFlag"
                    class="label-required"
                    :src="getIcon(cdnImagesEnum.required_icon)"
                  />
                  <v-select
                    outlined
                    dense
                    flat
                    attach
                    :clearable="true"
                    :placeholder="chargeCodeInitialData.transportMode.placeholder"
                    :class="'inputText'"
                    color="highlight"
                    :items="chargeCodeInitialData.transportMode.modes || []"
                    item-text="displayValue"
                    whitespace="false"
                    id="mode"
                    :disabled="isEditForm"
                    v-model="chargeCodeInitialData.formData.transportMode"
                    @input="onModeSelected($event)"
                    :rules="is405ChargeCodeFlag ? rules.required : []"
                  >
                    <template v-slot:selection="{ item }">
                      <div :class="'select-overflow'">
                        {{ item.displayValue }}
                      </div>
                    </template>
                  </v-select>
                </div>
              </div>
              <!-- country -->
              <div class="field country-filter" v-if="is405ChargeCodeFlag">
                <label class="field-label">Country</label>
                <v-select
                  dense
                  flat
                  attach
                  :clearable="true"
                  color="highlight"
                  :items="['USA', 'CAN', 'MEX']"
                  placeholder="Select Country"
                  outlined
                  v-model="chargeCodeInitialData.formData.country"
                  :disabled="isEditForm"
                ></v-select>
              </div>
              <!--  Equipment Type -->
              <div class="field equipment-filter">
                <div>
                  <label class="field-label">{{ chargeCodeInitialData.equipmentType.menuLabel }}
                  </label>
                  <span class="d-inline-flex"> </span>
                  <v-select outlined dense flat attach :clearable="true" color="highlight"
                    :items="chargeCodeInitialData.equipmentType.equipmentTypes || []"
                    :item-text="item => `${item.equipmentType}${item.length.amount}`"
                    :placeholder="chargeCodeInitialData.equipmentType.placeholder" whitespace="false" return-object
                    id="equipmentTypes" :disabled="isEditForm"
                    multiple
                    v-model="chargeCodeInitialData.formData.equipment">
                  <template v-slot:selection="data">
                    <v-chip
                      v-if="chargeCodeInitialData.formData.equipment.length < 3"
                      v-bind="data.attrs"
                      small
                    >
                        {{ `${data.item.equipmentType}${data.item.length.amount}` }}
                    </v-chip>
                    <div v-else-if="data.index === 0">
                        {{ `(${chargeCodeInitialData.formData.equipment.length}) selected` }}
                    </div>
                    </template>
                  </v-select>
                </div>
              </div>
            </div>
            <div class="d-row-flex">
              <!--  Effective Date Config -->
              <div class="field">
                <div class="timePickerWrapper">
                  <DatetimePickerComponent
                    ref="effectiveDateTime"
                    :config="chargeCodeInitialData.effectiveDateConfig"
                    :dateTime="chargeCodeInitialData.formData.effectiveDateTime.dateTime"
                    @dateTimeChanged="onEffectiveDateTimeChange($event)"
                    :required="true"
                    checkIfValidDate
                    :showTimeOption="false"
                    :showRequiredIcon="true"
                    :disabled="isEditForm"
                  />
                </div>
                <span class="disclaimer-1" v-if="resetEffectiveDateTime"
                  >Effective Date Changed.</span
                >
              </div>
              <!--  Expired Date Config -->
              <div class="field">
                <div class="timePickerWrapper">
                  <DatetimePickerComponent
                    checkIfValidDate
                    ref="expiredDateTime"
                    :config="chargeCodeInitialData.expiredDateConfig"
                    :dateTime="chargeCodeInitialData.formData.expiredDateTime.dateTime"
                    @dateTimeChanged="onExpiredDateTimeChange($event)"
                    :showTimeOption="false"
                  />
                </div>
              </div>
              <!-- Hub Default Toggle -->
              <div class="field">
                <div>
                  <label class="field-label">
                    {{ chargeCodeInitialData.hubDefaultToggle.menuLabel }}
                  </label>
                  <v-switch class="hubDefaultToggle" v-model="isHubDefault" @change="updateType($event)" :label="isHubDefault ? 'Yes' : 'No'"
                  :disabled="isEditForm"/>
                </div>
              </div>
              <!-- Hub Default Name -->
              <div class="field">
                    <div>
                      <label class="field-label">
                        {{ chargeCodeInitialData.hubDefault.menuLabel }}</label
                      >
                    <img v-if="isHubDefault" class="label-required" :src="getIcon(cdnImagesEnum.required_icon)" />
                      <span class="d-inline-flex"> </span>
                      <v-text-field
                        flat
                        dense
                        outlined
                        ref="hubDefault"
                        color="highlight"
                        class="input-text"
                        :clearable="true"
                        :placeholder="chargeCodeInitialData.hubDefault.placeholder"
                        :class="'input-text'"
                        hide-details="auto"
                        id="hubDefault-id"
                        maxlength="20"
                        @keydown.enter.prevent
                        v-model="chargeCodeInitialData.formData.hubDefault.name"
                        :rules="isHubDefault ? rules.required : []"
                        :disabled="!isHubDefault"
                      >
                      </v-text-field>
                    </div>
                  </div>
            </div>
            <hr class="horizontal-divider" />
            <rates-component
              ref="ratesComponent"
              :is405ChargeCodeFlag="is405ChargeCodeFlag"
              @selectedRateQualifier="selectedRateQualifier($event)"
              :prepopulateRateQualifier="chargeCodeInitialData.formData.rateQualifier"
              :rates="chargeCodeInitialData.formData.rates"
              :prepopulatedLayoverType="chargeCodeInitialData.formData.layoverType"
              :selectedChargeCode="chargeCodeInitialData.formData.chargeCode"
              @selectedLayoverType="chargeCodeInitialData.formData.layoverType = $event"
            ></rates-component>
            <div v-if="!is405ChargeCodeFlag">
              <hr class="horizontal-divider" />
              <!-- Sub Details Section for other charge codes -->
              <v-card style="background-color: #F7F7F7;box-shadow: none;" id="tabsContainer">
                <div class="d-row-flex">
                  <!-- Service Type -->
                  <div class="field">
                    <div>
                      <label class="field-label"
                        >{{ chargeCodeInitialData.serviceType.menuLabel }}
                      </label>
                      <span class="d-inline-flex"> </span>
                      <v-select
                        outlined
                        dense
                        flat
                        attach
                        :clearable="true"
                        :class="'input-text'"
                        color="highlight"
                        :item-value="'displayValue'"
                        v-model="chargeCodeInitialData.formData.serviceType"
                        :placeholder="chargeCodeInitialData.serviceType.placeholder"
                        :items="chargeCodeInitialData.serviceType.serviceTypes || []"
                        whitespace="false"
                        id="service-type"
                        :disabled="isEditForm"
                      >
                        <template v-slot:item="{ item }">
                          <div>{{ item.value }} - {{ item.displayValue }}</div>
                        </template>
                        <template v-slot:selection="{ item }">
                          <div>{{ item.value }} - {{ item.displayValue }}</div>
                        </template>
                      </v-select>
                    </div>
                  </div>
                  <!-- Ramp SCAC -->
                  <div class="field">
                    <div>
                      <label class="field-label">
                        {{ chargeCodeInitialData.rampScac.menuLabel }}</label
                      >
                      <span class="d-inline-flex"> </span>
                      <HgAutocomplete
                        :clearable="true"
                        :searchType="'rampScac'"
                        :placeholder="chargeCodeInitialData.rampScac.placeholder"
                        :items="chargeCodeInitialData.rampScac.items || []"
                        :backgroundColor="getColor('color_white')"
                        return-object
                        :itemText="'displayValue'"
                        @onValueSelected="onValueSelected($event, 'rampSac')"
                        @onSearchTextChanged="onSearchTextChanged($event, 'rampScac')"
                        :prepopulateItem="chargeCodeInitialData.formData.rampScac"
                        id="ramp-scac-autocomplete"
                        :disabled="isEditForm"
                      />
                    </div>
                  </div>
                  <!-- Rail SCAC -->
                  <div class="field">
                    <div>
                      <label class="field-label">
                        {{ chargeCodeInitialData.railScac.menuLabel }}</label
                      >
                      <span class="d-inline-flex"> </span>
                      <v-select
                        outlined
                        dense
                        flat
                        attach
                        :clearable="true"
                        :class="'input-text'"
                        color="highlight"
                        :placeholder="chargeCodeInitialData.railScac.placeholder"
                        :items="chargeCodeInitialData.railScac.items || []"
                        whitespace="false"
                        id="rail-SCAC"
                        v-model="chargeCodeInitialData.formData.railScac"
                        :disabled="isEditForm"
                      >
                      </v-select>
                    </div>
                  </div>
                  <!-- Bundle Code -->
                  <div class="field">
                    <div>
                      <label class="field-label"
                        >{{ chargeCodeInitialData.bundleCode.menuLabel }}
                      </label>
                      <span class="d-inline-flex"> </span>
                      <v-select
                        outlined
                        dense
                        flat
                        attach
                        :clearable="true"
                        :class="'input-text'"
                        color="highlight"
                        :placeholder="chargeCodeInitialData.bundleCode.placeholder"
                        :items="chargeCodeInitialData.bundleCode.bundleCodes || []"
                        whitespace="false"
                        :item-text="item => item.code + ' - ' + item.description"
                        id="bundle-code"
                        return-object
                        v-model="chargeCodeInitialData.formData.bundleCode"
                        :disabled="isEditForm"
                      >
                      </v-select>
                    </div>
                  </div>
                  <!-- Vendor/ Carrier -->
                  <div class="field customer-filter">
                    <label class="field-label">{{ chargeCodeInitialData.vendor.menuLabel }}</label>
                    <span class="d-inline-flex"> </span>
                    <HgAutocomplete
                      returnObject
                      :clearable="true"
                      :searchType="chargeCodeInitialData.vendor.searchType"
                      :placeholder="chargeCodeInitialData.vendor.placeholder"
                      :items="chargeCodeInitialData.vendor.items || []"
                      :itemText="'text'"
                      :prepopulateItem="chargeCodeInitialData.formData.vendor"
                      :backgroundColor="getColor('color_white')"
                      @onSearchTextChanged="onSearchTextChanged($event, 'vendor')"
                      @onValueSelected="onValueSelected($event)"
                      id="vendor-autocomplete"
                      :disabled="isEditForm"
                    />
                  </div>
                </div>
                <div class="d-row-flex">
                  <!-- Special Terms -->
                  <div class="smallFieldWidth">
                    <label class="field-label">
                      {{ chargeCodeInitialData.specialTerms.menuLabel }}</label
                    >
                    <span class="d-inline-flex"> </span>
                    <v-select
                      outlined
                      dense
                      flat
                      attach
                      :clearable="false"
                      :placeholder="chargeCodeInitialData.specialTerms.placeholder"
                      :items="chargeCodeInitialData.specialTerms.items"
                      item-text="displayValue"
                      item-value="value"
                      :class="'input-text'"
                      color="highlight"
                      whitespace="false"
                      id="special-terms-id"
                      v-model="chargeCodeInitialData.formData.specialTerms"
                    />
                  </div>
                  <!-- Notes -->
                  <div class="fullFieldWidth">
                    <div>
                      <label class="field-label">
                        {{ chargeCodeInitialData.notes.menuLabel }}</label
                      >
                      <span class="d-inline-flex"> </span>
                      <v-textarea
                        flat
                        dense
                        outlined
                        ref="notes"
                        color="highlight"
                        class="input-text notes"
                        :clearable="true"
                        :placeholder="chargeCodeInitialData.notes.placeholder"
                        rows="1"
                        auto-grow
                        :class="'input-text notes'"
                        hide-details="auto"
                        id="hub-default-notes-id"
                        @keydown.enter.prevent
                        v-model="chargeCodeInitialData.formData.notes"
                      >
                      </v-textarea>
                    </div>
                  </div>
                </div>
                <!-- Locations Section  -->
                <locations-component
                  ref="locationsComponent"
                  :locations="chargeCodeInitialData.formData.locations"
                  :isEditForm="isEditForm"
                ></locations-component>
              </v-card>
              <hr class="horizontal-divider" />
              <v-card style="background-color: #F7F7F7;box-shadow: none;">
                <div class="d-row-flex">
                  <!-- Minimun Rate -->
                  <div class="field">
                    <div>
                      <label class="field-label">
                        {{ chargeCodeInitialData.minimumRate.menuLabel }}</label
                      >
                      <span class="d-inline-flex"> </span>
                      <v-text-field
                        flat
                        dense
                        outlined
                        ref="minimunRate"
                        color="highlight"
                        class="input-text"
                        :clearable="true"
                        :placeholder="chargeCodeInitialData.minimumRate.placeholder"
                        :class="'input-text'"
                        hide-details="auto"
                        id="minimum-rate-id"
                        maxlength="20"
                        @keydown.enter.prevent
                        v-model="chargeCodeInitialData.formData.minimumRate"
                        onkeypress="return (event.charCode >= 48 && event.charCode <= 57) || (event.charCode == 46)"
                      >
                      </v-text-field>
                    </div>
                  </div>
                  <!-- Maximum Rate -->
                  <div class="field">
                    <div>
                      <label class="field-label">
                        {{ chargeCodeInitialData.maximumRate.menuLabel }}</label
                      >
                      <span class="d-inline-flex"> </span>
                      <v-text-field
                        flat
                        dense
                        outlined
                        ref="maximumRate"
                        color="highlight"
                        class="input-text"
                        :clearable="true"
                        :placeholder="chargeCodeInitialData.maximumRate.placeholder"
                        :class="'input-text'"
                        hide-details="auto"
                        id="maximum-rate-id"
                        maxlength="20"
                        @keydown.enter.prevent
                        v-model="chargeCodeInitialData.formData.maximumRate"
                        onkeypress="return (event.charCode >= 48 && event.charCode <= 57) || (event.charCode == 46)"
                      >
                      </v-text-field>
                    </div>
                  </div>
                  <!-- start Event -->
                  <div class="field" style="width: 25em;">
                    <div>
                      <label class="field-label"
                        >{{ chargeCodeInitialData.startEvent.menuLabel }}
                      </label>
                      <span class="d-inline-flex"> </span>
                      <v-select
                        outlined
                        dense
                        flat
                        attach
                        :clearable="true"
                        :class="'input-text'"
                        color="highlight"
                        :placeholder="chargeCodeInitialData.startEvent.placeholder"
                        :items="chargeCodeInitialData.startEvent.items || []"
                        whitespace="false"
                        id="start-event"
                        item-text="displayValue"
                        item-value="value"
                        v-model="chargeCodeInitialData.formData.startEvent"
                        :menu-props="{ top: true, offsetY: true }"
                      >
                        <template v-slot:item="{ item }">
                          <div :class="'select-overflow'">
                            {{ item.value }} - {{ item.displayValue }}
                          </div>
                        </template>
                      </v-select>
                    </div>
                  </div>
                  <!-- End Event -->
                  <div class="field" style="width: 25em;">
                    <div>
                      <label class="field-label"
                        >{{ chargeCodeInitialData.endEvent.menuLabel }}
                      </label>
                      <v-select
                        outlined
                        dense
                        flat
                        attach
                        :clearable="true"
                        :class="'input-text'"
                        color="highlight"
                        :placeholder="chargeCodeInitialData.endEvent.placeholder"
                        :items="chargeCodeInitialData.endEvent.items || []"
                        whitespace="false"
                        id="end-event"
                        item-text="displayValue"
                        item-value="value"
                        v-model="chargeCodeInitialData.formData.endEvent"
                        :menu-props="{ top: true, offsetY: true }"
                      >
                        <template v-slot:item="{ item }">
                          <div :class="'select-overflow'">
                            {{ item.value }} - {{ item.displayValue }}
                          </div>
                        </template>
                      </v-select>
                    </div>
                  </div>
                </div>
                <div class="d-row-flex">
                  <!-- Holidays Free -->
                  <div class="field">
                    <div>
                      <label class="field-label">
                        {{ chargeCodeInitialData.freeHolidays.menuLabel }}</label
                      >
                      <span class="d-inline-flex"> </span>
                      <v-select
                        outlined
                        dense
                        flat
                        attach
                        :clearable="true"
                        :placeholder="chargeCodeInitialData.freeHolidays.placeholder"
                        :items="chargeCodeInitialData.freeHolidays.items"
                        :class="'input-text'"
                        color="highlight"
                        whitespace="false"
                        id="holidays-free-id"
                        v-model="chargeCodeInitialData.formData.freeHolidays"
                      >
                      </v-select>
                    </div>
                  </div>
                  <!-- Free Time Type -->
                  <div class="field">
                    <div>
                      <label class="field-label"
                        >{{ chargeCodeInitialData.freeTimeType.menuLabel }}
                      </label>
                      <span class="d-inline-flex"> </span>
                      <v-select
                        outlined
                        dense
                        flat
                        attach
                        :clearable="true"
                        :placeholder="chargeCodeInitialData.freeTimeType.placeholder"
                        class="input-text"
                        color="highlight"
                        :items="chargeCodeInitialData.freeTimeType.items"
                        whitespace="false"
                        id="free-time-type"
                        item-text="text"
                        item-value="value"
                        @change="onFreeTimeTypeSelected($event)"
                        v-model="chargeCodeInitialData.formData.freeTimeType"
                        :disabled="chargeCodeInitialData.formData.isFreeDays999"
                      >
                      </v-select>
                    </div>
                  </div>
                  <!--  Free Days-->
                  <div class="field" v-if="chargeCodeInitialData.formData.freeTimeType === 'DAY'">
                    <div>
                      <label class="field-label">
                        {{ chargeCodeInitialData.freeDays.menuLabel }}</label
                      >
                      <v-text-field
                        flat
                        dense
                        outlined
                        ref="freeDays"
                        color="highlight"
                        class="input-text"
                        :clearable="true"
                        :placeholder="chargeCodeInitialData.freeDays.placeholder"
                        :class="'input-text'"
                        hide-details="auto"
                        id="free-days"
                        :name="v4()"
                        maxlength="3"
                        @keydown.enter.prevent
                        v-model="chargeCodeInitialData.formData.freeDays"
                        :disabled="chargeCodeInitialData.formData.isFreeDays999"
                      >
                      </v-text-field>
                    </div>
                  </div>
                  <!-- Free Time -->
                  <div
                    class="field"
                    style="width: 10em;"
                    v-if="chargeCodeInitialData.formData.freeTimeType === 'TIME'"
                  >
                    <div>
                      <label class="field-label">{{
                        chargeCodeInitialData.freeTime.menuLabel
                      }}</label>
                      <span class="d-inline-flex"> </span>
                      <vue-timepicker
                        :minute-interval="15"
                        placeholder="24 Hr Format"
                        auto-scroll
                        close-on-complete
                        manual-input
                        id="time-picker"
                        drop-direction="up"
                        format="HH:mm"
                        input-width="125px"
                        @change="
                          onTimeChange($event, 'freeTime', chargeCodeInitialData.freeTime.format)
                        "
                        v-model="chargeCodeInitialData.formData.freeTime"
                      />
                    </div>
                  </div>
                  <!-- Free Time Cutoff -->
                  <div class="field" style="width: 10em;">
                    <div class="timePickerWrapper">
                      <label class="field-label">{{
                        chargeCodeInitialData.freeCutOffTime.menuLabel
                      }}</label>
                      <span class="d-inline-flex"> </span>
                      <vue-timepicker
                        :minute-interval="15"
                        placeholder="12 Hr Format"
                        auto-scroll
                        close-on-complete
                        manual-input
                        id="time-picker"
                        drop-direction="up"
                        format="hh:mm A"
                        input-width="125px"
                        @change="
                          onTimeChange(
                            $event,
                            'freeCutOffTime',
                            chargeCodeInitialData.freeCutOffTime.format
                          )
                        "
                        v-model="chargeCodeInitialData.formData.freeCutOffTime"
                      />
                    </div>
                  </div>
                  <!-- Free LOAD Days -->
                  <div class="field" style="width: 9em;">
                    <div>
                      <label class="field-label">{{
                        chargeCodeInitialData.reloads.menuLabel
                      }}</label>
                      <span class="d-inline-flex"> </span>
                      <v-text-field
                        flat
                        dense
                        outlined
                        ref="freeDays"
                        color="highlight"
                        class="input-text"
                        :clearable="true"
                        :placeholder="chargeCodeInitialData.reloads.placeholder"
                        :class="'input-text'"
                        hide-details="auto"
                        id="free-time-cut-off-id"
                        :name="v4()"
                        maxlength="3"
                        @keydown.enter.prevent
                        v-model="chargeCodeInitialData.formData.reloads"
                        onkeypress="return (event.charCode >= 48 && event.charCode <= 57)"
                      >
                      </v-text-field>
                    </div>
                  </div>
                  <!--  Free Weekend Type-->
                  <div class="field" style="width: 16em;">
                    <div>
                      <label class="field-label">{{
                        chargeCodeInitialData.freeWeekendType.menuLabel
                      }}</label>
                      <span class="d-inline-flex"> </span>
                      <v-select
                        outlined
                        dense
                        flat
                        attach
                        :clearable="true"
                        :placeholder="chargeCodeInitialData.freeWeekendType.placeholder"
                        :items="chargeCodeInitialData.freeWeekendType.weekendTypes || []"
                        :class="'input-text'"
                        color="highlight"
                        whitespace="false"
                        id="free-weekend-id"
                        v-model="chargeCodeInitialData.formData.freeWeekendType"
                        :menu-props="{ top: true, offsetY: true }"
                      >
                      </v-select>
                    </div>
                  </div>
                </div>
              </v-card>
            </div>
          </div>

          <!--  Actions -->
          <v-card-actions style="padding-top: 4em">
            <v-spacer></v-spacer>
            <hg-lib-btn
              :title="'Cancel'"
              :type="'secondary'"
              :disabled="false"
              @click.native="closeDialog()"
              id="cancel-dialog"
            />
            <hg-lib-btn
              :disabled="!formValid"
              :title="isEditForm ? 'Save' : 'Create'"
              :type="'primary'"
              @click.native="submit()"
              id="submit-charge-codes"
            />
          </v-card-actions>
        </v-form>
      </v-card>
    </v-dialog>
  </div>
</template>

<script src="./charge-codes-modal.js"></script>
<style src="./charge-codes-modal.sass" scoped lang="sass"></style>
