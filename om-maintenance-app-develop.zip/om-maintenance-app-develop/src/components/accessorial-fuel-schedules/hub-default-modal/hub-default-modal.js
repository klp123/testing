import moment from 'moment';
import Vue from 'vue';
import _ from 'lodash';
import { AppSetupEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import { ImageLoaderService, GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import cdnImagesEnum from '@hubgroup/hg-vue-oc-util-lib/src/enums/cdn-images.enum';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import createHubDefaultModel from './create-hub-default-model';
import customerService from '../../../services/customer/customer.service';
import hubDefaultService from '../../../services/accessorial-fuel-schedules/hub-default.service';
import timeZoneService from '../../../services/accessorial-fuel-schedules/time-zone.service';
import hgPagination from '../../shared/hg-pagination/hg-pagination.vue';
import DateTimePickerComponent from '../../shared/datetime-picker/datetime-picker.vue';

moment.tz.setDefault('America/Chicago');

function getColor(name) {
  return _colors[name];
}

function getIcon(iconName) {
  return ImageLoaderService.getCdnImageUrl(iconName);
}

function closeDialog() {
  this.resetEffectiveDateTime = false;
  this.formValid = false;
  this.showDialog = false;
  this.$emit('closeDialog', {});
  GoogleAnalyticsService.event(Vue, 'Close dialog', 'Hub-default', 'Hub Default dialog closed');
  this.$store.dispatch('customerAccessorialFuelStore/updateRefreshGrid', true);
}
async function confirmSubmitHubDefaultCode() {
  this.showHubDefaultExistsDialog.dialog = false;
  const responseStatus = await hubDefaultService.saveChargeCodeUsingHubDefaults(this.chargeCodeData);
  if (responseStatus) {
    this.closeDialog();
  }
}

function cancelSubmitHubDefaultCode() {
  this.showHubDefaultExistsDialog.dialog = false;
}
async function submit() {
  this.showHubDefaultExistsDialog.dialog = true;
  this.chargeCodeData = {
    hubDefaults: this.tableData.map((item) => (
      {
        _id: item._id,
        effectiveDateTime: {
          dateTime: timeZoneService.cstStartOf(item.effectiveDateTime.dateTime, true, 'MM/DD/YY')
        },
        expiredDateTime: {
          dateTime: item.expiredDateTime.dateTime
            ? timeZoneService.cstEndOf(item.expiredDateTime.dateTime, true, 'MM/DD/YY')
            : null
        }
      })),
    customer: {
      id: _.get(this.hubDefaultInitialData, 'customer.selectedItem.value', null),
      name: _.get(this.hubDefaultInitialData, 'customer.selectedItem.name', null)
    },
    publishDateTime: {
      dateTime: timeZoneService.cstDateTime(new Date())
    }
  };
}
function onKeyDown(source) {
  clearTimeout(this.timeout);
  this.timeout = setTimeout(() => {
    this.onSearchTextChanged(source === 'customer' ? this.customerSearch : this.hubDefaultSearch, source);
  }, 1000);
}

function deleteChip(item) {
  this.tableData = this.tableData.filter((selectedItem) => item._id !== selectedItem._id);
  const deletedHubDefault = this.tableData.find((it) => it.hubDefault.name === item.hubDefault.name);
  if (!deletedHubDefault) {
    // un-select the item in auto complete
    this.hubDefaultInitialData.hubDefault.selectedItems = this.hubDefaultInitialData.hubDefault.selectedItems
      .filter((it) => it.name !== item.hubDefault.name);
  }
}

async function onSearchTextChanged(searchText = '', source) {
  try {
    if (!searchText || searchText.length >= AppSetupEnum.MINIMUM_SEARCH_CHARACTER) {
      switch (source) {
        case 'customer':
          this.loadingCustList = true;
          this.hubDefaultInitialData.customer.items = await customerService.searchCustomers(searchText);
          this.loadingCustList = false;
          break;
        case 'hubDefault':
          this.loadinghubDefaultList = true;
          this.hubDefaultInitialData.hubDefault.items = await hubDefaultService.searchHubDefaultData(searchText, 20);
          this.loadinghubDefaultList = false;
          break;
        default:
          break;
      }
    }
  } catch (error) {
    console.error(`Error when fetching data on search Text for ${source}`, error);
    this.loadingCustList = false;
    this.loadinghubDefaultList = false;
  }
}

function onEffectiveDateTimeChange(value, item, rowIndex) {
  if (value) {
    item.effectiveDateTime = {
      dateTime: moment(value).format('MM/DD/YY')
    };
    if (moment(item.effectiveDateTime.dateTime)
      > moment(item.expiredDateTime.dateTime)) {
      item.expiredDateTime.dateTime = null;
    }
    this.$nextTick(() => {
      const dateTime = moment(item.effectiveDateTime.dateTime) > moment().startOf('day') ? value : moment().startOf('day').toISOString();
      this.$refs[`expiredDateTime${rowIndex}`].config.minDate = moment(dateTime).startOf('day').toISOString();
    });
    this.shown = false;
  } else {
    item.effectiveDateTime.dateTime = null;
  }
}

function onExpiredDateTimeChange(value, item) {
  if (value) {
    item.expiredDateTime = {
      dateTime: moment(value).format('MM/DD/YY')
    };
    this.shown = false;
  } else {
    item.expiredDateTime.dateTime = null;
  }
}

function getDatePickerConfig(item) {
  const config = _.cloneDeep(this.hubDefaultInitialData.effectiveDateConfig);
  const dateTime = moment(item.effectiveDateTime.dateTime) > moment().startOf('day') ? item.effectiveDateTime.dateTime : moment().startOf('day').toISOString();
  config.minDate = moment(dateTime).startOf('day').toISOString();
  item.effectiveDateTime.dateTime = moment(config.minDate).format('MM/DD/YY');
  if (item.expiredDateTime && item.expiredDateTime.dateTime) {
    config.maxDate = moment(item.expiredDateTime.dateTime).startOf('day').toISOString();
  }
  return config;
}

function updateTableData(selectedHubDefaultList) {
  if (selectedHubDefaultList && selectedHubDefaultList.length > 0) {
    // eslint-disable-next-line prefer-spread
    const selectedItems = _.cloneDeep([].concat.apply([], selectedHubDefaultList.map((item) => item.items)));
    const selectedUniqueNames = [...new Set(selectedItems.map((it) => it.hubDefault.name))];
    const tableDataUniqueNames = [...new Set(this.tableData.map((it) => it.hubDefault.name))];
    tableDataUniqueNames.map((td) => {
      if (!selectedUniqueNames.includes(td)) {
        // item unselected in auto complete, so delete all items in table
        this.tableData = this.tableData.filter((f) => f.hubDefault.name !== td);
      }
    });
    selectedUniqueNames.map((m) => {
      if (!tableDataUniqueNames.includes(m)) {
        // item not found in table, so all items
        this.tableData.push(...selectedItems.filter((it) => it.hubDefault.name === m));
      }
    });
  }
}

export default {
  name: 'hub-default-modal',
  components: {
    hgPagination,
    DateTimePickerComponent
  },
  data() {
    return {
      header: [
        {
          text: 'Hub Default', value: 'text', sortable: false
        },
        {
          text: 'Charge Code', value: 'chargeCode', sortable: false
        },
        {
          text: 'Mode', value: 'mode', sortable: false
        },
        {
          text: 'Equipment', value: 'equipmentType', sortable: false
        },
        {
          text: 'Effective Date', value: 'effectiveDateTime', sortable: false
        },
        {
          text: 'Expired Date', value: 'expiredDateTime', sortable: false
        },
        { text: 'Actions', sortable: false, value: 'actions' },
        { text: '', value: 'data-table-expand' },
      ],
      cdnImagesEnum,
      chargeCodeData: {},
      todayDateString: moment().format('YYYY-MM-DD').toString(),
      loading: false,
      showDialog: true,
      formValid: false,
      tableData: [],
      customerSearch: null,
      hubDefaultSearch: null,
      hubDefaultInitialData: createHubDefaultModel.getHubDefaultInitialData(),
      resetEffectiveDateTime: false,
      rules: {
        required: (value) => (!!value) || 'Required',
        requiredArray: (value) => (!!value.length) || 'Required',
      },
      showHubDefaultExistsDialog: {
        dialog: false,
        headerText: 'Confirmation',
        subText: 'Existing charge code(s) will be overridden . Click OK to proceed?'
      },
    };
  },
  methods: {
    closeDialog,
    getColor,
    getIcon,
    submit,
    onSearchTextChanged,
    onEffectiveDateTimeChange,
    onExpiredDateTimeChange,
    onKeyDown,
    deleteChip,
    confirmSubmitHubDefaultCode,
    cancelSubmitHubDefaultCode,
    getDatePickerConfig,
    updateTableData
  },
  filters: {
    formatDate(value) {
      if (!value || !value.trim()) return '-';
      return timeZoneService.cstDateTime(value, null, 'MM/DD/YYYY');
    },
    formatDateTime(value) {
      if (!value || !value.trim()) return '-';
      return timeZoneService.cstDateTime(value, null, 'MM/DD/YYYY HH:mm');
    }
  },
  created() {
    this.onSearchTextChanged('', 'hubDefault');
  },
  watch: {
    'hubDefaultInitialData.hubDefault.selectedItems': {
      handler(val) {
        this.updateTableData(val);
      },
      deep: true
    },
    customerSearch(val) {
      if (!val) {
        return;
      }
      this.customerSearch = val;
      this.isLoading = true;
    },
    hubDefaultSearch(val) {
      if (!val) {
        return;
      }
      this.hubDefaultSearch = val;
      this.isLoading = true;
    },
  },
};