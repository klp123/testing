import * as _ from 'lodash';
import moment from 'moment';

moment.tz.setDefault('America/Chicago');
const getTodayDate = moment().format('YYYY-MM-DD');

const formData = {
  customer: {},
  effectiveDateTime: { dateTime: moment().format('YYYY-MM-DD') },
  expiredDateTime: {},
  hubDefaultIds: []
};

const hubDefaultInitialData = {
  showAsfModal: false,
  loadingCustList: false,
  loadingHubDefaultList: false,
  formData: _.cloneDeep(formData),
  customer: {
    items: [],
    selectedItem: null,
    key: 'customer',
    placeholder: 'Search Customers',
    searchType: 'customer',
    menuLabel: 'CUSTOMER',
  },
  hubDefault: {
    items: [],
    selectedItems: [],
    key: 'hubDefault',
    placeholder: 'Search Hub Default',
    searchType: 'hubDefault',
    menuLabel: 'HUB DEFAULT',
  },
  effectiveDateTime: '',
  expiredDateTime: '',
  effectiveDateConfig: {
    maxDate: null,
    minDate: getTodayDate,
    disabled: false,
    required: true
  },
  expiredDateConfig: {
    maxDate: null,
    minDate: getTodayDate,
    disabled: false,
    required: true
  }
};

function getHubDefaultInitialData() {
  return _.cloneDeep(hubDefaultInitialData);
}

export default {
  getHubDefaultInitialData,
};