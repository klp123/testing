<template>
  <div class="hub-default-container">
    <hg-alert-dialog
      v-if="showHubDefaultExistsDialog.dialog"
      :confirmationHeaderText="showHubDefaultExistsDialog.headerText"
      :confirmationSubText="showHubDefaultExistsDialog.subText"
      @confirm="confirmSubmitHubDefaultCode()"
      @cancel="cancelSubmitHubDefaultCode()"
    />
    <v-dialog v-model="showDialog" max-width="60%" style="overflow:visible;" persistent>
      <v-overlay v-if="loading">
        <v-progress-circular
          indeterminate
          :size="70"
          :color="getColor('color_white')"
        ></v-progress-circular>
      </v-overlay>
      <v-card elevation="2">
        <v-form ref="hubDefaultCreateForm" v-model="formValid">
          <div class="d-flex justify-space-between w-100 modal-header-container">
            <!-- Modal header -->
            <div class="modal-header">Assign Customer to Hub Default</div>
            <v-btn @click="closeDialog()" icon>
              <v-icon id="modal-close">mdi-close</v-icon>
            </v-btn>
          </div>
          <hr class="horizontal-divider" />
          <!-- Modal Body -->
          <div class="modal-header">
            <div class="d-row-flex">
              <!-- customer  -->
              <div class="auto-complete-field">
                <label class="field-label">{{ hubDefaultInitialData.customer.menuLabel }}</label>
                <img class="label-required" :src="getIcon(cdnImagesEnum.required_icon)" />
                <v-autocomplete
                  v-model="hubDefaultInitialData.customer.selectedItem"
                  item-value="id"
                  clearable
                  background-color="white"
                  :search-input.sync="customerSearch"
                  @keydown="onKeyDown('customer')"
                  @change="event => onSearchTextChanged(event)"
                  :items="hubDefaultInitialData.customer.items || []"
                  :placeholder="hubDefaultInitialData.customer.placeholder"
                  outlined
                  hide-details="auto"
                  return-object
                  :rules="[rules.required]"
                ></v-autocomplete>
              </div>
              <!-- hubDefault  -->
              <div class="auto-complete-field">
                <label class="field-label">{{ hubDefaultInitialData.hubDefault.menuLabel }}</label>
                <img class="label-required" :src="getIcon(cdnImagesEnum.required_icon)" />
                <v-autocomplete
                  v-model="hubDefaultInitialData.hubDefault.selectedItems"
                  multiple
                  item-value="_id"
                  background-color="white"
                  :search-input.sync="hubDefaultSearch"
                  @keydown="onKeyDown('hubDefault')"
                  @change="event => onSearchTextChanged(event)"
                  :items="hubDefaultInitialData.hubDefault.items || []"
                  :placeholder="hubDefaultInitialData.hubDefault.placeholder"
                  outlined
                  hide-details="auto"
                  return-object
                  :rules="[rules.requiredArray]"
                  cache-items
                >
                  <template v-slot:selection></template>
                </v-autocomplete>
              </div>
            </div>
          </div>
          <!-- Hub Default-BAse records Grid  -->
          <div class="modal-body" v-if="tableData.length">
            <v-data-table
              fixed-header
              :headers="header"
              :items="tableData"
              class="hg-table elevation-1"
              id="hub-default-base-records-grid"
              show-expand
              item-key="_id"
              single-expand
              :footer-props="{ 'items-per-page-text':'Hub Defaults Per Page' }"
            >
              <template v-slot:item.text="{ item }">
                <div class="table-template-field">{{ item.hubDefault.name }}</div>
              </template>
              <template v-slot:item.chargeCode="{ item }">
                <div class="table-template-field">{{ item.chargeCode.code }}</div>
              </template>
              <template v-slot:item.mode="{ item }">
                <div class="table-template-field">{{ item.transportMode }}</div>
              </template>
              <template v-slot:item.equipmentType="{ item }">
                <div class="table-template-field">
                  {{ (item.equipment && item.equipment.equipmentType) ? (item.equipment.equipmentType + item.equipment.length.amount) : '' }}
                </div>
              </template>
              <template v-slot:item.effectiveDateTime="{ item, index }">
                <DateTimePickerComponent
                      :ref="`effectiveDateTime${index}`"
                      :config="getDatePickerConfig(item)"
                      :dateTime="item.effectiveDateTime.dateTime"
                      @dateTimeChanged="onEffectiveDateTimeChange($event, item, index)"
                      :required="true"
                      checkIfValidDate
                      :datePickerAttach="false"
                    />
              </template>
              <template v-slot:item.expiredDateTime="{ item, index }">
                <DateTimePickerComponent
                  checkIfValidDate
                  :ref="`expiredDateTime${index}`"
                  :config="getDatePickerConfig(item)"
                  :dateTime="item.expiredDateTime.dateTime"
                  @dateTimeChanged="onExpiredDateTimeChange($event, item)"
                  :showTimeOption="false"
                  :datePickerAttach="false"
                />
              </template>
              <template v-slot:item.actions="{ item }">
                  <img
                    @click.prevent="deleteChip(item)"
                    :id="`hub-default-delete`"
                    class="trash-icon-delete"
                    style="cursor: pointer"
                    :src="getIcon(cdnImagesEnum.delete_icon)"
                  />
              </template>
              <div></div>
              <template v-slot:expanded-item="{ headers, item }">
                <td :colspan="headers.length">
                  <div class="cc-detail-card">
                    <div class="cc-detail-container padding-top-1">
                      <div class="cc-detail-item">
                        <div class="cc-detail-item-label">Origin:</div>
                        <div class="cc-detail-item-value">
                          {{ item.locations && item.locations[0] && item.locations[0].LocationName }}
                        </div>
                      </div>
                      <div class="cc-detail-item">
                        <div class="cc-detail-item-label">Destination:</div>
                        <div class="cc-detail-item-value">
                          {{ item.locations && item.locations[1] && item.locations[1].LocationName }}
                        </div>
                      </div>
                      <div class="cc-detail-item">
                        <div class="cc-detail-item-label">RailScac:</div>
                        <div class="cc-detail-item-value">
                          {{ item.railScac }}
                        </div>
                      </div>
                      <div class="cc-detail-item">
                        <div class="cc-detail-item-label">RampScac:</div>
                        <div class="cc-detail-item-value">
                          {{ item.rampScac }}
                        </div>
                      </div>
                      <div class="cc-detail-item">
                        <div class="cc-detail-item-label">Bundle Code:</div>
                        <div class="cc-detail-item-value">
                          {{ item.bundleCode && item.bundleCode.code }}
                        </div>
                      </div>
                      <div class="cc-detail-item">
                        <div class="cc-detail-item-label">Service Type:</div>
                        <div class="cc-detail-item-value">
                          {{ item.serviceType }}
                        </div>
                      </div>
                      <div class="cc-detail-item">
                        <div class="cc-detail-item-label">Vendor:</div>
                        <div class="cc-detail-item-value">
                          {{ item.vendor && item.vendor.name }}
                        </div>
                      </div>
                    </div>
                  </div>
                </td>
              </template>
              <template v-slot:bottom="{ pagination, options, updateOptions }">
                <v-data-footer
                  :pagination="pagination"
                  :options="options"
                  @update:options="updateOptions"
                  items-per-page-text="$vuetify.dataTable.itemsPerPageText"
                />
              </template>
            </v-data-table>
          </div>
          <!--  Actions -->
          <v-card-actions style="padding-top: 4em">
            <v-spacer></v-spacer>
            <hg-lib-btn
              :title="'Cancel'"
              :type="'secondary'"
              :disabled="false"
              @click.native="closeDialog()"
              id="cancel-dialog"
            />
            <hg-lib-btn
              :title="'Create'"
              :type="'primary'"
              @click.native="submit()"
              :disabled="!formValid"
              id="submit-charge-codes"
            />
          </v-card-actions>
        </v-form>
      </v-card>
    </v-dialog>
  </div>
</template>

<script src="./hub-default-modal.js"></script>
<style src="./hub-default-modal.sass" scoped lang="sass"></style>
