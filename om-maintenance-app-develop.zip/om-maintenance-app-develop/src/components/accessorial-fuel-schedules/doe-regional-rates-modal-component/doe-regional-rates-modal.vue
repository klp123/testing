<template>
  <div class="modal-wrapper">
  <v-dialog v-model="dialog" max-width="582px" @click:outside="cancel">
    <v-overlay v-if="loading">
      <v-progress-circular indeterminate :size="70" :color="getColor('color_white')"></v-progress-circular>
    </v-overlay>
    <v-card class="reason-code-card">
      <v-card-title>{{ messages.title }}
        <v-spacer></v-spacer>
        <v-icon @click="cancel()">mdi-close</v-icon>
      </v-card-title>
      <div class="border-line"></div>
      <div class="timePickerWrapper">
        <DatetimePickerComponent
          :dateTime="publishDate"
          ref="startDatetimePicker"
          :config="dateTimeRangeConfig.start"
          @dateTimeChanged="onDateTimeChange($event)"
          checkIfValidDate
        />
      </div>
      <div class="section-header">Viewing rates for the corresponding week</div>

      <div class="order-acceptance-data-table">
        <table class="table">
          <tr class="data-table-header">
            <th class="data-table-td-region-name">REGION</th>
            <th class="data-table-td-region-rate">{{ displayPublishDateTime | shortDate }}</th>
          </tr>
          <tr
            v-for="(region, index) of doeRegionalRatesEnum"
            :key="`region-${index}`"
            class="data-table-td"
          >
            <td v-bind:class="{
              'data-table-td-region-name-padding': region.padding
              }">{{ region.displayName }}</td>
            <td class="data-table-td-region-rate">
              {{ getRegionalRate(region.regionName) !== 0 ? parseFloat(getRegionalRate(region.regionName)).toFixed(3) : 'N/A' }}
            </td>
          </tr>
        </table>
        <div class="footer-details">
          *The prices are published around 5:00 p.m. Monday (Eastern time), except on government holidays, when the data are released on Tuesday (but still represent Monday's price).
        </div>
      </div>
    </v-card>
  </v-dialog>
  </div>
</template>

<script src="./doe-regional-rates-modal.js"></script>
<style src="./doe-regional-rates-modal.sass" lang="sass" scoped></style>
