import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import CdnImagesEnum from '@hubgroup/hg-vue-oc-util-lib/src/enums/cdn-images.enum';
import moment from 'moment';
import _ from 'lodash';
import Vue from 'vue';
import { GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import DatetimePickerComponent from '../../shared/datetime-picker/datetime-picker.vue';
import doeRegionalRatesEnum from '../../../enums/doe-regional-rates.enum';
import doeRegionalRatesData from '../../../services/accessorial-fuel-schedules/doe-regional-rates-data.service';

moment.tz.setDefault('America/Chicago');

function getColor(name) {
  return _colors[name];
}

function cancel() {
  this.dialog = false;
  this.publishDate = new Date().toISOString();
  this.$emit('closeDialog', {});
  GoogleAnalyticsService.event(Vue, 'Close dialog', 'Customer-Accessorials-Fuel', 'DOE regional rated dialog closes');
}

function setValidDateTime(value, key) {
  this.isValidDateTime[key] = value;
}

async function getDoeRegionalRatesData() {
  try {
    this.loading = true;
    const resp = await doeRegionalRatesData.doeRegionalRatesData(this.publishDate);
    this.doeRegionalRatesData = resp.data;
    this.displayPublishDateTime = moment(_.get(resp, 'data[0].publishDateTime.dateTime')).weekday(1);
    GoogleAnalyticsService.event(Vue, 'Get DOE rates', 'Customer-Accessorials-Fuel', 'Successfully retreived DOE regional rates');
  } catch (err) {
    console.error('Error when fetching DOE rates:', err.message);
    if (err.message && err.message !== RequestErrorTypesEnum.CANCEL_REQUEST) {
      HgNotificationService.errorMessage('Error while fetching doe regional rates.');
      this.loading = false;
    }
  }
  this.loading = false;
}

async function onDateTimeChange(value) {
  this.publishDate = value || moment().toISOString();
  this.publishDate = moment(this.publishDate).format('MM/DD/YYYY');
  await this.getDoeRegionalRatesData();
}

function getRegionalRate(regionName) {
  const region = this.doeRegionalRatesData[0] && this.doeRegionalRatesData[0].regionalRates.find(
    (regional) => regionName.toLowerCase() === regional.regionName.toLowerCase()
  );
  return (region && region.regionRate) || 0;
}

const data = {
  loading: false,
  publishDate: new Date().toISOString(),
  displayPublishDateTime: new Date(),
  CdnImagesEnum,
  doeRegionalRatesEnum,
  dialog: true,
  messages: {
    cancel: 'Cancel',
    title: 'DOE REGIONAL RATES'
  },
  doeRegionalRatesData: [],
  dateTimeRangeConfig: {
    start: {
      label: 'Search for specific date',
      maxDate: null,
      minDate: null,
      disabled: false,
      required: false
    }
  },
  isValidDateTime: {
    start: true,
    end: true
  },
};
// @vuese
// @group ORDER_DETAILS
// View page for customs broker
export default {
  name: 'DoeRegionalRatesModal',
  components: {
    DatetimePickerComponent,
  },
  data: () => (data),
  props: {
    type: {
      type: String,
      required: true,
      default: () => null,
    },
  },
  computed: {
  },
  mounted() {
    this.dialog = true;
  },
  filters: {
  },
  methods: {
    // @vuese
    // Gets color for given color name
    // @arg (name) color name
    getColor,
    cancel,
    getDoeRegionalRatesData,
    getRegionalRate,
    onDateTimeChange,
    setValidDateTime,
  },
};
