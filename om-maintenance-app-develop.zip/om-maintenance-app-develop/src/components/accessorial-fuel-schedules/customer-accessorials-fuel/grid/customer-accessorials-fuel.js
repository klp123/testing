import { HgNotificationService, ImageLoaderService, GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import moment from 'moment';
import Vue from 'vue';
import _ from 'lodash';
import accessorialsEntitlements from '@hubgroup/hg-om-shared-services/src/enums/entitlements.enum';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import CdnImagesEnum from '@hubgroup/hg-vue-oc-util-lib/src/enums/cdn-images.enum';
import customerAccessorialsHeadersEnum from '../../../../enums/customer-accessorials-headers.enum';
import doeRegionalRatesModal from '../../doe-regional-rates-modal-component/doe-regional-rates-modal.vue';
import UploadDialog from '../../upload-dialog/upload-dialog.vue';
import chargeCodesModal from '../../charge-codes-modal/charge-codes-modal.vue';
import customerAccessorialsFuelDetails from '../../customer-accessorials-fuel-details/customer-accessorials-fuel-details.vue';
import chargeCodesService from '../../../../services/accessorial-fuel-schedules/charge-codes.service';
import timeZoneService from '../../../../services/accessorial-fuel-schedules/time-zone.service';
import hubDefaultModal from '../../hub-default-modal/hub-default-modal.vue';
import chargeCodeHistoryModal from '../../charge-code-history-modal/charge-code-history-modal.vue';
import hubDefaultService from '../../../../services/accessorial-fuel-schedules/hub-default.service';

moment.tz.setDefault('America/Chicago');

function closeDialog() {
  this.$store.dispatch('customerAccessorialFuelStore/updateMultiSelectAction', '');
  this.dialog = false;
  this.showChargeCodeModal = false;
  this.showHubDefaultModal = false;
  this.showChargeCodeHistoryModal = false;
  this.action = null;
  // reset the modal data
  this.doeRegionalRatesModal.show = false;
  this.doeRegionalRatesModal.type = '';
  GoogleAnalyticsService.event(Vue, 'Close dialog', 'Customer-Accessorials-Fuel', 'DOE regional rates dialog closed');
}

function getIcon(iconName) {
  return ImageLoaderService.getCdnImageUrl(iconName);
}
function getColor(name) {
  return _colors[name];
}
function activeRow(item) {
  this.activeRowId = item._id;
  this.updateActiveCustomerId(item);
  this.selectActiveCustomer();
  GoogleAnalyticsService.event(Vue, 'Selected customer', 'Customer-Accessorials-Fuel', 'Active customer accessorials fuel schedule',
    { accessorials_fuel_customer: _.get(item, 'customer.name', '') });
}
/**
 * update active order to session storage
 * @param {*} order
 */
function updateActiveCustomerId(order) {
  sessionStorage.setItem('activeOrderId', order.orderId);
}

/**
 * update selectedId from session storage
 */
function selectActiveCustomer() {
  this.activeOrderId = sessionStorage.getItem('activeOrderId');
}

function multiSelectionActionChanged(newValue) {
  if (newValue === 'UPLOAD_DIALOG') {
    this.dialog = true;
  } else if (newValue === 'DOE_REGIONAL_RATES') {
    this.doeRegionalRatesModal.type = newValue;
    this.doeRegionalRatesModal.show = true;
  } else if (newValue === 'CHARGE_CODES_MODAL') {
    this.showChargeCodeModal = true;
  } else if (newValue === 'HUB_DEFAULT_MODAL') {
    this.showHubDefaultModal = true;
  } else if (newValue === 'CHARGE_CODE_HISTORY_MODAL') {
    this.showChargeCodeHistoryModal = true;
  }
}

function multiSelectAction() {
  return this.$store.getters['customerAccessorialFuelStore/getMultiSelectAction'];
}

function selectCustomerDetailsChanged(newValue) {
  this.selectedCustomerDetails = newValue;
  this.toggleSlideWindow = true;
}

function clearSelectCustomerDetails() {
  this.activeRowId = '';
  this.toggleSlideWindow = false;
  GoogleAnalyticsService.event(Vue, 'Clear customer', 'Customer-Accessorials-Fuel', 'Clear active customer');
}
async function openCustAccessorialEditModal(item, action) {
  try {
    this.selectedCustomerDetails = item;
    this.selectedCustomer = item._id;
    this.action = action;
    this.showChargeCodeModal = true;
  } catch (error) {
    console.error('Error in pre populating Charge Code Modal:', error);
    HgNotificationService.errorMessage(Vue, 'Error when opening Charge Code modal');
  }
}
async function deleteCustAccessorialChargeCode(item) {
  try {
    this.deleteChargeCodeId = item._id;
    this.showDeleteChargeCodeDialog.dialog = true;
  } catch (error) {
    console.error('Error in deleteCustAccessorialChargeCode:', error);
    HgNotificationService.errorMessage(Vue, 'Error when deleting Charge Code ');
  }
}
async function confirmDeleteChargeCode() {
  this.showDeleteChargeCodeDialog.dialog = false;
  const response = await chargeCodesService.deleteChargeCodeData(this.deleteChargeCodeId);
  if (_.get(response, 'data.status')) {
    HgNotificationService.successMessage(Vue, _.get(response, 'data.message'));
    this.$store.dispatch('customerAccessorialFuelStore/updateRefreshGrid', true);
  } else {
    HgNotificationService.errorMessage(Vue, _.get(response, 'data.message'));
  }
}

function cancelDeleteChargeCode() {
  this.showDeleteChargeCodeDialog.dialog = false;
}

function refreshGridCloseDetails() {
  return this.$store.getters['customerAccessorialFuelStore/getRefreshGrid'];
}

async function viewHistoryCustAccessorialChargeCode(item) {
  try {
    this.selectedCustomerDetails = item;
    this.selectedCustomer = item._id;
    this.showChargeCodeHistoryModal = true;
  } catch (error) {
    console.error('Error in pre populating Charge Code History Modal:', error);
    HgNotificationService.errorMessage(Vue, 'Error when opening Charge Code History modal');
  }
}

async function unassignCustAccessorialChargeCode(chargeCodeId) {
  try {
    const response = await hubDefaultService.unassignChargeCodeUsingHubDefaults(chargeCodeId);
    if (_.get(response, 'status') === 200 && _.get(response, 'data.result')) {
      HgNotificationService.successMessage(Vue, _.get(response, 'data.message'));
      this.$store.dispatch('customerAccessorialFuelStore/updateRefreshGrid', true);
    } else {
      HgNotificationService.errorMessage(Vue, _.get(response, 'errorMessage'));
    }
  } catch (error) {
    console.error('Error in unassignCustAccessorialChargeCode:', error);
    HgNotificationService.errorMessage(Vue, 'Error when unassigning Charge Code ');
  }
}

export default {
  name: 'CustomerAccessorialsFuel',

  components: {
    doeRegionalRatesModal,
    UploadDialog,
    customerAccessorialsFuelDetails,
    chargeCodesModal,
    hubDefaultModal,
    chargeCodeHistoryModal
  },
  data: () => ({
    selectedCustomer: null,
    deleteChargeCodeId: null,
    customerAccessorialsHeadersEnum,
    accessorialsEntitlements,
    token: localStorage.getItem('jwt'),
    CdnImagesEnum,
    loading: false,
    singleSelect: false,
    rowsPerPageItems: [20, 30, 40, 50, 100],
    doeRegionalRatesModal: {
      show: false,
      type: '',
      orderIds: [],
    },
    dialog: false,
    showChargeCodeModal: false,
    showHubDefaultModal: false,
    showChargeCodeHistoryModal: false,
    lodash: _,
    selectedCustomerDetails: {
    },
    toggleSlideWindow: false,
    activeRowId: '',
    showDeleteChargeCodeDialog: {
      dialog: false,
      headerText: 'Confirmation',
      subText: 'Are you sure , Do you want to delete the Charge Code?'
    },
    action: null
  }),
  watch: {
    multiSelectAction: {
      handler(newValue) {
        if (newValue) {
          multiSelectionActionChanged.bind(this)(newValue);
        }
      },
    },
    refreshGridCloseDetails(value) {
      if (value) {
        this.toggleSlideWindow = false;
        this.$store.dispatch('customerAccessorialFuelStore/updateRefreshGrid', false);
      }
    }
  },
  computed: {
    multiSelectAction,
    refreshGridCloseDetails
  },
  props: {
    loadingCustomerAccesorial: {
      type: Boolean,
      default: false
    },
    customerAccessorialFuelData: {
      type: Array,
      required: true,
      default: []
    }
  },
  created() { },
  methods: {
    getIcon,
    getColor,
    activeRow,
    updateActiveCustomerId,
    selectActiveCustomer,
    multiSelectionActionChanged,
    closeDialog,
    selectCustomerDetailsChanged,
    clearSelectCustomerDetails,
    openCustAccessorialEditModal,
    deleteCustAccessorialChargeCode,
    confirmDeleteChargeCode,
    cancelDeleteChargeCode,
    viewHistoryCustAccessorialChargeCode,
    unassignCustAccessorialChargeCode
  },
  filters: {
    formatDate(value) {
      if (!value || !value.trim()) return '-';
      return timeZoneService.cstDateTime(value, null, 'MM/DD/YY');
    }
  }
};
