<template>
  <div class="wrapper">
    <hg-alert-dialog v-if="showDeleteChargeCodeDialog.dialog"
      :confirmationHeaderText="showDeleteChargeCodeDialog.headerText"
      :confirmationSubText="showDeleteChargeCodeDialog.subText" @confirm="confirmDeleteChargeCode()"
      @cancel="cancelDeleteChargeCode()"/>
    <doe-regional-rates-modal v-if="doeRegionalRatesModal.show" :type="doeRegionalRatesModal.type"
      @closeDialog="closeDialog($event)"></doe-regional-rates-modal>
    <upload-dialog v-if="dialog" @closeDialog="closeDialog"/>
    <charge-codes-modal id="editChargeCodeModal" ref="editChargeCodeModal" v-if="showChargeCodeModal"
      :selectedCustomerAccessorial="selectedCustomerDetails" :action="action"
      @closeDialog="closeDialog"/>
    <hub-default-modal id="hubDefaultModal" ref="hubDefaultModal" v-if="showHubDefaultModal" @closeDialog="closeDialog"/>
    <charge-code-history-modal :selectedCustomerAccessorial="selectedCustomerDetails" id="chargeCodeHistoryModal" ref="chargeCodeHistoryModal" v-if="showChargeCodeHistoryModal" @closeDialog="closeDialog" />
    <v-card tile class="fill-height" :class="{ active: toggleSlideWindow }">
      <div>
        <v-skeleton-loader :loading="loadingCustomerAccesorial" type="table" :types="{ 'table-tbody': 'table-row-divider@20' }">
        <v-data-table v-if="customerAccessorialFuelData" disable-sort hide-default-footer
          :headers="customerAccessorialsHeadersEnum"
          :items="customerAccessorialFuelData"
          fixed-header
          class="hg-table" id="cust-accessorial-grid" disable-pagination>
          <template v-slot:item="{ item, index }">
            <tr @click="activeRow(item); selectCustomerDetailsChanged(item);" :key="item._id"
              :class="{ 'active-row': item._id === activeRowId }">
              <!-- NAME COLUMN -->
              <td>
                <div v-if="item.status" class="status-bar" :class="{
                    activeStatus: item.status === 'ACTIVE',
                    expiredStatus: (item.status === 'EXPIRED' && item.action !== 'DELETE'),
                    deletedStatus: (item.status === 'EXPIRED' && item.action === 'DELETE'),
                    futureStatus: item.status === 'INACTIVE',
                  }">
                 {{
                    item.status === 'INACTIVE'
                      ? 'FUTURE'
                      : (item.status === 'EXPIRED' && item.action === 'DELETE') ? 'DELETE' : item.status
                  }}
                </div>
              </td>
              <!-- CUSTOMER COLUMN -->
              <td>
                <div v-if="item.customer && item.customer.id" class="customer-details"
                  :id="`cust-number-${item.customer.id}`">
                  {{ item.customer.id }}
                </div>
                <label v-if="item.customer && item.customer.name" class="customer-details bold-font"
                  :id="`cust-name-${item.customer.name}`">{{ item.customer.name }}</label>
              </td>
              <!-- MODE COLUMN -->
              <td>
                <label v-if="!loading" class="customer-details regular-font" :id="`cust-mode-${item.transportMode}`">{{
                  item.transportMode }}</label>
              </td>
              <!-- CHARGE CODE COLUMN -->
              <td>
                <label v-if="item.chargeCode && item.chargeCode.code" class="customer-details regular-font"
                  :id="`cust-charge-code-${item.chargeCode.code}`">{{ item.chargeCode.code }} / {{
                    item.chargeCode.description }}</label>
              </td>
              <!-- EQUIPMENT COLUMN -->
              <td>
                <label v-if="item.equipment && item.equipment.equipmentType"
                  class="customer-details regular-font" :id="`cust-charge-code-${item.equipment.equipmentType}${item.equipment.length.amount}`
                    ">{{ item.equipment.equipmentType }}{{ item.equipment.length.amount }}</label>
              </td>
              <!-- CUSTOMER TYPE COLUMN -->
              <td>
                <label v-if="!loading" class="customer-details regular-font" :id="`cust-type-${item.type}`">{{
                  item.type }}</label>
              </td>
              <!-- HUB DEFAULT COLUMN -->
              <td>
                <label v-if="!loading" class="hub-default-details regular-font" :id="`cust-type-${lodash.get(item, 'hubDefault.name')}`">{{
                  lodash.get(item, 'hubDefault.name')}}</label>
              </td>
              <!-- RATE VALUE COLUMN -->
              <td>
                <div v-if="!loading">
                  <span v-for="(rate, index) of item.rates" :key="rate.value" class="customer-details regular-font"
                    :id="`cust-rate-value-${rate.rateValue}`">
                    <label><span>{{ rate.rateValue }}</span><span v-if="index < item.rates.length - 1">, </span>
                    </label>
                  </span>
                </div>
              </td>
              <!-- RATE QUALIFIER COLUMN -->
              <td>
                <label v-if="!loading" class="customer-details regular-font"
                  :id="`cust-rate-qualifer-${item.rateQualifier}`">{{ item.rateQualifier }}</label>
              </td>
              <!-- LAST UPDATE COLUMN -->
              <td>
                <label v-if="!loading" class="customer-details regular-font"
                  :id="`cust-effective-date-${lodash.get(item, 'effectiveDateTime.dateTime')}`">{{ lodash.get(item,
                    'effectiveDateTime.dateTime') | formatDate }}</label>
              </td>
              <td>
                <label v-if="!loading" class="customer-details regular-font"
                  :id="`cust-expired-date-${lodash.get(item, 'expiredDateTime.dateTime')}`">{{ lodash.get(item,
                    'expiredDateTime.dateTime') | formatDate }}</label>
              </td>
              <!-- ACTION MENU COLUMN -->
              <td >
               <v-menu :attach="`#actions${index}`" :close-on-content-click="true" v-if="!loading">
                  <template v-slot:activator="{ on: onMenu }">
                    <v-tooltip bottom>
                      <template v-slot:activator="{ on: attrs }">
                        <v-btn
                          class="btn-actions"
                          text
                          dense
                          v-bind="attrs"
                          v-on="{ ...onMenu}"
                          icon
                        >
                          <v-icon :id="`actions${index}`" class="action-icon" dark>mdi-dots-horizontal</v-icon>
                        </v-btn>
                      </template>
                      <span class="tooltip">
                        Actions
                      </span>
                    </v-tooltip>
                  </template>
                  <v-list dense >
                    <v-list-item v-if="(!item.isUsingHubDefault && item.type === 'C') && (item.status !== 'EXPIRED')" v-oc-entitlements="[[accessorialsEntitlements.ACCS_CREATE,accessorialsEntitlements.ACCS_EDIT], token]"
           @click.stop="openCustAccessorialEditModal(item, 'EDIT')">
                      <v-list-item-title> Edit </v-list-item-title>
                    </v-list-item>
                    <v-list-item v-oc-entitlements="[[accessorialsEntitlements.ACCS_CREATE], token]"
           @click="openCustAccessorialEditModal(item, 'COPY')">
                      <v-list-item-title>Copy</v-list-item-title>
                    </v-list-item>
                      <v-list-item v-if="item.status !== 'EXPIRED'" v-oc-entitlements="[[accessorialsEntitlements.ACCS_DELETE], token]"
           @click="deleteCustAccessorialChargeCode(item)">
                      <v-list-item-title>Delete</v-list-item-title>
                    </v-list-item>
                    <v-list-item v-if="item.isUsingHubDefault && item.type === 'C' && item.status !== 'EXPIRED'" v-oc-entitlements="[[accessorialsEntitlements.ACCS_CREATE,accessorialsEntitlements.ACCS_EDIT], token]"
           @click="unassignCustAccessorialChargeCode(item._id)">
                    <v-list-item-title>Unassign</v-list-item-title>
                    </v-list-item>
                      <v-list-item
                        @click="viewHistoryCustAccessorialChargeCode(item)">
                        <v-list-item-title>View History</v-list-item-title>
                      </v-list-item>
                  </v-list>
                </v-menu>
              </td>
            </tr>
          </template>
        </v-data-table>
        </v-skeleton-loader>
      </div>
    </v-card>
    <div v-if="toggleSlideWindow">
      <v-scroll-x-reverse-transition>
        <div class="detailsWrapper d-flex flex-row">
          <customerAccessorialsFuelDetails @close="clearSelectCustomerDetails()"
            :selectedCustomerDetails="selectedCustomerDetails" transition="dialog-bottom-transition"/>
        </div>
      </v-scroll-x-reverse-transition>
    </div>
  </div>
</template>
<script src="./customer-accessorials-fuel.js"></script>
<style src="./customer-accessorials-fuel.sass" lang="sass" scoped></style>