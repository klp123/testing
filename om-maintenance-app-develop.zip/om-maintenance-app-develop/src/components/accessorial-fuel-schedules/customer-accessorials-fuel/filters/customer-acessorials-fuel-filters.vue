<template>
  <div class="filter-container" id="accessorial-fuel-schedules">
    <div class="d-flex justify-space-between">
      <div class="filter-components" id="accessorial-fuel-schedules-components">
        <!-- Customer -->
        <hg-lib-menu-search-bar
          id="accessorial-fuel-schedules-customer"
          :placeholder="customer.placeholder"
          :menuLabel="customer.menuLabel"
          :filterKey="customer.filterKey"
          :items="customer.items || []"
          :selectedItems="selectedFilters('customer')"
          :loading="loadingCustList"
          @searchTextChanged="onSearchTextChanged($event, 'customer')"
          @searchItemSelected="onFilterSelected($event)"
          @searchItemUnSelected="onFilterUnSelected($event)"
          @filterClosed="onFilterClosed('customer')"
        />
        <!-- Mode -->
        <hg-lib-menu-select-box
          id="accessorial-fuel-schedules-modes"
          :menuLabel="mode.menuLabel"
          :items="mode.modes || []"
          :selectedItems="selectedFilters('mode')"
          @onItemChecked="onFilterSelected($event)"
          @onItemUnchecked="onFilterUnSelected($event)"
        />
        <!-- Equipment Type -->
        <hg-lib-menu-select-box
          id="accessorial-fuel-schedules-equipments"
          :menuLabel="equipment.menuLabel"
          :items="equipment.equipment || []"
          :selectedItems="selectedFilters('equipment')"
          @onItemChecked="onFilterSelected($event)"
          @onItemUnchecked="onFilterUnSelected($event)"
        />

        <!-- Charge Codes -->
        <hg-lib-menu-search-bar
          id="accessorial-fuel-schedules-customer"
          :placeholder="chargeCodes.placeholder"
          :menuLabel="chargeCodes.menuLabel"
          :filterKey="chargeCodes.filterKey"
          :items="chargeCodes.items || []"
          :selectedItems="selectedFilters('chargeCodes')"
          :loading="loadingChargeCodesList"
          @searchTextChanged="onSearchTextChanged($event, 'chargeCodes')"
          @searchItemSelected="onFilterSelected($event)"
          @searchItemUnSelected="onFilterUnSelected($event)"
          @filterClosed="onFilterClosed('chargeCodes')"
        />

        <!-- Customer Type -->
        <hg-lib-menu-select-box
          id="accessorial-fuel-schedules-customer-types"
          :menuLabel="recordType.menuLabel"
          :items="recordType.recordTypes || []"
          :selectedItems="selectedFilters('recordType')"
          @onItemChecked="onFilterSelected($event)"
          @onItemUnchecked="onFilterUnSelected($event)"
        />

         <!-- Record Type -->
         <hg-lib-menu-select-box
          id="accessorial-fuel-schedules-record-types"
          :menuLabel="customerHubDefault.menuLabel"
          :items="customerHubDefault.customerHubDefaults || []"
          :selectedItems="selectedFilters('customerHubDefault')"
          @onItemChecked="onFilterSelected($event)"
          @onItemUnchecked="onFilterUnSelected($event)"
        />

        <!-- Rate Qualifiers -->
        <hg-lib-menu-select-box
          id="accessorial-fuel-schedules-rate-qualifiers"
          :menuLabel="rateQualifier.menuLabel"
          :items="rateQualifier.rateQualifiers || []"
          :selectedItems="selectedFilters('rateQualifier')"
          @onItemChecked="onFilterSelected($event)"
          @onItemUnchecked="onFilterUnSelected($event)"
        />

        <!-- Charge Code Status -->
        <hg-lib-menu-select-box
          id="accessorial-fuel-schedules-status"
          :menuLabel="status.menuLabel"
          :items="status.statuses || []"
          :selectedItems="selectedFilters('status')"
          @onItemChecked="onFilterSelected($event)"
          @onItemUnchecked="onFilterUnSelected($event)"
        />

        <!-- Expiry Date -->
        <div class="filter-content d-inline-flex">
          <v-menu
            ref="menu"
            attach
            class="expired-filter-menu"
            :value="shown"
            @input="shown = !shown"
            offset-y
            :close-on-content-click="false"
          >
            <template v-slot:activator="{ on, attrs }">
              <label dark v-bind="attrs" v-on="on" v-on:click="shown = !shown" class="label-filter">
                <label>Expired Date</label>
                <v-icon :color="getColor('color_text_gray')" v-if="!shown">
                  mdi-chevron-down
                </v-icon>
                <v-icon :color="getColor('color_text_gray')" v-if="shown"> mdi-chevron-up </v-icon>
              </label>
            </template>
               <DatetimePickerComponent
                    checkIfValidDate
                    ref="startDatetimePicker"
                    :dateTime="expiredDateTime"
                    :config="dateTimeRangeConfig"
                    @dateTimeChanged="onDateTimeChange($event, 'expiredDateTime')"
                  />
          </v-menu>
        </div>
      </div>

      <div class="action-menu d-flex justify-space-between">
        <hg-lib-btn-multi-action
          v-oc-entitlements="[[accessorialsEntitlements.ACCS_CREATE], token]"
          class="pl-3 btn-height-36"
          id="hg-create-actions"
          :disabled="false"
          :btnLabel="createDropDownButton"
          :actions="getButtonActions('create')"
          @actionClicked="multiActionClicked"
        />
        <hg-lib-btn-multi-action
          class="d-inline-flex pl-1"
          id="hg-actions"
          :disabled="false"
          :btnLabel="moreDropDownButton"
          :actions="getButtonActions('more')"
          @actionClicked="multiActionClicked"
        />
      </div>
    </div>

    <div class="current-filters">
      <hg-lib-filter-bread-crumb-display
        id="afs-filter-breadcrumbs"
        :groupBy="{}"
        :selectedFilters="selectedFilters()"
        @clearFilters="clearFilter($event)"
        @clearAllFilters="clearAllFilters()"
      />
    </div>
  </div>
</template>

<script src="./customer-acessorials-fuel-filters.js"></script>
<style src="./customer-acessorials-fuel-filters.sass" scoped lang="sass"></style>
