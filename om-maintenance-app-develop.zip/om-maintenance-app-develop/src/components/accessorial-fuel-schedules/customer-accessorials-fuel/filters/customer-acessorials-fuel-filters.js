import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import Vue from 'vue';
import { EntitlementsEnum, AppSetupEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import { GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import accessorialsEntitlements from '@hubgroup/hg-om-shared-services/src/enums/entitlements.enum';
import FilterNamesEnum from '@hubgroup/hg-vue-oc-util-lib/src/enums/filter-names.enum';
import DatetimePickerComponent from '../../../shared/datetime-picker/datetime-picker.vue';
import LocalFilterNamesEnum from '../../../../enums/filter-names.enum';
import customerService from '../../../../services/customer/customer.service';
import commonService from '../../../../services/common.service';
import filterService from '../../../../services/filters/filters.service';
import customerAcessorialsService from '../../../../services/accessorial-fuel-schedules/customer-acessorials.service';
import timeZoneService from '../../../../services/accessorial-fuel-schedules/time-zone.service';

const filterParams = filterService.getAccesorialFilterParams();
filterParams.entitlement = EntitlementsEnum;
filterParams.createDropDownButton = 'Create';
filterParams.moreDropDownButton = 'More';

function setGoogleAnalytics(details) {
  GoogleAnalyticsService.event(Vue, 'Metric', 'Maintenance', details);
}

function onDateTimeChange(value, key) {
  value ? this.onFilterSelected({
    key, value: timeZoneService.cstEndOf(value), single: true, label: 'Expired Date', text: value.substring(0, 10)
  }) : this.onFilterUnSelected({
    key, single: true
  });
  this.shown = false;
}
/**
 * Populate list of values for the filters
 */
async function loadFiltersList() {
  try {
    filterParams.customer.items = await customerService.searchCustomers('', 20);
    filterParams.chargeCodes.items = await customerAcessorialsService.getAccessorialChargeCodes('', 20);
    filterParams.mode.modes = commonService.getFilterList('mode', await commonService.getCommonLov(FilterNamesEnum.MODES));
    filterParams.recordType.recordTypes = commonService.getFilterList('recordType', await commonService.getCommonLov(LocalFilterNamesEnum.OM_ACCESSORIALS_CUSTOMER_TYPE));
    filterParams.customerHubDefault.customerHubDefaults = commonService.getFilterList('customerHubDefault', await commonService.getCommonLov(LocalFilterNamesEnum.OM_ACCESSORIALS_CUSTOMER_HUB_DEFAULT_TYPE));
    filterParams.rateQualifier.rateQualifiers = commonService.getFilterList('rateQualifier', await commonService.getCommonLov(LocalFilterNamesEnum.OM_ACCESSORIALS_RATE_QUALIFIER));
    filterParams.equipment.equipment = commonService.getFilterList('equipment', await commonService.getCommonLov(LocalFilterNamesEnum.ALL_OM_EQUIPMENTS));
    filterParams.status.statuses = commonService.getFilterList('status', await commonService.getCommonLov(LocalFilterNamesEnum.OM_CHARGE_CODE_STATUS));
  } catch (e) {
    console.error('Error when setting beforemount data', e);
  }
}

async function onSearchTextChanged(searchText = '', source) {
  try {
    if (!searchText || searchText.length >= AppSetupEnum.MINIMUM_SEARCH_CHARACTER) {
      switch (source) {
        case 'customer':
          this.loadingCustList = true;
          this.customer.items = await customerService.searchCustomers(searchText);
          this.loadingCustList = false;
          break;
        case 'chargeCodes':
          this.loadingChargeCodesList = true;
          this.chargeCodes.items = await customerAcessorialsService.getAccessorialChargeCodes(searchText, 20);
          this.loadingChargeCodesList = false;
          break;
        default:
          break;
      }
    }
  } catch (error) {
    console.error(`Error when fetching data on search Text for ${source}`, error);
    this.loadingCustList = false;
    this.loadingChargeCodesList = false;
  }
}

/**
 * reset results to default in the customer and charge codefilter when filter is closed
 * TODO: hg-vue-lib needs to updated for this component to make it work.
 */
function onFilterClosed(source) {
  this.onSearchTextChanged('', source);
}

/**
 * Update the selected filter to the store
 */
function onFilterSelected(filterSelected) {
  // clear quickSearch type if value is empty
  if (filterSelected.key === 'quickSearch' && filterSelected.value === '') {
    filterSelected.type = '';
  }
  this.$store.dispatch('customerAccessorialFuelStore/updateFilter', filterSelected);
  GoogleAnalyticsService.event(Vue, 'Accessorials-Filters', filterSelected.label, filterSelected.value);
  this.setLocalStorageFilter();
  this.uncheckSavedFilter();
}

/**
 *
 * @param {*} filterType type of filter
 * @returns filter values from the store
 */
function selectedFilters(filterType) {
  return filterType ? this.$store.getters['customerAccessorialFuelStore/getFilters'][filterType] : this.$store.getters['customerAccessorialFuelStore/getFilters'];
}

/**
 * Clear the specific filter closed from the filtering component and relaod customer accesorials
 */
function clearFilter(filter) {
  this.uncheckSavedFilter();
  this.onFilterUnSelected(filter);
}

/**
 * Clear all filters from the filtering by component and reload customer accesorials
 */
function clearAllFilters() {
  this.uncheckSavedFilter();
  this.onFilterUnSelected();
}

/**
 *
 * @param {*} filterUnSelected The filter unselected from lov / removed
 * from filtering by the filter is removed from the store
 */
function onFilterUnSelected(filterUnSelected) {
  if (filterUnSelected) {
    this.$store.dispatch('customerAccessorialFuelStore/removeFilter', filterUnSelected);
  } else {
    this.$store.dispatch('customerAccessorialFuelStore/removeFilter');
  }
  this.setLocalStorageFilter();
  this.uncheckSavedFilter();
}

function uncheckSavedFilter() {
  this.selectedSavedFilter = null;
}

function setLocalStorageFilter() {
  const currentAFSFilters = this.$store.getters['customerAccessorialFuelStore/getFilters'];
  this.$emit('filters', currentAFSFilters);
  localStorage.setItem('customerAccesorialsFuelFiters', JSON.stringify(currentAFSFilters));
}

async function selectLocalStorageFilter() {
  const localStorageFilters = localStorage.getItem('customerAccesorialsFuelFiters');
  const currentAccesorialFilters = localStorageFilters ? JSON.parse(localStorageFilters) : null;

  if (currentAccesorialFilters) {
    Object.values(currentAccesorialFilters).forEach((ftr) => {
      if (ftr && ftr.length) {
        ftr.forEach((element) => {
          if (element.value) {
            this.onFilterSelected(element);
          }
        });
      }
    });
  }
}

function getColor(name) {
  return _colors[name];
}

function getButtonActions(actionButton) {
  if (actionButton === 'more') {
    const actionValues = [{ title: 'DOE Regional Rates', action: 'DOE_REGIONAL_RATES' }];
    return actionValues;
  }
  if (actionButton === 'create') {
    const actionValues = [{ title: 'Assign Hub Default', action: 'HUB_DEFAULT_MODAL' }, { title: 'Custom Charge Code', action: 'CHARGE_CODES_MODAL' }];
    return actionValues;
  }
}
async function multiActionClicked(action) {
  this.$store.dispatch('customerAccessorialFuelStore/updateMultiSelectAction', action);
  GoogleAnalyticsService.event(Vue, 'Accessorials-Actions', action, 'click');
}

export default {
  name: 'customer-accessorials-fuel-filters',
  data() {
    filterParams.shown = false;
    filterParams.token = localStorage.getItem('jwt');
    filterParams.expiredDateTime = null;
    filterParams.dateTimeRangeConfig = {
      mode: 'date',
      maxDate: null,
      minDate: null,
      disabled: false,
      required: false
    };
    filterParams.accessorialsEntitlements = accessorialsEntitlements;
    return filterParams;
  },
  components: {
    DatetimePickerComponent
  },
  props: [],
  computed: {},
  methods: {
    loadFiltersList,
    onFilterSelected,
    clearFilter,
    clearAllFilters,
    selectedFilters,
    onFilterUnSelected,
    onSearchTextChanged,
    onFilterClosed,
    uncheckSavedFilter,
    setLocalStorageFilter,
    selectLocalStorageFilter,
    onDateTimeChange,
    getColor,
    getButtonActions,
    multiActionClicked,
    setGoogleAnalytics,
  },
  created() {
    this.loadFiltersList();
    this.selectLocalStorageFilter();
    this.setGoogleAnalytics();
  },
};
