<template>
  <div class="charge-code-container">
    <v-dialog v-model="showDialog" width="60%" style="overflow:visible;" persistent>
      <v-overlay v-if="loading">
        <v-progress-circular indeterminate :size="70" :color="getColor('color_white')"></v-progress-circular>
      </v-overlay>
      <v-card elevation="2" class="wrapper">
        <div class="d-flex justify-space-between w-100 modal-header-container">
          <div class="modal-header">
            CHARGE CODE HISTORY
          </div>
          <div>
            <v-btn @click="closeDialog()" icon>
              <v-icon id="modal-close">mdi-close</v-icon>
            </v-btn>
          </div>
        </div>
        <hr class="hrMargin" />
        <div>
          <v-row>
            <v-col cols="2">
              <div class="d-flex flex-column">
                <!-- CUSTOMER NAME -->
                <div class="details">CUSTOMER NAME</div>
                <div class="sub-header">
                  {{ _.get(selectedCustomerAccessorial, 'customer.name', '') }}
                </div>
              </div>
            </v-col>
            <v-col cols="2">
              <div class="d-flex flex-column">
                <!-- CHARGE CODE -->
                <div class="details">CHARGE CODE</div>
                <div class="sub-header">
                  {{ _.get(selectedCustomerAccessorial, 'chargeCode.code', '') }}
                </div>
              </div>
            </v-col>
            <v-col cols="2">
              <div class="d-flex flex-column">
                <!-- MODE -->
                <div class="details">MODE</div>
                <div class="sub-header">
                  {{ _.get(selectedCustomerAccessorial, 'transportMode', '') }}
                </div>
              </div>
            </v-col>
            <v-col cols="2">
              <div class="d-flex flex-column">
                <!-- EQUIPMENT -->
                <div class="details">EQUIPMENT</div>
                <div v-if="_.get(selectedCustomerAccessorial, 'equipment.equipmentType')" class="sub-header">
                  {{ _.get(selectedCustomerAccessorial, 'equipment.equipmentType', '') +
                    _.get(selectedCustomerAccessorial, 'equipment.length.amount', '') }}
                </div>
                <div v-else>
                </div>
              </div>
            </v-col>
            <v-col v-if="is405FuelSurcharge" cols="2">
              <div class="d-flex flex-column">
                <!-- COUNTRY -->
                <div class="details">COUNTRY</div>
                <div class="sub-header">
                  {{ _.get(selectedCustomerAccessorial, 'country', '') }}
                </div>
              </div>
            </v-col>
            <v-col cols="2">
              <div class="d-flex flex-column">
                <!-- HUB DEFAULT NAME -->
                <div class="details">HUB DEFAULT NAME</div>
                <div class="sub-header">
                  {{ _.get(selectedCustomerAccessorial, 'hubDefault.name', '') }}
                </div>
              </div>
            </v-col>
          </v-row>
          <v-row v-if="!is405FuelSurcharge">
            <v-col cols="2">
              <div class="d-flex flex-column">
                <!-- SERVICE TYPE -->
                <div class="details">SERVICE TYPE</div>
                <div class="sub-header">
                  {{ _.get(selectedCustomerAccessorial, 'serviceType', '') }}
                </div>
              </div>
            </v-col>
            <v-col cols="2">
              <div>
                <!-- RAMP SCAC -->
                <div class="details">RAMP SCAC</div>
                <div class="sub-header">
                  {{ _.get(selectedCustomerAccessorial, 'rampScc', '') }}
                </div>
              </div>
            </v-col>
            <v-col cols="2">
              <div class="d-flex flex-column">
                <!-- RAIL SCAC -->
                <div class="details">RAIL SCAC</div>
                <div class="sub-header">
                  {{ _.get(selectedCustomerAccessorial, 'railScac', '') }}
                </div>
              </div>
            </v-col>
            <v-col cols="2">
              <div class="d-flex flex-column">
                <!-- BUNDLE CODE -->
                <div class="details">BUNDLE CODE</div>
                <div v-if="_.get(selectedCustomerAccessorial, 'bundleCode.code', '')" class="sub-header">
                  {{ _.get(selectedCustomerAccessorial, 'bundleCode.code', '') + ', ' +
                    _.get(selectedCustomerAccessorial, 'bundleCode.description', '') }}
                </div>
              </div>
            </v-col>
            <v-col cols="2">
              <div class="d-flex flex-column">
                <!-- VENDOR -->
                <div class="details">VENDOR/CARRIER</div>
                <div class="sub-header">
                  {{ _.get(selectedCustomerAccessorial, 'vendor.name', '') }}
                </div>
              </div>
            </v-col>
          </v-row>
          <v-row v-if="!is405FuelSurcharge">
            <!-- LOCATION -->
            <v-col cols="12">
              <div class="details">LOCATION(S)</div>
              <div>
                <v-data-table disable-sort dense hide-default-footer :headers="accessorialsLocationHeader"
                  :items="selectedCustomerAccessorial.locations" id="cust-accessorial-location-grid" width="70%">
                  <template v-slot:item="{ item }">
                    <tr :key="item.LocationID">
                      <td>
                        <label>{{
                          _.get(item, 'StopType', '') === 'Destination'
                          ? 'DES'
                          : _.get(item, 'StopType', '') === 'Origin'
                            ? 'ORG'
                            : ''
                        }}</label>
                      </td>
                      <td>
                        <label>{{ _.get(item, 'Address1', '') }}</label>
                      </td>
                      <td>
                        <label>{{ _.get(item, 'City', '') }}</label>
                      </td>
                      <td>
                        <label>{{ _.get(item, 'State', '') }}</label>
                      </td>
                      <td>
                        <label>{{ _.get(item, 'PostalCode', '') }}</label>
                      </td>
                      <td>
                        <label>{{ _.get(item, 'CountryCode', '') }}</label>
                      </td>
                    </tr>
                  </template>
                </v-data-table>
              </div>
            </v-col>
          </v-row>
        </div>
        <hr class="hrMargin" />
        <div>
          <div class="details">HISTORY</div>
          <div>
            <v-data-table class="noOverflow-x" disableSort dense fixed-header :headers="chargeCodeHistoryHeader.mainGrid"
              :items="chargeCodeHistory" item-key="modifiedDateTime" id="cust-accessorial-history-grid" width="100%"
              :expanded="expanded" show-expand @click:row="clickRow" hide-default-footer>
              <template v-slot:item.effectiveDateTime.dateTime="{ item }">
                <!-- EFFECTIVE DATE -->
                <td class="pa-2">
                  {{ item.effectiveDateTime.dateTime | formatDateTime }}
                </td>
              </template>
              <template v-slot:item.expiredDateTime.dateTime="{ item }">
                <!-- EXPIRED DATE -->
                <td>
                  {{ item.expiredDateTime.dateTime | formatDateTime }}
                </td>
              </template>
              <template v-slot:item.modifiedDateTime="{ item }">
                <!-- MODIFIED DATE -->
                <td>
                  {{ item.modifiedDateTime | formatDateTime }}
                </td>
              </template>
              <template v-slot:item.modifiedBy="{ item }">
                <!-- MODIFIED BY -->
                <td>
                  {{ item.modifiedBy }}
                </td>
              </template>
              <template v-slot:expanded-item="{ item }">
                <td :colspan="chargeCodeHistoryHeader.mainGrid.length + 1">
                  <v-row class="historyDetails-padding">
                    <v-col v-if="!is405FuelSurcharge" cols="3">
                      <!-- Minimum Rate -->
                      <div class="d-flex flex-column">
                        <div class="details">
                          MINIMUM RATE
                        </div>
                        <div class="sub-header">
                          {{ _.get(item, 'minimumRate', '') }}
                        </div>
                      </div>
                      <!-- Start Event -->
                      <div class="d-flex flex-column">
                        <div class="details">
                          START EVENT
                        </div>
                        <div class="sub-header">
                          {{ _.get(item, 'startEvent', '') }}
                        </div>
                      </div>
                      <!-- Free Time Cut Off -->
                      <div class="d-flex flex-column">
                        <div class="details">
                          FREE TIME CUT OFF
                        </div>
                        <div class="sub-header">
                          {{ _.get(item, 'freeTimeCutOffTime', '') }}
                        </div>
                      </div>
                      <!-- Holidays Free -->
                      <div class="d-flex flex-column">
                        <div class="details">
                          HOLIDAYS FREE
                        </div>
                        <div class="sub-header">
                          {{ _.get(item, 'freeHolidays', '') ? 'Y' : 'N' }}
                        </div>
                      </div>
                    </v-col>
                    <v-col v-if="!is405FuelSurcharge" cols="3">
                      <!-- Maximum Rate -->
                      <div class="d-flex flex-column">
                        <div class="details">
                          MAXIMUM RATE
                        </div>
                        <div class="sub-header">
                          {{ _.get(item, 'maximumRate', '') }}
                        </div>
                      </div>
                      <!-- End Event -->
                      <div class="d-flex flex-column">
                        <div class="details">
                          END EVENT
                        </div>
                        <div class="sub-header">
                          {{ _.get(item, 'endEvent', '') }}
                        </div>
                      </div>
                      <!-- Free Days -->
                      <div class="d-flex flex-column">
                        <div class="details">
                          FREE DAYS
                        </div>
                        <div class="sub-header">
                          {{ _.get(item, 'freeDays', '') }}
                        </div>
                      </div>
                      <!-- Free Time Type -->
                      <div class="d-flex flex-column">
                        <div class="details">
                          FREE TIME TYPE
                        </div>
                        <div class="sub-header">
                          {{ _.get(item, 'FreeTimeType', '') }}
                        </div>
                      </div>
                    </v-col>
                    <v-col v-if="!is405FuelSurcharge" cols="3">
                      <!-- Reloads -->
                      <div class="d-flex flex-column">
                        <div class="details">
                          RELOADS
                        </div>
                        <div class="sub-header">
                          {{ _.get(item, 'reloads', '') }}
                        </div>
                      </div>
                      <!-- Layover Type -->
                      <div class="d-flex flex-column">
                        <div class="details">
                          LAYOVER TYPE
                        </div>
                        <div class="sub-header">
                          {{ _.get(item, 'layoverType', '') }}
                        </div>
                      </div>
                      <!-- Special Terms -->
                      <div class="d-flex flex-column">
                        <div class="details">
                          SPECIAL TERMS
                        </div>
                        <div class="sub-header">
                          {{ _.get(item, 'specialTerms', '') }}
                        </div>
                      </div>
                      <!-- Free Weekend Type-->
                      <div class="d-flex flex-column">
                        <div class="details">
                          FREE WEEKEND TYPE
                        </div>
                        <div class="sub-header">
                          {{ _.get(item, 'freeWeekendType', '') }}
                        </div>
                      </div>
                    </v-col>
                    <v-col v-if="!is405FuelSurcharge" cols="3">
                      <!-- Rate Qualifier-->
                      <div class="d-flex flex-column">
                        <div class="details">
                          RATE QUALIFIER
                        </div>
                        <div class="sub-header">
                          {{ _.get(item, 'rateQualifier', '') }}
                        </div>
                      </div>
                      <v-data-table class="rateTable" dense disableSort :headers="chargeCodeHistoryHeader.rateTable"
                        :items="item.rates" item-key="rateValue" id="cust-accessorial-history-rate-table"
                        hide-default-footer>
                      </v-data-table>
                    </v-col>
                    <v-col v-if="is405FuelSurcharge" cols="3">
                      <!-- Rate Qualifier-->
                      <div class="d-flex flex-column">
                        <div class="details">
                          RATE QUALIFIER
                        </div>
                        <div class="sub-header">
                          {{ _.get(item, 'rateQualifier', '') }}
                        </div>
                      </div>
                    </v-col>
                    <v-col v-if="is405FuelSurcharge" cols="3">
                      <!-- Rate Amount-->
                      <div class="d-flex flex-column">
                        <div class="details">
                          RATE AMOUNT
                        </div>
                        <div class="sub-header">
                          {{ _.get(item, 'rates[0].rateValue', '') }}
                        </div>
                      </div>
                    </v-col>
                  </v-row>
                  <v-row class="notes">
                    <v-col cols="12">
                      <!-- Notes -->
                      <div class="d-flex flex-column notes">
                        <div class="details">
                          NOTES
                        </div>
                        <div class="sub-header">
                          {{ _.get(item, 'notes', '') }}
                        </div>
                      </div>
                    </v-col>
                  </v-row>
                </td>
              </template>
            </v-data-table>
          </div>
        </div>
      </v-card>
    </v-dialog>
  </div>
</template>

<script src="./charge-code-history-modal.js"></script>
<style src="./charge-code-history-modal.sass" scoped lang="sass"></style>