import _ from 'lodash';
import moment from 'moment';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import customerAccessorialsRateDetailsHeader from '../../../enums/customer-details-rate-grid-headers.enum';
import chargeCodeHistoryHeadersEnum from '../../../enums/charge-code-history-headers.enum';
import chargeCodesService from '../../../services/accessorial-fuel-schedules/charge-codes.service';
import timeZoneService from '../../../services/accessorial-fuel-schedules/time-zone.service';

moment.tz.setDefault("America/Chicago");

function getColor(name) {
  return _colors[name];
}

async function getChargeCodeHistory(chargeCodeId) {
  try {
    this.loading = true;
    this.chargeCodeHistory = await chargeCodesService.getChargeCodeHistory(chargeCodeId);
    this.loading = false;
  } catch (error) {
    console.error(`Error retrieving Charge Code History due to: ${error}`);
  }
}

function closeDialog() {
  this.$emit('closeDialog', {});
}

function clickRow(item, event) {
  if (event.isExpanded) {
    const index = this.expanded.findIndex((i) => i === item);
    this.expanded.splice(index, 1);
  } else {
    this.expanded.push(item);
  }
}

export default {
  name: 'charge-code-history',
  data: () => ({
    _,
    moment,
    showDialog: true,
    loading: false,
    expanded: [],
    accessorialsLocationHeader: customerAccessorialsRateDetailsHeader.LOCATION_HEADER,
    chargeCodeHistoryHeader: chargeCodeHistoryHeadersEnum,
    chargeCodeHistory: [],
    is405FuelSurcharge: false
  }),
  props: {
    selectedCustomerAccessorial: {
      type: Object,
      required: true
    }
  },
  mounted() {
    this.getChargeCodeHistory(this.selectedCustomerAccessorial._id);
    this.is405FuelSurcharge = _.get(this.selectedCustomerAccessorial, 'chargeCode.code') === '405';
  },
  methods: {
    getColor,
    getChargeCodeHistory,
    closeDialog,
    clickRow
  },
  filters: {
    formatDate(value) {
      if (!value || !value.trim()) return '-';
      return timeZoneService.cstDateTime(value, null, 'MM/DD/YYYY');
    },
    formatDateTime(value) {
      if (!value || !value.trim()) return '-';
      return timeZoneService.cstDateTime(value, null, 'MM/DD/YYYY HH:mm');
    }
  }
};