import moment from 'moment';
import Vue from 'vue';
import _ from 'lodash';
import filterNamesEnum from '@hubgroup/hg-vue-oc-util-lib/src/enums/filter-names.enum';
import commonUtilityService from '@hubgroup/hg-vue-oc-util-lib/src/utils/common-utility.service';
import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import { GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import { EntitlementsEnum, AppSetupEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import DatetimePickerComponent from '../../../shared/datetime-picker/datetime-picker.vue';
import customerService from '../../../../services/customer/customer.service';
import commonService from '../../../../services/common.service';
import filterService from '../../../../services/filters/filters.service';
import { countryList } from '../../../../enums/countries.enum';
import timeZoneService from '../../../../services/accessorial-fuel-schedules/time-zone.service';

const filterParams = filterService.getAccesorialUploadDialogFilterParams();
filterParams.entitlement = EntitlementsEnum;
filterParams.countries = countryList;
filterParams.createDropDownButton = 'More';

function onKeyDown() {
  clearTimeout(this.timeout);
  this.timeout = setTimeout(() => {
    this.customerSearchTextChanged(this.search);
  }, 1000);
}

function selectedCustomer(selectedObject) {
  if (!selectedObject) {
    this.onFilterUnSelected({ key: 'customer', single: true });
  } else {
    this.onFilterSelected('customer', selectedObject);
  }
}

function onDateTimeChange(value, key) {
  this.publishDateTime = value ? moment(value).format('MM/DD/YY') : null;
  if (value) {
    this.onFilterSelected(key, timeZoneService.cstStartOf(moment(value).format('YYYY-MM-DD')));
  } else {
    this.onFilterUnSelected({ key, single: true });
  }
  this.shown = false;
}
/**
 * Populate list of values for the filters
 */
async function loadFiltersList() {
  try {
    filterParams.mode.modes = await commonService.getCommonLov(filterNamesEnum.MODES);
    filterParams.equipmentType.equipmentTypes = [];
  } catch (e) {
    console.error('Error when setting beforemount data', e);
  }
}

async function customerSearchTextChanged(searchText) {
  if (!searchText || searchText.length >= AppSetupEnum.MINIMUM_SEARCH_CHARACTER) {
    this.loadingCustList = true;
    try {
      filterParams.customer.items = await customerService.searchCustomers(searchText);
      this.loadingCustList = false;
    } catch (e) {
      this.loadingCustList = false;
    }
  }
}

/**
 * reset results to default in the customer filter when filter is closed
 * TODO: hg-vue-lib needs to updated for this component to make it work.
 */
function customerFilterClosed() {
  this.customerSearchTextChanged('');
}

async function onModeSelected(mode) {
  this.selectedEquipmentTypes = [];
  this.onFilterUnSelected({
    key: 'equipmentType',
    single: true
  });
  this.onFilterSelected('transportMode', mode);
  if (mode !== 'TL') {
    filterParams.equipmentType.equipmentTypes = await commonUtilityService.getEquipmentTypes(mode);
  } else {
    Promise.all(['PWR', 'FLT', 'REF', 'VAN'].map(async (subMode) => {
      const response = await commonUtilityService.getEquipmentTypes(mode, subMode);
      return response;
    })).then((results) => {
      filterParams.equipmentType.equipmentTypes = _.sortBy(_.uniqBy(results.flat(), 'displayValue'), 'displayValue');
    });
  }
}
/**
 * Update the selected filter to the store
 */
function onFilterSelected(filterKey, value, isSingle = true) {
  if (!isSingle && Array.isArray(value)) {
    const filterOjbect = {
      key: filterKey,
      single: true
    };
    this.onFilterUnSelected(filterOjbect);
  }

  value = Array.isArray(value) ? value : [value];
  value.forEach((val) => {
    const filterOjbect = {
      key: filterKey,
      value: val,
      single: isSingle
    };
    if (!val) {
      this.onFilterUnSelected(filterOjbect);
    } else {
      GoogleAnalyticsService.event(Vue, 'Accessorials-Bulk-Upload-Filters', filterKey, value.text || value);
      this.$store.dispatch('customerAccessorialsUploadDialogFiltersStore/updateFilter', filterOjbect);
    }
  });

  this.updateStorageFilter();
}

/**
 *
 * @param {*} filterType type of filter
 * @returns filter values from the store
 */
function selectedFilters(filterType) {
  return filterType ? this.$store.getters['customerAccessorialsUploadDialogFiltersStore/getFilters'][filterType] : this.$store
    .getters['customerAccessorialsUploadDialogFiltersStore/getFilters'];
}

/**
 * Clear all filters from the filtering by component and reload customer accesorials
 */
function clearAllFilters() {
  this.onFilterUnSelected();
}

/**
 *
 * @param {*} filterUnSelected The filter unselected from lov / removed
 * from filtering by the filter is removed from the store
 */
function onFilterUnSelected(filterUnSelected) {
  if (filterUnSelected) {
    this.$store.dispatch('customerAccessorialsUploadDialogFiltersStore/removeFilter', filterUnSelected);
  } else {
    this.$store.dispatch('customerAccessorialsUploadDialogFiltersStore/removeFilter');
  }
  this.updateStorageFilter();
}

function updateStorageFilter() {
  const currentAFSFilters = this.$store.getters['customerAccessorialsUploadDialogFiltersStore/getFilters'];
  this.$emit('filters', currentAFSFilters);
}

function getColor(name) {
  return _colors[name];
}

function resetComponent() {
  Object.assign(this.$data, this.initialState());
  this.$refs.selectedMode.reset();
  this.$refs.selectedEquipmentType.reset();
  this.$refs.selectedCountry.reset();
  this.$refs.startDatetimePicker.clearDatetime();
}

function initialState() {
  this.onFilterUnSelected();
  filterParams.dateTimeRangeConfig = {
    start: {
      mode: 'date',
      maxDate: null,
      minDate: null,
      disabled: false,
      required: false
    }
  };
  filterParams.search = null;
  filterParams.shown = false;
  filterParams.token = localStorage.getItem('jwt');
  filterParams.publishDateTime = null;
  filterParams.customer.items = [];
  filterParams.selectedCustomerItem = null;
  filterParams.selectedEquipmentTypes = [];
  return filterParams;
}

function selectAllEquipmentTypes() {
  if (this.selectedFilters('equipmentType').length === this.equipmentType.equipmentTypes.length) {
    this.onFilterUnSelected({ key: 'equipmentType', single: true });
    this.selectedEquipmentTypes = [];
  } else {
    this.selectedEquipmentTypes = this.equipmentType.equipmentTypes;
    this.equipmentType.equipmentTypes.forEach((element) => {
      this.onFilterSelected('equipmentType', element, false);
    });
  }
}

export default {
  name: 'upload-dialog-filters',
  data() {
    return this.initialState();
  },
  components: {
    DatetimePickerComponent
  },
  props: {
    customerData: {
      type: Object
    }
  },
  computed: {},
  methods: {
    onDateTimeChange,
    loadFiltersList,
    onFilterSelected,
    clearAllFilters,
    selectedFilters,
    onFilterUnSelected,
    customerSearchTextChanged,
    customerFilterClosed,
    updateStorageFilter,
    getColor,
    onKeyDown,
    selectedCustomer,
    initialState,
    resetComponent,
    selectAllEquipmentTypes,
    onModeSelected,
  },
  created() {
    if (this.customerData) {
      const customer = customerService.mapToFilterObj(this.customerData);
      filterParams.selectedCustomerItem = customer;
      filterParams.customer.items = [customer];
      this.selectedCustomer(customer);
      this.$nextTick(() => {
        if (this.customerData.location.country) {
          this.$refs.selectedCountry.selectedItems = [this.customerData.location.country];
        }
      });
      this.onFilterSelected('country', this.customerData.location.country);
    }
    this.loadFiltersList();
  },
  watch: {
    search(val) {
      if (!val) {
        return;
      }
      this.search = val;
      this.isLoading = true;
    },
  },
};
