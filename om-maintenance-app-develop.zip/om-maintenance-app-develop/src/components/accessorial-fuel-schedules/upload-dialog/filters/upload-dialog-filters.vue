<template>
  <div class="filter-container" id="accessorial-fuel-schedules">
    <div class="filter-components d-flex" id="accessorial-fuel-schedules-components">
      <div class="customer-filter filter-content">
        <label class="label-filter">Customer </label>
        <v-autocomplete
          v-model="selectedCustomerItem"
          item-value="id"
          clearable
          background-color="white"
          :search-input.sync="search"
          @keydown="onKeyDown"
          @change="(event) => selectedCustomer(event)"
          :items="customer.items || []"
          :placeholder="customer.placeholder"
          outlined
          hide-details="auto"
          return-object
          :loading="loadingCustList"
        ></v-autocomplete>
      </div>
      <div class="mode-filter filter-content">
        <label class="label-filter">Mode </label>
        <v-select
          ref="selectedMode"
          :menu-props="{ bottom: true, offsetY: true }"
          :clearable="true"
          :items="mode.modes || []"
          :item-text="'displayValue'"
          placeholder="Select Mode"
          outlined
          @input="onModeSelected($event)"
        ></v-select>
      </div>
      <div class="equipment-filter filter-content">
        <label class="label-filter">Equipment Type </label>
        <v-autocomplete
          ref="selectedEquipmentType"
          item-value="id"
          clearable
          background-color="white"
          @change="(event) => onFilterSelected('equipmentType', event, false)"
          :items="equipmentType.equipmentTypes || []"
          :item-text="'displayValue'"
          placeholder="Select Equipment Type"
          outlined
          hide-details="auto"
          return-object
          multiple
          v-model="selectedEquipmentTypes"
          chips
          deletable-chips
        >
          <template v-slot:prepend-item>
            <v-list-item ripple @click="selectAllEquipmentTypes">
              <v-list-item-action>
                <v-checkbox
                  :value="
                    selectedEquipmentTypes.length === equipmentType.equipmentTypes.length
                  "
                ></v-checkbox>
              </v-list-item-action>
              <v-list-item-content>
                <v-list-item-title>Select All</v-list-item-title>
              </v-list-item-content>
            </v-list-item>
          </template>
        </v-autocomplete>
      </div>
      <div class="country-filter filter-content">
        <label class="label-filter">Country </label>
        <v-select
          ref="selectedCountry"
          :menu-props="{ bottom: true, offsetY: true }"
          :clearable="true"
          :items="countries || []"
          placeholder="Select Country"
          outlined
          @input="onFilterSelected('country', $event)"
        ></v-select>
      </div>
      <div class="publish-date-time-filter filter-content" style="margin-right: 0px !important">
        <label class="label-filter">Published Date </label>
          <DatetimePickerComponent
            ref="startDatetimePicker"
            :config="dateTimeRangeConfig.start"
            :dateTime="publishDateTime"
            checkIfValidDate
            @dateTimeChanged="onDateTimeChange($event, 'publishDateTime')"
          />
      </div>
    </div>
  </div>
</template>

<script src="./upload-dialog-filters.js"></script>
<style src="./upload-dialog-filters.sass" scoped lang="sass"></style>
