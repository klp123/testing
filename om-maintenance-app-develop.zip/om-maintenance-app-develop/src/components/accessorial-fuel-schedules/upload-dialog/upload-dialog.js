import _colors from '@hubgroup/hg-vue-library/src/assets/styles/core/_colors';
import moment from 'moment';
import Vue from 'vue';
import _ from 'lodash';
import * as XLSX from 'xlsx';
import CdnImagesEnum from '@hubgroup/hg-vue-oc-util-lib/src/enums/cdn-images.enum';
import { ImageLoaderService, GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import massUploadService from '../../../services/accessorial-fuel-schedules/mass-upload.service';
import uploadDialogFilters from './filters/upload-dialog-filters.vue';
import uploadDialogFiltersService from '../../../services/accessorial-fuel-schedules/upload-dialog-filters.service';
import HgConfirmActionModal from '../../shared/hg-confirm-modal/hg-confirm-modal.vue';
import timeZoneService from '../../../services/accessorial-fuel-schedules/time-zone.service';

function getIcon(iconName) {
  return ImageLoaderService.getCdnImageUrl(iconName);
}

function getColor(name) {
  return _colors[name];
}

function closeDialog() {
  GoogleAnalyticsService.event(Vue, 'Accessorials-Bulk-Upload', 'cancel', 'click');
  this.showDialog = false;
  this.file = '';
  this.$emit('closeDialog');
}

function removeFile() {
  GoogleAnalyticsService.event(Vue, 'Accessorials-Bulk-Upload', 'ReUpload', 'Re-Upload');
  this.file = '';
}

function submit() {
  if (!this.file) {
    console.log('There are no files to upload');
  } else {
    this.$emit('filesUploaded"', this.file);
    this.closeDialog();
  }
}

async function downloadTemplate() {
  await massUploadService.downloadTemplate();
  GoogleAnalyticsService.event(Vue, 'Accessorials-Bulk-Upload', 'downloadTemplate', this.file.name);
}

function onChange(e) {
  const files = e.target.files || e.dataTransfer.files;

  if (!files.length) {
    this.dragging = false;
    return;
  }

  this.createFile(files[0]);
}

function createFile(file) {
  if (file.size > 1000000) {
    this.dragging = false;
    return;
  }

  this.file = file;
  console.log(this.file);
  this.dragging = false;
  GoogleAnalyticsService.event(Vue, 'Accessorials-Bulk-Upload', 'selectFile', this.file.name);
  const reader = new FileReader();
  reader.onload = async (e) => {
    try {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, {
        type: 'array'
      });
      const sheetName = workbook.SheetNames[0];
      this.excelRowObjects = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName], {
        raw: false
      });
      if (this.excelRowObjects.length === 0) {
        HgNotificationService.errorMessage('No records found in the excel.');
      }
    } catch (error) {
      throw new Error(error, 'Failed while uploading file');
    }
  };

  reader.readAsArrayBuffer(file);
}

function validateFileData(excelRows) {
  const filters = this.$store.getters['customerAccessorialsUploadDialogFiltersStore/getFilters'];
  let flag = true;
  let previousMaxDoeRate = 0;
  excelRows.forEach((row) => {
    if (flag && row.customerId !== _.get(filters, 'customer[0].value.value')) {
      HgNotificationService.errorMessage(`customerid mismatch in selected file (${row.customerId}) and filter (${_.get(filters, 'customer[0].value.value', '')}).`);
      flag = false;
      return false;
    }

    row.minDoeRate = parseFloat(Number.parseFloat(row.minDoeRate).toFixed(4));
    row.maxDoeRate = parseFloat(Number.parseFloat(row.maxDoeRate).toFixed(4));
    row.rateValue = parseFloat(Number.parseFloat(row.rateValue).toFixed(4));

    if (flag && (previousMaxDoeRate > row.minDoeRate)) {
      HgNotificationService.errorMessage('Min and Max DOE values in the template are either overlapping or not accurate . Please check and re-upload');
      flag = false;
      return false;
    }

    previousMaxDoeRate = row.maxDoeRate;
  });
  return flag;
}

async function uploadData() {
  const filters = this.$store.getters['customerAccessorialsUploadDialogFiltersStore/getFilters'];
  GoogleAnalyticsService.event(Vue, 'Accessorials-Bulk-Upload', 'File-Uploaded', this.file.name);

  if (this.validateFileData(this.excelRowObjects)) {
    this.uploadFuelsData = {
      customer: {
        id: _.get(filters, 'customer[0].value.value'),
        name: _.get(filters, 'customer[0].value.name')
      },
      type: _.get(filters, 'customer[0].value.value') ? 'C' : 'H',
      transportMode: _.get(filters, 'transportMode[0].value'),
      equipment: filters.equipmentType.map((equipmentType) => ({
        equipmentCode: _.get(equipmentType, 'value.value.code'),
        equipmentType: _.get(equipmentType, 'value.value.type'),
        length: {
          amount: _.get(equipmentType, 'value.value.length'),
        },
      })),
      country: filters.country[0].value,
      fileName: this.file.name,
      publishDateTime: {
        dateTime: timeZoneService.cstDateTime(_.get(filters, 'publishDateTime[0].value'))
      },
      fuelScales: this.excelRowObjects,
    };

    // Send fuel scale payload - user confirmation false
    let response = await massUploadService.addFuelScales(this.uploadFuelsData, 'FALSE');

    GoogleAnalyticsService.event(Vue, 'Upload fuel scale', 'Fuel-Scalees', 'Fuel Scale uploaded', {
      accessorials_fuel_customer: _.get(this.uploadFuelsData, 'customer.name', ''),
      accessorials_fuel_mode: _.get(this.uploadFuelsData, 'transportMode', ''),
      accessorials_fuel_country: _.get(this.uploadFuelsData, 'country', ''),
      accessorials_fuel_equipment: this.uploadFuelsData.equipment
        ? _.get(this.uploadFuelsData, 'equipment.equipmentType', '') + _.get(this.uploadFuelsData, 'equipment.length.amount', '') : '',
    });

    // If active record/s found, open confirm modal
    if (response.existingRecords && response.existingRecords.length) {
      const userConfirmed = await this.$refs.confirm.open('', `${response.message}. Do you want to replace?`);
      // If user confirmed, send payload with user confirmation true
      if (userConfirmed) {
        response = await massUploadService.addFuelScales(this.uploadFuelsData, 'TRUE');
        GoogleAnalyticsService.event(Vue, 'Upload fuel scale overwrite', 'Fuel-Scalees', 'User confirmed fuel scale overwrite', {
          accessorials_fuel_customer: _.get(this.uploadFuelsData, 'customer.name', ''),
          accessorials_fuel_mode: _.get(this.uploadFuelsData, 'transportMode', ''),
          accessorials_fuel_country: _.get(this.uploadFuelsData, 'country', ''),
          accessorials_fuel_equipment: this.uploadFuelsData.equipment
            ? _.get(this.uploadFuelsData, 'equipment.equipmentType', '') + _.get(this.uploadFuelsData, 'equipment.length.amount', '') : '',
        });
      }
    }
    // If successfully inserted / replaced fuel scale, notify success
    if (response.message && response.message.includes('Successfully published fuel scale/s')) {
      HgNotificationService.successMessage(response.message);
    }

    // Reset modal (file)
    this.file = '';
    const currentAFSFilters = this.$store.getters['customerAccessorialsUploadDialogFiltersStore/getFilters'];
    this.getPublishedFilesByFilter(currentAFSFilters);
  }
}

function getAllSelectedFilters() {
  const currentAFSFilters = this.$store.getters['customerAccessorialsUploadDialogFiltersStore/getFilters'];
  return currentAFSFilters;
}

async function getPublishedFilesByFilter() {
  GoogleAnalyticsService.event(Vue, 'Accessorials-Bulk-Upload', 'showHistory', 'showHistory');
  if (this.showHistory) {
    const filters = this.getAllSelectedFilters();
    await this.getPublishedFilesData(filters);
  }
}

async function getPublishedFilesData(filters) {
  try {
    this.loadingPublishedFiles = true;
    const resp = await uploadDialogFiltersService.publishedFiles(filters);
    this.publishedFilesData = resp.data;
  } catch (err) {
    if (err.message && err.message !== RequestErrorTypesEnum.CANCEL_REQUEST) {
      HgNotificationService.errorMessage('Error while fetching published files');
    }
  }
  this.loadingPublishedFiles = false;
}

function openFileHandler() {
  this.$refs.uploader.click();
}

function initialState() {
  return {
    showHistory: false,
    CdnImagesEnum,
    loadingPublishedFiles: false,
    file: '',
    dragging: false,
    showDialog: true,
    options: {
      width: '70%',
      zIndex: 200
    },
    publishedFilesData: [],
    header: [
      {
        text: 'File Name', value: 'fileName', sortable: false
      },
      {
        text: 'Customer', value: 'customer', sortable: false
      },
      { text: 'Mode', value: 'transportMode', sortable: false },
      {
        text: 'Equipment Type', value: 'equipment', sortable: false
      },
      { text: 'Country', value: 'country', sortable: false },
      { text: 'Published Date', value: 'publishDateTime', sortable: false },
      { text: 'Upload Date Time', value: 'createdDateTime', sortable: false },
      {
        text: 'Uploaded By', value: 'createdBy', sortable: false
      },
      { text: 'Status', value: 'status', sortable: false },
      { text: 'Actions', value: 'actions', sortable: false }
    ],
    search: '',
    lodash: _,
  };
}

function refreshModal() {
  GoogleAnalyticsService.event(Vue, 'Accessorials-Bulk-Upload', 'refreshModal', 'refresh-Modal');
  this.$refs.uploadDialogFilters.resetComponent();
  Object.assign(this.$data, this.initialState());
}

function downloadFuelScalesFile(currentRow) {
  const fuelScales = currentRow.fuelScales.map((fuelScale) => ({
    customerId: _.get(currentRow, 'customer.id'),
    transportMode: currentRow.transportMode,
    minDoeRate: fuelScale.minDoeRate,
    maxDoeRate: fuelScale.maxDoeRate,
    rateQualifier: fuelScale.rateQualifier,
    rateValue: fuelScale.rateValue,
  }));
  const workBook = XLSX.utils.book_new();
  const workSheet = XLSX.utils.json_to_sheet(fuelScales);
  XLSX.utils.book_append_sheet(workBook, workSheet, 'Sheet 1');
  XLSX.writeFile(workBook, currentRow.fileName);
}

export default {
  components: {
    uploadDialogFilters,
    HgConfirmActionModal
  },
  name: 'UploadDialog',
  filters: {
    formatDate(value) {
      if (!value || !value.trim()) return '-';
      return timeZoneService.cstDateTime(value, null, 'MM/DD/YYYY');
    },
    formatDateTime(value) {
      if (!value || !value.trim()) return '-';
      return timeZoneService.cstDateTime(value, null, 'MM/DD/YYYY HH:mm');
    }
  },
  data() {
    return this.initialState();
  },
  props: {
    multiple: {
      type: Boolean,
      default: false
    },
    fileData: {
      type: Array,
      default: () => []
    },
    customerId: {
      type: String
    },
    customerData: {
      type: Object
    }
  },
  computed: {
    allFiltersSelected() {
      const currentAFSFilters = this.$store.getters['customerAccessorialsUploadDialogFiltersStore/getFilters'];
      return currentAFSFilters.country.length
        && currentAFSFilters.publishDateTime.length
        && currentAFSFilters.transportMode.length
        && currentAFSFilters.equipmentType.length;
    },
    // to check if "publishDateTime" is in the future
    isFuture() {
      return (dateTime) => {
        const centralTimeNow = moment().tz('America/Chicago');
        const publishDateTime = moment(dateTime);
        return publishDateTime.isAfter(centralTimeNow);
      };
    },
  },
  methods: {
    getColor,
    closeDialog,
    removeFile,
    submit,
    downloadTemplate,
    createFile,
    onChange,
    getPublishedFilesByFilter,
    getPublishedFilesData,
    getIcon,
    openFileHandler,
    uploadData,
    getAllSelectedFilters,
    initialState,
    refreshModal,
    downloadFuelScalesFile,
    validateFileData,
  }
};
