<template>
  <div class="modal-wrapper">
    <v-dialog
      v-model="showDialog"
      :max-width="options.width"
      :style="{ zIndex: options.zIndex }"
      @keydown.esc="closeDialog"
      @click:outside="closeDialog"
    >
      <v-card>
        <v-card-title class="modal-header"
          >{{ customerData ? `Upload Customer Fuel Scales for ${customerData.name} ${customerData.id}` : 'Upload Customer Fuel Scales' }}
          <v-spacer></v-spacer>
          <v-icon @click="closeDialog()">mdi-close</v-icon>
        </v-card-title>
        <v-divider class="my-1 primary_border"></v-divider>
        <v-card-text>
          <v-container fluid fill-height grid-list-md>
            <v-row>
              <v-spacer> <label class="sub-details-header"> Fill the form and upload the file </label></v-spacer>
              <v-btn @click="refreshModal"
              text small color="secondary" class="font-weight-bold text-capitalize" plain>
                <v-icon right style="margin-right: auto;">mdi-refresh</v-icon>
                Refresh
              </v-btn>
              <v-btn
              @click="showHistory = !showHistory;getPublishedFilesByFilter()"
                text
                small
                color="secondary"
                class="font-weight-bold text-capitalize"
                plain
              >
                <v-icon right style="margin-right: auto;">mdi-history</v-icon>
                View History
              </v-btn>
              <v-btn
                text
                small
                color="secondary"
                class="font-weight-bold text-capitalize"
                plain
                @click="downloadTemplate"
              >
                <v-icon right style="margin-right: auto;">mdi-file-download</v-icon>
                Download Template
              </v-btn>
            </v-row>
            <v-row>
              <upload-dialog-filters ref="uploadDialogFilters" :customerData="customerData" @filters="getPublishedFilesByFilter($event)">
              </upload-dialog-filters>
            </v-row>
            <v-row v-if="!file" style="justify-content: center">
              <div >
                <HgLibBtn
                  :disabled="!allFiltersSelected"
                  title="Select File"
                  type="primary"
                  class="confirm-btn"
                  @click.native="openFileHandler"
                >
                </HgLibBtn>
              </div>
            </v-row>
            <v-row v-if="!file" style="justify-content: center">
              <div class="or-text"> or </div>
            </v-row>
            <v-row class="justify-center inline-block">
              <div v-if="!file">
                <div
                class="dropZone"
                  :class="{ 'dropZone-over': allFiltersSelected, 'disable-events': !allFiltersSelected }"
                  @dragenter="dragging = true"
                  @dragleave="dragging = false"
                >
                  <div @click.stop.prevent class="dropZone-info" :disabled="!allFiltersSelected" @drag="onChange">
                    <span class="fa fa-cloud-upload dropZone-title"></span>
                    <span class="dropZone-title">Drag and drop file here</span>
                  </div>
                  <input type="file"
                  ref="uploader"
                  @change="onChange"
                  accept=".xlsx, .xls, .csv" />
                </div>
              </div>
              <div v-else class="dropZone-uploaded">
                <div class="dropZone-uploaded-info">
                  <span class="dropZone-title" style="color: green !important;"
                    >{{ file.name }} </span
                  >
                  <v-btn plain @click="removeFile" class="re-upload-text">Re-upload</v-btn>
                </div>
              </div>
            </v-row>
            <v-row v-if="showHistory">
                <v-data-table
                  fixed-header
                  hide-default-footer
                  :loading="loadingPublishedFiles"
                  :headers="header"
                  :items="publishedFilesData"
                  class="hg-table elevation-1"
                  id="upload-dialog-grid"
                >
                  <template v-slot:item="{ item }">
                    <tr>
                      <td>
                        <v-skeleton-loader
                          v-if="loadingPublishedFiles"
                          class="py-1"
                          type="text"
                          width="75"
                        />
                        <label
                          v-if="!loadingPublishedFiles"
                          class="customer-details regular-font"
                          :id="`upload-dialog-${item.fileName}`"
                          >{{ item.fileName }}</label
                        >
                      </td>
                      <td>
                        <v-skeleton-loader
                          v-if="loadingPublishedFiles"
                          class="py-1"
                          type="text"
                          width="75"
                        />
                        <label
                          v-if="!loadingPublishedFiles"
                          class="customer-details regular-font"
                          :id="`upload-dialog-${item.customer.id}`"
                          >{{ item.customer.id ? `${item.customer.name ? item.customer.name + ', ' : ''} ${item.customer.id}` : '' }}</label
                        >
                      </td>
                      <!-- MODE COLUMN -->
                      <td>
                        <v-skeleton-loader
                          v-if="loadingPublishedFiles"
                          class="py-1"
                          type="text"
                          width="75"
                        />
                        <label
                          v-if="!loadingPublishedFiles"
                          class="customer-details regular-font"
                          :id="`upload-dialog-${item.transportMode}`"
                          >{{ item.transportMode }}</label
                        >
                      </td>

                      <td>
                        <v-skeleton-loader
                          v-if="loadingPublishedFiles"
                          class="py-1"
                          type="text"
                          width="75"
                        />
                        <label
                          v-if="!loadingPublishedFiles"
                          class="customer-details regular-font"
                          :id="`upload-dialog-${item.equipment.equipmentType}`"
                          >{{ item.equipment.equipmentType }} {{item.equipment.length.amount}}</label
                        >
                      </td>
                      <td>
                        <v-skeleton-loader
                          v-if="loadingPublishedFiles"
                          class="py-1"
                          type="text"
                          width="75"
                        />
                        <label
                          v-if="!loadingPublishedFiles"
                          class="customer-details regular-font"
                          :id="`upload-dialog-${item.country}`"
                          >{{ item.country }}</label
                        >
                      </td>
                      <!-- LAST UPDATE COLUMN -->
                      <td>
                        <v-skeleton-loader
                          v-if="loadingPublishedFiles"
                          class="py-1"
                          type="text"
                          width="75"
                        />
                        <label
                          v-if="!loadingPublishedFiles"
                          class="customer-details regular-font"
                          :id="`cust-publish-date-${lodash.get(item, 'publishDateTime.dateTime')}`"
                          >{{ lodash.get(item, 'publishDateTime.dateTime') | formatDate }}</label
                        >
                      </td>
                      <td>
                        <v-skeleton-loader
                          v-if="loadingPublishedFiles"
                          class="py-1"
                          type="text"
                          width="75"
                        />
                        <label
                          v-if="!loadingPublishedFiles"
                          class="customer-details regular-font"
                          :id="`cust-publish-date-${item.createdDateTime}`"
                          >{{ item.createdDateTime | formatDateTime }}</label
                        >
                      </td>
                      <td>
                        <v-skeleton-loader
                          v-if="loadingPublishedFiles"
                          class="py-1"
                          type="text"
                          width="75"
                        />
                        <label
                          v-if="!loadingPublishedFiles"
                          class="customer-details regular-font"
                          :id="`cust-created-by-${item.createdBy}`"
                          >{{ item.createdBy }}</label
                        >
                      </td>
                      <td>
                        <v-skeleton-loader
                          v-if="loadingPublishedFiles"
                          class="py-1"
                          type="text"
                          width="75"
                        />
                        <label
                          v-if="!loadingPublishedFiles"
                          class="customer-details regular-font"
                          :id="`upload-dialog-${item.status}`"
                          >{{ (item.status === 'INACTIVE') && isFuture(item.publishDateTime.dateTime) ? "FUTURE" : item.status }}</label
                        >
                      </td>
                      <!-- ACTIONS COLUMN -->
                      <td>
                        <template>
                          <v-menu
                            :close-on-content-click="false"
                            offset-y
                            :transition="false"
                          >
                          <template #activator="{ on, attrs }">
                            <v-btn icon v-bind="attrs" v-on="on">
                              <v-icon>mdi-dots-horizontal</v-icon>
                            </v-btn>
                          </template>

                          <v-card>
                            <v-list>
                              <v-list-item ripple @click="downloadFuelScalesFile(item)">
                                <v-list-item-content>
                                  <v-list-item-title>Download</v-list-item-title>
                                </v-list-item-content>
                              </v-list-item>
                            </v-list>
                          </v-card>
                          </v-menu>
                        </template>
                         <!-- <template v-slot:activator="{ on, attrs }">
                            <v-btn
                              class="btn-actions"
                              text
                              dense
                              v-bind="attrs"
                              v-on="on"
                            >
                              <img
                                class="edit-action mt-n2 mr-4"
                                :src="getIcon(CdnImagesEnum.edit_icon)"
                              />
                            </v-btn>
                          </template>
                          <div class="actions">
                            <label class="actionItems"  @click="downloadFuelScalesFile(item)">Download</label>
                          </div> -->
                      </td>
                    </tr>
                  </template>
                </v-data-table>
            </v-row>
          </v-container>
        </v-card-text>
        <v-card-actions class="actions">
          <v-spacer></v-spacer>
          <HgLibBtn
            title="Cancel"
            type="secondary"
            :disabled="false"
            class="cancel-btn ml-3"
            @click.native="closeDialog"
          >
          </HgLibBtn>
          <HgLibBtn
            :disabled="!(file && allFiltersSelected)"
            title="Upload"
            type="primary"
            class="confirm-btn ml-3"
            @click.native="uploadData"
          >
          </HgLibBtn>
          <HgConfirmActionModal ref="confirm" />
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script src="./upload-dialog.js" />
<style src="./upload-dialog.sass" lang="sass" scoped />
