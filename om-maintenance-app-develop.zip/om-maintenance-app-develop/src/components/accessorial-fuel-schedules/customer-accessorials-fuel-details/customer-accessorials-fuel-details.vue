<template>
  <v-card class="wrapper">
    <v-card-title class="form-header">
      <v-row justify="space-between">
        <v-col cols="7">
          <span>
            {{ lodash.get(selectedCustomerDetails, 'customer.name', '') }}
          </span>
          <span v-if="selectedCustomerDetails.customer &&
            selectedCustomerDetails.customer.name &&
            selectedCustomerDetails.customer.id
            ">
            {{ '-' }}
          </span>
          <span>
            {{ lodash.get(selectedCustomerDetails, 'customer.id', '') }}
          </span>
        </v-col>
        <v-col cols="4" class="expansion clickable word-break justify-end" v-on:click="showDialogToggle = true"
          v-oc-entitlements="[
            [accessorialsEntitlements.ACCS_CREATE, accessorialsEntitlements.ACCS_EDIT],
            token
          ]" v-if="selectedCustomerDetails && selectedCustomerDetails.chargeCode.code === '405' && !selectedCustomerDetails.isUsingHubDefault && selectedCustomerDetails.status !== 'EXPIRED'">Automated Fuel
          Schedule
        </v-col>
        <automatedFuelScheduleModal v-if="showDialogToggle" @afsClosed="closeAutomatedFuelSchedule()"
          :selectedCustomerDetails="selectedCustomerDetails" />
        <v-card-actions>
          <v-icon @click="$emit('close')" id="modal-close">mdi-close</v-icon>
        </v-card-actions>
      </v-row>
    </v-card-title>
    <v-divider class="my-1 primary_border"></v-divider>
    <v-card-text>
      <v-row>
        <!-- CHARGE CODE -->
        <v-col cols="9" v-if="selectedCustomerDetails && selectedCustomerDetails.chargeCode.code === '405'">
          <h2 class="form-sub-header">CHARGE CODE</h2>
          <span class="form-detail">
            {{
              `${lodash.get(selectedCustomerDetails, 'chargeCode.code')}, ${lodash.get(
                selectedCustomerDetails,
                'chargeCode.description'
              )}` || ''
            }}
          </span>
        </v-col>
        <!-- COUNTRY -->
        <v-col cols="3" v-if="selectedCustomerDetails && selectedCustomerDetails.chargeCode.code === '405'">
          <h2 class="form-sub-header">COUNTRY</h2>
          <span class="form-detail">{{ lodash.get(selectedCustomerDetails, 'country', '') }}</span>
        </v-col>
        <!-- CHARGE CODE -->
        <v-col cols="12" v-else>
          <h2 class="form-sub-header">CHARGE CODE</h2>
          <span class="form-detail">
            {{
              `${lodash.get(selectedCustomerDetails, 'chargeCode.code')}, ${lodash.get(
                selectedCustomerDetails,
                'chargeCode.description'
              )}` || ''
            }}
          </span>
        </v-col>
        <!-- MODE -->
        <v-col cols="3">
          <h2 class="form-sub-header">MODE</h2>
          <span class="form-detail">{{
            lodash.get(selectedCustomerDetails, 'transportMode', '')
          }}</span>
        </v-col>
        <!-- EQUIPMENT TYPE -->
        <v-col cols="3">
          <h2 class="form-sub-header">EQUIPMENT TYPE</h2>
          <span class="form-detail">
            {{ lodash.get(selectedCustomerDetails, 'equipment.equipmentType')
            }}{{ lodash.get(selectedCustomerDetails, 'equipment.length.amount') }}
          </span>
        </v-col>
        <!-- EFFECTIVE DATE -->
        <v-col cols="3">
          <h2 class="form-sub-header">EFFECTIVE DATE</h2>
          <span class="form-detail">
            {{ lodash.get(selectedCustomerDetails, 'effectiveDateTime.dateTime') | formatDate }}
          </span>
        </v-col>
        <!-- EXPIRATION DATE -->
        <v-col cols="3">
          <h2 class="form-sub-header">EXPIRATION DATE</h2>
          <span class="form-detail">
            {{ lodash.get(selectedCustomerDetails, 'expiredDateTime.dateTime') | formatDate }}
          </span>
        </v-col>
        <!-- RATE QUALIFIER -->
        <v-col cols="3">
          <h2 class="form-sub-header">RATE QUALIFIER</h2>
          <span class="form-detail">
            {{ rateQualifierLookUp(lodash.get(selectedCustomerDetails, 'rateQualifier')) }}
          </span>
        </v-col>
        <!-- RATE TYPE -->
        <v-col cols="3" v-if="selectedCustomerDetails">
          <h2 class="form-sub-header">RATE TYPE</h2>
          <span class="form-detail">
            {{ lodash.get(selectedCustomerDetails, 'rateType', '') === 'ES' ? 'ESCALATING' : 'NON-ESCALATING' }}
          </span>
        </v-col>
        <!-- LAYOVER TYPE -->
        <v-col cols="3" v-if="lodash.get(selectedCustomerDetails, 'chargeCode.code') !== '405'">
          <h2 class="form-sub-header">LAYOVER TYPE</h2>
          <span class="form-detail">
            {{ lodash.get(selectedCustomerDetails, 'layoverType') }}
          </span>
        </v-col>
        <!-- HUB DEFAULT NAME -->
        <v-col cols="3">
          <h2 class="form-sub-header">HUB DEFAULT NAME</h2>
          <span class="form-detail">
            {{ lodash.get(selectedCustomerDetails, 'hubDefault.name', '') }}
          </span>
        </v-col>
         <!-- RATE AMOUNT -->
         <v-col cols="4" v-if="selectedCustomerDetails && selectedCustomerDetails.chargeCode.code === '405'">
          <h2 class="form-sub-header">($) RATE AMOUNT</h2>
          <span class="form-detail">
            {{ lodash.get(selectedCustomerDetails, 'rates[0].rateValue') }}
          </span>
        </v-col>
        <!-- RATE VALUE Table for non-405 -->
        <v-col cols="12" class="pt-0" v-if="selectedCustomerDetails && selectedCustomerDetails.chargeCode.code !== '405'">
          <v-data-table disable-sort dense hide-default-footer :headers="customerAccessorialsRateDetailsHeaderEnum"
            :items="selectedCustomerDetails.rates" id="cust-accessorial-details-grid" width="100%">
            <template v-slot:item="{ item }">
              <tr>
                <td>
                  <div class="customer-details" :id="`cust-number-${item.rateValue}`">
                    {{ item.rateValue }}
                  </div>
                </td>
                <td>
                  <div class="customer-details" :id="`cust-number-${item.rateLimit}`">
                    {{ item.rateLimit || item.rateLimit === 0 ? item.rateLimit : 'Unlimited' }}
                  </div>
                </td>
              </tr>
            </template>
          </v-data-table>
        </v-col>
      </v-row>
    </v-card-text>
    <v-divider class="my-1 primary_border"></v-divider>
    <v-card-text v-if="selectedCustomerDetails && selectedCustomerDetails.chargeCode.code === '405'">
      <v-row>
        <!-- FUEL DETAILS -->
        <v-col cols="12">
          <div class="form-header">FUEL DETAILS</div>
        </v-col>
        <!-- DOE REGION -->
        <v-col cols="6">
          <h2 class="form-sub-header">DOE REGION</h2>
          <span class="form-detail">{{ lodash.get(fuelScheduleData, 'doeRegion', '') }}</span>
        </v-col>
        <!-- SCHEDULE FREQUENCY -->
        <v-col cols="6">
          <h2 class="form-sub-header">SCHEDULE FREQUENCY</h2>
          <span class="form-detail">{{ scheduleFrequency }}</span>
        </v-col>
      </v-row>
    </v-card-text>
    <div v-if="selectedCustomerDetails && selectedCustomerDetails.chargeCode.code !== '405'">
      <v-card-text>
        <v-row>
          <!-- SERVICE TYPE -->
          <v-col cols="3">
            <h2 class="form-sub-header">SERVICE TYPE</h2>
            <span class="form-detail">
              {{
                lodash.get(serviceTypesList, lodash.get(selectedCustomerDetails, 'serviceType'), '')
              }}
            </span>
          </v-col>
          <!-- RAIL SCAC -->
          <v-col cols="3">
            <h2 class="form-sub-header">RAIL SCAC</h2>
            <span class="form-detail">
              {{ lodash.get(selectedCustomerDetails, 'railScac', '') }}
            </span>
          </v-col>
          <!-- RAMP SCAC -->
          <v-col cols="3">
            <h2 class="form-sub-header">RAMP SCAC</h2>
            <span class="form-detail">
              {{ lodash.get(selectedCustomerDetails, 'rampScac', '') }}
            </span>
          </v-col>
          <!-- BUNDLE CODE -->
          <v-col cols="3">
            <h2 class="form-sub-header">BUNDLE CODE</h2>
            <span class="form-detail">
              {{ lodash.get(selectedCustomerDetails, 'bundleCode.description', '') }}
            </span>
          </v-col>
          <!-- SPECIAL TERMS -->
          <v-col cols="3">
            <h2 class="form-sub-header">SPECIAL TERMS</h2>
            <span class="form-detail">
              {{ lodash.get(selectedCustomerDetails, 'specialTerms', '') }}
            </span>
          </v-col>
          <!-- VENDOR/CARRIER -->
          <v-col cols="6">
            <h2 class="form-sub-header">VENDOR/CARRIER</h2>
            <div v-if="(selectedCustomerDetails.vendor && selectedCustomerDetails.vendor.name) ||
              (selectedCustomerDetails.vendor && selectedCustomerDetails.vendor.id)
              " class="form-detail">
              {{
                `${lodash.get(selectedCustomerDetails, 'vendor.name', '')},
                            ${lodash.get(selectedCustomerDetails, 'vendor.id', '')}`
              }}
            </div>
            <div v-else class="form-detail"></div>
          </v-col>
          <!-- NOTES -->
          <v-col cols="12">
            <h2 class="form-sub-header">NOTES</h2>
            <span class="form-detail">{{ lodash.get(selectedCustomerDetails, 'notes', '') }}</span>
          </v-col>
        </v-row>
      </v-card-text>
      <v-divider class="my-1 primary_border"></v-divider>
      <v-card-text>
        <v-row>
          <!-- LOCATION(S) -->
          <v-col cols="12">
            <div class="form-header">LOCATION(S)</div>
          </v-col>
          <v-col cols="12">
            <v-data-table disable-sort dense hide-default-footer :headers="accessorialsLocationHeader"
              :items="selectedCustomerDetails.locations" id="cust-accessorial-location-grid" width="100%">
              <template v-slot:item="{ item }">
                <tr :key="item.LocationID">
                  <td>
                    <label>{{
                      lodash.get(item, 'StopType', '') === 'Destination'
                      ? 'DES'
                      : lodash.get(item, 'StopType', '') === 'Origin'
                        ? 'ORG'
                        : ''
                    }}</label>
                  </td>
                  <td>
                    <label>{{ lodash.get(item, 'Address1', '') }}</label>
                  </td>
                  <td>
                    <label>{{ lodash.get(item, 'City', '') }}</label>
                  </td>
                  <td>
                    <label>{{ lodash.get(item, 'State', '') }}</label>
                  </td>
                  <td>
                    <label>{{ lodash.get(item, 'PostalCode', '') }}</label>
                  </td>
                  <td>
                    <label>{{ lodash.get(item, 'CountryCode', '') }}</label>
                  </td>
                </tr>
              </template>
            </v-data-table>
          </v-col>
        </v-row>
      </v-card-text>
      <v-divider class="my-1 primary_border"></v-divider>
      <v-card-text>
        <v-row>
          <!-- MINIMUM RATE -->
          <v-col md="3">
            <h2 class="form-sub-header">MINIMUM RATE</h2>
            <span class="form-detail">
              {{ lodash.get(selectedCustomerDetails, 'minimumRate', '') }}
            </span>
          </v-col>
          <!-- MAXIMUM RATE -->
          <v-col md="3">
            <h2 class="form-sub-header">MAXIMUM RATE</h2>
            <span class="form-detail">
              {{ lodash.get(selectedCustomerDetails, 'maximumRate', '') }}
            </span>
          </v-col>
          <!-- START EVENT -->
          <v-col md="3">
            <h2 class="form-sub-header">START EVENT</h2>
            <span class="form-detail">
              {{ lodash.get(selectedCustomerDetails, 'startEvent', '') }}
            </span>
          </v-col>
          <!-- END EVENT -->
          <v-col md="3">
            <h2 class="form-sub-header">END EVENT</h2>
            <span class="form-detail">
              {{ lodash.get(selectedCustomerDetails, 'endEvent', '') }}
            </span>
          </v-col>
          <!-- HOLIDAYS FREE -->
          <v-col md="3">
            <h2 class="form-sub-header">HOLIDAYS FREE</h2>
            <span class="form-detail">
              {{ lodash.get(selectedCustomerDetails, 'freeHolidays') ? 'Yes' : 'No' || '' }}
            </span>
          </v-col>
          <!-- FREE TIME -->
          <v-col md="3">
            <h2 class="form-sub-header">FREE TIME</h2>
            <span class="form-detail">
              {{ selectedCustomerDetails.freeTime | convertToMinutes }}
            </span>
          </v-col>
          <!-- FREE DAYS -->
          <v-col md="3">
            <h2 class="form-sub-header">FREE DAYS</h2>
            <span class="form-detail">
              {{ lodash.get(selectedCustomerDetails, 'freeDays', '') }}
            </span>
          </v-col>
          <!-- FREE TIME CUTOFF -->
          <v-col md="3">
            <h2 class="form-sub-header">FREE TIME CUTOFF</h2>
            <span class="form-detail">
              {{ lodash.get(selectedCustomerDetails, 'freeCutOffTime', '') }}
            </span>
          </v-col>
          <!-- RELOADS -->
          <v-col md="3">
            <h2 class="form-sub-header">RELOADS</h2>
            <span class="form-detail">{{
              lodash.get(selectedCustomerDetails, 'reloads', '')
            }}</span>
          </v-col>
          <!-- FREE WEEKEND TYPE -->
          <v-col md="3">
            <h2 class="form-sub-header">FREE WEEKEND TYPE</h2>
            <span class="form-detail">
              {{ lodash.get(selectedCustomerDetails, 'freeWeekendType', '') }}
            </span>
          </v-col>
        </v-row>
      </v-card-text>
    </div>
    <v-divider class="my-1 primary_border"></v-divider>
    <v-card-text>
      <v-row>
        <!-- CHARGECODE ID -->
        <v-col cols="4">
          <h2 class="form-sub-header">CHARGECODE ID</h2>
          <span class="form-detail">{{ lodash.get(selectedCustomerDetails, '_id', '') }}</span>
        </v-col>
        <!-- LAST MODIFIED BY -->
        <v-col cols="4">
          <h2 class="form-sub-header">LAST MODIFIED BY</h2>
          <span class="form-detail">{{ lodash.get(selectedCustomerDetails, 'modifiedBy', '') }}</span>
        </v-col>
        <!-- LAST MODIFIED DATETIME -->
        <v-col cols="4">
          <h2 class="form-sub-header">LAST MODIFIED DATETIME</h2>
          <span class="form-detail">{{ lodash.get(selectedCustomerDetails, 'modifiedDateTime', '') | formatDateTime}}</span>
        </v-col>
        <!-- HUB DEFAULT ID -->
        <v-col cols="5">
          <h2 class="form-sub-header">HUB DEFAULT ID</h2>
          <span class="form-detail">
            {{ lodash.get(selectedCustomerDetails, 'hubDefault.id', '') }}
          </span>
        </v-col>
      </v-row>
    </v-card-text>
  </v-card>
</template>

<script src="./customer-accessorials-fuel-details.js"></script>
<style src="./customer-accessorials-fuel-details.sass" lang="sass" scoped></style>
