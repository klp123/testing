import _ from 'lodash';
import moment from 'moment';
import Vue from 'vue';
import { RequestErrorTypesEnum } from '@hubgroup/hg-vue-om-util-lib/src/enums';
import HgNotificationService from '@hubgroup/hg-vue-om-util-lib/src/services/notification/notifications.service';
import { GoogleAnalyticsService } from '@hubgroup/hg-om-shared-services';
import accessorialsEntitlements from '@hubgroup/hg-om-shared-services/src/enums/entitlements.enum';
import serviceTypesEnum from '@hubgroup/hg-vue-om-util-lib/src/enums/service-types.enum';
import commonService from '../../../services/common.service';
import automatedFuelScheduleModal from '../automated-fuel-schedule-modal-component/automated-fuel-schedule-modal.vue';
import customerAccessorialsRateDetailsHeader from '../../../enums/customer-details-rate-grid-headers.enum';
import timeZoneService from '../../../services/accessorial-fuel-schedules/time-zone.service';
import AutomatedFuelScheduleService from '../../../services/accessorial-fuel-schedules/automated-fuel-schedule.service';

moment.tz.setDefault('America/Chicago');

async function closeAutomatedFuelSchedule() {
  this.showDialogToggle = false;
  await this.fuelSchedule();
  GoogleAnalyticsService.event(Vue, 'Close dialog', 'Customer-Accessorials-Fuel', 'AFS dialog closes');
}

async function fetchRateQualifierLOV() {
  // initialize LOV for rateQualifier
  try {
    this.rateQualifierList = await commonService.getCommonLov('OM_ACCESSORIALS_RATE_QUALIFIER');
  } catch (error) {
    console.error('Error when fetching rate qualifier data', error);
  }
}

function rateQualifierLookUp(rateQualifier) {
  if (!rateQualifier) return '';
  for (let i = 0; i < this.rateQualifierList.length; i++) {
    if (this.rateQualifierList[i].value === rateQualifier) return this.rateQualifierList[i].displayValue;
  }
}

function getOrdinalNumber(number) {
  const lastDigit = _.last(String(number));
  const lastTwoDigits = _.slice(String(number), -2).join('');
  if (_.inRange(Number(lastTwoDigits), 11, 14)) {
    return `${number}th`;
  }

  switch (Number(lastDigit)) {
    case 1:
      return `${number}st`;
    case 2:
      return `${number}nd`;
    case 3:
      return `${number}rd`;
    default:
      return `${number}th`;
  }
}

async function fuelSchedule() {
  try {
    if (this.selectedCustomerDetails) {
      const identifier = _.get(this.selectedCustomerDetails, '_id', '');
      const res = await AutomatedFuelScheduleService.getFuelSchedule(identifier);
      GoogleAnalyticsService.event(
        Vue,
        'Fetch schedule',
        'Automated-Fuel-Schedule',
        'Fetched fuel schedule',
        { accessorials_fuel_customer: _.get(this.selectedCustomerDetails, 'customer.name', '') }
      );
      if (res && res.length) {
        const data = res[0];
        this.fuelScheduleData = data;
        const nxtRnDate = this.getOrdinalNumber(moment(data.nextRunDateTime.dateTime).date());
        const nxtRnDay = moment(data.nextRunDateTime.dateTime).format('dddd');
        if (data.interval.type === 'MONTH') {
          if (data.interval.amount === 1) {
            this.scheduleFrequency = `On the ${nxtRnDate} of every month`;
          } else if (data.interval.amount > 1) {
            this.scheduleFrequency = `On the ${nxtRnDate} of every ${data.interval.amount} months`;
          }
        } else if (data.interval.type === 'DAY') {
          if (data.interval.amount === 7) {
            this.scheduleFrequency = `Weekly on ${nxtRnDay}`;
          } else if (data.interval.amount === 14) {
            this.scheduleFrequency = `Bi-weekly on ${nxtRnDay}`;
          } else {
            this.scheduleFrequency = `On the ${nxtRnDay} of every ${(data.interval.amount / 7)} weeks`;
          }
        }
      }
    }
  } catch (error) {
    if (error.message && error.message !== RequestErrorTypesEnum.CANCEL_REQUEST) {
      HgNotificationService.errorMessage(`Could not fetch fuel schedule due to error: ${error}`);
    }
  }
}

export default {
  name: 'CustomerAccessorialsFuelDetails',
  components: {
    automatedFuelScheduleModal,
  },
  data: () => ({
    customerAccessorialsRateDetailsHeaderEnum: customerAccessorialsRateDetailsHeader.RATE_GRID_HEADER,
    accessorialsLocationHeader: customerAccessorialsRateDetailsHeader.LOCATION_HEADER,
    accessorialsEntitlements,
    token: localStorage.getItem('jwt'),
    serviceTypesList: serviceTypesEnum,
    rateQualifierList: [],
    loading: false,
    showDialogToggle: false,
    lodash: _,
    fuelScheduleData: {},
    scheduleFrequency: ''
  }),
  props: {
    selectedCustomerDetails: {
      type: Object,
      required: true
    }
  },
  methods: {
    closeAutomatedFuelSchedule,
    fetchRateQualifierLOV,
    rateQualifierLookUp,
    fuelSchedule,
    getOrdinalNumber
  },
  mounted() {
    this.fetchRateQualifierLOV();
    if (this.selectedCustomerDetails && this.selectedCustomerDetails.chargeCode.code === '405') {
      this.fuelSchedule();
    }
  },
  watch: {
    selectedCustomerDetails() {
      this.fuelScheduleData = {};
      this.scheduleFrequency = '';

      if (this.selectedCustomerDetails && this.selectedCustomerDetails.chargeCode.code === '405') {
        this.fuelSchedule();
      }
    }
  },
  filters: {
    formatDate(value) {
      if (!value || !value.trim()) return '-';
      return timeZoneService.cstDateTime(value, null, 'MM/DD/YYYY');
    },
    formatDateTime(value) {
      if (!value || !value.trim()) return '-';
      return timeZoneService.cstDateTime(value, null, 'MM/DD/YYYY HH:mm');
    },
    convertToMinutes(value) {
      if (!value) return '-';
      const duration = moment.duration(value, 'minutes').asMilliseconds();
      return moment.utc(duration).format('HH:mm');
    }
  }
};
