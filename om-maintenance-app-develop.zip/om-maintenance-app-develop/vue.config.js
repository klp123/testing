/* eslint-disable quote-props */
const path = require('path');
const CompressionPlugin = require("compression-webpack-plugin");

module.exports = {
  transpileDependencies: [
    'vuetify',
  ],
  chainWebpack: (config) => {
    config.externals(['vue', 'vue-router', 'vuetify', '@hubgroup/hg-vue-library', 'lodash', 'moment']);
  },
  filenameHashing: false,
  configureWebpack: {
    plugins: [
      new CompressionPlugin({
        filename: '[path].gz[query]',
        algorithm: 'gzip',
        test: /\.js$|\.css$|\.html$|\.eot?.+$|\.ttf?.+$|\.woff?.+$|\.svg?.+$/,
        threshold: 10240,
        minRatio: 0.8,
      }),
    ],
    resolve: {
      symlinks: false,
      alias: {
        'vue$': path.resolve(__dirname, 'node_modules/vue/dist/vue.runtime.esm.js'),
        '^vuetify': path.resolve(__dirname, 'node_modules/vuetify'),
      },
    },
  },
};
