# om-maintenance
## How to setup single-spa

1. run `vue create om-maintenance` with settings to create a vue app
2. run `vue add single-spa` to init single spa dependancies
3. after single-spa dependancies have be injected create a file called `set-public-path.js` in the src folder. Add the following code
```
import { setPublicPath } from 'systemjs-webpack-interop';

setPublicPath('@order-management/your-app-name');
```
add the following import to the main.js
```
import './set-public-path';
```

4. update your package.json name with the same as what you set your public path as `@order-management/your-app-name` and add "systemjs-webpack-interop" to your dependancy


## How to import single-spa app to runner

1.
